from pathlib import Path

from mika.app import MikaApp
from mika.cli import _parser, main
from mika.config import Settings
from mika.embeddings import Embedder


def _config(tmp_path: Path) -> Settings:
    return Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
    ).resolve()


def test_parser_builds_primary_commands() -> None:
    parser = _parser()
    assert parser.parse_args(["search", "evidence"]).command == "search"
    assert parser.parse_args(["tools", "--role", "viewer"]).role == "viewer"
    assert parser.parse_args(["graph-path", "edges.csv", "A", "B"]).max_depth == 6


def test_doctor_search_and_tool_listing(tmp_path: Path, monkeypatch, capsys) -> None:
    config = _config(tmp_path)
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"

    with MikaApp(config, embedder=embedder) as seed:
        (tmp_path / "evidence.txt").write_text(
            "CASE-900 queue latency exceeded the review threshold.",
            encoding="utf-8",
        )
        seed.evidence.ingest_path("evidence.txt")

    import mika.cli as cli_module

    def factory() -> MikaApp:
        return MikaApp(config, embedder=embedder)

    monkeypatch.setattr(cli_module, "MikaApp", factory)

    assert main(["doctor"]) == 0
    assert main(["search", "CASE-900", "--k", "3"]) == 0
    assert main(["tools", "--role", "viewer"]) == 0
    output = capsys.readouterr().out
    assert '"audit_chain_valid": true' in output
    assert '"citation": "S1:C1"' in output
    assert '"entity.resolve"' in output


def test_evaluate_command_writes_report(tmp_path: Path) -> None:
    output = tmp_path / "evaluation.json"
    assert main(["evaluate", "--output", str(output), "--repeats", "2"]) == 0
    assert output.exists()
