from __future__ import annotations

from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from threading import RLock
from typing import Any

from .security import redact_text

_ZERO_HASH = "0" * 64


def _clean(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): _clean(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_clean(item) for item in value]
    if isinstance(value, str):
        return redact_text(value)
    return value


def _canonical(value: dict[str, Any]) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()


class AuditLog:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = RLock()
        self._cached_signature: tuple[int, int] | None = None
        self._cached_hash = _ZERO_HASH

    def _signature(self) -> tuple[int, int] | None:
        if not self.path.exists():
            return None
        stat = self.path.stat()
        return stat.st_size, stat.st_mtime_ns

    def _last_hash(self) -> str:
        signature = self._signature()
        if signature is None or signature[0] == 0:
            self._cached_signature = signature
            self._cached_hash = _ZERO_HASH
            return self._cached_hash
        if signature == self._cached_signature:
            return self._cached_hash

        last = ""
        with self.path.open("r", encoding="utf-8") as handle:
            for line in handle:
                if line.strip():
                    last = line
        self._cached_hash = str(json.loads(last)["hash"]) if last else _ZERO_HASH
        self._cached_signature = signature
        return self._cached_hash

    def record(self, event: str, payload: dict[str, Any]) -> dict[str, Any]:
        with self._lock:
            record = {
                "timestamp": datetime.now(timezone.utc).isoformat(),
                "event": event,
                "payload": _clean(payload),
                "prev_hash": self._last_hash(),
            }
            record["hash"] = hashlib.sha256(_canonical(record)).hexdigest()
            line = json.dumps(record, ensure_ascii=False, sort_keys=True) + "\n"
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(line)
                handle.flush()
            self._cached_hash = str(record["hash"])
            self._cached_signature = self._signature()
            return record

    def verify(self) -> tuple[bool, int, str | None]:
        with self._lock:
            previous = _ZERO_HASH
            count = 0
            if not self.path.exists():
                return True, 0, None
            with self.path.open("r", encoding="utf-8") as handle:
                for count, line in enumerate(handle, start=1):
                    try:
                        record = json.loads(line)
                        supplied = record.pop("hash")
                        if record.get("prev_hash") != previous:
                            return False, count, "previous hash mismatch"
                        expected = hashlib.sha256(_canonical(record)).hexdigest()
                        if supplied != expected:
                            return False, count, "record hash mismatch"
                        previous = supplied
                    except (json.JSONDecodeError, KeyError, TypeError, ValueError) as exc:
                        return False, count, f"invalid record: {type(exc).__name__}"
            return True, count, None
