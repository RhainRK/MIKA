from __future__ import annotations

from dataclasses import dataclass
import math
import re
import sqlite3
from typing import Sequence

import numpy as np

from .embeddings import Embedder
from .storage import Database

_IDENTIFIER = re.compile(r"\b[A-Za-z][A-Za-z0-9_]*-\d{2,}\b")
_RRF_K = 60
_CANDIDATE_LIMIT = 100


@dataclass(frozen=True, slots=True)
class SearchHit:
    chunk_id: int
    source_id: int
    source_name: str
    locator: str
    content: str
    score: float
    semantic_score: float
    lexical_rank: int | None
    source_sha256: str
    injection_score: float

    def citation(self) -> str:
        return f"S{self.source_id}:C{self.chunk_id}"


def _fts_query(text: str) -> str:
    tokens = [
        token.replace("'", "")
        for token in re.findall(r"[\w']+", text.casefold())
        if len(token) > 1
    ]
    return " OR ".join(f'"{token}"' for token in tokens[:20])


def _top_indices(scores: np.ndarray, limit: int) -> np.ndarray:
    if len(scores) <= limit:
        return np.argsort(scores)[::-1]
    selected = np.argpartition(scores, -limit)[-limit:]
    return selected[np.argsort(scores[selected])[::-1]]


class HybridRetriever:
    def __init__(self, db: Database, embedder: Embedder) -> None:
        self.db = db
        self.embedder = embedder

    def _lexical_ranks(self, query: str, include_quarantined: bool) -> dict[int, int]:
        if not self.db.fts_enabled:
            return {}
        expression = _fts_query(query)
        if not expression:
            return {}
        try:
            rows = self.db.conn.execute(
                """
                SELECT CAST(f.chunk_id AS INTEGER) AS chunk_id, bm25(chunks_fts) AS rank
                FROM chunks_fts f
                JOIN chunks c ON c.id=CAST(f.chunk_id AS INTEGER)
                JOIN sources s ON s.id=c.source_id
                WHERE chunks_fts MATCH ? AND (? OR s.quarantined=0)
                ORDER BY rank LIMIT ?
                """,
                (expression, int(include_quarantined), _CANDIDATE_LIMIT),
            ).fetchall()
        except sqlite3.OperationalError:
            return {}
        return {int(row["chunk_id"]): index + 1 for index, row in enumerate(rows)}

    def _semantic_ranks(
        self,
        rows: Sequence[sqlite3.Row],
        query: str,
    ) -> tuple[dict[int, int], dict[int, float]]:
        query_vector = self.embedder.encode(query).astype(np.float32, copy=False)
        identity = self.embedder.identity
        ids: list[int] = []
        vectors: list[np.ndarray] = []
        updates: list[tuple[bytes, str, int]] = []
        missing = [
            row
            for row in rows
            if not row["embedding"] or row["embedding_model"] != identity
        ]
        generated = iter(self.embedder.encode_many(row["content"] for row in missing))

        for row in rows:
            if row["embedding"] and row["embedding_model"] == identity:
                vector = np.frombuffer(row["embedding"], dtype=np.float32)
            else:
                vector = next(generated).astype(np.float32, copy=False)
                updates.append((vector.tobytes(), identity, int(row["id"])))
            if vector.shape == query_vector.shape:
                ids.append(int(row["id"]))
                vectors.append(vector)

        if updates:
            with self.db.conn:
                self.db.conn.executemany(
                    "UPDATE chunks SET embedding=?,embedding_model=? WHERE id=?",
                    updates,
                )
        if not vectors:
            return {}, {}

        scores = np.vstack(vectors) @ query_vector
        top = _top_indices(scores, _CANDIDATE_LIMIT)
        ranks: dict[int, int] = {}
        score_by_id: dict[int, float] = {}
        for rank, index in enumerate(top, start=1):
            chunk_id = ids[int(index)]
            ranks[chunk_id] = rank
            score_by_id[chunk_id] = float(scores[int(index)])
        return ranks, score_by_id

    def search(self, query: str, k: int = 6, *, include_quarantined: bool = False) -> list[SearchHit]:
        query = query.strip()
        if not query or k <= 0:
            return []

        lexical_ranks = self._lexical_ranks(query, include_quarantined)
        rows = self.db.conn.execute(
            """
            SELECT c.id,c.source_id,c.content,c.locator,c.embedding,c.embedding_model,
                   s.name AS source_name,s.sha256 AS source_sha256,s.injection_score
            FROM chunks c
            JOIN sources s ON s.id=c.source_id
            WHERE (? OR s.quarantined=0)
            """,
            (int(include_quarantined),),
        ).fetchall()
        if not rows:
            return []

        row_by_id = {int(row["id"]): row for row in rows}
        semantic_ranks, semantic_scores = self._semantic_ranks(rows, query)
        candidates = set(semantic_ranks) | set(lexical_ranks)
        identifiers = {token.casefold() for token in _IDENTIFIER.findall(query)}

        ranked: list[tuple[float, int]] = []
        for chunk_id in candidates:
            semantic_rank = semantic_ranks.get(chunk_id)
            lexical_rank = lexical_ranks.get(chunk_id)
            score = (
                (1.0 / (_RRF_K + semantic_rank) if semantic_rank else 0.0)
                + (1.25 / (_RRF_K + lexical_rank) if lexical_rank else 0.0)
                + max(0.0, semantic_scores.get(chunk_id, -1.0)) * 0.001
            )
            if identifiers:
                content = str(row_by_id[chunk_id]["content"]).casefold()
                score += 0.05 * sum(identifier in content for identifier in identifiers)
            ranked.append((score, chunk_id))

        ranked.sort(reverse=True)
        return [
            SearchHit(
                chunk_id=chunk_id,
                source_id=int(row_by_id[chunk_id]["source_id"]),
                source_name=row_by_id[chunk_id]["source_name"],
                locator=row_by_id[chunk_id]["locator"],
                content=row_by_id[chunk_id]["content"],
                score=score,
                semantic_score=semantic_scores.get(chunk_id, math.nan),
                lexical_rank=lexical_ranks.get(chunk_id),
                source_sha256=row_by_id[chunk_id]["source_sha256"],
                injection_score=float(row_by_id[chunk_id]["injection_score"]),
            )
            for score, chunk_id in ranked[:k]
        ]
