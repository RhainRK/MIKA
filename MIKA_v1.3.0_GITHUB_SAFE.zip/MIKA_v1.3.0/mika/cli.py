from __future__ import annotations

import argparse
from dataclasses import asdict
import json
from pathlib import Path
import sys
from typing import Any

from . import __version__
from .analyst import AnalystEngine
from .app import MikaApp
from .connectors import fetch_uk_sanctions_csv
from .evaluation import run_suite
from .llm import OllamaClient
from .policy import Policy
from .tools.base import ToolCall
from .tools.builtins import register_builtin_tools
from .tools.registry import ToolRegistry


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False, default=str))


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="mika", description="MIKA - Model Integrity & Knowledge Analysis")
    parser.add_argument("--version", action="version", version=f"MIKA {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="Check local configuration and integrity")

    ingest = sub.add_parser("ingest", help="Ingest evidence with provenance")
    ingest.add_argument("path")

    search = sub.add_parser("search", help="Hybrid search over trusted evidence")
    search.add_argument("query")
    search.add_argument("--k", type=int, default=6)

    ask = sub.add_parser("ask", help="Generate a grounded local-model analysis")
    ask.add_argument("query")
    ask.add_argument("--k", type=int, default=6)

    case_create = sub.add_parser("case-create", help="Create an analysis case")
    case_create.add_argument("title")
    case_create.add_argument("--objective", default="")

    case_attach = sub.add_parser("case-attach", help="Attach evidence to a case")
    case_attach.add_argument("case_id")
    case_attach.add_argument("chunk_ids", nargs="+", type=int)

    finding = sub.add_parser("case-finding", help="Record a finding")
    finding.add_argument("case_id")
    finding.add_argument("statement")
    finding.add_argument("--confidence", required=True, type=float)
    finding.add_argument("--evidence", nargs="*", type=int, default=[])
    finding.add_argument("--alternative", action="append", default=[])
    finding.add_argument("--limitation", action="append", default=[])

    report = sub.add_parser("case-report", help="Export an evidence-backed briefing")
    report.add_argument("case_id")
    report.add_argument("--output", type=Path)

    evaluate = sub.add_parser("evaluate", help="Run retrieval/security/latency benchmarks")
    evaluate.add_argument("--output", type=Path, default=Path("reports/evaluation-results.json"))
    evaluate.add_argument("--repeats", type=int, default=20)

    sub.add_parser("audit-verify", help="Verify the audit hash chain")

    tools = sub.add_parser("tools", help="List tools allowed for a role")
    tools.add_argument("--role", choices=["viewer", "analyst", "reviewer"], default="analyst")

    tool_run = sub.add_parser("tool-run", help="Execute a typed tool through policy enforcement")
    tool_run.add_argument("name")
    tool_run.add_argument("--args", default="{}", help="JSON object containing tool arguments")
    tool_run.add_argument("--role", choices=["viewer", "analyst", "reviewer"], default="analyst")

    resolve = sub.add_parser("entity-resolve", help="Resolve an entity against a workspace CSV")
    resolve.add_argument("path")
    resolve.add_argument("query")
    resolve.add_argument("--threshold", type=float, default=0.82)
    resolve.add_argument("--limit", type=int, default=10)

    graph = sub.add_parser("graph-path", help="Trace a relationship path through a CSV edge list")
    graph.add_argument("path")
    graph.add_argument("source")
    graph.add_argument("target")
    graph.add_argument("--max-depth", type=int, default=6)

    profile = sub.add_parser("profile", help="Profile CSV data quality")
    profile.add_argument("path")

    fetch = sub.add_parser("fetch-uk-sanctions", help="Fetch the official FCDO UK Sanctions List CSV")
    fetch.add_argument("--output", default="data/uk-sanctions-list.csv")

    serve = sub.add_parser("serve", help="Run the analyst API and TypeScript console")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    return parser


def _registry(app: MikaApp, role: str) -> ToolRegistry:
    registry = ToolRegistry(Policy.for_role(role), app.audit)
    register_builtin_tools(
        registry,
        retriever=app.retriever,
        workspace=app.settings.workspace,
        cases=app.cases,
    )
    return registry


def _run_tool(app: MikaApp, name: str, arguments: dict[str, Any], *, role: str = "analyst") -> int:
    result = _registry(app, role).execute(ToolCall(name, arguments))
    _json({"name": result.name, "success": result.success, "output": result.output, "error": result.error})
    return 0 if result.success else 1


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    root = Path(__file__).resolve().parents[1]

    if args.command == "evaluate":
        report = run_suite(root, args.output.resolve(), repeats=args.repeats)
        _json(report)
        return 0 if report["status"] == "passed" else 1

    if args.command == "fetch-uk-sanctions":
        destination = (root / args.output).resolve()
        if root.resolve() not in destination.parents:
            raise SystemExit("--output must remain inside the MIKA workspace")
        _json(fetch_uk_sanctions_csv(destination))
        return 0

    if args.command == "serve":
        try:
            import uvicorn
        except ImportError as exc:
            raise SystemExit("Install the server extra with `pip install -e \".[server]\"`") from exc
        uvicorn.run("mika.api:app", host=args.host, port=args.port, reload=False)
        return 0

    app = MikaApp()
    try:
        if args.command == "doctor":
            valid, records, error = app.audit.verify()
            _json(
                {
                    "version": __version__,
                    "database": str(app.settings.db_path),
                    "workspace": str(app.settings.workspace),
                    "fts5": app.db.fts_enabled,
                    "embedding_backend": app.embedder.backend,
                    "embedding_identity": app.embedder.identity,
                    "embedding_fallback_error": app.embedder.load_error,
                    "audit_chain_valid": valid,
                    "audit_records": records,
                    "audit_error": error,
                }
            )
        elif args.command == "ingest":
            result = app.evidence.ingest_path(args.path)
            app.audit.record("evidence.ingest", asdict(result))
            _json(asdict(result))
        elif args.command == "search":
            with app.telemetry.span(
                "mika.retrieval.search",
                attributes={"mika.query.length": len(args.query), "mika.retrieval.k": args.k},
            ):
                _json([asdict(hit) | {"citation": hit.citation()} for hit in app.retriever.search(args.query, args.k)])
        elif args.command == "ask":
            llm = OllamaClient(app.settings.ollama_url, app.settings.ollama_model, app.settings.request_timeout)
            try:
                _json(asdict(AnalystEngine(app.retriever, llm, app.telemetry).answer(args.query, args.k)))
            finally:
                llm.close()
        elif args.command == "case-create":
            case_id = app.cases.create(args.title, args.objective)
            app.audit.record("case.create", {"case_id": case_id, "title": args.title})
            _json({"case_id": case_id})
        elif args.command == "case-attach":
            app.cases.attach_evidence(args.case_id, args.chunk_ids)
            app.audit.record("case.attach_evidence", {"case_id": args.case_id, "chunk_ids": args.chunk_ids})
            _json({"case_id": args.case_id, "attached": args.chunk_ids})
        elif args.command == "case-finding":
            finding_id = app.cases.add_finding(
                args.case_id,
                args.statement,
                args.confidence,
                evidence_chunk_ids=args.evidence,
                alternatives=args.alternative,
                limitations=args.limitation,
            )
            app.audit.record("case.add_finding", {"case_id": args.case_id, "finding_id": finding_id})
            _json({"finding_id": finding_id})
        elif args.command == "case-report":
            markdown = app.cases.report_markdown(args.case_id)
            if args.output:
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.write_text(markdown, encoding="utf-8")
                _json({"output": str(args.output.resolve())})
            else:
                print(markdown)
        elif args.command == "audit-verify":
            valid, records, error = app.audit.verify()
            _json({"valid": valid, "records": records, "error": error})
            return 0 if valid else 1
        elif args.command == "tools":
            _json({"role": args.role, "tools": [item["function"]["name"] for item in _registry(app, args.role).schemas()]})
        elif args.command == "tool-run":
            try:
                payload = json.loads(args.args)
            except json.JSONDecodeError as exc:
                raise SystemExit(f"Invalid --args JSON: {exc}") from exc
            if not isinstance(payload, dict):
                raise SystemExit("--args must decode to a JSON object")
            return _run_tool(app, args.name, payload, role=args.role)
        elif args.command == "entity-resolve":
            return _run_tool(
                app,
                "entity.resolve",
                {"path": args.path, "query": args.query, "threshold": args.threshold, "limit": args.limit},
                role="viewer",
            )
        elif args.command == "graph-path":
            return _run_tool(
                app,
                "graph.shortest_path",
                {"path": args.path, "source": args.source, "target": args.target, "max_depth": args.max_depth},
                role="viewer",
            )
        elif args.command == "profile":
            return _run_tool(app, "dataset.profile", {"path": args.path}, role="viewer")
        return 0
    finally:
        app.close()


if __name__ == "__main__":
    sys.exit(main())
