from __future__ import annotations

import math
from statistics import mean
from typing import Any


def recall_at_k(retrieved: list[int], relevant: set[int], k: int) -> float:
    if not relevant:
        return 1.0
    return len(set(retrieved[:k]) & relevant) / len(relevant)


def precision_at_k(retrieved: list[int], relevant: set[int], k: int) -> float:
    selected = retrieved[:k]
    if not selected:
        return 0.0
    return len(set(selected) & relevant) / len(selected)


def reciprocal_rank(retrieved: list[int], relevant: set[int]) -> float:
    for index, item in enumerate(retrieved, start=1):
        if item in relevant:
            return 1.0 / index
    return 0.0


def ndcg_at_k(retrieved: list[int], relevant: set[int], k: int) -> float:
    dcg = sum((1.0 / math.log2(index + 2)) for index, item in enumerate(retrieved[:k]) if item in relevant)
    ideal = sum(1.0 / math.log2(index + 2) for index in range(min(len(relevant), k)))
    return dcg / ideal if ideal else 1.0


def percentile(values: list[float], q: float) -> float | None:
    if not values:
        return None
    ordered = sorted(values)
    rank = max(1, math.ceil(q * len(ordered)))
    return ordered[rank - 1]


def aggregate(rows: list[dict[str, Any]], key: str) -> float | None:
    values = [float(row[key]) for row in rows if row.get(key) is not None]
    return mean(values) if values else None
