from __future__ import annotations

from datetime import datetime, timezone
import json
from typing import Any, Iterable
from uuid import uuid4

from .storage import Database


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class CaseStore:
    def __init__(self, db: Database) -> None:
        self.db = db

    def create(self, title: str, objective: str = "") -> str:
        case_id = f"case_{uuid4().hex[:12]}"
        now = _now()
        with self.db.conn:
            self.db.conn.execute(
                "INSERT INTO cases(id,title,objective,created_at,updated_at) VALUES(?,?,?,?,?)",
                (case_id, title.strip(), objective.strip(), now, now),
            )
        return case_id

    def attach_evidence(self, case_id: str, chunk_ids: Iterable[int], note: str = "") -> None:
        self._require_case(case_id)
        with self.db.conn:
            for chunk_id in chunk_ids:
                row = self.db.conn.execute("SELECT 1 FROM chunks WHERE id=?", (int(chunk_id),)).fetchone()
                if row is None:
                    raise ValueError(f"Unknown evidence chunk: {chunk_id}")
                self.db.conn.execute(
                    "INSERT OR REPLACE INTO case_evidence(case_id,chunk_id,note) VALUES(?,?,?)",
                    (case_id, int(chunk_id), note.strip()),
                )
            self.db.conn.execute("UPDATE cases SET updated_at=? WHERE id=?", (_now(), case_id))

    def add_finding(
        self,
        case_id: str,
        statement: str,
        confidence: float,
        *,
        evidence_chunk_ids: Iterable[int] = (),
        alternatives: Iterable[str] = (),
        limitations: Iterable[str] = (),
    ) -> str:
        self._require_case(case_id)
        confidence = float(confidence)
        if not 0 <= confidence <= 1:
            raise ValueError("Confidence must be between 0 and 1")
        finding_id = f"finding_{uuid4().hex[:12]}"
        with self.db.conn:
            self.db.conn.execute(
                """
                INSERT INTO findings(id,case_id,statement,confidence,alternatives_json,limitations_json,created_at)
                VALUES(?,?,?,?,?,?,?)
                """,
                (
                    finding_id,
                    case_id,
                    statement.strip(),
                    confidence,
                    json.dumps(list(alternatives), ensure_ascii=False),
                    json.dumps(list(limitations), ensure_ascii=False),
                    _now(),
                ),
            )
            for chunk_id in evidence_chunk_ids:
                self.db.conn.execute(
                    "INSERT INTO finding_evidence(finding_id,chunk_id) VALUES(?,?)",
                    (finding_id, int(chunk_id)),
                )
            self.db.conn.execute("UPDATE cases SET updated_at=? WHERE id=?", (_now(), case_id))
        return finding_id

    def _require_case(self, case_id: str) -> Any:
        row = self.db.conn.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
        if row is None:
            raise ValueError(f"Unknown case: {case_id}")
        return row

    def get_case(self, case_id: str) -> dict[str, Any]:
        case = dict(self._require_case(case_id))
        evidence = self.db.conn.execute(
            """
            SELECT c.id AS chunk_id,c.locator,s.name AS source,s.sha256,ce.note,c.content
            FROM case_evidence ce JOIN chunks c ON c.id=ce.chunk_id JOIN sources s ON s.id=c.source_id
            WHERE ce.case_id=? ORDER BY c.id
            """,
            (case_id,),
        ).fetchall()
        findings = self.db.conn.execute(
            "SELECT * FROM findings WHERE case_id=? ORDER BY created_at,id",
            (case_id,),
        ).fetchall()
        output_findings = []
        for row in findings:
            item = dict(row)
            item["alternatives"] = json.loads(item.pop("alternatives_json"))
            item["limitations"] = json.loads(item.pop("limitations_json"))
            cited = self.db.conn.execute(
                "SELECT chunk_id FROM finding_evidence WHERE finding_id=? ORDER BY chunk_id",
                (item["id"],),
            ).fetchall()
            item["evidence_chunk_ids"] = [int(value["chunk_id"]) for value in cited]
            output_findings.append(item)
        return {"case": case, "evidence": [dict(row) for row in evidence], "findings": output_findings}

    def report_markdown(self, case_id: str) -> str:
        data = self.get_case(case_id)
        case = data["case"]
        lines = [f"# {case['title']}", "", f"**Case ID:** `{case_id}`", f"**Status:** {case['status']}"]
        if case["objective"]:
            lines += ["", "## Objective", "", case["objective"]]
        lines += ["", "## Findings", ""]
        if not data["findings"]:
            lines.append("No findings recorded.")
        for index, finding in enumerate(data["findings"], start=1):
            lines += [
                f"### {index}. Finding",
                "",
                finding["statement"],
                "",
                f"**Confidence:** {finding['confidence']:.0%}",
                f"**Evidence chunks:** {', '.join(map(str, finding['evidence_chunk_ids'])) or 'None'}",
            ]
            if finding["alternatives"]:
                lines += ["", "**Alternative explanations**", *[f"- {item}" for item in finding["alternatives"]]]
            if finding["limitations"]:
                lines += ["", "**Limitations**", *[f"- {item}" for item in finding["limitations"]]]
            lines.append("")
        lines += ["## Evidence register", ""]
        for item in data["evidence"]:
            lines.append(f"- Chunk {item['chunk_id']} - `{item['source']}` / `{item['locator']}` / SHA-256 `{item['sha256']}`")
        return "\n".join(lines).rstrip() + "\n"
