from __future__ import annotations

from collections import defaultdict, deque
from dataclasses import dataclass
from typing import Iterable


@dataclass(frozen=True, slots=True)
class Edge:
    source: str
    target: str
    relation: str


@dataclass(frozen=True, slots=True)
class PathStep:
    source: str
    target: str
    relation: str


class RelationshipGraph:
    def __init__(self, edges: Iterable[Edge]) -> None:
        self._adjacency: dict[str, list[tuple[str, str]]] = defaultdict(list)
        for edge in edges:
            source = edge.source.strip()
            target = edge.target.strip()
            relation = edge.relation.strip() or "related_to"
            if not source or not target:
                continue
            self._adjacency[source].append((target, relation))
            self._adjacency[target].append((source, relation))

    def neighbours(self, node: str) -> list[dict[str, str]]:
        return [
            {"node": neighbour, "relation": relation}
            for neighbour, relation in sorted(self._adjacency.get(node, ()))
        ]

    def shortest_path(self, source: str, target: str, *, max_depth: int = 6) -> list[PathStep]:
        if max_depth < 1:
            raise ValueError("max_depth must be positive")
        if source == target:
            return []

        queue = deque([(source, 0)])
        parent: dict[str, tuple[str, str] | None] = {source: None}
        while queue:
            node, depth = queue.popleft()
            if depth >= max_depth:
                continue
            for neighbour, relation in self._adjacency.get(node, ()):
                if neighbour in parent:
                    continue
                parent[neighbour] = (node, relation)
                if neighbour == target:
                    return self._reconstruct_path(parent, source, target)
                queue.append((neighbour, depth + 1))
        return []

    @staticmethod
    def _reconstruct_path(
        parent: dict[str, tuple[str, str] | None],
        source: str,
        target: str,
    ) -> list[PathStep]:
        reverse_path: list[PathStep] = []
        node = target
        while node != source:
            link = parent[node]
            if link is None:
                return []
            previous, relation = link
            reverse_path.append(PathStep(previous, node, relation))
            node = previous
        reverse_path.reverse()
        return reverse_path

    def degree_ranking(self, *, limit: int = 20) -> list[dict[str, int | str]]:
        if limit < 1:
            raise ValueError("limit must be positive")
        ranked = sorted(
            ((node, len(neighbours)) for node, neighbours in self._adjacency.items()),
            key=lambda item: (item[1], item[0]),
            reverse=True,
        )
        return [{"node": node, "degree": degree} for node, degree in ranked[:limit]]
