# Contributing

MIKA keeps changes small, testable and tied to a measurable system property.

## Setup

```bash
python -m venv .venv
source .venv/bin/activate
pip install -e ".[dev,server]"
npm install --prefix dashboard --ignore-scripts --no-audit --no-fund
```

## Before opening a pull request

```bash
ruff format --check .
ruff check .
mypy mika
bandit -q -r mika
pytest --cov=mika --cov-fail-under=82 -q
mika evaluate --repeats 50
npm run --prefix dashboard typecheck
npm run --prefix dashboard build
```

Benchmark changes must include the dataset version and SHA-256 fingerprints in the generated report. Security-sensitive changes should include a regression test for the failed or denied path, not only the successful path.
