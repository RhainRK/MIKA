from __future__ import annotations

from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
SKIP_PARTS = {".git", ".venv", "node_modules", "__pycache__", ".pytest_cache", ".mypy_cache", ".ruff_cache"}
TEXT_SUFFIXES = {".py", ".md", ".toml", ".yml", ".yaml", ".json", ".ts", ".html", ".txt", ".ps1", ".bat"}
BANNED_FILES = {".env", ".coverage", "coverage.xml", ".DS_Store"}
BANNED_SUFFIXES = {".sqlite3", ".db", ".log", ".pem", ".key"}
BANNED_TEXT = {
    "\u2014": "em dash",
    "\u2026": "unicode ellipsis",
}
LEGACY_TERMS = re.compile(r"(?i)\b(?:MAI|idol|vtuber|elevenlabs)\b")
SECRET_PATTERNS = {
    "private key": re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----"),
    "OpenAI-style key": re.compile(r"\bsk-[A-Za-z0-9_-]{20,}\b"),
    "GitHub token": re.compile(r"\b(?:gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"),
    "AWS access key": re.compile(r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"),
    "Google API key": re.compile(r"\bAIza[0-9A-Za-z_-]{30,}\b"),
    "Slack token": re.compile(r"\bxox[baprs]-[0-9A-Za-z-]{20,}\b"),
    "Stripe live key": re.compile(r"\b(?:sk|rk)_live_[0-9A-Za-z]{16,}\b"),
    "Anthropic key": re.compile(r"\bsk-ant-[0-9A-Za-z_-]{20,}\b"),
    "Hugging Face token": re.compile(r"\bhf_[0-9A-Za-z]{20,}\b"),
}
ALLOW_LEGACY = {Path("scripts/release_check.py")}
ALLOW_SECRET_TESTS = {Path("mika/security.py"), Path("tests/test_security.py"), Path("tests/test_audit.py")}


def iter_files() -> list[Path]:
    files: list[Path] = []
    for path in ROOT.rglob("*"):
        if not path.is_file() or any(part in SKIP_PARTS for part in path.parts):
            continue
        files.append(path)
    return files


def main() -> int:
    errors: list[str] = []
    for path in iter_files():
        relative = path.relative_to(ROOT)
        if path.name in BANNED_FILES or path.suffix.casefold() in BANNED_SUFFIXES:
            errors.append(f"generated/sensitive file: {relative}")
            continue
        if path.suffix.casefold() not in TEXT_SUFFIXES:
            continue

        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue

        for token, label in BANNED_TEXT.items():
            if token in text:
                errors.append(f"{label}: {relative}")
        if relative not in ALLOW_LEGACY and LEGACY_TERMS.search(text):
            errors.append(f"legacy project term: {relative}")
        if relative not in ALLOW_SECRET_TESTS:
            for label, pattern in SECRET_PATTERNS.items():
                if pattern.search(text):
                    errors.append(f"possible {label}: {relative}")

    if errors:
        print("release check failed")
        for error in sorted(set(errors)):
            print(f"- {error}")
        return 1

    print("release check passed")
    return 0


if __name__ == "__main__":
    sys.exit(main())
