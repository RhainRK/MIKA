type SearchHit = {
  citation: string;
  source_name: string;
  locator: string;
  content: string;
  score: number;
  source_sha256: string;
};

type Health = {
  version: string;
  audit_chain_valid: boolean;
  embedding_backend: string;
  sources: number;
  chunks: number;
};

type Metric = { mean: number | null };

type EvaluationSuite = {
  name: string;
  case_count: number;
  metrics: Record<string, Metric>;
};

type Evaluation = {
  status: string;
  benchmark_suites: EvaluationSuite[];
};

function requiredElement<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Missing element: ${selector}`);
  return element;
}

const form = requiredElement<HTMLFormElement>("#search-form");
const query = requiredElement<HTMLInputElement>("#query");
const results = requiredElement<HTMLDivElement>("#results");
const health = requiredElement<HTMLDivElement>("#health");
const benchmark = requiredElement<HTMLDivElement>("#benchmark");

function metric(value: number | null | undefined): string {
  return value == null ? "n/a" : value.toFixed(3);
}

function text(tag: string, value: string, className?: string): HTMLElement {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`${url}: ${response.status}`);
  return await response.json() as T;
}

async function loadHealth(): Promise<void> {
  const body = await getJson<Health>("/api/health");
  health.replaceChildren(
    text("strong", `MIKA ${body.version}`),
    text("span", body.audit_chain_valid ? "audit verified" : "audit failed"),
    text("span", body.embedding_backend),
    text("span", `${body.sources} sources / ${body.chunks} chunks`),
  );
}

async function loadEvaluation(): Promise<void> {
  const response = await fetch("/api/evaluation/latest", { headers: { Accept: "application/json" } });
  if (response.status === 404) {
    benchmark.textContent = "No evaluation report. Run mika evaluate.";
    return;
  }
  if (!response.ok) throw new Error(`/api/evaluation/latest: ${response.status}`);

  const body = await response.json() as Evaluation;
  const suite = body.benchmark_suites.at(-1);
  if (!suite) return;

  const summary = text("div", `${suite.name} | ${suite.case_count} cases | ${body.status}`);
  const metrics = document.createElement("div");
  metrics.className = "metrics";
  metrics.append(
    text("span", `Recall@k ${metric(suite.metrics.recall_at_k?.mean)}`),
    text("span", `MRR ${metric(suite.metrics.mrr?.mean)}`),
    text("span", `nDCG ${metric(suite.metrics.ndcg_at_k?.mean)}`),
  );
  benchmark.replaceChildren(summary, metrics);
}

function renderHits(hits: SearchHit[]): void {
  if (hits.length === 0) {
    results.replaceChildren(text("p", "No trusted evidence matched."));
    return;
  }

  const nodes = hits.map((hit) => {
    const article = document.createElement("article");
    const header = document.createElement("header");
    header.append(text("strong", hit.citation), document.createTextNode(` | ${hit.source_name}`));
    article.append(
      header,
      text("small", `${hit.locator} | score ${hit.score.toFixed(4)}`),
      text("p", hit.content),
      text("code", `sha256:${hit.source_sha256.slice(0, 16)}...`),
    );
    return article;
  });
  results.replaceChildren(...nodes);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const q = query.value.trim();
  if (!q) return;

  results.textContent = "Searching evidence...";
  try {
    const hits = await getJson<SearchHit[]>(`/api/search?q=${encodeURIComponent(q)}&k=6`);
    renderHits(hits);
  } catch (error: unknown) {
    results.textContent = error instanceof Error ? error.message : "Search failed";
  }
});

Promise.all([loadHealth(), loadEvaluation()]).catch((error: unknown) => {
  health.textContent = error instanceof Error ? error.message : "System status unavailable";
});
