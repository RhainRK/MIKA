# Changelog

## 1.3.0

- Reworked the FastAPI composition layer around shared embedding state and request-scoped application sessions.
- Replaced full semantic score sorting with partial top-k selection using NumPy `argpartition`.
- Cached normalized entity candidates and token blocks to reduce repeated record-linkage work.
- Reworked BFS path finding to store parent links instead of copying complete paths during traversal.
- Added SQLite WAL, busy timeout and thread-safe connection settings for concurrent API access.
- Hardened embedding cache/model initialization and audit verification with explicit locking.
- Removed generated frontend output and legacy launch/requirements wrappers from the source tree.
- Added stricter TypeScript compiler checks, Dependabot configuration and updated GitHub Actions workflows.
- Expanded CLI/API integration tests to 36 tests and raised measured Python coverage to 82%.
- Added repository release checks for generated state, legacy project terms, sensitive key patterns and non-ASCII punctuation.

## 1.2.0

- Added explainable entity resolution with token blocking, alias matching and weighted fuzzy scoring.
- Added relationship analysis with adjacency lists and bounded breadth-first shortest-path traversal.
- Added CSV data-quality profiling with missingness, uniqueness, duplicate and candidate-key checks.
- Added an exact allow-listed FCDO public-data connector.
- Vectorized semantic scoring and batched embedding generation.
- Added benchmark/source SHA-256 fingerprints and bootstrap confidence intervals.
- Added thread-safe audit-chain appends and telemetry redaction.
- Expanded FastAPI health/evaluation endpoints and strict TypeScript analyst console.
- Added Docker non-root execution and CI gates for linting, typing, security scanning, coverage and frontend compilation.
- Expanded the automated suite to 33 tests with 78% measured Python coverage.

## 1.1.0

- Added a 120-case operational retrieval regression suite.
- Added FastAPI/TypeScript analyst interface and public-data connector scaffolding.
- Added reciprocal-rank fusion and structured-identifier ranking support.

## 1.0.0

- Established a personality-free evidence-analysis and AI-assurance architecture.
- Added provenance-bearing ingestion, hybrid retrieval, evaluation, default-deny typed tools, prompt-injection quarantine, read-only data tooling, tamper-evident audit logging, case reporting and local-model analysis.
