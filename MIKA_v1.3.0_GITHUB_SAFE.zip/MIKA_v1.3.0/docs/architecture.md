# Architecture

## Design principles

1. **Evidence before generation.** Claims should remain traceable to source material.
2. **Authorization outside the model.** Model output cannot grant capabilities.
3. **Untrusted context.** Retrieved documents are data, never instructions.
4. **Measurability.** Retrieval, policy and latency are evaluated independently of presentation quality.
5. **Reproducibility.** Benchmarks carry dataset fingerprints, environment metadata and explicit limitations.
6. **Local-first operation.** Core analysis and regression tests work without model APIs.
7. **Explainability.** Retrieval, entity matching and graph traversal expose deterministic evidence for review.

## Core components

- `provenance.py` - ingestion, chunking, SHA-256 source identity, metadata and quarantine state.
- `embeddings.py` - batched semantic encoding with bounded LRU caching and deterministic offline fallback.
- `retrieval.py` - FTS5 lexical retrieval, vectorized semantic scoring, RRF fusion and identifier boosting.
- `entity_resolution.py` - normalized-name matching, token blocking, alias handling and match explanations.
- `relationships.py` - adjacency-list representation, neighbour queries and bounded BFS shortest paths.
- `data_quality.py` - CSV missingness, uniqueness, candidate-key, duplicate and numeric profiling.
- `policy.py` + `tools/` - typed capabilities and default-deny authorization.
- `audit.py` - thread-safe append-only redacted events chained by SHA-256.
- `cases.py` - evidence-backed findings with confidence, alternatives and limitations.
- `analyst.py` - grounded synthesis over retrieved evidence.
- `telemetry.py` - structured traces using GenAI-style operation/model/token attributes.
- `benchmarking.py` + `evaluation/` - ranking metrics, bootstrap intervals and security regression gates.
- `api.py` + `dashboard/` - FastAPI service and strict TypeScript analyst interface.

## Retrieval pipeline

1. FTS5 produces a lexical ranking from the query.
2. The embedding model produces a normalized query vector.
3. Stored chunk embeddings are stacked into a NumPy matrix and scored in one matrix-vector operation.
4. Semantic and lexical rankings are fused with reciprocal-rank fusion.
5. Exact structured identifiers receive a deterministic boost so high-information case IDs are not displaced by generic semantic similarity.
6. Quarantined sources are excluded unless the caller explicitly opts in.

The semantic stage remains an exact scan over the local embedding matrix. This is simple and deterministic for the intended portfolio-scale corpus. A production-scale corpus would normally replace that stage with an ANN index such as HNSW/FAISS/vector-database infrastructure.

## Entity resolution

Entity resolution uses a lightweight explainable pipeline rather than an opaque classifier:

1. Unicode normalization and case folding.
2. Punctuation removal and legal-suffix normalization.
3. Inverted-token blocking to reduce candidate comparisons.
4. Exact alias/name checks.
5. Weighted sequence similarity, token-set overlap and containment scoring.
6. Thresholded matches with human-readable signals.

This is intended for analyst candidate generation, not automated identity adjudication.

## Relationship analysis

Relationships are stored as an adjacency list. Bounded breadth-first search returns the minimum-hop connection between two nodes in `O(V + E)` worst-case time for the visited subgraph. Depth limits prevent unbounded traversal over unexpectedly dense datasets.

## Trust boundaries

The model is never a policy authority. Deterministic code controls:

- tool registration and permission checks,
- workspace path resolution,
- read-only SQL validation,
- prompt-injection quarantine,
- public connector endpoint allow-lists,
- audit verification.

## Runtime and complexity notes

- Query embeddings are cached behind a bounded LRU; missing document embeddings are generated in batches.
- Semantic scoring is a matrix-vector dot product over normalized embeddings. Top-k selection uses `argpartition`, avoiding a full `O(n log n)` sort when only a small prefix is required.
- Entity candidate normalization and token blocks are computed once when the resolver is built, so repeated lookups avoid duplicate normalization work.
- BFS stores one parent pointer per visited node and reconstructs the final route only after the target is found, avoiding repeated path-list copies.
- The API shares the embedding runtime across requests while opening request-scoped application/database sessions.
- SQLite file databases use WAL mode, a busy timeout and normal synchronous mode to improve local concurrent read/write behavior without changing the single-node storage model.
