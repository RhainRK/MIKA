# Design references

MIKA is an independent portfolio/research implementation. Its design choices are informed by current public guidance and evaluation practice rather than by one vendor framework.

- **NIST AI RMF / Generative AI Profile** - risk management, measurement and lifecycle governance for AI systems.  
  https://www.nist.gov/itl/ai-risk-management-framework  
  https://www.nist.gov/publications/artificial-intelligence-risk-management-framework-generative-artificial-intelligence
- **OWASP GenAI - Prompt Injection (LLM01:2025)** - treat external/retrieved content as untrusted and keep authorization outside model text.  
  https://genai.owasp.org/llmrisk/llm01-prompt-injection/
- **OWASP GenAI - Excessive Agency (LLM06:2025)** - constrain tools and privileges rather than allowing the model to self-authorize actions.  
  https://genai.owasp.org/llmrisk/llm062025-excessive-agency/
- **OpenTelemetry semantic conventions / GenAI observability** - structured tracing of model and tool operations, latency and token usage.  
  https://opentelemetry.io/docs/specs/semconv/
- **Ragas metrics** - common RAG and agent evaluation vocabulary including context precision/recall, groundedness and tool-call metrics.  
  https://docs.ragas.io/en/latest/concepts/metrics/available_metrics/

These references do not imply certification, endorsement or compatibility guarantees.
