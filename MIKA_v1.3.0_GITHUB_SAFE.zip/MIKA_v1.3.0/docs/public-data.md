# Public-data workflow

MIKA includes a constrained connector for the official FCDO UK Sanctions List CSV. It demonstrates ingestion of a changing public dataset, dataset fingerprinting and analyst-reviewed entity resolution. It is not legal or compliance advice.

```powershell
mika fetch-uk-sanctions
mika profile data\uk-sanctions-list.csv
mika entity-resolve data\uk-sanctions-list.csv "Example Name" --threshold 0.90
mika ingest data\uk-sanctions-list.csv
```

The connector accepts only the exact official HTTPS endpoint:

`https://sanctionslist.fcdo.gov.uk/docs/UK-Sanctions-List.csv`

It rejects alternate hosts, paths, ports, credentials, query parameters and fragments, applies a 25 MiB response cap and records the SHA-256 digest of the downloaded bytes.

The live dataset is not bundled because it changes over time. Preserve the retrieval time, source URL and digest with any exported analysis.
