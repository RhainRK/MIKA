@echo off
setlocal
if not exist .venv py -3.11 -m venv .venv
.venv\Scripts\python.exe -m pip install -q -r requirements.txt
.venv\Scripts\python.exe main.py doctor
