# Operations case study

The bundled `samples/operations_incidents.csv` contains 120 generated operational incident records used to exercise MIKA end-to-end without external dependencies. `benchmarks/operations_120.jsonl` contains one held-out retrieval question per record.

The case study tests a common operational pattern: an analyst receives a case/incident identifier and must recover the correct source record despite many semantically similar records. Hybrid retrieval therefore combines semantic similarity, lexical ranking and exact structured-identifier evidence.

The dataset is synthetic. Its purpose is regression testing and architecture demonstration, not domain-performance measurement.
