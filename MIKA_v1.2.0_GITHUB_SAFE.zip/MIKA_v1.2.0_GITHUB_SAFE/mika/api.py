from __future__ import annotations

from dataclasses import asdict
import json
from pathlib import Path
from typing import Any

from . import __version__
from .app import MikaApp
from .policy import Policy
from .tools.builtins import register_builtin_tools
from .tools.registry import ToolRegistry


def create_app() -> Any:
    try:
        from fastapi import FastAPI, HTTPException, Query
        from fastapi.responses import FileResponse
        from fastapi.staticfiles import StaticFiles
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("Install requirements-server.txt to run the API") from exc

    service = FastAPI(title="MIKA API", version=__version__, docs_url="/docs", redoc_url=None)
    root = Path(__file__).resolve().parents[1]
    dashboard = root / "dashboard"
    if (dashboard / "dist").exists():
        service.mount("/assets", StaticFiles(directory=dashboard / "dist"), name="assets")

    @service.get("/")
    def index() -> Any:
        page = dashboard / "index.html"
        if not page.exists():
            raise HTTPException(status_code=404, detail="dashboard not built")
        return FileResponse(page)

    @service.get("/api/health")
    def health() -> dict[str, Any]:
        app = MikaApp()
        try:
            valid, records, error = app.audit.verify()
            source_count = int(app.db.conn.execute("SELECT COUNT(*) AS n FROM sources").fetchone()["n"])
            chunk_count = int(app.db.conn.execute("SELECT COUNT(*) AS n FROM chunks").fetchone()["n"])
            return {
                "status": "ok",
                "version": __version__,
                "fts5": app.db.fts_enabled,
                "embedding_backend": app.embedder.backend,
                "audit_chain_valid": valid,
                "audit_records": records,
                "audit_error": error,
                "sources": source_count,
                "chunks": chunk_count,
            }
        finally:
            app.close()

    @service.get("/api/search")
    def search(q: str = Query(min_length=1, max_length=2000), k: int = Query(default=6, ge=1, le=20)) -> list[dict[str, Any]]:
        app = MikaApp()
        try:
            with app.telemetry.span(
                "mika.retrieval.search",
                attributes={"mika.query.length": len(q), "mika.retrieval.k": k},
            ):
                return [asdict(hit) | {"citation": hit.citation()} for hit in app.retriever.search(q, k)]
        finally:
            app.close()

    @service.get("/api/evaluation/latest")
    def evaluation() -> Any:
        path = root / "reports" / "evaluation-results.json"
        if not path.exists():
            raise HTTPException(status_code=404, detail="run `python main.py evaluate` first")
        return json.loads(path.read_text(encoding="utf-8"))

    @service.get("/api/cases/{case_id}")
    def case(case_id: str) -> dict[str, Any]:
        app = MikaApp()
        try:
            try:
                return app.cases.get_case(case_id)
            except ValueError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
        finally:
            app.close()

    @service.get("/api/tools")
    def tools(role: str = "analyst") -> dict[str, Any]:
        try:
            policy = Policy.for_role(role)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        app = MikaApp()
        try:
            registry = ToolRegistry(policy, app.audit)
            register_builtin_tools(
                registry,
                retriever=app.retriever,
                workspace=app.settings.workspace,
                cases=app.cases,
            )
            return {"role": role, "tools": [item["function"] for item in registry.schemas()]}
        finally:
            app.close()

    return service


app = create_app()
