from __future__ import annotations

import csv
from dataclasses import asdict
from pathlib import Path
import re
import sqlite3
from typing import Any

from pydantic import Field

from ..cases import CaseStore
from ..data_quality import profile_csv
from ..entity_resolution import EntityRecord, EntityResolver
from ..policy import Permission
from ..relationships import Edge, RelationshipGraph
from ..retrieval import HybridRetriever
from ..security import assess_prompt_injection, safe_workspace_path
from .base import ToolArgs, ToolDefinition
from .registry import ToolRegistry


class SearchArgs(ToolArgs):
    query: str = Field(min_length=1, max_length=2000)
    k: int = Field(default=6, ge=1, le=20)


class ScanArgs(ToolArgs):
    text: str = Field(min_length=1, max_length=20000)


class DatasetProfileArgs(ToolArgs):
    path: str = Field(min_length=1, max_length=1000)


class SQLiteQueryArgs(ToolArgs):
    path: str = Field(min_length=1, max_length=1000)
    query: str = Field(min_length=1, max_length=5000)
    row_limit: int = Field(default=200, ge=1, le=1000)


class EntityResolveArgs(ToolArgs):
    path: str = Field(min_length=1, max_length=1000)
    query: str = Field(min_length=1, max_length=500)
    id_column: str | None = None
    name_columns: list[str] = Field(default_factory=list, max_length=20)
    alias_columns: list[str] = Field(default_factory=list, max_length=20)
    type_column: str | None = None
    threshold: float = Field(default=0.82, ge=0.0, le=1.0)
    limit: int = Field(default=10, ge=1, le=50)


class GraphPathArgs(ToolArgs):
    path: str = Field(min_length=1, max_length=1000)
    source: str = Field(min_length=1, max_length=500)
    target: str = Field(min_length=1, max_length=500)
    source_column: str = "source"
    target_column: str = "target"
    relation_column: str = "relation"
    max_depth: int = Field(default=6, ge=1, le=12)


class CaseSummaryArgs(ToolArgs):
    case_id: str = Field(min_length=1, max_length=100)


_FORBIDDEN_SQL = re.compile(
    r"(?is)\b(?:insert|update|delete|drop|alter|create|replace|attach|detach|pragma|vacuum|reindex|analyze|load_extension)\b"
)


def _read_only_sqlite(path: Path, query: str, row_limit: int) -> dict[str, Any]:
    stripped = query.strip()
    invalid = (
        ";" in stripped.rstrip(";")
        or not re.match(r"(?is)^\s*(?:select|with)\b", stripped)
        or _FORBIDDEN_SQL.search(stripped)
    )
    if invalid:
        raise ValueError("Only one read-only SELECT/WITH query is permitted")

    uri = f"file:{path.as_posix()}?mode=ro"
    conn = sqlite3.connect(uri, uri=True, timeout=3.0)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA query_only=ON")
        rows = conn.execute(stripped).fetchmany(row_limit + 1)
        truncated = len(rows) > row_limit
        return {
            "rows": [dict(row) for row in rows[:row_limit]],
            "returned": min(len(rows), row_limit),
            "truncated": truncated,
        }
    finally:
        conn.close()


def _resolve_columns(
    fields: list[str],
    *,
    id_column: str | None,
    name_columns: list[str],
    alias_columns: list[str],
    type_column: str | None,
) -> tuple[str | None, list[str], list[str], str | None]:
    field_lookup = {field.casefold(): field for field in fields}

    def existing(value: str | None) -> str | None:
        return field_lookup.get(value.casefold()) if value else None

    resolved_id = existing(id_column)
    if id_column and not resolved_id:
        raise ValueError(f"Unknown id column: {id_column}")

    resolved_names = [field_lookup[item.casefold()] for item in name_columns if item.casefold() in field_lookup]
    if name_columns and len(resolved_names) != len(name_columns):
        raise ValueError("One or more name columns do not exist")
    if not resolved_names:
        resolved_names = [field for field in fields if "name" in field.casefold() and "type" not in field.casefold()]
    if not resolved_names:
        raise ValueError("No name columns detected; provide name_columns explicitly")

    resolved_aliases = [field_lookup[item.casefold()] for item in alias_columns if item.casefold() in field_lookup]
    if alias_columns and len(resolved_aliases) != len(alias_columns):
        raise ValueError("One or more alias columns do not exist")
    if not alias_columns:
        resolved_aliases = [field for field in fields if "alias" in field.casefold()]

    resolved_type = existing(type_column)
    if type_column and not resolved_type:
        raise ValueError(f"Unknown type column: {type_column}")
    if not resolved_type:
        resolved_type = next(
            (field for field in fields if field.casefold() in {"entity_type", "type", "group type"}),
            None,
        )
    return resolved_id, resolved_names, resolved_aliases, resolved_type


def _load_entities(path: Path, args: EntityResolveArgs) -> list[EntityRecord]:
    with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as handle:
        reader = csv.DictReader(handle)
        fields = list(reader.fieldnames or [])
        id_column, name_columns, alias_columns, type_column = _resolve_columns(
            fields,
            id_column=args.id_column,
            name_columns=args.name_columns,
            alias_columns=args.alias_columns,
            type_column=args.type_column,
        )
        records: list[EntityRecord] = []
        for row_number, row in enumerate(reader, start=2):
            names = [(row.get(column) or "").strip() for column in name_columns]
            names = [value for value in names if value]
            if not names:
                continue
            aliases = [(row.get(column) or "").strip() for column in alias_columns]
            aliases = [*names[1:], *(value for value in aliases if value)]
            entity_id = (row.get(id_column) or "").strip() if id_column else str(row_number)
            entity_type = (row.get(type_column) or "unknown").strip() if type_column else "unknown"
            records.append(EntityRecord(entity_id or str(row_number), names[0], tuple(dict.fromkeys(aliases)), entity_type))
    return records


def _resolve_entities(workspace: Path, args: EntityResolveArgs) -> dict[str, Any]:
    path = safe_workspace_path(workspace, args.path)
    records = _load_entities(path, args)
    resolver = EntityResolver(records)
    matches = resolver.resolve(args.query, threshold=args.threshold, limit=args.limit)
    return {
        "query": args.query,
        "records_scanned": len(records),
        "threshold": args.threshold,
        "matches": [asdict(match) for match in matches],
    }


def _graph_path(workspace: Path, args: GraphPathArgs) -> dict[str, Any]:
    path = safe_workspace_path(workspace, args.path)
    with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as handle:
        reader = csv.DictReader(handle)
        fields = set(reader.fieldnames or [])
        required = {args.source_column, args.target_column, args.relation_column}
        if missing := required - fields:
            raise ValueError(f"Missing graph columns: {', '.join(sorted(missing))}")
        edges = [
            Edge(
                source=(row.get(args.source_column) or "").strip(),
                target=(row.get(args.target_column) or "").strip(),
                relation=(row.get(args.relation_column) or "").strip(),
            )
            for row in reader
        ]
    graph = RelationshipGraph(edges)
    path_steps = graph.shortest_path(args.source, args.target, max_depth=args.max_depth)
    return {
        "source": args.source,
        "target": args.target,
        "connected": bool(path_steps) or args.source == args.target,
        "hops": len(path_steps),
        "path": [asdict(step) for step in path_steps],
    }


def register_builtin_tools(
    registry: ToolRegistry,
    *,
    retriever: HybridRetriever,
    workspace: Path,
    cases: CaseStore,
) -> None:
    registry.register(
        ToolDefinition(
            "evidence.search",
            "Search trusted evidence and return provenance-bearing chunks.",
            SearchArgs,
            lambda args: [
                {
                    "citation": hit.citation(),
                    "source": hit.source_name,
                    "locator": hit.locator,
                    "score": hit.score,
                    "content": hit.content,
                }
                for hit in retriever.search(args.query, args.k)
            ],
            Permission.READ_EVIDENCE,
        )
    )
    registry.register(
        ToolDefinition(
            "risk.scan_text",
            "Score text for prompt-injection indicators.",
            ScanArgs,
            lambda args: asdict(assess_prompt_injection(args.text)),
            Permission.READ_DATA,
        )
    )
    registry.register(
        ToolDefinition(
            "dataset.profile",
            "Profile CSV quality, missingness, uniqueness and candidate keys.",
            DatasetProfileArgs,
            lambda args: profile_csv(safe_workspace_path(workspace, args.path)),
            Permission.READ_DATA,
        )
    )
    registry.register(
        ToolDefinition(
            "entity.resolve",
            "Resolve an entity against CSV records with explainable deterministic/fuzzy scoring.",
            EntityResolveArgs,
            lambda args: _resolve_entities(workspace, args),
            Permission.READ_DATA,
        )
    )
    registry.register(
        ToolDefinition(
            "graph.shortest_path",
            "Trace the shortest relationship path through a CSV edge list.",
            GraphPathArgs,
            lambda args: _graph_path(workspace, args),
            Permission.READ_DATA,
        )
    )
    registry.register(
        ToolDefinition(
            "sqlite.query",
            "Run a bounded read-only SELECT/WITH query against workspace SQLite data.",
            SQLiteQueryArgs,
            lambda args: _read_only_sqlite(
                safe_workspace_path(workspace, args.path),
                args.query,
                args.row_limit,
            ),
            Permission.EXECUTE_QUERY,
        )
    )
    registry.register(
        ToolDefinition(
            "case.summary",
            "Read a structured case summary and its attached evidence.",
            CaseSummaryArgs,
            lambda args: cases.get_case(args.case_id),
            Permission.READ_EVIDENCE,
        )
    )
