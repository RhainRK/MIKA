from __future__ import annotations

from pathlib import Path

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MIKA_", env_file=".env", extra="ignore")

    db_path: Path = Path("data/mika.sqlite3")
    audit_path: Path = Path("data/audit.jsonl")
    telemetry_path: Path = Path("data/telemetry.jsonl")
    workspace: Path = Path(".")
    embedding_model: str = "sentence-transformers/all-MiniLM-L6-v2"
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "qwen3.5:4b"
    request_timeout: float = 90.0
    retrieval_k: int = 6
    injection_quarantine_threshold: float = 0.75

    def resolve(self) -> "Settings":
        self.db_path = self.db_path.expanduser().resolve()
        self.audit_path = self.audit_path.expanduser().resolve()
        self.telemetry_path = self.telemetry_path.expanduser().resolve()
        self.workspace = self.workspace.expanduser().resolve()
        return self


settings = Settings().resolve()
