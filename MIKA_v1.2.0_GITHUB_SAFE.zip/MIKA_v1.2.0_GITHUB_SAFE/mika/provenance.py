from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import csv
import hashlib
import json
from pathlib import Path
import re
from typing import Iterable

import numpy as np

from .embeddings import Embedder
from .security import assess_prompt_injection, safe_workspace_path
from .storage import Database


@dataclass(frozen=True, slots=True)
class IngestResult:
    source_id: int
    source_key: str
    name: str
    chunks: int
    sha256: str
    injection_score: float
    injection_signals: tuple[str, ...]
    quarantined: bool


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _extract_text(path: Path) -> tuple[str, str]:
    suffix = path.suffix.casefold()
    if suffix in {".txt", ".md", ".rst", ".log"}:
        return path.read_text(encoding="utf-8", errors="replace"), "text/plain"
    if suffix == ".json":
        obj = json.loads(path.read_text(encoding="utf-8"))
        return json.dumps(obj, indent=2, ensure_ascii=False), "application/json"
    if suffix == ".jsonl":
        lines = []
        for line in path.read_text(encoding="utf-8", errors="replace").splitlines():
            if line.strip():
                lines.append(json.dumps(json.loads(line), ensure_ascii=False))
        return "\n".join(lines), "application/x-ndjson"
    if suffix == ".csv":
        rows = []
        with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as handle:
            reader = csv.DictReader(handle)
            for index, row in enumerate(reader, start=2):
                cells = [f"{key}={value}" for key, value in row.items()]
                rows.append(f"row {index}: " + " | ".join(cells))
        return "\n\n".join(rows), "text/csv"
    raise ValueError(f"Unsupported file type: {path.suffix or '<none>'}")


def chunk_text(text: str, size: int = 1200, overlap: int = 180) -> list[str]:
    if size <= overlap or size < 200:
        raise ValueError("Chunk size must exceed overlap and be at least 200 characters")
    raw = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not raw:
        return []

    # Keep paragraph boundaries stable for reproducible citations.
    paragraphs = ["\n".join(line.rstrip() for line in block.splitlines()).strip()
                  for block in re.split(r"\n\s*\n+", raw)]
    paragraphs = [block for block in paragraphs if block]
    chunks: list[str] = []
    for paragraph in paragraphs:
        if len(paragraph) <= size:
            chunks.append(paragraph)
            continue
        start = 0
        while start < len(paragraph):
            end = min(len(paragraph), start + size)
            if end < len(paragraph):
                boundary = max(
                    paragraph.rfind("\n", start + size // 2, end),
                    paragraph.rfind(". ", start + size // 2, end),
                )
                if boundary > start:
                    end = boundary + 1
            chunk = paragraph[start:end].strip()
            if chunk:
                chunks.append(chunk)
            if end >= len(paragraph):
                break
            start = max(start + 1, end - overlap)
    return chunks


class EvidenceStore:
    def __init__(self, db: Database, embedder: Embedder, workspace: Path, quarantine_threshold: float = 0.75) -> None:
        self.db = db
        self.embedder = embedder
        self.workspace = workspace
        self.quarantine_threshold = max(0.0, min(float(quarantine_threshold), 1.0))

    def ingest_path(self, candidate: str | Path, *, metadata: dict | None = None) -> IngestResult:
        path = safe_workspace_path(self.workspace, candidate)
        if not path.is_file():
            raise ValueError("Input must be a file inside the configured workspace")
        raw = path.read_bytes()
        text, media_type = _extract_text(path)
        digest = _sha256(raw)
        assessment = assess_prompt_injection(text)
        quarantined = assessment.score >= self.quarantine_threshold
        source_key = f"sha256:{digest}"
        now = datetime.now(timezone.utc).isoformat()
        metadata_json = json.dumps(metadata or {}, ensure_ascii=False, sort_keys=True)
        with self.db.conn:
            self.db.conn.execute(
                """
                INSERT INTO sources(source_key,name,path,sha256,media_type,metadata_json,
                                    injection_score,injection_signals_json,quarantined,ingested_at)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(source_key) DO UPDATE SET
                    name=excluded.name,path=excluded.path,metadata_json=excluded.metadata_json,
                    injection_score=excluded.injection_score,
                    injection_signals_json=excluded.injection_signals_json,
                    quarantined=excluded.quarantined,ingested_at=excluded.ingested_at
                """,
                (
                    source_key,
                    path.name,
                    str(path),
                    digest,
                    media_type,
                    metadata_json,
                    assessment.score,
                    json.dumps(assessment.signals),
                    int(quarantined),
                    now,
                ),
            )
            source_id = int(self.db.conn.execute("SELECT id FROM sources WHERE source_key=?", (source_key,)).fetchone()["id"])
            existing = self.db.conn.execute("SELECT id FROM chunks WHERE source_id=?", (source_id,)).fetchall()
            if existing:
                if self.db.fts_enabled:
                    ids = [int(row["id"]) for row in existing]
                    marks = ",".join("?" for _ in ids)
                    self.db.conn.execute(f"DELETE FROM chunks_fts WHERE chunk_id IN ({marks})", ids)
                self.db.conn.execute("DELETE FROM chunks WHERE source_id=?", (source_id,))
            contents = chunk_text(text)
            vectors = self.embedder.encode_many(contents)
            for ordinal, (content, vector) in enumerate(zip(contents, vectors, strict=True)):
                vector = vector.astype(np.float32, copy=False)
                locator = f"{path.name}#chunk-{ordinal + 1}"
                cursor = self.db.conn.execute(
                    """
                    INSERT INTO chunks(source_id,ordinal,content,locator,content_sha256,embedding,embedding_model)
                    VALUES(?,?,?,?,?,?,?)
                    """,
                    (
                        source_id,
                        ordinal,
                        content,
                        locator,
                        _sha256(content.encode()),
                        vector.tobytes(),
                        self.embedder.identity,
                    ),
                )
                if self.db.fts_enabled:
                    self.db.conn.execute("INSERT INTO chunks_fts(chunk_id,content) VALUES(?,?)", (cursor.lastrowid, content))
        count = int(self.db.conn.execute("SELECT COUNT(*) AS n FROM chunks WHERE source_id=?", (source_id,)).fetchone()["n"])
        return IngestResult(source_id, source_key, path.name, count, digest, assessment.score, assessment.signals, quarantined)
