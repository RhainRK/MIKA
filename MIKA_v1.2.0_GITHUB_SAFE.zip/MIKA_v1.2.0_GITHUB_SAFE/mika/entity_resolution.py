from __future__ import annotations

from collections import defaultdict
from dataclasses import dataclass
from difflib import SequenceMatcher
import re
import unicodedata
from typing import Iterable, Mapping


_WORD = re.compile(r"[a-z0-9]+")
_LEGAL_SUFFIXES = {
    "co",
    "company",
    "corp",
    "corporation",
    "inc",
    "incorporated",
    "ltd",
    "limited",
    "llc",
    "plc",
}


@dataclass(frozen=True, slots=True)
class EntityRecord:
    entity_id: str
    name: str
    aliases: tuple[str, ...] = ()
    entity_type: str = "unknown"
    metadata: Mapping[str, str] | None = None


@dataclass(frozen=True, slots=True)
class EntityMatch:
    entity_id: str
    name: str
    entity_type: str
    matched_value: str
    score: float
    signals: tuple[str, ...]


def normalize_name(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    tokens = _WORD.findall(normalized.casefold())
    while tokens and tokens[-1] in _LEGAL_SUFFIXES:
        tokens.pop()
    return " ".join(tokens)


def _token_set(value: str) -> set[str]:
    return set(normalize_name(value).split())


def _score(query: str, candidate: str) -> tuple[float, tuple[str, ...]]:
    q_norm = normalize_name(query)
    c_norm = normalize_name(candidate)
    if not q_norm or not c_norm:
        return 0.0, ()
    if q_norm == c_norm:
        return 1.0, ("normalized_exact",)

    q_tokens = _token_set(q_norm)
    c_tokens = _token_set(c_norm)
    overlap = len(q_tokens & c_tokens) / len(q_tokens | c_tokens) if q_tokens | c_tokens else 0.0
    sequence = SequenceMatcher(None, q_norm, c_norm, autojunk=False).ratio()
    containment = 1.0 if q_norm in c_norm or c_norm in q_norm else 0.0
    score = 0.55 * sequence + 0.35 * overlap + 0.10 * containment

    signals: list[str] = []
    if overlap >= 0.8:
        signals.append("high_token_overlap")
    elif overlap >= 0.5:
        signals.append("token_overlap")
    if sequence >= 0.9:
        signals.append("high_string_similarity")
    if containment:
        signals.append("normalized_containment")
    return min(score, 1.0), tuple(signals)


class EntityResolver:
    def __init__(self, records: Iterable[EntityRecord]) -> None:
        self.records = tuple(records)
        self._token_index: dict[str, set[int]] = defaultdict(set)
        for index, record in enumerate(self.records):
            for value in (record.name, *record.aliases):
                for token in _token_set(value):
                    self._token_index[token].add(index)

    def resolve(self, query: str, *, threshold: float = 0.82, limit: int = 10) -> list[EntityMatch]:
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("threshold must be between 0 and 1")
        if limit < 1:
            raise ValueError("limit must be positive")

        query_tokens = _token_set(query)
        candidate_ids: set[int] = set()
        for token in query_tokens:
            candidate_ids.update(self._token_index.get(token, ()))
        if not candidate_ids:
            candidate_ids = set(range(len(self.records)))

        matches: list[EntityMatch] = []
        for index in candidate_ids:
            record = self.records[index]
            best_value = record.name
            best_score = 0.0
            best_signals: tuple[str, ...] = ()
            for value in (record.name, *record.aliases):
                score, signals = _score(query, value)
                if score > best_score:
                    best_value = value
                    best_score = score
                    best_signals = signals
            if best_score >= threshold:
                alias_signal = ("alias_match",) if best_value != record.name else ()
                matches.append(
                    EntityMatch(
                        entity_id=record.entity_id,
                        name=record.name,
                        entity_type=record.entity_type,
                        matched_value=best_value,
                        score=best_score,
                        signals=best_signals + alias_signal,
                    )
                )
        matches.sort(key=lambda item: (item.score, item.entity_id), reverse=True)
        return matches[:limit]
