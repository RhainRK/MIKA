from __future__ import annotations

from dataclasses import dataclass
import ipaddress
from pathlib import Path
import re
from urllib.parse import urlsplit


_SECRET = re.compile(
    r"(?i)(\b(?:api[_-]?key|token|password|passwd|secret|authorization|cookie)\b"
    r"[\"']?\s*[:=]\s*[\"']?)(?:bearer\s+)?[^\s&\"'<>;,}]+"
)
_BEARER = re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+")
_PROVIDER_KEY = re.compile(
    r"\b(?:sk-[A-Za-z0-9_-]{16,}|gh[pousr]_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,})\b"
)

_PATTERNS: tuple[tuple[re.Pattern[str], float, str], ...] = (
    (re.compile(r"(?i)\bignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?\b"), 0.45, "instruction_override"),
    (re.compile(r"(?i)\b(?:system|developer)\s+prompt\b"), 0.25, "prompt_reference"),
    (re.compile(r"(?i)\b(?:reveal|print|show|leak|expose)\b.{0,32}\b(?:secret|token|password|prompt)\b"), 0.35, "secret_exfiltration"),
    (re.compile(r"(?i)\b(?:call|invoke|execute|run)\b.{0,24}\b(?:tool|function|command)\b"), 0.20, "tool_directive"),
    (re.compile(r"(?i)\b(?:send|upload|exfiltrate|post)\b.{0,32}\b(?:data|content|secret|credentials?)\b"), 0.35, "data_exfiltration"),
    (re.compile(r"(?i)\b(?:you are now|act as|new role|override policy)\b"), 0.25, "role_override"),
)


@dataclass(frozen=True, slots=True)
class InjectionAssessment:
    score: float
    signals: tuple[str, ...]

    @property
    def suspicious(self) -> bool:
        return self.score >= 0.35


def redact_text(value: str) -> str:
    value = _SECRET.sub(r"\1[REDACTED]", value)
    value = _BEARER.sub("Bearer [REDACTED]", value)
    return _PROVIDER_KEY.sub("[REDACTED]", value)


def assess_prompt_injection(text: str) -> InjectionAssessment:
    score = 0.0
    signals: list[str] = []
    for pattern, weight, label in _PATTERNS:
        if pattern.search(text):
            score += weight
            signals.append(label)
    return InjectionAssessment(min(score, 1.0), tuple(dict.fromkeys(signals)))


def validate_endpoint(value: str) -> str:
    try:
        parsed = urlsplit(value)
        host = parsed.hostname
        _ = parsed.port
    except ValueError:
        raise ValueError("Invalid endpoint URL") from None
    if parsed.scheme not in {"http", "https"} or not host:
        raise ValueError("Endpoint requires an HTTP(S) URL")
    if parsed.username is not None or parsed.password is not None or parsed.query or parsed.fragment:
        raise ValueError("Use a base URL without credentials, query parameters or fragments")
    local = host.casefold() == "localhost"
    try:
        local = local or ipaddress.ip_address(host).is_loopback
    except ValueError:
        pass
    if parsed.scheme == "http" and not local:
        raise ValueError("Remote endpoints require HTTPS; plaintext is limited to loopback")
    return value


def safe_workspace_path(workspace: Path, candidate: str | Path) -> Path:
    root = workspace.expanduser().resolve()
    path = Path(candidate).expanduser()
    if not path.is_absolute():
        path = root / path
    path = path.resolve()
    try:
        path.relative_to(root)
    except ValueError:
        raise ValueError("Path escapes the configured workspace") from None
    return path
