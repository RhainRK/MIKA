from __future__ import annotations

from dataclasses import dataclass
import math
import re
import sqlite3

import numpy as np

from .embeddings import Embedder
from .storage import Database


_IDENTIFIER = re.compile(r"\b[A-Za-z][A-Za-z0-9_]*-\d{2,}\b")


@dataclass(frozen=True, slots=True)
class SearchHit:
    chunk_id: int
    source_id: int
    source_name: str
    locator: str
    content: str
    score: float
    semantic_score: float
    lexical_rank: int | None
    source_sha256: str
    injection_score: float

    def citation(self) -> str:
        return f"S{self.source_id}:C{self.chunk_id}"


def _fts_query(text: str) -> str:
    tokens = [
        token.replace("'", "")
        for token in re.findall(r"[\w']+", text.casefold())
        if len(token) > 1
    ]
    return " OR ".join(f'"{token}"' for token in tokens[:20])


class HybridRetriever:
    def __init__(self, db: Database, embedder: Embedder) -> None:
        self.db = db
        self.embedder = embedder

    def _lexical_ranks(self, query: str, include_quarantined: bool) -> dict[int, int]:
        if not self.db.fts_enabled:
            return {}
        expression = _fts_query(query)
        if not expression:
            return {}
        try:
            rows = self.db.conn.execute(
                """
                SELECT CAST(f.chunk_id AS INTEGER) AS chunk_id, bm25(chunks_fts) AS rank
                FROM chunks_fts f
                JOIN chunks c ON c.id=CAST(f.chunk_id AS INTEGER)
                JOIN sources s ON s.id=c.source_id
                WHERE chunks_fts MATCH ? AND (? OR s.quarantined=0)
                ORDER BY rank LIMIT 100
                """,
                (expression, int(include_quarantined)),
            ).fetchall()
        except sqlite3.OperationalError:
            return {}
        return {int(row["chunk_id"]): index + 1 for index, row in enumerate(rows)}

    def _semantic_scores(self, rows: list, query: str) -> dict[int, float]:
        q = self.embedder.encode(query).astype(np.float32, copy=False)
        ids: list[int] = []
        vectors: list[np.ndarray] = []
        updates: list[tuple[bytes, str, int]] = []
        missing_rows = [
            row
            for row in rows
            if not row["embedding"] or row["embedding_model"] != self.embedder.identity
        ]
        generated = iter(self.embedder.encode_many(row["content"] for row in missing_rows))

        for row in rows:
            if row["embedding"] and row["embedding_model"] == self.embedder.identity:
                vector = np.frombuffer(row["embedding"], dtype=np.float32)
            else:
                vector = next(generated).astype(np.float32, copy=False)
                updates.append((vector.tobytes(), self.embedder.identity, int(row["id"])))
            if vector.shape == q.shape:
                ids.append(int(row["id"]))
                vectors.append(vector)

        if updates:
            with self.db.conn:
                self.db.conn.executemany(
                    "UPDATE chunks SET embedding=?,embedding_model=? WHERE id=?",
                    updates,
                )
        if not vectors:
            return {}

        matrix = np.vstack(vectors)
        scores = matrix @ q
        return {chunk_id: float(score) for chunk_id, score in zip(ids, scores, strict=True)}

    def search(self, query: str, k: int = 6, *, include_quarantined: bool = False) -> list[SearchHit]:
        query = query.strip()
        if not query or k <= 0:
            return []

        lexical_order = self._lexical_ranks(query, include_quarantined)
        rows = self.db.conn.execute(
            """
            SELECT c.id,c.source_id,c.content,c.locator,c.embedding,c.embedding_model,
                   s.name AS source_name,s.sha256 AS source_sha256,s.injection_score
            FROM chunks c JOIN sources s ON s.id=c.source_id
            WHERE (? OR s.quarantined=0)
            """,
            (int(include_quarantined),),
        ).fetchall()
        if not rows:
            return []

        row_by_id = {int(row["id"]): row for row in rows}
        semantic_score = self._semantic_scores(rows, query)
        semantic_order = {
            chunk_id: rank
            for rank, (chunk_id, _) in enumerate(
                sorted(semantic_score.items(), key=lambda item: item[1], reverse=True),
                start=1,
            )
        }
        candidates = set(list(semantic_order)[:100]) | set(lexical_order)
        identifiers = {token.casefold() for token in _IDENTIFIER.findall(query)}

        ranked: list[tuple[float, int]] = []
        for chunk_id in candidates:
            srank = semantic_order.get(chunk_id)
            lrank = lexical_order.get(chunk_id)
            rrf = (1.0 / (60 + srank) if srank else 0.0) + (1.25 / (60 + lrank) if lrank else 0.0)
            score = rrf + max(0.0, semantic_score.get(chunk_id, -1.0)) * 0.001
            if identifiers:
                content = str(row_by_id[chunk_id]["content"]).casefold()
                score += 0.05 * sum(identifier in content for identifier in identifiers)
            ranked.append((score, chunk_id))

        ranked.sort(reverse=True)
        return [
            SearchHit(
                chunk_id=chunk_id,
                source_id=int(row_by_id[chunk_id]["source_id"]),
                source_name=row_by_id[chunk_id]["source_name"],
                locator=row_by_id[chunk_id]["locator"],
                content=row_by_id[chunk_id]["content"],
                score=score,
                semantic_score=semantic_score.get(chunk_id, math.nan),
                lexical_rank=lexical_order.get(chunk_id),
                source_sha256=row_by_id[chunk_id]["source_sha256"],
                injection_score=float(row_by_id[chunk_id]["injection_score"]),
            )
            for score, chunk_id in ranked[:k]
        ]
