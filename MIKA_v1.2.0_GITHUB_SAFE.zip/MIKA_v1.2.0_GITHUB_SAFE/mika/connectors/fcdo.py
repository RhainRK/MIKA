from __future__ import annotations

import csv
import hashlib
from io import StringIO
from pathlib import Path
from urllib.parse import urlparse
from urllib.request import Request, urlopen


UK_SANCTIONS_CSV_URL = "https://sanctionslist.fcdo.gov.uk/docs/UK-Sanctions-List.csv"
_ALLOWED_HOST = "sanctionslist.fcdo.gov.uk"
_ALLOWED_PATH = "/docs/UK-Sanctions-List.csv"
_MAX_BYTES = 25 * 1024 * 1024


def _validate_url(url: str) -> None:
    parsed = urlparse(url)
    allowed = (
        parsed.scheme == "https"
        and parsed.hostname == _ALLOWED_HOST
        and parsed.path == _ALLOWED_PATH
        and parsed.port in (None, 443)
        and parsed.username is None
        and parsed.password is None
        and not parsed.query
        and not parsed.fragment
    )
    if not allowed:
        raise ValueError("Connector only permits the official FCDO sanctions-list endpoint")


def parse_csv(text: str) -> list[dict[str, str]]:
    reader = csv.DictReader(StringIO(text))
    return [{str(key): value or "" for key, value in row.items()} for row in reader]


def fetch_uk_sanctions_csv(destination: Path, *, url: str = UK_SANCTIONS_CSV_URL, timeout: float = 20.0) -> dict:
    _validate_url(url)
    request = Request(url, headers={"User-Agent": "MIKA/1.1 public-data-connector"})
    with urlopen(request, timeout=timeout) as response:  # nosec B310 - fixed allow-listed HTTPS host
        content_type = response.headers.get("Content-Type", "")
        payload = response.read(_MAX_BYTES + 1)
    if len(payload) > _MAX_BYTES:
        raise ValueError("Remote dataset exceeds connector size limit")
    text = payload.decode("utf-8-sig", errors="replace")
    rows = parse_csv(text)
    if not rows:
        raise ValueError("Downloaded sanctions dataset contained no rows")
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(payload)
    return {
        "source_url": url,
        "destination": str(destination),
        "bytes": len(payload),
        "rows": len(rows),
        "sha256": hashlib.sha256(payload).hexdigest(),
        "content_type": content_type,
    }
