from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import Iterable


class Permission(str, Enum):
    READ_EVIDENCE = "read_evidence"
    READ_DATA = "read_data"
    EXECUTE_QUERY = "execute_query"
    WRITE_CASE = "write_case"
    USE_MODEL = "use_model"


ROLE_PERMISSIONS: dict[str, frozenset[Permission]] = {
    "viewer": frozenset({Permission.READ_EVIDENCE, Permission.READ_DATA}),
    "analyst": frozenset(
        {
            Permission.READ_EVIDENCE,
            Permission.READ_DATA,
            Permission.EXECUTE_QUERY,
            Permission.WRITE_CASE,
            Permission.USE_MODEL,
        }
    ),
    "reviewer": frozenset({Permission.READ_EVIDENCE, Permission.READ_DATA, Permission.EXECUTE_QUERY}),
}


@dataclass(frozen=True, slots=True)
class Decision:
    allowed: bool
    permission: Permission
    reason: str


class Policy:
    """Explicit allow-list policy. Empty permissions means deny everything."""

    def __init__(self, permissions: Iterable[Permission] = ()) -> None:
        self.permissions = frozenset(permissions)

    @classmethod
    def for_role(cls, role: str) -> "Policy":
        if role not in ROLE_PERMISSIONS:
            raise ValueError(f"Unknown role: {role}")
        return cls(ROLE_PERMISSIONS[role])

    def check(self, permission: Permission) -> Decision:
        if permission in self.permissions:
            return Decision(True, permission, "explicitly allowed")
        return Decision(False, permission, "default deny")
