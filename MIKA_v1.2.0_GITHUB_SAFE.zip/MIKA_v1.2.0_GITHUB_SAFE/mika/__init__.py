"""MIKA: Model Integrity & Knowledge Analysis."""

__version__ = "1.2.0"
