from __future__ import annotations

from .audit import AuditLog
from .cases import CaseStore
from .config import Settings, settings
from .embeddings import Embedder
from .provenance import EvidenceStore
from .retrieval import HybridRetriever
from .storage import Database
from .telemetry import Telemetry


class MikaApp:
    def __init__(self, config: Settings | None = None) -> None:
        self.settings = (config or settings).resolve()
        self.db = Database(self.settings.db_path)
        self.embedder = Embedder(self.settings.embedding_model)
        self.evidence = EvidenceStore(
            self.db,
            self.embedder,
            self.settings.workspace,
            self.settings.injection_quarantine_threshold,
        )
        self.retriever = HybridRetriever(self.db, self.embedder)
        self.audit = AuditLog(self.settings.audit_path)
        self.telemetry = Telemetry(self.db, self.settings.telemetry_path)
        self.cases = CaseStore(self.db)

    def close(self) -> None:
        self.db.close()
