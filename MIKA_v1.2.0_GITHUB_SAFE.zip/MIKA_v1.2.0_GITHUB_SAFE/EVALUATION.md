# Evaluation

MIKA separates deterministic system evaluation from subjective model quality.

## Core offline suite

Run:

```powershell
python main.py evaluate --output reports\evaluation-results.json
```

The suite measures:

- `Precision@k`: proportion of retrieved items that are relevant.
- `Recall@k`: proportion of expected relevant items recovered.
- `MRR`: reciprocal rank of the first relevant item.
- `nDCG@k`: ranking quality with discount for lower positions.
- Default-deny and explicit-allow tool authorization.
- Rejection of unknown/unadvertised tools.
- Prompt-injection source quarantine and default retrieval exclusion.
- Audit hash-chain integrity.
- Retrieval p50/p95/p99 latency.

## Reporting discipline

Bundled data is synthetic and intentionally small. Treat it as a regression suite, not proof of general retrieval quality. For a CV or public README, add a larger held-out benchmark and publish the exact dataset, environment and evaluation report used for any number you quote.
