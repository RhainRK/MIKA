type SearchHit = {
  citation: string;
  source_name: string;
  locator: string;
  content: string;
  score: number;
  source_sha256: string;
};

type Health = {
  version: string;
  audit_chain_valid: boolean;
  embedding_backend: string;
  sources: number;
  chunks: number;
};

type EvaluationSuite = {
  name: string;
  case_count: number;
  metrics: Record<string, { mean: number | null }>;
};

type Evaluation = {
  status: string;
  benchmark_suites: EvaluationSuite[];
  authorization: Record<string, boolean>;
  retrieval_security: Record<string, unknown>;
};

const form = document.querySelector<HTMLFormElement>("#search-form")!;
const query = document.querySelector<HTMLInputElement>("#query")!;
const results = document.querySelector<HTMLDivElement>("#results")!;
const health = document.querySelector<HTMLDivElement>("#health")!;
const benchmark = document.querySelector<HTMLDivElement>("#benchmark")!;

function escapeHtml(value: string): string {
  return value.replace(/[&<>'"]/g, (char) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;"
  }[char] ?? char));
}

function metric(value: number | null | undefined): string {
  return value == null ? "n/a" : value.toFixed(3);
}

async function loadHealth(): Promise<void> {
  const response = await fetch("/api/health");
  if (!response.ok) throw new Error(`health ${response.status}`);
  const body = await response.json() as Health;
  health.innerHTML = `
    <strong>MIKA ${escapeHtml(body.version)}</strong>
    <span>${body.audit_chain_valid ? "audit verified" : "audit failed"}</span>
    <span>${escapeHtml(body.embedding_backend)}</span>
    <span>${body.sources} sources / ${body.chunks} chunks</span>`;
}

async function loadEvaluation(): Promise<void> {
  const response = await fetch("/api/evaluation/latest");
  if (response.status === 404) {
    benchmark.textContent = "No evaluation report yet. Run python main.py evaluate.";
    return;
  }
  if (!response.ok) throw new Error(`evaluation ${response.status}`);
  const body = await response.json() as Evaluation;
  const suite = body.benchmark_suites[body.benchmark_suites.length - 1];
  if (!suite) return;
  benchmark.innerHTML = `
    <div><strong>${escapeHtml(suite.name)}</strong> · ${suite.case_count} cases · ${escapeHtml(body.status)}</div>
    <div class="metrics">
      <span>Recall@k ${metric(suite.metrics.recall_at_k?.mean)}</span>
      <span>MRR ${metric(suite.metrics.mrr?.mean)}</span>
      <span>nDCG ${metric(suite.metrics.ndcg_at_k?.mean)}</span>
    </div>`;
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const q = query.value.trim();
  if (!q) return;
  results.textContent = "Searching evidence...";
  const response = await fetch(`/api/search?q=${encodeURIComponent(q)}&k=6`);
  if (!response.ok) {
    results.textContent = `Search failed (${response.status})`;
    return;
  }
  const hits = await response.json() as SearchHit[];
  results.innerHTML = hits.length === 0
    ? "<p>No trusted evidence matched.</p>"
    : hits.map((hit) => `
      <article>
        <header><strong>${escapeHtml(hit.citation)}</strong> · ${escapeHtml(hit.source_name)}</header>
        <small>${escapeHtml(hit.locator)} · score ${hit.score.toFixed(4)}</small>
        <p>${escapeHtml(hit.content)}</p>
        <code>sha256:${escapeHtml(hit.source_sha256.slice(0, 16))}…</code>
      </article>`).join("");
});

Promise.all([loadHealth(), loadEvaluation()]).catch(() => {
  health.textContent = "system status unavailable";
});
