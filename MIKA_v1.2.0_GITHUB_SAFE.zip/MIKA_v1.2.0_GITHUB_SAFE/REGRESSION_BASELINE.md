# MIKA v1.2.0 regression baseline

This baseline is generated from bundled deterministic **synthetic** regression corpora. It exists to catch engineering regressions and does not establish production-domain accuracy.

## Verification

- Python tests: **33 passed**
- Measured Python coverage: **78%**
- Core authorization/security regression: **passed**
- Default-deny authorization: **passed**
- Explicit allow: **passed**
- Unadvertised tool rejection: **passed**
- Malicious-source quarantine: **passed**
- Quarantined-source exclusion: **passed**
- Audit-chain verification: **passed**

## Operational retrieval suite

- Cases: **120**
- Precision@5: **0.200**
- Recall@5: **1.000**
- MRR: **1.000**
- nDCG@5: **1.000**
- Benchmark definition SHA-256: `2fec1dea23b7456c3b0d4d8e33f69a6df59ca17f438550e8bcb6b03deabb0f43`
- Evidence snapshot SHA-256: `850a5a96bf60bcb6745bb09cbae1aa2c95ae4aad4aafd64cf2f2a3f9532c67a8`

Precision@5 is 0.2 because each query has one relevant record and the evaluator deliberately retrieves five results. Recall/MRR/nDCG are therefore more informative for this single-relevant-document regression design.

## Local latency sample

A 100-query local run using deterministic hash embeddings produced approximately millisecond-scale retrieval latency on the build environment. Treat local latency as hardware/corpus dependent; run `python main.py evaluate --repeats 100` on the target machine before quoting it externally.

## Reproduce

```powershell
pytest --cov=mika --cov-report=term
python main.py evaluate --output reports\evaluation-results.json --repeats 100
```
