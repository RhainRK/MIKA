# MIKA

**Model Integrity & Knowledge Analysis** is a local evidence-intelligence and AI-assurance workbench for analysing operational data with measurable retrieval quality, explicit provenance, constrained tool execution and reviewable analytical outputs.

MIKA treats the language model as a replaceable component. The core system is deterministic Python around **evidence, entities, relationships, policies, cases, audit events, telemetry and benchmark runs**.

## Engineering highlights

- Hybrid retrieval using SQLite FTS5/BM25 signals, semantic embeddings, reciprocal-rank fusion and structured-identifier boosting.
- Batched embedding generation and vectorized NumPy similarity scoring.
- Source and chunk provenance using SHA-256 fingerprints and stable evidence locators.
- Versioned retrieval evaluation with Precision@k, Recall@k, MRR, nDCG and bootstrap confidence intervals.
- Explainable entity resolution with normalization, token blocking, alias matching and deterministic/fuzzy similarity scoring.
- Relationship analysis using adjacency lists and bounded breadth-first shortest-path traversal.
- Default-deny typed tool authorization enforced outside the LLM with Pydantic schemas.
- Prompt-injection heuristics, evidence quarantine, workspace confinement and bounded read-only SQLite access.
- Thread-safe tamper-evident audit logging using a chained SHA-256 record structure.
- Structured cases with findings, linked evidence, confidence, alternative hypotheses and limitations.
- GenAI-style structured telemetry for model/retrieval operations, tokens, errors and latency.
- FastAPI service and strict TypeScript analyst console.
- Docker packaging and GitHub Actions gates for compile, lint, typing, security scan, coverage, regression evaluation and frontend compilation.

## Verified regression state

The bundled deterministic regression suite is intentionally synthetic and exists to detect engineering regressions rather than claim production-domain accuracy.

- Python tests: **33 passing**.
- Measured Python coverage: **78%**.
- Operational retrieval suite: **120 cases**.
- Recall@5: **1.000**.
- MRR: **1.000**.
- nDCG@5: **1.000**.
- Default-deny authorization: **pass**.
- Unknown tool rejection: **pass**.
- Prompt-injection quarantine: **pass**.
- Audit-chain verification: **pass**.

See `REGRESSION_BASELINE.md` and `reports/evaluation-results.json` for dataset fingerprints and limitations.

## Architecture

```text
                    +----------------------+
Local / public data | ingestion + hashing  |
------------------->| injection assessment |
                    +----------+-----------+
                               |
                  trusted -----+----- quarantined
                               |
                               v
                    +----------------------+
                    | provenance + chunks  |
                    +----------+-----------+
                               |
            +------------------+------------------+
            |                                     |
            v                                     v
 +----------------------+              +----------------------+
 | hybrid retrieval     |              | entity resolution    |
 | FTS5 + embeddings    |              | aliases + blocking   |
 | RRF + ID boosting    |              | explainable scoring  |
 +----------+-----------+              +----------+-----------+
            |                                     |
            +------------------+------------------+
                               |
                               v
                    +----------------------+
                    | cases / relationships|
                    | BFS graph analysis   |
                    | findings + confidence|
                    +----------+-----------+
                               |
                               v
                    +----------------------+
                    | grounded LLM analyst |
                    | citations + limits   |
                    +----------------------+

Typed tools -> default-deny policy -> audit hash chain
All major stages -> structured telemetry -> evaluation reports
```

## Quick start

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -U pip
pip install -r requirements.txt
python main.py doctor
python main.py evaluate
```

Development environment:

```powershell
pip install -e ".[dev,server]"
pytest --cov=mika --cov-report=term
python main.py evaluate --repeats 100
```

Optional semantic model:

```powershell
pip install -r requirements-semantic.txt
```

Optional local LLM:

```powershell
pip install -r requirements-llm.txt
ollama pull qwen3.5:4b
python main.py ask "What evidence explains the reconciliation anomaly?"
```

## Analyst workflows

### Evidence retrieval

```powershell
python main.py ingest samples\benchmark_evidence.txt
python main.py search "tool authorization policy"
```

### Data quality

```powershell
python main.py profile samples\operations_incidents.csv
```

### Entity resolution

```powershell
python main.py entity-resolve samples\entities.csv "Northstar Comp"
```

### Relationship path analysis

```powershell
python main.py graph-path samples\relationships.csv "Maya Chen" "Helios Research Group"
```

### Public-data connector

```powershell
python main.py fetch-uk-sanctions
python main.py entity-resolve data\uk-sanctions-list.csv "Example Name" --threshold 0.90
```

The connector is restricted to the official FCDO UK Sanctions List HTTPS endpoint and records a SHA-256 digest of the downloaded dataset. MIKA is not a compliance decision system; matches require analyst review.

### Case workflow

```powershell
python main.py case-create "Reconciliation review" --objective "Explain the unresolved-record anomaly"
python main.py case-attach <case_id> <chunk_id>
python main.py case-finding <case_id> "Queue depth exceeded the review threshold." --confidence 0.85 --evidence <chunk_id> --alternative "Delayed upstream feed" --limitation "Single nightly snapshot"
python main.py case-report <case_id> --output reports\case-brief.md
```

### Analyst console

```powershell
pip install -r requirements-server.txt
python main.py serve
```

Open `http://127.0.0.1:8000`.

## Security model

The LLM is not a security boundary. Tool authorization, path restrictions, SQL restrictions, quarantine filtering and audit verification are deterministic controls outside model generation. Retrieved documents are treated as untrusted data. See `SECURITY.md`.

## Evaluation

`python main.py evaluate` generates a machine-readable report containing:

- benchmark and source SHA-256 fingerprints,
- ranking metrics and bootstrap intervals,
- authorization tests,
- prompt-injection quarantine checks,
- audit-chain verification,
- local p50/p95/p99 retrieval latency,
- explicit limitations.

The bundled 120-case operations benchmark is synthetic. Replace it with a domain-specific held-out dataset before making real-world performance claims.
