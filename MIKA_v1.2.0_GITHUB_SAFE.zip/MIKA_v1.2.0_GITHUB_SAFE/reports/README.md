# Reports

Generated benchmark and case reports are written here and ignored by Git by default. Reproduce them with `python main.py evaluate` or `python main.py case-report ...`.
