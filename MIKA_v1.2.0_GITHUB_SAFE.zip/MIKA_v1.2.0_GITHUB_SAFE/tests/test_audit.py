import json
from pathlib import Path

from mika.audit import AuditLog


def test_audit_chain_detects_tamper(tmp_path: Path):
    path = tmp_path / "audit.jsonl"
    audit = AuditLog(path)
    audit.record("a", {"value": 1})
    audit.record("b", {"value": 2})
    assert audit.verify()[0]
    lines = path.read_text().splitlines()
    item = json.loads(lines[0])
    item["payload"]["value"] = 999
    lines[0] = json.dumps(item)
    path.write_text("\n".join(lines) + "\n")
    assert not audit.verify()[0]
