import pytest

from mika.connectors.fcdo import _validate_url, parse_csv


def test_fcdo_connector_rejects_non_allowlisted_host():
    with pytest.raises(ValueError):
        _validate_url("https://example.com/list.csv")


def test_fcdo_csv_parser():
    rows = parse_csv("id,name\n1,Example\n")
    assert rows == [{"id": "1", "name": "Example"}]
