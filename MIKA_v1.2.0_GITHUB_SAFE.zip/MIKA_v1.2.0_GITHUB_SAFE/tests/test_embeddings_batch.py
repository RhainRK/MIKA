import numpy as np

from mika.embeddings import Embedder


def test_encode_many_matches_single_encode_and_preserves_order():
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    texts = ["alpha beta", "gamma delta", "alpha beta"]
    batch = embedder.encode_many(texts)
    assert len(batch) == len(texts)
    for text, vector in zip(texts, batch, strict=True):
        assert np.allclose(vector, embedder.encode(text))
