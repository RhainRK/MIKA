from mika.relationships import Edge, RelationshipGraph


def test_shortest_path_and_degree_ranking():
    graph = RelationshipGraph(
        [
            Edge("A", "B", "supplies"),
            Edge("B", "C", "delivers"),
            Edge("B", "D", "owns"),
        ]
    )
    path = graph.shortest_path("A", "C")
    assert [(step.source, step.target) for step in path] == [("A", "B"), ("B", "C")]
    assert graph.degree_ranking(limit=1) == [{"node": "B", "degree": 3}]


def test_shortest_path_respects_depth_limit():
    graph = RelationshipGraph([Edge("A", "B", "x"), Edge("B", "C", "x")])
    assert graph.shortest_path("A", "C", max_depth=1) == []
