from pathlib import Path

from mika.evaluation.runner import run_suite


def test_core_evaluation_suite(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    report = run_suite(root, tmp_path / "results.json", repeats=5)
    assert report["status"] == "passed"
    assert report["authorization"]["default_deny_passed"]
    assert report["retrieval_security"]["malicious_source_quarantined"]
