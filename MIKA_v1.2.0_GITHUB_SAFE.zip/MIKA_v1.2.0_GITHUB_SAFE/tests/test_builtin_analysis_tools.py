from pathlib import Path

from mika.audit import AuditLog
from mika.cases import CaseStore
from mika.embeddings import Embedder
from mika.policy import Policy
from mika.retrieval import HybridRetriever
from mika.storage import Database
from mika.tools.base import ToolCall
from mika.tools.builtins import register_builtin_tools
from mika.tools.registry import ToolRegistry


def _registry(root: Path):
    db = Database(root / "test.sqlite3")
    registry = ToolRegistry(Policy.for_role("viewer"), AuditLog(root / "audit.jsonl"))
    register_builtin_tools(
        registry,
        retriever=HybridRetriever(db, Embedder("__force_hash_backend__")),
        workspace=root,
        cases=CaseStore(db),
    )
    return db, registry


def test_entity_and_graph_tools(tmp_path: Path):
    (tmp_path / "entities.csv").write_text(
        "id,name,alias,type\n1,Northstar Components Ltd,Northstar Comp,organisation\n",
        encoding="utf-8",
    )
    (tmp_path / "graph.csv").write_text(
        "source,target,relation\nA,B,supplies\nB,C,delivers\n",
        encoding="utf-8",
    )
    db, registry = _registry(tmp_path)
    try:
        entity = registry.execute(
            ToolCall(
                "entity.resolve",
                {
                    "path": "entities.csv",
                    "query": "Northstar Comp",
                    "id_column": "id",
                    "name_columns": ["name"],
                    "alias_columns": ["alias"],
                    "type_column": "type",
                },
            )
        )
        graph = registry.execute(
            ToolCall(
                "graph.shortest_path",
                {"path": "graph.csv", "source": "A", "target": "C"},
            )
        )
        assert entity.success and entity.output["matches"][0]["entity_id"] == "1"
        assert graph.success and graph.output["hops"] == 2
    finally:
        db.close()
