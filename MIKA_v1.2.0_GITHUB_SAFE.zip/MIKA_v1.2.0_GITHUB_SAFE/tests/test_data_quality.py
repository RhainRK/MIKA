from pathlib import Path

from mika.data_quality import profile_csv


def test_profile_csv_detects_keys_missingness_and_duplicates(tmp_path: Path):
    path = tmp_path / "records.csv"
    path.write_text("id,value,note\n1,10,x\n2,,x\n2,,x\n", encoding="utf-8")
    profile = profile_csv(path)
    assert profile["rows"] == 3
    assert profile["duplicate_rows"] == 1
    assert profile["column_stats"]["value"]["missing"] == 2
    assert any(issue["check"] == "missingness" for issue in profile["issues"])
