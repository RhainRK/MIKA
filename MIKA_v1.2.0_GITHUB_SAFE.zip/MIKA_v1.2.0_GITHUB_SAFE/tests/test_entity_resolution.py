from mika.entity_resolution import EntityRecord, EntityResolver, normalize_name


def test_normalize_name_removes_case_punctuation_and_legal_suffix():
    assert normalize_name("Northstar Components, Ltd.") == "northstar components"


def test_entity_resolution_exact_and_alias():
    resolver = EntityResolver(
        [
            EntityRecord("1", "Northstar Components Ltd", ("Northstar Comp",), "organisation"),
            EntityRecord("2", "Asterion Logistics PLC", (), "organisation"),
        ]
    )
    exact = resolver.resolve("Northstar Components", threshold=0.8)
    alias = resolver.resolve("Northstar Comp", threshold=0.8)
    assert exact[0].entity_id == "1"
    assert exact[0].score == 1.0
    assert alias[0].entity_id == "1"
    assert "alias_match" in alias[0].signals


def test_entity_resolution_rejects_weak_match():
    resolver = EntityResolver([EntityRecord("1", "Northstar Components")])
    assert resolver.resolve("Completely Different", threshold=0.9) == []
