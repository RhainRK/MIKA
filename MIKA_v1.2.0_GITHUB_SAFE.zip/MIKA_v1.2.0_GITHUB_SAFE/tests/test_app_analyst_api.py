from pathlib import Path

from fastapi.testclient import TestClient

from mika.analyst import AnalystEngine
from mika.app import MikaApp
from mika.config import Settings
from mika.embeddings import Embedder
from mika.llm import ModelResponse
from mika.provenance import EvidenceStore
from mika.retrieval import HybridRetriever
from mika.storage import Database


class FakeLLM:
    model = "test-model"

    def chat(self, messages, *, temperature=0.0, max_tokens=700):
        assert messages[-1]["role"] == "user"
        return ModelResponse("Supported by [S1:C1].", 0.01, 12, 6, 600.0)


def _settings(tmp_path: Path) -> Settings:
    return Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
    ).resolve()


def test_mika_app_composes_and_closes(tmp_path: Path):
    app = MikaApp(_settings(tmp_path))
    assert app.settings.workspace == tmp_path.resolve()
    assert app.db.fts_enabled in {True, False}
    app.close()


def test_analyst_engine_returns_grounded_metadata(tmp_path: Path):
    db = Database(tmp_path / "analyst.sqlite3")
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    evidence_path = tmp_path / "evidence.txt"
    evidence_path.write_text("CASE-100 reconciled after the upstream file arrived.", encoding="utf-8")
    store = EvidenceStore(db, embedder, tmp_path)
    source = store.ingest_path("evidence.txt")
    result = AnalystEngine(HybridRetriever(db, embedder), FakeLLM()).answer("What happened to CASE-100?", 3)
    assert source.chunks == 1
    assert result.model == "test-model"
    assert result.evidence[0]["citation"].startswith("S")
    assert "[S1:C1]" in result.answer
    db.close()


def test_api_health_search_and_tools(tmp_path: Path, monkeypatch):
    config = _settings(tmp_path)
    seed = MikaApp(config)
    seed.embedder._backend = "hash"
    (tmp_path / "evidence.txt").write_text("CASE-200 inventory variance was reviewed.", encoding="utf-8")
    seed.evidence.ingest_path("evidence.txt")
    seed.close()

    import mika.api as api_module

    real_app = MikaApp

    def factory():
        app = real_app(config)
        app.embedder._backend = "hash"
        return app

    monkeypatch.setattr(api_module, "MikaApp", factory)
    client = TestClient(api_module.create_app())

    health = client.get("/api/health")
    search = client.get("/api/search", params={"q": "CASE-200", "k": 3})
    tools = client.get("/api/tools", params={"role": "viewer"})

    assert health.status_code == 200
    assert health.json()["sources"] == 1
    assert search.status_code == 200
    assert search.json()[0]["source_name"] == "evidence.txt"
    assert tools.status_code == 200
    assert any(item["name"] == "entity.resolve" for item in tools.json()["tools"])
