from pathlib import Path

from mika.cases import CaseStore
from mika.embeddings import Embedder
from mika.provenance import EvidenceStore
from mika.storage import Database


def test_case_report_contains_confidence_alternatives_limitations(tmp_path: Path):
    (tmp_path / "doc.txt").write_text("Observed queue depth was 37 records.")
    db = Database(tmp_path / "mika.sqlite3")
    embedder = Embedder("fixture"); embedder._backend = "hash"
    try:
        store = EvidenceStore(db, embedder, tmp_path)
        result = store.ingest_path("doc.txt")
        chunk_id = int(db.conn.execute("SELECT id FROM chunks WHERE source_id=?", (result.source_id,)).fetchone()["id"])
        cases = CaseStore(db)
        case_id = cases.create("Queue review", "Explain the queue anomaly")
        cases.attach_evidence(case_id, [chunk_id])
        cases.add_finding(case_id, "Queue depth exceeded threshold.", 0.8, evidence_chunk_ids=[chunk_id], alternatives=["Late upstream feed"], limitations=["Single snapshot"])
        report = cases.report_markdown(case_id)
        assert "80%" in report and "Alternative explanations" in report and "Limitations" in report
    finally:
        db.close()
