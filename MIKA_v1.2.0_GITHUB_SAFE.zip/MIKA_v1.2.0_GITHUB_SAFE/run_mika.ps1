$ErrorActionPreference = "Stop"
if (-not (Test-Path ".venv")) { py -3.11 -m venv .venv }
.\.venv\Scripts\python.exe -m pip install -q -r requirements.txt
.\.venv\Scripts\python.exe main.py doctor
