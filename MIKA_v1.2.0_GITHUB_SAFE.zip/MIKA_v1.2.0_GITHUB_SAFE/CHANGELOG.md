# Changelog

## 1.2.0

- Added explainable entity resolution with token blocking, alias matching and weighted fuzzy scoring.
- Added relationship analysis with adjacency lists and bounded breadth-first shortest-path traversal.
- Added CSV data-quality profiling with missingness, uniqueness, duplicate and candidate-key checks.
- Added an exact allow-listed FCDO public-data connector.
- Vectorized semantic scoring and batched embedding generation.
- Added benchmark/source SHA-256 fingerprints and bootstrap confidence intervals.
- Added thread-safe audit-chain appends and telemetry redaction.
- Expanded FastAPI health/evaluation endpoints and strict TypeScript analyst console.
- Added Docker non-root execution and CI gates for linting, typing, security scanning, coverage and frontend compilation.
- Expanded the automated suite to 33 tests with 78% measured Python coverage.

## 1.1.0

- Added a 120-case operational retrieval regression suite.
- Added FastAPI/TypeScript analyst interface and public-data connector scaffolding.
- Added reciprocal-rank fusion and structured-identifier ranking support.

## 1.0.0

- Established a personality-free evidence-analysis and AI-assurance architecture.
- Added provenance-bearing ingestion, hybrid retrieval, evaluation, default-deny typed tools, prompt-injection quarantine, read-only data tooling, tamper-evident audit logging, case reporting and local-model analysis.
