# ADR 0002: Provenance-first retrieval

## Status
Accepted

## Decision
Every ingested source receives a SHA-256 digest; each evidence chunk stores a locator and content digest. Retrieval returns provenance metadata with every hit.

## Rationale
Analytical conclusions must be reproducible and reviewable. A high retrieval score without source identity is insufficient for evidence-backed analysis.
