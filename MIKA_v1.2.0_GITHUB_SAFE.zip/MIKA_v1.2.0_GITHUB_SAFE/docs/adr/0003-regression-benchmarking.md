# ADR 0003: Separate regression benchmarks from production claims

## Status
Accepted

## Decision
Bundled benchmark suites are deterministic and versioned. Reports identify whether data is synthetic and include confidence intervals and limitations. Production-quality claims require a separate domain dataset and hardware/model disclosure.

## Rationale
Portfolio benchmarks should detect regressions without encouraging unsupported claims about real-world accuracy.
