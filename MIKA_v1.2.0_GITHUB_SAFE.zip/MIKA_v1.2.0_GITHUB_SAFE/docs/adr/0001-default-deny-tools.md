# ADR 0001: Enforce tool authorization outside the model

## Status
Accepted

## Decision
Tool permissions are evaluated by a deterministic policy layer before argument validation or handler execution. The empty permission set denies all tools, unknown tools are rejected, and every execution/denial is written to the audit chain.

## Rationale
Model output is untrusted. Authorization must not depend on the model obeying prompt instructions or accurately representing user intent.

## Consequences
Adding a tool requires an explicit permission, typed schema and policy decision. This adds ceremony but makes the trust boundary testable and reviewable.
