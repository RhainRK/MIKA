from __future__ import annotations

import argparse
import json
import sys
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from . import __version__
from .analyst import AnalystEngine
from .app import MikaApp
from .connectors import fetch_uk_sanctions_csv
from .evaluation import run_suite
from .llm import OllamaClient
from .policy import Policy
from .screening import ScreeningConfig, evaluate_labels, load_inputs, load_labels, screen
from .tools.base import ToolCall
from .tools.builtins import register_builtin_tools
from .tools.registry import ToolRegistry


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False, default=str))


def _add_evidence_filters(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--source", action="append", type=int, dest="source_ids")
    parser.add_argument("--chunk", action="append", type=int, dest="chunk_ids")
    parser.add_argument("--case", dest="case_id")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mika", description="MIKA - Model Integrity & Knowledge Analysis"
    )
    parser.add_argument("--version", action="version", version=f"MIKA {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="Check local configuration and integrity")

    ingest = sub.add_parser("ingest", help="Ingest evidence with provenance")
    ingest.add_argument("path")

    sources = sub.add_parser("sources", help="List the source register")
    sources.add_argument("--trusted-only", action="store_true")

    source = sub.add_parser("source", help="Inspect one source and its chunks")
    source.add_argument("source_id", type=int)

    search = sub.add_parser("search", help="Hybrid search over trusted evidence")
    search.add_argument("query")
    search.add_argument("--k", type=int, default=6)
    _add_evidence_filters(search)

    ask = sub.add_parser("ask", help="Generate a grounded local-model analysis")
    ask.add_argument("query")
    ask.add_argument("--k", type=int, default=6)
    _add_evidence_filters(ask)

    case_create = sub.add_parser("case-create", help="Create an analysis case")
    case_create.add_argument("title")
    case_create.add_argument("--objective", default="")

    sub.add_parser("cases", help="List analysis cases")

    case_attach = sub.add_parser("case-attach", help="Attach evidence to a case")
    case_attach.add_argument("case_id")
    case_attach.add_argument("chunk_ids", nargs="+", type=int)

    finding = sub.add_parser("case-finding", help="Record a finding")
    finding.add_argument("case_id")
    finding.add_argument("statement")
    finding.add_argument("--confidence", required=True, type=float)
    finding.add_argument("--evidence", nargs="*", type=int, default=[])
    finding.add_argument("--alternative", action="append", default=[])
    finding.add_argument("--limitation", action="append", default=[])

    report = sub.add_parser("case-report", help="Export an evidence-backed briefing")
    report.add_argument("case_id")
    report.add_argument("--output", type=Path)

    backup = sub.add_parser("backup", aliases=["database-backup"], help="Create a database backup")
    backup.add_argument("--output", type=Path)

    evaluate = sub.add_parser("evaluate", help="Run retrieval/security/latency benchmarks")
    evaluate.add_argument("--output", type=Path, default=Path("reports/evaluation-results.json"))
    evaluate.add_argument("--repeats", type=int, default=20)

    sub.add_parser("audit-verify", help="Verify the audit hash chain")

    tools = sub.add_parser("tools", help="List tools allowed for a role")
    tools.add_argument("--role", choices=["viewer", "analyst", "reviewer"], default="analyst")

    tool_run = sub.add_parser("tool-run", help="Execute a typed tool through policy enforcement")
    tool_run.add_argument("name")
    tool_run.add_argument("--args", default="{}", help="JSON object containing tool arguments")
    tool_run.add_argument("--role", choices=["viewer", "analyst", "reviewer"], default="analyst")

    resolve = sub.add_parser("entity-resolve", help="Resolve an entity against a workspace CSV")
    resolve.add_argument("path")
    resolve.add_argument("query")
    resolve.add_argument("--threshold", type=float, default=0.82)
    resolve.add_argument("--limit", type=int, default=10)

    graph = sub.add_parser("graph-path", help="Trace a relationship path through a CSV edge list")
    graph.add_argument("path")
    graph.add_argument("source")
    graph.add_argument("target")
    graph.add_argument("--max-depth", type=int, default=6)

    profile = sub.add_parser("profile", help="Profile CSV data quality")
    profile.add_argument("path")

    fetch = sub.add_parser(
        "fetch-uk-sanctions", help="Fetch the official FCDO UK Sanctions List CSV"
    )
    fetch.add_argument("--output", default="data/uk-sanctions-list.csv")

    screening = sub.add_parser(
        "screen", help="Screen a portfolio for sanctions and ownership-derived exposure"
    )
    screening.add_argument(
        "--dir",
        type=Path,
        help="Folder holding holdings.csv, entities.csv, ownership.csv and watchlist.csv",
    )
    for name in ("holdings", "entities", "ownership", "watchlist"):
        screening.add_argument(f"--{name}", help=f"{name} CSV (overrides --dir)")
    screening.add_argument("--labels", help="Expected-status CSV to score the run against")
    screening.add_argument("--output", type=Path, default=Path("reports/screening-latest.json"))
    screening.add_argument(
        "--create-cases", action="store_true", help="Open an evidence-backed case per flag"
    )
    screening.add_argument("--ownership-threshold", type=float, default=50.0)
    screening.add_argument("--review-share", type=float, default=25.0)

    serve = sub.add_parser("serve", help="Run the analyst API and TypeScript console")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    return parser


def _registry(app: MikaApp, role: str) -> ToolRegistry:
    registry = ToolRegistry(Policy.for_role(role), app.audit)
    register_builtin_tools(
        registry,
        retriever=app.retriever,
        workspace=app.settings.workspace,
        cases=app.cases,
    )
    return registry


def _run_tool(app: MikaApp, name: str, arguments: dict[str, Any], *, role: str = "analyst") -> int:
    result = _registry(app, role).execute(ToolCall(name, arguments))
    _json(
        {
            "name": result.name,
            "success": result.success,
            "output": result.output,
            "error": result.error,
        }
    )
    return 0 if result.success else 1


def _selected_chunks(
    app: MikaApp, case_id: str | None, chunk_ids: list[int] | None
) -> list[int] | None:
    if case_id is None:
        return chunk_ids
    case_chunks = app.cases.evidence_chunk_ids(case_id)
    if chunk_ids is None:
        return case_chunks
    return sorted(set(case_chunks).intersection(chunk_ids))


def _workspace_output(app: MikaApp, requested: Path, label: str) -> Path:
    candidate = requested.expanduser()
    if not candidate.is_absolute():
        candidate = app.settings.workspace / candidate
    target = candidate.resolve()
    try:
        relative = target.relative_to(app.settings.workspace)
    except ValueError:
        raise SystemExit(f"{label} output must remain inside the MIKA workspace") from None
    cursor = app.settings.workspace
    for part in relative.parts:
        if part.startswith(".") or ":" in part or part.endswith((".", " ")):
            raise SystemExit(f"{label} output contains a forbidden path component")
        cursor = cursor / part
        if cursor.exists() and cursor.is_symlink():
            raise SystemExit(f"{label} output cannot traverse symbolic links")
    return target


def _backup_path(app: MikaApp, requested: Path | None) -> Path:
    if requested is None:
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        requested = Path("data/backups") / f"mika-{stamp}.sqlite3"
    return _workspace_output(app, requested, "Backup")


def _screen(app: MikaApp, args: argparse.Namespace) -> int:
    from .screening.cases import open_cases

    output = _workspace_output(app, args.output, "Screening")
    paths: dict[str, str] = {}
    for name in ("holdings", "entities", "ownership", "watchlist"):
        explicit = getattr(args, name)
        if explicit is None and args.dir is None:
            raise SystemExit(f"Provide --dir or --{name}")
        paths[name] = explicit or str(args.dir / f"{name}.csv")
    try:
        config = ScreeningConfig(
            ownership_threshold=args.ownership_threshold, review_share=args.review_share
        )
        report = screen(load_inputs(app.settings.workspace, **paths), config)
        if args.labels:
            report["evaluation"] = evaluate_labels(
                report, load_labels(app.settings.workspace, args.labels)
            )
    except ValueError as exc:
        raise SystemExit(f"Screening failed: {exc}") from None
    if args.create_cases:
        report["cases"] = open_cases(app, report)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    app.audit.record(
        "screening.run",
        {
            "inputs": {name: meta["sha256"] for name, meta in report["inputs"].items()},
            "statuses": {k: v["count"] for k, v in report["summary"]["by_status"].items()},
            "cases_opened": len(report.get("cases", [])),
            "output": output.relative_to(app.settings.workspace).as_posix(),
        },
    )
    summary = dict(report["summary"]) | {
        "output": output.relative_to(app.settings.workspace).as_posix()
    }
    if "evaluation" in report:
        summary["evaluation"] = {
            key: report["evaluation"][key] for key in ("accuracy", "blocked", "flagged")
        }
    if "cases" in report:
        summary["cases_opened"] = len(report["cases"])
    _json(summary)
    return 0


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    root = Path(__file__).resolve().parents[1]

    if args.command == "evaluate":
        report = run_suite(root, args.output.resolve(), repeats=args.repeats)
        _json(report)
        return 0 if report["status"] == "passed" else 1

    if args.command == "fetch-uk-sanctions":
        destination = (root / args.output).resolve()
        if root.resolve() not in destination.parents:
            raise SystemExit("--output must remain inside the MIKA workspace")
        _json(fetch_uk_sanctions_csv(destination))
        return 0

    if args.command == "serve":
        try:
            import uvicorn
        except ImportError as exc:
            raise SystemExit('Install the server extra with `pip install -e ".[server]"`') from exc
        if args.host not in {"127.0.0.1", "::1"}:
            raise SystemExit("MIKA only serves on 127.0.0.1 or ::1")
        import secrets

        from .api import create_app

        password = secrets.token_urlsafe(32)
        print("Local browser login: username mika", flush=True)
        print(f"Session password: {password}", flush=True)
        uvicorn.run(
            create_app(password=password),
            host=args.host,
            port=args.port,
            reload=False,
            proxy_headers=False,
            access_log=False,
            limit_concurrency=16,
            timeout_keep_alive=5,
            server_header=False,
            h11_max_incomplete_event_size=16384,
        )
        return 0

    app = MikaApp()
    try:
        if args.command == "doctor":
            valid, records, error = app.audit.verify()
            _json(
                {
                    "version": __version__,
                    "database": str(app.settings.db_path),
                    "database_schema": int(
                        app.db.conn.execute("PRAGMA user_version").fetchone()[0]
                    ),
                    "workspace": str(app.settings.workspace),
                    "fts5": app.db.fts_enabled,
                    "embedding_backend": app.embedder.backend,
                    "embedding_identity": app.embedder.identity,
                    "embedding_fallback_error": app.embedder.load_error,
                    "audit_chain_valid": valid,
                    "audit_records": records,
                    "audit_error": error,
                }
            )
        elif args.command == "ingest":
            result = app.evidence.ingest_path(args.path)
            app.audit.record("evidence.ingest", asdict(result))
            _json(asdict(result))
        elif args.command == "sources":
            _json(app.evidence.list_sources(include_quarantined=not args.trusted_only))
        elif args.command == "source":
            _json(app.evidence.get_source(args.source_id))
        elif args.command == "search":
            selected_chunks = _selected_chunks(app, args.case_id, args.chunk_ids)
            with app.telemetry.span(
                "mika.retrieval.search",
                attributes={
                    "mika.query.length": len(args.query),
                    "mika.retrieval.k": args.k,
                    "mika.retrieval.source_filter_count": len(args.source_ids or []),
                    "mika.retrieval.chunk_filter_count": len(selected_chunks or []),
                },
            ):
                _json(
                    [
                        asdict(hit) | {"citation": hit.citation()}
                        for hit in app.retriever.search(
                            args.query,
                            args.k,
                            source_ids=args.source_ids,
                            chunk_ids=selected_chunks,
                        )
                    ]
                )
        elif args.command == "ask":
            selected_chunks = _selected_chunks(app, args.case_id, args.chunk_ids)
            llm = OllamaClient(
                app.settings.ollama_url, app.settings.ollama_model, app.settings.request_timeout
            )
            try:
                _json(
                    asdict(
                        AnalystEngine(app.retriever, llm, app.telemetry, app.cases).answer(
                            args.query,
                            args.k,
                            source_ids=args.source_ids,
                            chunk_ids=selected_chunks,
                            case_id=args.case_id,
                        )
                    )
                )
            finally:
                llm.close()
        elif args.command == "case-create":
            case_id = app.cases.create(args.title, args.objective)
            app.audit.record("case.create", {"case_id": case_id, "title": args.title})
            _json({"case_id": case_id})
        elif args.command == "cases":
            _json(app.cases.list_cases())
        elif args.command == "case-attach":
            app.cases.attach_evidence(args.case_id, args.chunk_ids)
            app.audit.record(
                "case.attach_evidence", {"case_id": args.case_id, "chunk_ids": args.chunk_ids}
            )
            _json({"case_id": args.case_id, "attached": args.chunk_ids})
        elif args.command == "case-finding":
            finding_id = app.cases.add_finding(
                args.case_id,
                args.statement,
                args.confidence,
                evidence_chunk_ids=args.evidence,
                alternatives=args.alternative,
                limitations=args.limitation,
            )
            app.audit.record(
                "case.add_finding", {"case_id": args.case_id, "finding_id": finding_id}
            )
            _json({"finding_id": finding_id})
        elif args.command == "case-report":
            markdown = app.cases.report_markdown(args.case_id)
            if args.output:
                args.output.parent.mkdir(parents=True, exist_ok=True)
                args.output.write_text(markdown, encoding="utf-8")
                _json({"output": str(args.output.resolve())})
            else:
                print(markdown)
        elif args.command in {"backup", "database-backup"}:
            destination = _backup_path(app, args.output)
            saved = app.db.backup_to(destination)
            app.audit.record("database.backup", {"destination": str(saved)})
            _json({"output": str(saved)})
        elif args.command == "screen":
            return _screen(app, args)
        elif args.command == "audit-verify":
            valid, records, error = app.audit.verify()
            _json({"valid": valid, "records": records, "error": error})
            return 0 if valid else 1
        elif args.command == "tools":
            _json(
                {
                    "role": args.role,
                    "tools": [
                        item["function"]["name"] for item in _registry(app, args.role).schemas()
                    ],
                }
            )
        elif args.command == "tool-run":
            try:
                payload = json.loads(args.args)
            except json.JSONDecodeError as exc:
                raise SystemExit(f"Invalid --args JSON: {exc}") from exc
            if not isinstance(payload, dict):
                raise SystemExit("--args must decode to a JSON object")
            return _run_tool(app, args.name, payload, role=args.role)
        elif args.command == "entity-resolve":
            return _run_tool(
                app,
                "entity.resolve",
                {
                    "path": args.path,
                    "query": args.query,
                    "threshold": args.threshold,
                    "limit": args.limit,
                },
                role="viewer",
            )
        elif args.command == "graph-path":
            return _run_tool(
                app,
                "graph.shortest_path",
                {
                    "path": args.path,
                    "source": args.source,
                    "target": args.target,
                    "max_depth": args.max_depth,
                },
                role="viewer",
            )
        elif args.command == "profile":
            return _run_tool(app, "dataset.profile", {"path": args.path}, role="viewer")
        return 0
    finally:
        app.close()


if __name__ == "__main__":
    sys.exit(main())
