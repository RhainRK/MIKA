from __future__ import annotations

import heapq
import math
import re
import unicodedata
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from difflib import SequenceMatcher

_WORD = re.compile(r"[a-z0-9]+")
_TOKEN_SIMILARITY = 0.88
_LEGAL_SUFFIXES = {
    "co",
    "company",
    "corp",
    "corporation",
    "inc",
    "incorporated",
    "ltd",
    "limited",
    "llc",
    "plc",
}


@dataclass(frozen=True, slots=True)
class EntityRecord:
    entity_id: str
    name: str
    aliases: tuple[str, ...] = ()
    entity_type: str = "unknown"
    metadata: Mapping[str, str] | None = None


@dataclass(frozen=True, slots=True)
class EntityMatch:
    entity_id: str
    name: str
    entity_type: str
    matched_value: str
    score: float
    signals: tuple[str, ...]


@dataclass(frozen=True, slots=True)
class _CandidateValue:
    raw: str
    normalized: str
    tokens: frozenset[str]


def normalize_name(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    tokens = _WORD.findall(normalized.casefold())
    while tokens and tokens[-1] in _LEGAL_SUFFIXES:
        tokens.pop()
    return " ".join(tokens)


def jaro_winkler(left: str, right: str, *, prefix_scale: float = 0.1) -> float:
    """Jaro-Winkler similarity; rewards shared prefixes, suiting transliterated names."""
    if left == right:
        return 1.0
    if not left or not right:
        return 0.0
    window = max(0, max(len(left), len(right)) // 2 - 1)
    left_hits = [False] * len(left)
    right_hits = [False] * len(right)
    matches = 0
    for i, char in enumerate(left):
        for j in range(max(0, i - window), min(len(right), i + window + 1)):
            if not right_hits[j] and right[j] == char:
                left_hits[i] = right_hits[j] = True
                matches += 1
                break
    if not matches:
        return 0.0
    left_seq = [char for char, hit in zip(left, left_hits, strict=True) if hit]
    right_seq = [char for char, hit in zip(right, right_hits, strict=True) if hit]
    transpositions = sum(a != b for a, b in zip(left_seq, right_seq, strict=True)) / 2
    jaro = (matches / len(left) + matches / len(right) + (matches - transpositions) / matches) / 3
    prefix = 0
    for a, b in zip(left[:4], right[:4], strict=False):
        if a != b:
            break
        prefix += 1
    return jaro + prefix * prefix_scale * (1.0 - jaro)


def _tokens_match(left: str, right: str) -> bool:
    if left == right:
        return True
    # Short tokens (initials, "co", "kim") must match exactly to avoid noise.
    if min(len(left), len(right)) <= 3:
        return False
    return jaro_winkler(left, right) >= _TOKEN_SIMILARITY


def _soft_overlap(left: frozenset[str], right: frozenset[str]) -> float:
    """Jaccard overlap where near-identical tokens (typos, transliterations) count as shared."""
    if not left or not right:
        return 0.0
    unmatched = set(right)
    matched = 0
    for token in sorted(left, key=lambda item: (item not in right, item)):
        hit = token if token in unmatched else None
        if hit is None:
            hit = next((other for other in sorted(unmatched) if _tokens_match(token, other)), None)
        if hit is not None:
            unmatched.discard(hit)
            matched += 1
    return matched / (len(left) + len(right) - matched)


def _candidate(value: str) -> _CandidateValue:
    normalized = normalize_name(value)
    return _CandidateValue(value, normalized, frozenset(normalized.split()))


def _score(query: _CandidateValue, candidate: _CandidateValue) -> tuple[float, tuple[str, ...]]:
    if not query.normalized or not candidate.normalized:
        return 0.0, ()
    if query.normalized == candidate.normalized:
        return 1.0, ("normalized_exact",)
    if sorted(query.normalized.split()) == sorted(candidate.normalized.split()):
        return 0.97, ("token_order_variant",)

    overlap = _soft_overlap(query.tokens, candidate.tokens)
    sequence = SequenceMatcher(None, query.normalized, candidate.normalized, autojunk=False).ratio()
    containment = float(
        query.normalized in candidate.normalized or candidate.normalized in query.normalized
    )
    score = 0.55 * sequence + 0.35 * overlap + 0.10 * containment

    signals: list[str] = []
    if overlap >= 0.8:
        signals.append("high_token_overlap")
    elif overlap >= 0.5:
        signals.append("token_overlap")
    if sequence >= 0.9:
        signals.append("high_string_similarity")
    if containment:
        signals.append("normalized_containment")
    return min(score, 1.0), tuple(signals)


class EntityResolver:
    def __init__(self, records: Iterable[EntityRecord]) -> None:
        self.records = tuple(records)
        self._values: list[tuple[_CandidateValue, ...]] = []
        self._token_index: dict[str, set[int]] = defaultdict(set)

        for index, record in enumerate(self.records):
            values = tuple(_candidate(value) for value in (record.name, *record.aliases))
            self._values.append(values)
            for value in values:
                for token in value.tokens:
                    self._token_index[token].add(index)

    def resolve(
        self,
        query: str,
        *,
        threshold: float = 0.82,
        limit: int = 10,
        require_token_overlap: bool = False,
        max_candidates: int | None = None,
    ) -> list[EntityMatch]:
        """Rank records similar to ``query``.

        Candidates come from an inverted token index. When no token is shared the resolver
        normally falls back to scanning every record; ``require_token_overlap`` disables that
        fallback, which bounds cost for bulk screening at the price of missing names whose
        every token is misspelt.

        ``max_candidates`` caps how many records receive full (expensive) scoring. Candidates
        are ranked by the summed inverse document frequency of the tokens they share with the
        query, so a rare distinguishing token outweighs common words such as "holdings".
        """
        if not 0.0 <= threshold <= 1.0:
            raise ValueError("threshold must be between 0 and 1")
        if limit < 1:
            raise ValueError("limit must be positive")

        query_value = _candidate(query)
        if max_candidates is not None and max_candidates < 1:
            raise ValueError("max_candidates must be positive")
        candidate_ids: set[int] = set()
        if max_candidates is None:
            for token in query_value.tokens:
                candidate_ids.update(self._token_index.get(token, ()))
        else:
            weights: dict[int, float] = defaultdict(float)
            total = len(self.records)
            # Sorted iteration and an index tie-break keep the capped candidate set identical
            # across processes (string hashing, and so set order, is randomized per process).
            for token in sorted(query_value.tokens):
                postings = self._token_index.get(token, ())
                if not postings:
                    continue
                idf = math.log((total + 1) / len(postings)) + 1e-6
                for index in postings:
                    weights[index] += idf
            ranked = heapq.nsmallest(
                max_candidates, weights.items(), key=lambda kv: (-kv[1], kv[0])
            )
            candidate_ids = {index for index, _ in ranked}
        if not candidate_ids and not require_token_overlap:
            candidate_ids = set(range(len(self.records)))

        matches: list[EntityMatch] = []
        for index in candidate_ids:
            record = self.records[index]
            best_value = self._values[index][0]
            best_score = 0.0
            best_signals: tuple[str, ...] = ()
            for value in self._values[index]:
                score, signals = _score(query_value, value)
                if score > best_score:
                    best_value = value
                    best_score = score
                    best_signals = signals
            if best_score >= threshold:
                alias_signal = ("alias_match",) if best_value.raw != record.name else ()
                matches.append(
                    EntityMatch(
                        entity_id=record.entity_id,
                        name=record.name,
                        entity_type=record.entity_type,
                        matched_value=best_value.raw,
                        score=best_score,
                        signals=best_signals + alias_signal,
                    )
                )
        matches.sort(key=lambda item: (item.score, item.entity_id), reverse=True)
        return matches[:limit]
