"""MIKA: Model Integrity & Knowledge Analysis."""

__version__ = "2.0.0"
