from __future__ import annotations

import heapq
import json
import math
import re
import sqlite3
from collections.abc import Sequence
from dataclasses import dataclass

import numpy as np

from .embeddings import Embedder
from .storage import Database

_IDENTIFIER = re.compile(r"\b[A-Za-z][A-Za-z0-9_]*-\d{2,}\b")
_RRF_K = 60
_CANDIDATE_LIMIT = 100
_SEMANTIC_BATCH = 256


@dataclass(frozen=True, slots=True)
class SearchHit:
    chunk_id: int
    source_id: int
    source_name: str
    locator: str
    content: str
    score: float
    semantic_score: float
    lexical_rank: int | None
    source_sha256: str
    injection_score: float

    def citation(self) -> str:
        return f"S{self.source_id}:C{self.chunk_id}"


def _fts_query(text: str) -> str:
    tokens = [
        token.replace("'", "")
        for token in re.findall(r"[\w']+", text.casefold())
        if len(token) > 1 or token.isdigit()
    ]
    return " OR ".join(f'"{token}"' for token in tokens[:20])


def _normalise_ids(values: Sequence[int] | None) -> tuple[int, ...] | None:
    if values is None:
        return None
    return tuple(sorted({int(value) for value in values if int(value) > 0}))


def _filter_params(
    include_quarantined: bool,
    source_ids: Sequence[int] | None,
    chunk_ids: Sequence[int] | None,
) -> tuple[int, str | None, str | None] | None:
    sources = _normalise_ids(source_ids)
    chunks = _normalise_ids(chunk_ids)
    if sources is not None and not sources:
        return None
    if chunks is not None and not chunks:
        return None
    return (
        int(include_quarantined),
        json.dumps(sources) if sources is not None else None,
        json.dumps(chunks) if chunks is not None else None,
    )


class HybridRetriever:
    def __init__(self, db: Database, embedder: Embedder) -> None:
        self.db = db
        self.embedder = embedder

    def _lexical_ranks(
        self,
        query: str,
        include_quarantined: bool,
        source_ids: Sequence[int] | None,
        chunk_ids: Sequence[int] | None,
    ) -> dict[int, int]:
        if not self.db.fts_enabled:
            return {}
        expression = _fts_query(query)
        if not expression:
            return {}
        filters = _filter_params(include_quarantined, source_ids, chunk_ids)
        if filters is None:
            return {}
        quarantine, sources_json, chunks_json = filters
        try:
            rows = self.db.conn.execute(
                """
                SELECT CAST(f.chunk_id AS INTEGER) AS chunk_id,bm25(chunks_fts) AS rank
                FROM chunks_fts f
                JOIN chunks c ON c.id=CAST(f.chunk_id AS INTEGER)
                JOIN sources s ON s.id=c.source_id
                WHERE chunks_fts MATCH ?
                  AND (? OR s.quarantined=0)
                  AND (? IS NULL OR c.source_id IN (
                      SELECT CAST(value AS INTEGER) FROM json_each(?)
                  ))
                  AND (? IS NULL OR c.id IN (
                      SELECT CAST(value AS INTEGER) FROM json_each(?)
                  ))
                ORDER BY rank LIMIT ?
                """,
                [
                    expression,
                    quarantine,
                    sources_json,
                    sources_json,
                    chunks_json,
                    chunks_json,
                    _CANDIDATE_LIMIT,
                ],
            ).fetchall()
        except sqlite3.OperationalError:
            return {}
        return {int(row["chunk_id"]): index + 1 for index, row in enumerate(rows)}

    def _decode_or_generate(
        self, rows: Sequence[sqlite3.Row], identity: str, query_shape: tuple[int, ...]
    ) -> list[np.ndarray]:
        vectors: list[np.ndarray | None] = [None] * len(rows)
        missing_indices: list[int] = []
        for index, row in enumerate(rows):
            vector: np.ndarray | None = None
            if row["embedding"] and row["embedding_model"] == identity:
                try:
                    decoded = np.frombuffer(row["embedding"], dtype=np.float32)
                    if decoded.shape == query_shape and np.isfinite(decoded).all():
                        vector = decoded
                except (TypeError, ValueError):
                    vector = None
            if vector is None:
                missing_indices.append(index)
            else:
                vectors[index] = vector

        if missing_indices:
            generated = self.embedder.encode_many(
                str(rows[index]["content"]) for index in missing_indices
            )
            updates: list[tuple[bytes, str, int]] = []
            for index, vector in zip(missing_indices, generated, strict=True):
                item = np.asarray(vector, dtype=np.float32)
                vectors[index] = item
                updates.append((item.tobytes(), identity, int(rows[index]["id"])))
            with self.db.conn:
                self.db.conn.executemany(
                    "UPDATE chunks SET embedding=?,embedding_model=? WHERE id=?", updates
                )

        return [vector for vector in vectors if vector is not None]

    def _semantic_ranks(
        self,
        query: str,
        include_quarantined: bool,
        source_ids: Sequence[int] | None,
        chunk_ids: Sequence[int] | None,
    ) -> tuple[dict[int, int], dict[int, float]]:
        query_vector = self.embedder.encode(query).astype(np.float32, copy=False)
        identity = self.embedder.identity
        filters = _filter_params(include_quarantined, source_ids, chunk_ids)
        if filters is None:
            return {}, {}
        quarantine, sources_json, chunks_json = filters
        cursor = self.db.conn.execute(
            """
            SELECT c.id,c.content,c.embedding,c.embedding_model
            FROM chunks c JOIN sources s ON s.id=c.source_id
            WHERE (? OR s.quarantined=0)
              AND (? IS NULL OR c.source_id IN (
                  SELECT CAST(value AS INTEGER) FROM json_each(?)
              ))
              AND (? IS NULL OR c.id IN (
                  SELECT CAST(value AS INTEGER) FROM json_each(?)
              ))
            ORDER BY c.id
            """,
            [
                quarantine,
                sources_json,
                sources_json,
                chunks_json,
                chunks_json,
            ],
        )
        top: list[tuple[float, int]] = []
        while True:
            batch = cursor.fetchmany(_SEMANTIC_BATCH)
            if not batch:
                break
            vectors = self._decode_or_generate(batch, identity, query_vector.shape)
            if not vectors:
                continue
            matrix = np.stack(vectors, axis=0)
            scores = matrix @ query_vector
            for row, score in zip(batch, scores, strict=True):
                item = (float(score), int(row["id"]))
                if len(top) < _CANDIDATE_LIMIT:
                    heapq.heappush(top, item)
                elif item > top[0]:
                    heapq.heapreplace(top, item)

        ranked = sorted(top, reverse=True)
        ranks = {chunk_id: index + 1 for index, (_, chunk_id) in enumerate(ranked)}
        score_by_id = {chunk_id: score for score, chunk_id in ranked}
        return ranks, score_by_id

    def search(
        self,
        query: str,
        k: int = 6,
        *,
        include_quarantined: bool = False,
        source_ids: Sequence[int] | None = None,
        chunk_ids: Sequence[int] | None = None,
    ) -> list[SearchHit]:
        query = query.strip()
        if not query or k <= 0:
            return []
        if source_ids is not None and not _normalise_ids(source_ids):
            return []
        if chunk_ids is not None and not _normalise_ids(chunk_ids):
            return []

        lexical_ranks = self._lexical_ranks(query, include_quarantined, source_ids, chunk_ids)
        semantic_ranks, semantic_scores = self._semantic_ranks(
            query, include_quarantined, source_ids, chunk_ids
        )
        candidates = set(semantic_ranks) | set(lexical_ranks)
        if not candidates:
            return []

        candidate_json = json.dumps(sorted(candidates))
        rows = self.db.conn.execute(
            """
            SELECT c.id,c.source_id,c.content,c.locator,s.name AS source_name,
                   s.sha256 AS source_sha256,s.injection_score
            FROM chunks c JOIN sources s ON s.id=c.source_id
            WHERE c.id IN (
                SELECT CAST(value AS INTEGER) FROM json_each(?)
            )
            """,
            (candidate_json,),
        ).fetchall()
        row_by_id = {int(row["id"]): row for row in rows}
        identifiers = {token.casefold() for token in _IDENTIFIER.findall(query)}
        ranked: list[tuple[float, int]] = []
        for chunk_id in candidates:
            row = row_by_id.get(chunk_id)
            if row is None:
                continue
            semantic_rank = semantic_ranks.get(chunk_id)
            lexical_rank = lexical_ranks.get(chunk_id)
            score = (
                (1.0 / (_RRF_K + semantic_rank) if semantic_rank else 0.0)
                + (1.25 / (_RRF_K + lexical_rank) if lexical_rank else 0.0)
                + max(0.0, semantic_scores.get(chunk_id, -1.0)) * 0.001
            )
            if identifiers:
                content = str(row["content"]).casefold()
                score += 0.05 * sum(identifier in content for identifier in identifiers)
            ranked.append((score, chunk_id))

        ranked.sort(reverse=True)
        return [
            SearchHit(
                chunk_id=chunk_id,
                source_id=int(row_by_id[chunk_id]["source_id"]),
                source_name=str(row_by_id[chunk_id]["source_name"]),
                locator=str(row_by_id[chunk_id]["locator"]),
                content=str(row_by_id[chunk_id]["content"]),
                score=score,
                semantic_score=semantic_scores.get(chunk_id, math.nan),
                lexical_rank=lexical_ranks.get(chunk_id),
                source_sha256=str(row_by_id[chunk_id]["source_sha256"]),
                injection_score=float(row_by_id[chunk_id]["injection_score"]),
            )
            for score, chunk_id in ranked[:k]
        ]
