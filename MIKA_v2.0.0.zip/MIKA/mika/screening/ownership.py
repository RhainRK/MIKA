"""Aggregate-ownership blocking (the OFAC "50 percent rule") over an ownership graph.

An entity is treated as blocked when it is listed, or when one or more blocked parties own,
directly or indirectly, 50% or more of it in aggregate. "Indirectly" means through entities
that are themselves blocked: a blocked subsidiary's stakes count in full, while stakes held
through an unblocked intermediary do not pass through.

The propagation is a worklist algorithm. Each entity enters the queue at most once, at the
moment it becomes blocked, and each ownership edge is relaxed only when its owner is
dequeued. That gives O(V + E) time over the reachable subgraph and terminates on cycles.
"""

from __future__ import annotations

from collections import defaultdict, deque
from collections.abc import Iterable, Mapping
from dataclasses import dataclass
from typing import Any

# Percentages are summed from CSV floats; tolerate representation error at the threshold.
_EPSILON = 1e-9


@dataclass(frozen=True, slots=True)
class OwnershipLink:
    owner_id: str
    owned_id: str
    percent: float


@dataclass(frozen=True, slots=True)
class BlockingResult:
    listed: frozenset[str]
    blocked: frozenset[str]
    blocked_share: Mapping[str, float]
    contributors: Mapping[str, tuple[tuple[str, float], ...]]

    def tree(self, entity_id: str, *, max_depth: int = 8, max_nodes: int = 250) -> dict[str, Any]:
        """Explain an entity's status as a tree of blocked owners, back to listed parties.

        Contributors form a DAG, so a dense ownership lattice can have exponentially many
        root-to-leaf paths. ``max_nodes`` bounds the rendered tree; largest stakes are expanded
        first and ``truncated`` reports whether anything was left out.
        """
        budget = [max(1, max_nodes)]
        truncated = [False]
        root = self._node(entity_id, max_depth, frozenset(), budget, truncated)
        root["truncated"] = truncated[0]
        return root

    def _node(
        self,
        entity_id: str,
        depth: int,
        path: frozenset[str],
        budget: list[int],
        truncated: list[bool],
    ) -> dict[str, Any]:
        budget[0] -= 1
        owners: list[dict[str, Any]] = []
        # Listed parties are the roots of an explanation, so their own owners are not expanded.
        if depth > 0 and entity_id not in self.listed:
            seen = path | {entity_id}
            for owner, percent in self.contributors.get(entity_id, ()):
                if owner in seen:
                    continue
                if budget[0] <= 0:
                    truncated[0] = True
                    break
                owners.append(
                    {
                        "percent": percent,
                        "node": self._node(owner, depth - 1, seen, budget, truncated),
                    }
                )
        return {
            "entity_id": entity_id,
            "listed": entity_id in self.listed,
            "blocked": entity_id in self.blocked,
            "blocked_share": self.blocked_share.get(entity_id, 0.0),
            "owners": owners,
        }


def propagate_blocking(
    listed: Iterable[str],
    links: Iterable[OwnershipLink],
    *,
    threshold: float = 50.0,
) -> BlockingResult:
    if not 0.0 < threshold <= 100.0:
        raise ValueError("threshold must be in (0, 100]")

    holdings_of: dict[str, list[tuple[str, float]]] = defaultdict(list)
    for link in links:
        holdings_of[link.owner_id].append((link.owned_id, link.percent))

    seeds = frozenset(listed)
    blocked = set(seeds)
    share: dict[str, float] = defaultdict(float)
    contributors: dict[str, list[tuple[str, float]]] = defaultdict(list)
    queue = deque(sorted(seeds))
    while queue:
        owner = queue.popleft()
        for owned, percent in holdings_of.get(owner, ()):
            share[owned] += percent
            contributors[owned].append((owner, percent))
            if owned not in blocked and share[owned] + _EPSILON >= threshold:
                blocked.add(owned)
                queue.append(owned)

    return BlockingResult(
        listed=seeds,
        blocked=frozenset(blocked),
        blocked_share={key: min(value, 100.0) for key, value in share.items()},
        contributors={
            key: tuple(sorted(value, key=lambda item: (-item[1], item[0])))
            for key, value in contributors.items()
        },
    )
