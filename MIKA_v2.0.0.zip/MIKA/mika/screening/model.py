"""Typed screening inputs loaded from workspace CSV files.

Structural problems (missing columns, paths outside the workspace) fail fast. Row-level
problems become ``DataIssue`` records and the row is skipped or repaired, so one bad line in
a vendor file does not stop a portfolio from being screened, but the gap stays visible.
"""

from __future__ import annotations

import csv
import hashlib
import math
from collections import defaultdict
from collections.abc import Iterator
from dataclasses import dataclass, field
from pathlib import Path

from ..security import safe_workspace_path
from .ownership import OwnershipLink

_OVER_ALLOCATION_TOLERANCE = 0.01

REQUIRED_COLUMNS = {
    "holdings": ("holding_id", "issuer", "identifier", "market_value_usd"),
    "entities": ("entity_id", "name", "aliases", "entity_type", "country", "lei"),
    "ownership": ("owner_id", "owned_id", "percent"),
    "watchlist": ("list_id", "name", "aliases", "program"),
}


@dataclass(frozen=True, slots=True)
class Entity:
    entity_id: str
    name: str
    aliases: tuple[str, ...]
    entity_type: str
    country: str
    lei: str


@dataclass(frozen=True, slots=True)
class Holding:
    holding_id: str
    issuer: str
    identifier: str
    market_value: float


@dataclass(frozen=True, slots=True)
class WatchlistEntry:
    list_id: str
    name: str
    aliases: tuple[str, ...]
    program: str


@dataclass(frozen=True, slots=True)
class DataIssue:
    severity: str
    file: str
    row: int | None
    check: str
    detail: str


@dataclass(frozen=True, slots=True)
class InputFile:
    path: str
    sha256: str
    rows: int


@dataclass(frozen=True, slots=True)
class ScreeningInputs:
    holdings: tuple[Holding, ...]
    entities: dict[str, Entity]
    ownership: tuple[OwnershipLink, ...]
    watchlist: tuple[WatchlistEntry, ...]
    files: dict[str, InputFile]
    issues: tuple[DataIssue, ...] = field(default=())


def _split_aliases(value: str) -> tuple[str, ...]:
    return tuple(dict.fromkeys(item.strip() for item in value.split(";") if item.strip()))


def _read(
    workspace: Path, candidate: str, kind: str
) -> tuple[InputFile, Iterator[tuple[int, dict[str, str]]]]:
    path = safe_workspace_path(workspace, candidate)
    if not path.is_file():
        raise ValueError(f"{kind} input not found: {candidate}")
    raw = path.read_bytes()
    reader = csv.DictReader(raw.decode("utf-8-sig", errors="replace").splitlines())
    columns = {name.strip() for name in reader.fieldnames or []}
    missing = [name for name in REQUIRED_COLUMNS[kind] if name not in columns]
    if missing:
        raise ValueError(f"{path.name} is missing columns: {', '.join(missing)}")
    rows = [
        (number, {str(k).strip(): (v or "").strip() for k, v in row.items() if k is not None})
        for number, row in enumerate(reader, start=2)
    ]
    relative = path.relative_to(workspace.expanduser().resolve()).as_posix()
    meta = InputFile(relative, hashlib.sha256(raw).hexdigest(), len(rows))
    return meta, iter(rows)


def _parse_number(value: str) -> float | None:
    try:
        number = float(value.replace(",", ""))
    except ValueError:
        return None
    return number if math.isfinite(number) else None


def load_inputs(
    workspace: Path,
    *,
    holdings: str,
    entities: str,
    ownership: str,
    watchlist: str,
) -> ScreeningInputs:
    issues: list[DataIssue] = []
    files: dict[str, InputFile] = {}

    def issue(
        file: str, row: int | None, check: str, detail: str, severity: str = "warning"
    ) -> None:
        issues.append(DataIssue(severity, file, row, check, detail))

    meta, rows = _read(workspace, entities, "entities")
    files["entities"] = meta
    entity_map: dict[str, Entity] = {}
    for number, row in rows:
        entity_id, name = row["entity_id"], row["name"]
        if not entity_id or not name:
            issue(meta.path, number, "missing_value", "entity_id and name are required")
            continue
        if entity_id in entity_map:
            issue(meta.path, number, "duplicate_id", f"duplicate entity_id {entity_id}")
            continue
        entity_map[entity_id] = Entity(
            entity_id,
            name,
            _split_aliases(row["aliases"]),
            row["entity_type"] or "unknown",
            row["country"],
            row["lei"].upper(),
        )

    meta, rows = _read(workspace, ownership, "ownership")
    files["ownership"] = meta
    stakes: dict[tuple[str, str], float] = {}
    for number, row in rows:
        owner, owned = row["owner_id"], row["owned_id"]
        percent = _parse_number(row["percent"])
        unknown = [value for value in (owner, owned) if value not in entity_map]
        if unknown:
            issue(meta.path, number, "unknown_entity", f"unknown entity {unknown[0]!r}")
            continue
        if owner == owned:
            issue(meta.path, number, "self_ownership", f"{owner} cannot own itself")
            continue
        if percent is None or not 0.0 < percent <= 100.0:
            issue(
                meta.path, number, "invalid_percent", f"percent {row['percent']!r} not in (0, 100]"
            )
            continue
        key = (owner, owned)
        if key in stakes:
            issue(meta.path, number, "duplicate_link", f"{owner}->{owned} repeated; stakes summed")
        stakes[key] = min(100.0, stakes.get(key, 0.0) + percent)
    totals: dict[str, float] = defaultdict(float)
    for (_, owned), percent in stakes.items():
        totals[owned] += percent
    for owned, total in sorted(totals.items()):
        if total > 100.0 + _OVER_ALLOCATION_TOLERANCE:
            issue(meta.path, None, "over_allocated", f"{owned} has {total:g}% recorded owners")

    meta, rows = _read(workspace, watchlist, "watchlist")
    files["watchlist"] = meta
    entries: list[WatchlistEntry] = []
    for number, row in rows:
        if not row["list_id"] or not row["name"]:
            issue(meta.path, number, "missing_value", "list_id and name are required")
            continue
        entries.append(
            WatchlistEntry(
                row["list_id"], row["name"], _split_aliases(row["aliases"]), row["program"]
            )
        )

    meta, rows = _read(workspace, holdings, "holdings")
    files["holdings"] = meta
    positions: list[Holding] = []
    for number, row in rows:
        value = _parse_number(row["market_value_usd"])
        if not row["holding_id"] or not row["issuer"]:
            issue(meta.path, number, "missing_value", "holding_id and issuer are required")
            continue
        if value is None or value < 0:
            issue(meta.path, number, "invalid_value", "market value missing or negative; using 0")
            value = 0.0
        positions.append(
            Holding(row["holding_id"], row["issuer"], row["identifier"].upper(), value)
        )

    return ScreeningInputs(
        holdings=tuple(positions),
        entities=entity_map,
        ownership=tuple(OwnershipLink(a, b, pct) for (a, b), pct in stakes.items()),
        watchlist=tuple(entries),
        files=files,
        issues=tuple(issues),
    )


def load_labels(workspace: Path, candidate: str) -> dict[str, str]:
    path = safe_workspace_path(workspace, candidate)
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        return {
            row["holding_id"].strip(): row["expected_status"].strip().upper()
            for row in csv.DictReader(handle)
        }
