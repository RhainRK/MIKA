"""Score a screening report against labelled expected statuses."""

from __future__ import annotations

from collections.abc import Mapping
from typing import Any

from .engine import STATUSES


def _prf(predicted: set[str], actual: set[str]) -> dict[str, float | int]:
    true_positive = len(predicted & actual)
    precision = true_positive / len(predicted) if predicted else 1.0
    recall = true_positive / len(actual) if actual else 1.0
    f1 = 2 * precision * recall / (precision + recall) if precision + recall else 0.0
    return {
        "precision": precision,
        "recall": recall,
        "f1": f1,
        "support": len(actual),
        "true_positive": true_positive,
    }


def evaluate_labels(report: Mapping[str, Any], labels: Mapping[str, str]) -> dict[str, Any]:
    """Confusion matrix plus precision/recall for BLOCKED and for any flag (BLOCKED or REVIEW).

    Missed BLOCKED exposure is the costly error in sanctions screening, so ``blocked.recall``
    is the headline gate; ``flagged.precision`` measures analyst workload from false alarms.
    """
    predicted = {row["holding_id"]: row["status"] for row in report["holdings"]}
    scored = sorted(set(predicted) & set(labels))
    confusion = {actual: dict.fromkeys(STATUSES, 0) for actual in STATUSES}
    misclassified: list[dict[str, str]] = []
    for holding_id in scored:
        actual, guess = labels[holding_id], predicted[holding_id]
        if actual in confusion and guess in confusion[actual]:
            confusion[actual][guess] += 1
        if actual != guess:
            misclassified.append({"holding_id": holding_id, "expected": actual, "actual": guess})

    def ids(source: Mapping[str, str], wanted: set[str]) -> set[str]:
        return {key for key in scored if source[key] in wanted}

    return {
        "cases": len(scored),
        "unlabelled": sorted(set(predicted) - set(labels)),
        "accuracy": (len(scored) - len(misclassified)) / len(scored) if scored else 0.0,
        "blocked": _prf(ids(predicted, {"BLOCKED"}), ids(labels, {"BLOCKED"})),
        "flagged": _prf(ids(predicted, {"BLOCKED", "REVIEW"}), ids(labels, {"BLOCKED", "REVIEW"})),
        "confusion": confusion,
        "misclassified": misclassified,
    }
