@echo off
cd /d "%~dp0"
if not exist ".venv\Scripts\mika.exe" (
 echo Follow WINDOWS_SETUP.md to install MIKA first.
 pause
 exit /b 1
)
.venv\Scripts\mika.exe serve --host 127.0.0.1 --port 8000
pause
