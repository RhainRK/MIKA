# MIKA 2.0 local setup

## What runs locally
MIKA screens investment portfolios for sanctions exposure, including exposure through ownership chains, and keeps the evidence behind every result. Python runs the local server; your browser displays the interface. No hosting account is needed. This build includes the compiled dashboard, so Node.js is only needed if you edit the TypeScript. The default hash search backend requires no model download. Installing dependencies requires internet access.

## 1. Extract and install
Install Python 3.13 or newer, then extract the full ZIP into a writable folder such as `C:\MIKA`. Open PowerShell in the folder containing `pyproject.toml`.

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools
.\.venv\Scripts\python.exe -m pip install -e ".[server]"
.\.venv\Scripts\mika.exe --version
```
Expected version: 2.0.0. If you installed a newer Python, replace `-3.13` with that version. Activation of the virtual environment is not required for these commands.

## 2. Screen the sample portfolio
```powershell
.\.venv\Scripts\mika.exe screen --dir samples\screening --labels samples\screening\labels.csv --create-cases
```
This writes `reports\screening-latest.json`, scores the run against the 30 labelled scenarios and opens a case for each flagged holding. To screen your own portfolio, see `docs\screening.md` for the four CSV formats.

## 2b. Add sample evidence (optional)
```powershell
.\.venv\Scripts\mika.exe ingest samples\benchmark_evidence.txt
.\.venv\Scripts\mika.exe ingest samples\operations_incidents.csv
```
For your own files, replace the sample path with a quoted path to a file in your workspace. Use files you are allowed to access. Imported evidence is stored in the local database.

## 3. Start the website
```powershell
.\.venv\Scripts\mika.exe serve --host 127.0.0.1 --port 8000
```
Keep the terminal open. Visit http://127.0.0.1:8000 in your browser. Sign in with username `mika` and the password printed by the server. You can also double-click `START_MIKA.bat` after installation. Stop the server with Ctrl+C.

## 4. Use the interface
- **Exposure:** portfolio value by status, the holdings list and, for a selected holding, its reasons and ownership chain. Filter by Blocked, Review or Clear.
- **Search:** enter a question, topic or identifier. Narrow results using the Source and Case dropdowns. Reset filters to search everything again. Matching passages show their citations and original sources. Ranking scores are not confidence probabilities.
- **Sources:** review imported files and select Search source to apply a filter. Expand the import help for instructions. Quarantined sources are marked with a warning and excluded from trusted search.
- **Cases:** select Review to see the objective, evidence and findings. Download report exports the case. Creating and editing cases still uses the command line; run `.\.venv\Scripts\mika.exe --help` for commands.
- **System:** view source counts, the audit status and regression evaluation. To produce an evaluation, run `.\.venv\Scripts\mika.exe evaluate --repeats 20` and refresh.
- **Refresh:** reload lists after imports or case changes. Your selected filters are retained when they still exist.
Navigation supports browser Back and Forward. The interface adapts to narrow browser windows. It loads no external fonts or UI scripts.

## 5. Upgrade safely
Stop the old server. Keep a copy of the complete old project folder, especially `data`, your original evidence, and any custom configuration. Extract this release into a separate folder and create a fresh virtual environment there. Copy your old `data` folder and custom configuration into the new folder before starting it. Preserve custom MIKA environment variables or update their paths deliberately. Do not copy the old virtual environment. Retain the old folder until you have checked searches and cases. Version 2.0 makes no database schema changes relative to 1.5 or 1.6.

## 6. Edit the dashboard (optional)
Install Node.js 22 or newer only if you want to modify the UI source.
```powershell
cd dashboard
npm.cmd ci --ignore-scripts
npm.cmd run typecheck
npm.cmd run build
cd ..
```
Restart the server and hard-refresh the browser after edits. Colours and layout are in `dashboard/style.css`; navigation markup is in `dashboard/index.html`; behaviour is in `dashboard/src/app.ts`.

## Troubleshooting
- **Cannot open the page:** check the terminal is still running and use the exact address above.
- **Port already used:** stop the older server, or use `--port 8001` and open that port.
- **Blank interface:** hard-refresh. Confirm `dashboard/dist/app.js` exists; it is included in this archive.
- **No results:** import a sample, reset filters, then search a word known to be in the file.
- **No evaluation:** run the evaluation command above. Its absence does not prevent searching.
- **Login fails:** use the password from the currently running terminal.

The default server is intended for this computer only. Keep its loopback binding. Evidence files and database backups are not encrypted by MIKA. Version 2.0 was built and tested on Windows 11 with Python 3.13, including headless-browser checks of the Exposure view at desktop and phone widths.
