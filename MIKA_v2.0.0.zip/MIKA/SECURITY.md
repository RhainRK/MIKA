# Security model

MIKA is designed around least privilege, complete mediation and reviewability.

## Controls

- **Default deny:** tools execute only when both registered and explicitly permitted by the active role policy.
- **Unknown tool rejection:** an LLM cannot invoke hidden or unregistered capabilities.
- **Typed arguments:** Pydantic models reject unknown fields and invalid bounds before handler execution.
- **Workspace confinement:** file-backed tools resolve paths against the configured workspace and reject traversal outside it.
- **Read-only SQL:** the SQLite tool accepts one bounded `SELECT`/`WITH` statement and rejects write/DDL/attach/pragma operations.
- **Untrusted retrieval:** evidence is separated from system instructions and treated as data.
- **Injection quarantine:** suspicious source text can be excluded from ordinary retrieval. This is defense-in-depth, not the security boundary.
- **Secret redaction:** common credential patterns are removed before audit/telemetry persistence.
- **Tamper evidence:** audit records include the previous record hash and their own SHA-256 digest.
- **Thread-safe audit append:** in-process writes are serialized to preserve chain ordering.
- **Endpoint restriction:** the public-data connector accepts only the exact official FCDO HTTPS sanctions-list endpoint.
- **Local model URL validation:** plaintext HTTP is accepted only for loopback endpoints.
- **Screening input confinement:** screening CSVs pass the same workspace path guard (no traversal, hidden files, symbolic links or files over 25 MiB) and reports use workspace-relative paths only.

## Threats exercised by tests

- implicit permission regression,
- unregistered tool invocation,
- malformed tool arguments,
- path traversal,
- SQLite write attempts,
- prompt-injection content entering the corpus,
- quarantined content leaking into default retrieval,
- audit-log modification/reordering,
- connector host substitution.

## Limitations

The audit chain is tamper-evident, not digitally signed; an attacker able to rewrite the complete log and recompute every hash can create a new internally valid chain. Multi-process append coordination is also outside the current design. Production deployment would use centralized append-only logging, external integrity anchoring and stronger identity/session controls.

Prompt-injection scanning is heuristic. Authorization remains deterministic even if that classifier misses an injection.

## Reporting

Do not post credentials, exploit payloads or sensitive datasets in a public issue. Use GitHub private vulnerability reporting when it is enabled for the repository. If private reporting is unavailable, open a minimal issue requesting a private contact channel without including exploit details.
