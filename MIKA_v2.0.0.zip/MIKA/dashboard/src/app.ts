type SearchHit = {
  citation: string;
  source_id: number;
  source_name: string;
  locator: string;
  content: string;
  score: number;
  source_sha256: string;
};

type Health = {
  version: string;
  audit_chain_valid: boolean;
  embedding_backend: string;
  sources: number;
  chunks: number;
};

type Metric = { mean: number | null };
type EvaluationSuite = { name: string; case_count: number; metrics: Record<string, Metric> };
type Evaluation = { status: string; benchmark_suites: EvaluationSuite[] };

type Source = {
  id: number;
  name: string;
  sha256: string;
  quarantined: boolean;
  chunk_count: number;
  ingest_count: number;
  last_ingested_at: string | null;
};

type CaseSummary = {
  id: string;
  title: string;
  status: string;
  evidence_count: number;
  finding_count: number;
};

type CaseDetail = {
  case: { id: string; title: string; objective: string; status: string };
  evidence: Array<{ citation: string; source: string; locator: string }>;
  findings: Array<{ statement: string; confidence: number; evidence_chunk_ids: number[] }>;
};

function requiredElement<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Missing element: ${selector}`);
  return element;
}

const form = requiredElement<HTMLFormElement>("#search-form");
const query = requiredElement<HTMLInputElement>("#query");
const sourceFilter = requiredElement<HTMLSelectElement>("#source-filter");
const caseFilter = requiredElement<HTMLSelectElement>("#case-filter");
const results = requiredElement<HTMLDivElement>("#results");
const health = requiredElement<HTMLDivElement>("#health");
const benchmark = requiredElement<HTMLDivElement>("#benchmark");
const sources = requiredElement<HTMLDivElement>("#sources");
const cases = requiredElement<HTMLDivElement>("#cases");
const caseDetail = requiredElement<HTMLDivElement>("#case-detail");

function metric(value: number | null | undefined): string {
  return value == null ? "n/a" : value.toFixed(3);
}

function text(tag: string, value: string, className?: string): HTMLElement {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}

function button(label: string, action: () => void): HTMLButtonElement {
  const node = document.createElement("button");
  node.type = "button";
  node.textContent = label;
  node.addEventListener("click", action);
  return node;
}

async function getJson<T>(url: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(url, { signal: signal ?? null, headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(response.status === 401 ? "Your session needs a login. Reload this page to sign in." : `Unable to load data (${response.status}). Try Refresh.`);
  return await response.json() as T;
}

async function loadHealth(): Promise<void> {
  const body = await getJson<Health>("/api/health");
  health.replaceChildren(
    text("strong", `MIKA ${body.version}`),
    text("span", body.audit_chain_valid ? "audit verified" : "audit failed"),
    text("span", body.embedding_backend),
    text("span", `${body.sources} sources / ${body.chunks} chunks`),
  );
}

async function loadEvaluation(): Promise<void> {
  const response = await fetch("/api/evaluation/latest", { headers: { Accept: "application/json" } });
  if (response.status === 404) {
    benchmark.textContent = "No evaluation report. Run mika evaluate.";
    return;
  }
  if (!response.ok) throw new Error(`/api/evaluation/latest: ${response.status}`);
  const body = await response.json() as Evaluation;
  const suite = body.benchmark_suites.at(-1);
  if (!suite) return;
  const summary = text("div", `${suite.name} | ${suite.case_count} cases | ${body.status}`);
  const metrics = document.createElement("div");
  metrics.className = "metrics";
  metrics.append(
    text("span", `Recall@k ${metric(suite.metrics.recall_at_k?.mean)}`),
    text("span", `MRR ${metric(suite.metrics.mrr?.mean)}`),
    text("span", `nDCG ${metric(suite.metrics.ndcg_at_k?.mean)}`),
  );
  benchmark.replaceChildren(summary, metrics);
}

function renderHits(hits: SearchHit[]): void {
  requiredElement("#result-count").textContent = `${hits.length} matching passages`;
  if (hits.length === 0) {
    results.replaceChildren(text("p", "No matching evidence. Try fewer words or reset the source and case filters.", "empty"));
    return;
  }
  const nodes = hits.map((hit) => {
    const article = document.createElement("article");
    const header = document.createElement("header");
    header.append(text("strong", hit.citation), document.createTextNode(` | ${hit.source_name}`));
    article.append(
      header,
      text("small", `${hit.locator} | score ${hit.score.toFixed(4)}`),
      text("p", hit.content),
      text("code", `sha256:${hit.source_sha256.slice(0, 16)}...`),
    );
    return article;
  });
  results.replaceChildren(...nodes);
}

async function loadSources(): Promise<void> {
  const body = await getJson<Source[]>("/api/sources");
  const options = [new Option("All sources", "")];
  for (const source of body) options.push(new Option(`${source.id}: ${source.name}`, String(source.id)));
  sourceFilter.replaceChildren(...options);
  const rows = body.map((source) => {
    const row = document.createElement("div");
    row.className = "row";
    const main = document.createElement("div");
    main.className = "row-main";
    const title = text("div", `${source.name}${source.quarantined ? " · Quarantined" : ""}`, "row-title");
    if (source.quarantined) title.classList.add("warning");
    main.append(
      title,
      text("div", `${source.chunk_count} chunks | ${source.ingest_count} imports`, "row-meta"),
      text("code", `sha256:${source.sha256.slice(0, 16)}...`),
    );
    row.append(main, button("Search source", () => { sourceFilter.value = String(source.id); location.hash = "search"; showView(); query.focus(); }));
    return row;
  });
  sources.replaceChildren(...rows.length ? rows : [text("p", "Your library is empty. Open ‘How do I add evidence?’ above to import your first file.", "empty")]);
}

let caseRequest = 0;
async function renderCase(id: string): Promise<void> {
  const request = ++caseRequest;
  caseDetail.textContent = "Loading case...";
  let body: CaseDetail;
  try { body = await getJson<CaseDetail>(`/api/cases/${encodeURIComponent(id)}`); }
  catch (error) { if (request === caseRequest) caseDetail.textContent = error instanceof Error ? error.message : "Unable to load case."; return; }
  if (request !== caseRequest) return;
  const heading = text("div", body.case.title, "row-title");
  const objective = text("p", body.case.objective || "No objective recorded.");
  const evidenceTitle = text("strong", `Evidence register (${body.evidence.length})`);
  const evidence = document.createElement("ul");
  for (const item of body.evidence) evidence.append(text("li", `${item.citation} | ${item.source} | ${item.locator}`));
  const findingsTitle = text("strong", `Findings (${body.findings.length})`);
  const findings = document.createElement("ul");
  for (const item of body.findings) findings.append(text("li", `${Math.round(item.confidence * 100)}% | ${item.statement}`));
  const actions = document.createElement("div");
  actions.className = "actions";
  const report = document.createElement("a");
  report.className = "button";
  report.href = `/api/cases/${encodeURIComponent(id)}/report`;
  report.textContent = "Download report";
  actions.append(report, button("Search this case", () => { caseFilter.value = id; location.hash = "search"; showView(); query.focus(); }));
  caseDetail.replaceChildren(heading, objective, evidenceTitle, evidence, findingsTitle, findings, actions);
}

async function loadCases(): Promise<void> {
  const body = await getJson<CaseSummary[]>("/api/cases");
  const options = [new Option("All evidence", "")];
  for (const item of body) options.push(new Option(item.title, item.id));
  caseFilter.replaceChildren(...options);
  const rows = body.map((item) => {
    const row = document.createElement("div");
    row.className = "row";
    const main = document.createElement("div");
    main.className = "row-main";
    main.append(
      text("div", item.title, "row-title"),
      text("div", `${item.status} | ${item.evidence_count} evidence | ${item.finding_count} findings`, "row-meta"),
    );
    row.append(main, button("Review", () => { void renderCase(item.id); }));
    return row;
  });
  cases.replaceChildren(...rows.length ? rows : [text("p", "No cases yet. Create a case with the MIKA command line, then select Refresh.", "empty")]);
}


/* Exposure */
type Status = "BLOCKED" | "REVIEW" | "CLEAR";
type ChainNode = {
  entity_id: string;
  name: string;
  listed: boolean;
  blocked: boolean;
  blocked_share: number;
  programs: string[];
  list_ids: string[];
  owners: Array<{ percent: number; node: ChainNode }>;
  truncated?: boolean;
};
type WatchlistMatch = { list_id: string; name: string; program: string; score: number; matched_value: string; entity_value: string };
type ScreenedHolding = {
  holding_id: string;
  issuer: string;
  identifier: string;
  market_value: number;
  weight: number;
  status: Status;
  reasons: string[];
  entity: { entity_id: string; name: string; score: number; signals: string[] } | null;
  watchlist_matches: WatchlistMatch[];
  blocked_share: number;
  explanation: ChainNode | null;
};
type StatusTotal = { count: number; market_value: number; weight: number };
type ScreeningReport = {
  generated_at: string;
  summary: {
    holdings: number;
    total_market_value: number;
    by_status: Record<Status, StatusTotal>;
    entities: number;
    ownership_links: number;
    watchlist_entries: number;
    blocked_by_ownership: number;
    data_issues: number;
  };
  holdings: ScreenedHolding[];
  evaluation?: { accuracy: number; blocked: { precision: number; recall: number } };
};

const STATUS_LABEL: Record<Status, string> = { BLOCKED: "Blocked", REVIEW: "Review", CLEAR: "Clear" };
const exposureSummary = requiredElement<HTMLDivElement>("#exposure-summary");
const exposureBody = requiredElement<HTMLDivElement>("#exposure-body");
const holdingsList = requiredElement<HTMLDivElement>("#holdings");
const holdingDetail = requiredElement<HTMLDivElement>("#holding-detail");
let screening: ScreeningReport | undefined;
let statusFilter: Status | "ALL" = "ALL";
let selectedHolding: string | undefined;

const money = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact", maximumFractionDigits: 1 });
const percent = new Intl.NumberFormat("en-US", { style: "percent", maximumFractionDigits: 1 });

function badge(status: Status): HTMLElement {
  return text("span", STATUS_LABEL[status], `badge badge-${status.toLowerCase()}`);
}

function renderSummary(report: ScreeningReport): void {
  const { summary } = report;
  const bar = document.createElement("div");
  bar.className = "exposure-bar";
  bar.setAttribute("role", "img");
  const legend = document.createElement("dl");
  legend.className = "exposure-legend";
  const parts: string[] = [];
  for (const status of ["BLOCKED", "REVIEW", "CLEAR"] as const) {
    const total = summary.by_status[status];
    const segment = document.createElement("span");
    segment.className = `segment segment-${status.toLowerCase()}`;
    segment.style.width = `${(total.weight * 100).toFixed(3)}%`;
    bar.append(segment);
    const item = document.createElement("div");
    item.className = `legend-${status.toLowerCase()}`;
    item.append(
      text("dt", `${STATUS_LABEL[status]}, ${total.count} holdings`),
      text("dd", money.format(total.market_value), "legend-value"),
      text("dd", `${percent.format(total.weight)} of value`, "muted"),
    );
    legend.append(item);
    parts.push(`${STATUS_LABEL[status]} ${percent.format(total.weight)}`);
  }
  bar.setAttribute("aria-label", `Portfolio value by screening status: ${parts.join(", ")}`);
  const panel = document.createElement("div");
  panel.className = "panel exposure-panel";
  panel.append(
    bar,
    legend,
    text(
      "p",
      `${money.format(summary.total_market_value)} across ${summary.holdings} holdings, screened against ${summary.watchlist_entries} watchlist entries and ${summary.ownership_links} ownership links. ${summary.blocked_by_ownership} entities are blocked only through ownership.`,
      "hint",
    ),
  );
  if (report.evaluation) {
    panel.append(text("p", `Labelled benchmark: ${percent.format(report.evaluation.accuracy)} accuracy, blocked recall ${percent.format(report.evaluation.blocked.recall)}.`, "hint"));
  }
  if (summary.data_issues) panel.append(text("p", `${summary.data_issues} input data issues were recorded. See the JSON report.`, "hint warning"));
  exposureSummary.replaceChildren(panel);
  requiredElement("#exposure-intro").textContent = `Screened ${new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" }).format(new Date(report.generated_at))}. Holdings are matched to the entity register, checked against the watchlist and traced through ownership under the 50% rule.`;
}

function renderHoldings(): void {
  if (!screening) return;
  const order: Record<Status, number> = { BLOCKED: 0, REVIEW: 1, CLEAR: 2 };
  const rows = screening.holdings
    .filter(item => statusFilter === "ALL" || item.status === statusFilter)
    .sort((a, b) => order[a.status] - order[b.status] || b.market_value - a.market_value)
    .map(item => {
      const row = document.createElement("button");
      row.type = "button";
      row.className = "holding-row";
      if (item.holding_id === selectedHolding) row.setAttribute("aria-current", "true");
      const name = document.createElement("span");
      name.className = "holding-name";
      name.append(text("span", item.issuer, "row-title"), text("span", item.reasons[0] ?? "No sanctions links found", "row-meta"));
      row.append(badge(item.status), name, text("span", money.format(item.market_value), "holding-value"));
      row.addEventListener("click", () => {
        selectedHolding = item.holding_id;
        renderHoldings();
        renderHolding(item);
        // Stacked layout: the detail panel sits below the list, so bring it into view.
        if (window.matchMedia("(max-width: 950px)").matches) holdingDetail.scrollIntoView({ block: "start" });
      });
      return row;
    });
  holdingsList.replaceChildren(...rows.length ? rows : [text("p", "No holdings have this status.", "empty")]);
}

const SVG_NS = "http://www.w3.org/2000/svg";
function svg<K extends keyof SVGElementTagNameMap>(tag: K, attrs: Record<string, string | number>): SVGElementTagNameMap[K] {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
  return node;
}

const ELLIPSIS = String.fromCharCode(0x2026);
function clip(value: string, length: number): string {
  return value.length > length ? value.slice(0, length - 1) + ELLIPSIS : value;
}

/* Layered tree layout: listed parties at the top, the screened holding at the bottom. */
function chainDiagram(root: ChainNode): SVGSVGElement {
  type Placed = { node: ChainNode; depth: number; column: number };
  const placed: Placed[] = [];
  const edges: Array<{ from: Placed; to: Placed; percent: number }> = [];
  let leaves = 0;
  let maxDepth = 0;
  const place = (node: ChainNode, depth: number): Placed => {
    maxDepth = Math.max(maxDepth, depth);
    const children = node.owners.map(edge => ({ edge, item: place(edge.node, depth + 1) }));
    const column = children.length ? children.reduce((sum, child) => sum + child.item.column, 0) / children.length : leaves++;
    const item = { node, depth, column };
    placed.push(item);
    for (const child of children) edges.push({ from: child.item, to: item, percent: child.edge.percent });
    return item;
  };
  place(root, 0);
  const nodeW = 224, nodeH = 54, colGap = 24, rowGap = 46, pad = 6;
  const width = Math.max(1, leaves) * (nodeW + colGap) - colGap + pad * 2;
  const height = (maxDepth + 1) * (nodeH + rowGap) - rowGap + pad * 2;
  const x = (column: number) => pad + column * (nodeW + colGap);
  const y = (depth: number) => pad + (maxDepth - depth) * (nodeH + rowGap);
  const canvas = svg("svg", { viewBox: `0 0 ${width} ${height}`, width, height, class: "chain" });
  for (const edge of edges) {
    const x1 = x(edge.from.column) + nodeW / 2, y1 = y(edge.from.depth) + nodeH;
    const x2 = x(edge.to.column) + nodeW / 2, y2 = y(edge.to.depth);
    const mid = (y1 + y2) / 2;
    canvas.append(svg("path", {
      d: `M${x1},${y1} C${x1},${mid} ${x2},${mid} ${x2},${y2}`,
      class: `chain-edge${edge.from.node.blocked ? " is-blocked" : ""}`,
      "stroke-width": (1.2 + edge.percent / 22).toFixed(2),
    }));
    const label = svg("text", { x: (x1 + x2) / 2 + 10, y: mid + 4, class: "chain-percent" });
    label.textContent = `${edge.percent}%`;
    canvas.append(label);
  }
  for (const item of placed) {
    const { node } = item;
    const state = node.listed ? "listed" : node.blocked ? "blocked" : "clear";
    const group = svg("g", { class: `chain-node is-${state}`, transform: `translate(${x(item.column)},${y(item.depth)})` });
    const title = svg("title", {});
    title.textContent = node.name;
    const name = svg("text", { x: 12, y: 22, class: "chain-name" });
    name.textContent = clip(node.name, 29);
    const meta = svg("text", { x: 12, y: 41, class: "chain-meta" });
    meta.textContent = node.listed
      ? `Listed ${node.list_ids.join(", ")}, ${node.programs.join(", ")}`
      : `${node.blocked ? "Blocked, " : ""}${node.blocked_share}% held by blocked owners`;
    group.append(title, svg("rect", { width: nodeW, height: nodeH, rx: 10 }), name, meta);
    canvas.append(group);
  }
  return canvas;
}

function chainSentences(node: ChainNode, out: string[] = []): string[] {
  for (const edge of node.owners) {
    chainSentences(edge.node, out);
    const owner = edge.node.listed ? `${edge.node.name} (listed ${edge.node.list_ids.join(", ")})` : edge.node.name;
    out.push(`${owner} owns ${edge.percent}% of ${node.name}.`);
  }
  return [...new Set(out)];
}

function renderHolding(item: ScreenedHolding): void {
  const header = document.createElement("div");
  header.className = "detail-head";
  header.append(badge(item.status), text("h3", item.issuer));
  const facts = document.createElement("dl");
  facts.className = "facts";
  const fact = (label: string, value: string): void => { facts.append(text("dt", label), text("dd", value)); };
  fact("Market value", `${money.format(item.market_value)}, ${percent.format(item.weight)} of portfolio`);
  fact("Register match", item.entity ? `${item.entity.name} (${item.entity.signals.join(", ").replaceAll("_", " ")})` : "Not found in the entity register");
  if (item.identifier) fact("Identifier", item.identifier);
  const reasons = document.createElement("ul");
  reasons.className = "reasons";
  for (const reason of item.reasons.length ? item.reasons : ["No watchlist match and no blocked ownership."]) reasons.append(text("li", reason));
  const parts: Node[] = [header, facts, text("strong", "Why"), reasons];
  if (item.explanation && item.explanation.owners.length) {
    const figure = document.createElement("figure");
    figure.className = "chain-figure";
    const diagram = chainDiagram(item.explanation);
    diagram.setAttribute("role", "img");
    diagram.setAttribute("aria-label", chainSentences(item.explanation).join(" "));
    const scroller = document.createElement("div");
    scroller.className = "chain-scroll";
    scroller.tabIndex = 0;
    scroller.setAttribute("aria-label", "Ownership chain");
    scroller.append(diagram);
    const caption = "Stakes flow down from listed parties to this holding. Thicker lines are larger stakes.";
    figure.append(scroller, text("figcaption", item.explanation.truncated ? `${caption} The chain is too large to draw in full; the largest stakes are shown. The JSON report has the complete set of contributors.` : caption));
    parts.push(text("strong", "Ownership chain"), figure);
  }
  if (item.watchlist_matches.length) {
    const matches = document.createElement("ul");
    matches.className = "reasons";
    for (const hit of item.watchlist_matches) matches.append(text("li", `${hit.list_id} ${hit.name} (${hit.program}) matched "${hit.entity_value}" at ${hit.score.toFixed(2)}`));
    parts.push(text("strong", "Watchlist matches"), matches);
  }
  holdingDetail.replaceChildren(...parts);
}

async function loadScreening(): Promise<void> {
  const response = await fetch("/api/screening/latest", { headers: { Accept: "application/json" } });
  if (response.status === 404) {
    screening = undefined;
    exposureBody.hidden = true;
    const empty = document.createElement("div");
    empty.className = "empty";
    empty.append(text("h3", "No screening report yet"), text("p", "From your MIKA folder, run this command, then select Refresh."), text("code", "mika screen --dir samples/screening"));
    exposureSummary.replaceChildren(empty);
    return;
  }
  if (!response.ok) throw new Error(response.status === 401 ? "Your session needs a login. Reload this page to sign in." : `Unable to load the screening report (${response.status}). Try Refresh.`);
  screening = await response.json() as ScreeningReport;
  exposureBody.hidden = false;
  renderSummary(screening);
  const depth = (node: ChainNode | null): number => node ? 1 + Math.max(0, ...node.owners.map(edge => depth(edge.node))) : 0;
  const current = screening.holdings.find(item => item.holding_id === selectedHolding)
    ?? [...screening.holdings].sort((a, b) => depth(b.explanation) - depth(a.explanation))[0];
  selectedHolding = current?.holding_id;
  renderHoldings();
  if (current) renderHolding(current);
}

document.querySelectorAll<HTMLButtonElement>(".segmented button").forEach(control => {
  control.addEventListener("click", () => {
    statusFilter = (control.dataset.status ?? "ALL") as Status | "ALL";
    document.querySelectorAll<HTMLButtonElement>(".segmented button").forEach(other => other.setAttribute("aria-pressed", String(other === control)));
    renderHoldings();
  });
});

/* Navigation */
function showView(): void {
  const name = ["exposure", "search", "sources", "cases", "system"].includes(location.hash.slice(1)) ? location.hash.slice(1) : "exposure";
  document.querySelectorAll<HTMLElement>(".view").forEach(view => { view.hidden = view.id !== `view-${name}`; });
  document.querySelectorAll<HTMLAnchorElement>("[data-view]").forEach(link => {
    if (link.dataset.view === name) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  requiredElement("#page-name").textContent = name.charAt(0).toUpperCase() + name.slice(1);
  document.title = `MIKA · ${name.charAt(0).toUpperCase() + name.slice(1)}`;
}
window.addEventListener("hashchange", showView);
showView();
requiredElement("#clear-filters").addEventListener("click", () => { sourceFilter.value = ""; caseFilter.value = ""; query.focus(); });
/* Search */
let searchController: AbortController | undefined;
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const q = query.value.trim();
  if (!q) return;
  searchController?.abort();
  const controller = new AbortController();
  searchController = controller;
  const params = new URLSearchParams({ q, k: "6" });
  if (sourceFilter.value) params.append("source_id", sourceFilter.value);
  if (caseFilter.value) params.set("case_id", caseFilter.value);
  results.textContent = "Searching evidence...";
  results.setAttribute("aria-busy", "true");
  requiredElement("#result-count").textContent = "Searching...";
  try { renderHits(await getJson<SearchHit[]>(`/api/search?${params.toString()}`, controller.signal)); }
  catch (error: unknown) {
    if (controller.signal.aborted) return;
    results.textContent = error instanceof Error ? error.message : "Search failed. Try again.";
    requiredElement("#result-count").textContent = "Search unavailable";
  } finally { if (searchController === controller) results.removeAttribute("aria-busy"); }
});
/* Workspace refresh */
async function refresh(): Promise<void> {
  const control = requiredElement<HTMLButtonElement>("#refresh");
  control.disabled = true;
  control.textContent = "Refreshing...";
  const sourceId = sourceFilter.value;
  const caseId = caseFilter.value;
  await Promise.all([
    [loadScreening, exposureSummary], [loadHealth, health], [loadEvaluation, benchmark], [loadSources, sources], [loadCases, cases],
  ].map(async ([loader, target]) => {
    try { await (loader as () => Promise<void>)(); }
    catch (error) { (target as HTMLElement).textContent = error instanceof Error ? error.message : "Unable to load. Try Refresh."; }
  }));
  if ([...sourceFilter.options].some(option => option.value === sourceId)) sourceFilter.value = sourceId;
  if ([...caseFilter.options].some(option => option.value === caseId)) caseFilter.value = caseId;
  control.disabled = false;
  control.textContent = "↻ Refresh";
}
requiredElement("#refresh").addEventListener("click", () => { void refresh(); });
void refresh();
