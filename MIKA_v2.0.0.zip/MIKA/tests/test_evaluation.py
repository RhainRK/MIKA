from pathlib import Path

from mika.evaluation.runner import run_suite


def test_core_evaluation_suite(tmp_path: Path):
    root = Path(__file__).resolve().parents[1]
    report = run_suite(root, tmp_path / "results.json", repeats=5)
    assert report["status"] == "passed"
    assert report["authorization"]["default_deny_passed"]
    assert report["retrieval_security"]["malicious_source_quarantined"]


def test_evaluation_gates_on_screening_benchmark(tmp_path):
    from pathlib import Path

    from mika.evaluation import run_suite

    root = Path(__file__).resolve().parents[1]
    report = run_suite(root, tmp_path / "report.json", repeats=10)
    screening = report["screening"]
    assert screening["cases"] == 30
    assert screening["blocked"]["recall"] == 1.0
    assert screening["scale"]["entities"] >= 5000
    assert screening["scale"]["seconds"] > 0
    assert report["status"] == "passed"
