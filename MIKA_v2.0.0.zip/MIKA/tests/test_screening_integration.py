import json
import shutil
from pathlib import Path

from fastapi.testclient import TestClient

from mika.api import create_app
from mika.app import MikaApp
from mika.cli import main
from mika.config import Settings
from mika.embeddings import Embedder

ROOT = Path(__file__).resolve().parents[1]
AUTH = {"Authorization": "Basic bWlrYTpwYXNz"}  # mika:pass


def _workspace(tmp_path: Path) -> Settings:
    shutil.copytree(ROOT / "samples" / "screening", tmp_path / "screening")
    return Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
    ).resolve()


def _embedder() -> Embedder:
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    return embedder


def _patch_cli(monkeypatch, config: Settings) -> None:
    import mika.cli as cli_module

    embedder = _embedder()
    monkeypatch.setattr(cli_module, "MikaApp", lambda: MikaApp(config, embedder=embedder))


def test_cli_screen_writes_report_scores_labels_and_audits(tmp_path, monkeypatch, capsys):
    config = _workspace(tmp_path)
    _patch_cli(monkeypatch, config)
    code = main(["screen", "--dir", "screening", "--labels", "screening/labels.csv"])
    assert code == 0
    summary = json.loads(capsys.readouterr().out)
    assert summary["by_status"]["BLOCKED"]["count"] == 10
    assert summary["evaluation"]["blocked"]["recall"] == 1.0
    report = json.loads((tmp_path / "reports" / "screening-latest.json").read_text("utf-8"))
    assert report["evaluation"]["accuracy"] == 1.0
    audit = (tmp_path / "audit.jsonl").read_text("utf-8")
    assert '"screening.run"' in audit
    assert report["inputs"]["holdings"]["sha256"] in audit


def test_cli_screen_creates_evidence_backed_cases(tmp_path, monkeypatch, capsys):
    config = _workspace(tmp_path)
    _patch_cli(monkeypatch, config)
    assert main(["screen", "--dir", "screening", "--create-cases"]) == 0
    capsys.readouterr()
    with MikaApp(config, embedder=_embedder()) as app:
        cases = app.cases.list_cases()
        assert len(cases) == 15  # 10 BLOCKED + 5 REVIEW
        arctic = next(case for case in cases if "Arctic Cold Chain" in case["title"])
        detail = app.cases.get_case(arctic["id"])
        cited = "\n".join(item["content"] for item in detail["evidence"])
        assert "owner_id=E004 | owned_id=E005" in cited
        assert "owner_id=E002 | owned_id=E003" in cited
        assert "list_id=WL-001" in cited
        [finding] = detail["findings"]
        assert finding["evidence_chunk_ids"]
        report = app.cases.report_markdown(arctic["id"])
        assert "Volkov Maritime Holdings" in report


def test_cli_screen_rejects_output_outside_workspace(tmp_path, monkeypatch):
    config = _workspace(tmp_path)
    _patch_cli(monkeypatch, config)
    try:
        main(["screen", "--dir", "screening", "--output", "../escape.json"])
    except SystemExit as exc:
        assert "workspace" in str(exc)
    else:
        raise AssertionError("expected SystemExit")


def test_api_serves_latest_screening_report(tmp_path, monkeypatch):
    config = _workspace(tmp_path)
    client = TestClient(
        create_app(config, embedder=_embedder(), password="pass"),
        base_url="http://127.0.0.1",
        client=("127.0.0.1", 50000),
    )
    assert client.get("/api/screening/latest", headers=AUTH).status_code == 404
    _patch_cli(monkeypatch, config)
    assert main(["screen", "--dir", "screening"]) == 0
    response = client.get("/api/screening/latest", headers=AUTH)
    assert response.status_code == 200
    body = response.json()
    assert body["summary"]["holdings"] == 30
    assert all(not Path(item["path"]).is_absolute() for item in body["inputs"].values())
    assert client.get("/api/screening/latest").status_code == 401
