from mika.entity_resolution import EntityRecord, EntityResolver, normalize_name


def test_normalize_name_removes_case_punctuation_and_legal_suffix():
    assert normalize_name("Northstar Components, Ltd.") == "northstar components"


def test_entity_resolution_exact_and_alias():
    resolver = EntityResolver(
        [
            EntityRecord("1", "Northstar Components Ltd", ("Northstar Comp",), "organisation"),
            EntityRecord("2", "Asterion Logistics PLC", (), "organisation"),
        ]
    )
    exact = resolver.resolve("Northstar Components", threshold=0.8)
    alias = resolver.resolve("Northstar Comp", threshold=0.8)
    assert exact[0].entity_id == "1"
    assert exact[0].score == 1.0
    assert alias[0].entity_id == "1"
    assert "alias_match" in alias[0].signals


def test_entity_resolution_rejects_weak_match():
    resolver = EntityResolver([EntityRecord("1", "Northstar Components")])
    assert resolver.resolve("Completely Different", threshold=0.9) == []


def test_token_order_variant_scores_as_near_exact():
    resolver = EntityResolver([EntityRecord("WL-7", "Yusuf Karimov", (), "person")])
    match = resolver.resolve("Karimov Yusuf", threshold=0.92)
    assert match and match[0].entity_id == "WL-7"
    assert "token_order_variant" in match[0].signals


def test_single_token_transliteration_is_a_strong_but_inexact_match():
    resolver = EntityResolver([EntityRecord("WL-1", "Volkov Maritime Holdings")])
    match = resolver.resolve("Volkoff Maritime Holdings", threshold=0.8)
    assert match and 0.8 <= match[0].score < 0.92
    assert "high_token_overlap" in match[0].signals


def test_shared_surname_alone_is_not_a_match():
    resolver = EntityResolver([EntityRecord("WL-2", "Aleksandr Petrenko", (), "person")])
    assert resolver.resolve("Olena Petrenko", threshold=0.8) == []


def test_require_token_overlap_skips_full_scan():
    resolver = EntityResolver([EntityRecord("1", "Northstar Components")])
    assert resolver.resolve("Zzz", threshold=0.0) != []
    assert resolver.resolve("Zzz", threshold=0.0, require_token_overlap=True) == []


def test_jaro_winkler_reference_values():
    from mika.entity_resolution import jaro_winkler

    assert round(jaro_winkler("martha", "marhta"), 4) == 0.9611
    assert round(jaro_winkler("dwayne", "duane"), 4) == 0.84
    assert jaro_winkler("abc", "abc") == 1.0
    assert jaro_winkler("", "abc") == 0.0


def test_max_candidates_keeps_the_rare_token_match_among_common_token_decoys(monkeypatch):
    import mika.entity_resolution as module

    decoys = [EntityRecord(f"D{i}", f"Decoy{i} Global Shipping Holdings") for i in range(500)]
    target = EntityRecord("T", "Zephyrine Global Shipping Holdings")
    resolver = EntityResolver([*decoys, target])
    calls = {"n": 0}
    original = module._score

    def counting(query, candidate):
        calls["n"] += 1
        return original(query, candidate)

    monkeypatch.setattr(module, "_score", counting)
    match = resolver.resolve(
        "Zephyrine Global Shipping Holdings", threshold=0.9, limit=1, max_candidates=20
    )
    assert match[0].entity_id == "T"
    assert calls["n"] <= 20


def test_candidate_cap_is_deterministic_across_hash_seeds():
    import os
    import subprocess
    import sys

    script = (
        "from mika.entity_resolution import EntityRecord, EntityResolver\n"
        "heads = ('alpha', 'gamma', 'delta')\n"
        "tails = ('beta', 'omega', 'kappa')\n"
        "names = [f'{a} {b}' for a in heads for b in tails]\n"
        "r = EntityResolver(EntityRecord(str(i), n) for i, n in enumerate(names))\n"
        "hits = r.resolve('alpha beta zeta', threshold=0.0, limit=9, max_candidates=3)\n"
        "print([m.entity_id for m in hits])\n"
    )
    outputs = set()
    for seed in ("1", "2", "3", "4", "5", "6"):
        env = {**os.environ, "PYTHONHASHSEED": seed}
        outputs.add(
            subprocess.run(
                [sys.executable, "-c", script], env=env, capture_output=True, text=True, check=True
            ).stdout
        )
    assert len(outputs) == 1
