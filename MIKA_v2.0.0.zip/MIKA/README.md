# MIKA

**Sanctions and ownership-risk screening for investment portfolios, built on an auditable evidence engine.**

MIKA finds the sanctioned exposure that name screening misses: holdings that are blocked not because
they appear on a list, but because listed parties own them through chains of other companies. Every
flag comes with the ownership path that caused it, the exact source rows behind it and a
tamper-evident audit record. It runs entirely on your machine.

![Exposure view: portfolio value by status, holdings list and the ownership chain behind a blocked holding](docs/img/exposure.png)

## The problem

Suppose a portfolio holds **Aral Sea Drilling**. It is not on any sanctions list, so a name check
clears it. But:

- listed person **Aleksandr Petrenko** owns 30% of **Caspian Energy Partners**,
- listed company **Golden Crescent Trading** owns another 25%,
- and Caspian Energy Partners owns 70% of Aral Sea Drilling.

Under the US Treasury's [OFAC 50 Percent Rule](https://ofac.treasury.gov/faqs/401), stakes held by
blocked parties are **aggregated** (30% + 25% = 55%), so Caspian is blocked, and blocked status
**passes through** entities that are themselves blocked, so Aral Sea Drilling is blocked too.
Neither company appears on a list. MIKA flags both and shows why.

## Results

All figures below are measured by `mika evaluate` and the commands in this README, on a laptop
(Python 3.13, Windows 11). The data is synthetic, so these numbers check that the rules are
implemented correctly; they do not measure real-world name-matching accuracy.

| What is measured | Result |
| --- | --- |
| Labelled screening scenarios (aliases, transliterations, 1 to 3-hop chains, aggregation, the exact 50% boundary, 49.9% near-miss, ownership cycles, look-alike names) | 30 / 30 correct |
| Blocked holdings: precision / recall | 1.00 / 1.00 |
| Scale run: 50,000 entities, 63,925 ownership links, 500 watchlist names, 2,000 holdings | **2.3 s** end to end |
| Ownership propagation alone at that scale | 28 ms |
| Propagation vs. a naive fixed-point reference, 300 random graphs with cycles | identical |
| Python tests / branch coverage | 154 passed / 90% |
| Evidence retrieval regression (120 held-out queries): Recall@5 / MRR | 1.00 / 1.00 |

`mika evaluate` fails, and so does CI, if blocked recall drops below 1.0 or scenario accuracy falls
below 90%.

## Quick start

Requires Python 3.13+. The compiled dashboard is included, so Node.js is optional.

```bash
python -m venv .venv
.venv/Scripts/pip install -e ".[server]"        # macOS/Linux: .venv/bin/pip

mika screen --dir samples/screening --labels samples/screening/labels.csv --create-cases
mika serve                                       # prints a one-time password
```

Open http://127.0.0.1:8000, sign in as `mika` with the printed password, and the Exposure view
opens on the deepest ownership chain. Windows step-by-step instructions are in
[WINDOWS_SETUP.md](WINDOWS_SETUP.md).

To screen your own data, provide four CSVs (formats in [docs/screening.md](docs/screening.md)):

```bash
mika screen --holdings my/holdings.csv --entities my/entities.csv \
            --ownership my/ownership.csv --watchlist my/watchlist.csv
```

To reproduce the scale benchmark:

```bash
python scripts/generate_screening_data.py --entities 50000 --out data/scale
mika screen --dir data/scale --output reports/screening-scale.json
```

## How it works

```mermaid
flowchart LR
    H[holdings.csv] --> R[Resolve issuer<br/>LEI, then name]
    E[entities.csv] --> R
    W[watchlist.csv] --> M[Match register<br/>to watchlist]
    E --> M
    O[ownership.csv] --> P[Propagate blocking<br/>50% rule]
    M -- confirmed listings --> P
    R --> A[Assess each holding<br/>BLOCKED / REVIEW / CLEAR]
    P --> A
    M -- possible matches --> A
    A --> J[Fingerprinted JSON report]
    A --> C[Cases citing source rows]
    A --> L[Audit chain]
```

**1. Name matching built for sanctions data.** Names are Unicode-normalised, case-folded and
stripped of legal suffixes, so "Volkov Maritime Holdings PLC" matches "Volkov Maritime Holdings".
Tokens are compared with Jaro-Winkler similarity, so a transliteration such as "Volkoff" still
counts as the same word, and names with swapped order such as "Karimov Yusuf" and "Yusuf Karimov"
are recognised. Scores of 0.92 or above confirm a listing. Scores from 0.80 to 0.92 go to an
analyst. A different person who only shares a surname scores far below either threshold.

**2. Candidate generation that scales.** Comparing every name with every other is quadratic. MIKA
uses an inverted token index and ranks candidates by the summed
[IDF](https://en.wikipedia.org/wiki/Tf%E2%80%93idf) of shared tokens, so a rare word such as
"Volkov" outweighs common ones such as "Holdings". Only the top 50 candidates are scored in full.
Profiling showed this one change taking holding resolution at 5,000 entities from 28.7 s to 0.67 s.

**3. Ownership propagation in O(V + E).** A worklist starts from the confirmed listed parties.
When an entity is dequeued, its stake in each company it owns is added to that company's blocked
share. A company is enqueued the first time its share reaches 50%, so every entity is processed at
most once and every edge at most once. This terminates on ownership cycles, and the tree recording
which owners contributed to each block becomes the explanation shown in the UI and in case findings.
See [ADR 0004](docs/adr/0004-ownership-propagation.md).

**4. Decisions an analyst can check.** Each holding gets plain-language reasons, for example
"55% owned in aggregate by blocked parties (threshold 50%)", alongside the register match and its
signals and every watchlist match with its score. Thresholds are configuration, recorded in the
report alongside SHA-256 fingerprints of every input file. Bad input rows, such as percentages
outside 0 to 100, unknown entities, self-ownership or owners totalling more than 100%, become
reported data issues rather than crashes.

**5. Cases with real provenance.** `--create-cases` ingests the input files into the evidence store
and opens a case for each flagged holding. Each case's finding cites the specific ownership,
watchlist and register rows behind it, each carrying the SHA-256 of its source file.

## The evidence engine underneath

Screening is built on MIKA's general-purpose evidence platform, which is also available directly.

- **Hybrid retrieval:** SQLite FTS5/BM25 and embeddings, fused with reciprocal-rank fusion, with
  extra ranking weight for exact identifiers. `mika search`.
- **Grounded analysis:** an optional local model (Ollama, loopback only) answers from retrieved
  evidence, and MIKA flags any answer that cites a source label it was never given. `mika ask`.
- **Default-deny tools:** model-callable tools need a typed schema and an explicit role permission,
  and every call or denial is audited. See [ADR 0001](docs/adr/0001-default-deny-tools.md).
- **Tamper-evident audit:** append-only JSONL records, each holding the SHA-256 of the previous
  record. `mika audit-verify`.
- **Prompt-injection quarantine:** suspicious sources are excluded from retrieval by default.
- **Hardened local server:** loopback only, a per-start password, Host/Origin checks, a strict CSP,
  rate limits and a read-only API.

## Engineering notes

- **Found by measuring, not guessing.** The first 50k-entity run took over 10 minutes. A profile
  showed about 700 fuzzy comparisons per lookup, caused by common words. IDF-ranked candidates,
  querying once per watchlist name instead of once per entity, and an O(1) exact-name path brought
  it to 2.3 s.
- **A reproducibility bug caught before release.** Two identical runs disagreed on one REVIEW
  count. The cause was Python's per-process string-hash randomisation changing the order of tied
  candidates at the cutoff. The fix sorts tokens and breaks ties by index, and a regression test
  now runs the resolver under six different `PYTHONHASHSEED` values.
- **Correctness by reference.** The propagation algorithm is checked against a deliberately naive
  fixed-point implementation on 300 random graphs that include cycles.

## Repository layout

```text
mika/screening/   model, matching engine, 50% propagation, evaluation, case bridge
mika/             evidence store, retrieval, cases, audit, policy, API, CLI
dashboard/        strict TypeScript UI (no framework, no external scripts)
samples/          labelled screening scenarios and retrieval corpora
benchmarks/       retrieval regression suites
scripts/          scale-data generator, release checks
docs/             screening design, architecture, ADRs, evaluation
tests/            pytest suite, including property and cross-seed tests
```

## Limitations

- All bundled data is synthetic. Real screening needs official lists (for example OFAC SDN or the
  UK list, which `mika fetch-uk-sanctions` retrieves) and licensed ownership data.
- A possible match is a lead for an analyst, not a determination. This is not legal or compliance
  advice.
- Owners missing from the ownership data are invisible to the screen.
- To bound cost, candidate generation skips names in which every token is misspelt.
- MIKA is designed for a single user on one machine. Evidence and backups are not encrypted at rest.

## License

MIT. See [LICENSE](LICENSE).
