# MIKA 2.0.0 regression baseline

Measured on Windows 11, Python 3.13.15, with deterministic hash embeddings. All corpora are
synthetic; these figures catch engineering regressions and do not establish real-world accuracy.

## Verification

- Python tests: **154 passed**, 1 skipped (symbolic-link test needs elevated rights on Windows)
- Branch coverage: **90%**
- ruff, ruff format, mypy (strict), bandit: clean
- Authorization, quarantine and audit-chain gates: passed

## Screening

| Measure | Result |
| --- | --- |
| Labelled scenarios | 30 / 30 |
| Blocked precision / recall | 1.00 / 1.00 |
| Flagged (blocked or review) precision / recall | 1.00 / 1.00 |
| 50,000 entities, 63,925 links, 500 watchlist names, 2,000 holdings | 2.3 s (3 runs: 2.33, 2.42, 2.34) |
| Propagation alone at that scale | 28 ms |

## Retrieval

| Suite | Cases | Recall@5 | MRR | nDCG@5 |
| --- | --- | --- | --- | --- |
| core-retrieval | 5 | 1.000 | 0.900 | 0.926 |
| operations-120 | 120 | 1.000 | 1.000 | 1.000 |

Retrieval latency p50 / p95 / p99: 1.3 / 1.7 / 1.8 ms (20 samples). Precision@5 is 0.2 on the
operations suite because each query has exactly one relevant record.

## Reproduce

```bash
pytest --cov=mika --cov-fail-under=82 -q
mika evaluate --repeats 50
python scripts/generate_screening_data.py --entities 50000 --out data/scale
mika screen --dir data/scale --output reports/screening-scale.json
```
