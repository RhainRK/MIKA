# ADR 0004: Propagate blocked status with a worklist, not look-through multiplication

## Status
Accepted

## Context
Ownership risk is often modelled by multiplying stakes along a path ("look-through": 60% of 55%
is 33%). The OFAC 50 Percent Rule does not work that way. Stakes held by blocked parties are summed,
and an entity that reaches 50% becomes blocked itself. From then on its own stakes count in full,
and stakes held through an unblocked company do not count at all.

## Decision
Model blocking as monotone propagation over the ownership graph. A worklist seeded with confirmed
listings adds each blocked owner's stake to the companies it owns, and enqueues a company the first
time its aggregate blocked share reaches the threshold. The contributing owners are recorded so
every result can be explained.

## Consequences
- O(V + E) time, at most one visit per entity and one relaxation per edge, and termination on
  cycles. 50,000 entities with 64,000 links propagate in about 30 ms.
- Results match the rule's semantics, including the cases where multiplication gives the wrong
  answer: aggregation across owners, the exact 50% boundary, and no pass-through via unblocked
  intermediaries. Each case has a test.
- Correctness is checked against a naive fixed-point reference on random graphs.
- Look-through percentages, useful for economic exposure as opposed to legal blocking, are not
  computed. They could be added as a separate measure without changing this algorithm.
