# Portfolio screening

`mika screen` decides, for every holding in a portfolio, whether it is **BLOCKED**, needs
**REVIEW** or is **CLEAR** with respect to a sanctions watchlist, including exposure that arises only
through ownership.

## Inputs

All four files are CSV with a header row. Paths must be inside the MIKA workspace; hidden files,
symbolic links and files over 25 MiB are refused by the same path guard used by the evidence tools.

| File | Required columns | Notes |
| --- | --- | --- |
| `holdings.csv` | `holding_id, issuer, identifier, market_value_usd` | `identifier` is optional per row; an LEI that matches the register wins over the name |
| `entities.csv` | `entity_id, name, aliases, entity_type, country, lei` | `aliases` separated by `;` |
| `ownership.csv` | `owner_id, owned_id, percent` | percent in (0, 100]; repeated pairs are summed |
| `watchlist.csv` | `list_id, name, aliases, program` | `aliases` separated by `;` |

A missing column stops the run with a clear error. A bad row is skipped or repaired, and the
problem is recorded in `data_issues`:

| Check | Example | Effect |
| --- | --- | --- |
| `unknown_entity` | ownership row naming `E999` | row skipped |
| `self_ownership` | `E001` owns `E001` | row skipped |
| `invalid_percent` | `abc`, `0`, `140` | row skipped |
| `duplicate_link` | same owner/owned pair twice | stakes summed, capped at 100 |
| `over_allocated` | recorded owners total 115% | kept, warned |
| `invalid_value` | negative market value | treated as 0, warned |

## Pipeline

1. **Register to watchlist.** Each watchlist name and alias is resolved against the entity
   register's names and aliases. A score of `block_match` (0.92) or above confirms a listing.
   Scores from `review_match` (0.80) up to 0.92 are possible matches.
2. **Propagation.** Confirmed listings seed the 50% rule over the ownership graph (see below).
3. **Issuer resolution.** In order: exact LEI, then an unambiguous normalised name in O(1), then
   fuzzy matching at `issuer_match` (0.90) or above. An unresolved issuer is sent to REVIEW, because
   an unknown issuer cannot be cleared.
4. **Assessment.**
   - BLOCKED: the issuer's entity is listed, or blocked under the 50% rule.
   - REVIEW: the entity has a possible watchlist match, or blocked parties own between
     `review_share` (25%) and 50% of it.
   - CLEAR: none of the above. A blocked stake below 25% is still reported in the reasons.

## Name matching

`normalize_name` applies NFKD folding, strips non-ASCII marks, case-folds, tokenises and removes
trailing legal suffixes (`ltd`, `plc`, `llc`, `inc`, `co`, `corp`, ...). Two names are then scored:

| Situation | Score | Signal |
| --- | --- | --- |
| Identical after normalisation | 1.00 | `normalized_exact` |
| Same tokens, different order | 0.97 | `token_order_variant` |
| Otherwise | 0.55 x sequence ratio + 0.35 x soft token overlap + 0.10 x containment | `high_token_overlap`, `high_string_similarity`, ... |

*Soft token overlap* is a Jaccard index in which two tokens count as shared when their Jaro-Winkler
similarity is at least 0.88. Tokens of three characters or fewer must match exactly, so initials
and short words cannot create false matches. Examples from the labelled set:

| Register name | Watchlist name | Score | Outcome |
| --- | --- | --- | --- |
| Volkov Maritime Holdings PLC | Volkov Maritime Holdings | 1.00 | listed |
| Karimov Yusuf | Yusuf Karimov | 0.97 | listed |
| Volkoff Maritime Holdings | Volkov Maritime Holdings | 0.87 | review |
| Red Delta Petrochemicals | Red Delta Petroleum | below 0.80 | clear |
| Olena Petrenko | Aleksandr Petrenko | below 0.80 | clear |

**Candidate generation.** Names are indexed by token. For each query, candidates are ranked by the
summed inverse document frequency of the tokens they share with it, and only the top
`max_candidates` (50) are scored in full. Ties are broken by record index, and tokens are visited in
sorted order, so the candidate set does not depend on Python's per-process hash seed.

## The 50% rule

OFAC's guidance (13 August 2014; [FAQ 401](https://ofac.treasury.gov/faqs/401)) treats an entity as
blocked if one or more blocked persons own 50% or more of it, directly or indirectly, in aggregate.
"Indirectly" means through entities that are themselves 50%-or-more owned by blocked persons. A
stake held through an unblocked intermediary does not count.

```text
queue <- confirmed listed entities
while queue not empty:
    owner <- pop(queue)
    for (owned, pct) in holdings_of[owner]:
        share[owned] += pct
        record owner as a contributor to owned
        if owned not yet blocked and share[owned] >= 50:
            mark owned blocked; push owned
```

Each entity is pushed at most once, when it first becomes blocked, and each edge is relaxed only
when its owner is popped, so the cost is O(V + E). Cycles terminate because an entity already
blocked is never pushed again. Contributors form a DAG of explanations, which `BlockingResult.tree`
renders depth-bounded and cycle-safe.

`tests/test_screening_ownership.py` checks the worklist against a naive "recompute every share until
nothing changes" implementation on 300 random graphs that include cycles.

## Report

`reports/screening-latest.json` contains:

- `config`: every threshold used.
- `inputs`: the workspace-relative path, SHA-256 and row count of each input.
- `summary`: counts and market value by status, plus graph statistics.
- `holdings[]`: status, reasons, register match, watchlist matches, blocked share and an
  explanation tree.
- `data_issues[]` and `timing_ms`.
- `evaluation`, when `--labels` is given: a confusion matrix, accuracy, precision, recall and F1
  for BLOCKED and for "flagged" (BLOCKED or REVIEW), plus the list of misclassified holdings.

Each run is also recorded in the audit chain as a `screening.run` event, holding the input digests
and the status counts.

## Benchmarks

`samples/screening/labels.csv` describes 30 scenarios, one per holding, each with a written
rationale. `mika evaluate` runs them and fails unless blocked recall is 1.0 and accuracy is at least
0.9. It also times a seeded run with 5,000 entities. The 50,000-entity figure in the README comes
from `scripts/generate_screening_data.py --entities 50000`.

The scenarios are hand-built to exercise the rules. They are a regression suite, not an estimate of
accuracy on real sanctions data, where transliteration, missing identifiers and stale ownership
records dominate.
