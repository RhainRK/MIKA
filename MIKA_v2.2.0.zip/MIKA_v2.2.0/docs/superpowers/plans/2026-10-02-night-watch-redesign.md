# Night watch redesign and cleanup: implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Ship MIKA 2.1.0 with the Night watch UI, the Lunar A logo and measured backend cleanup,
with zero regressions.

**Architecture:** The backend keeps its modules. `Database` caches schema setup per path,
`MikaApp.search` centralises scoped search, and the CLI dispatches through a table. The frontend
becomes plain TypeScript ES modules compiled by `tsc` into `dashboard/dist/`, loaded with
`<script type="module">` under the existing CSP (`script-src 'self'`).

**Tech stack:** Python 3.13, FastAPI, SQLite, TypeScript 5.8 (strict), headless Edge over CDP for
browser tests.

**Spec:** `docs/superpowers/specs/2026-10-02-night-watch-redesign-design.md`

## Global constraints

- Version `2.1.0` in `mika/__init__.py`, `pyproject.toml` and `dashboard/package.json`.
- No new runtime dependencies. No external fonts, scripts or CDNs; the CSP is unchanged except for
  adding `img-src 'self' data:` if the favicon needs it.
- No literal U+2014 or U+2026 in text files (`scripts/release_check.py`).
- Sentence case, no all-caps labels, status colour always paired with text or an accessible name.
- Existing API shapes stay backward compatible.

## Review focus

1. **Empty portfolio (total value 0).** The moon must render as a new moon with no NaN in the
   SVG path. Pin with a TS-free check: the browser smoke test loads a report with
   `total_market_value: 0`.
2. **A deep link to a holding that no longer exists** (`#exposure/H99`). It must fall back to the
   default selection without throwing. The smoke test navigates to it.
3. **Two processes or connections opening the same database.** The schema cache must not skip
   setup for a *different* path. A pytest test opens two paths.
4. **A theme toggle conflicting with the OS setting.** An explicit choice must persist, and
   storage access must be wrapped in try/catch. The smoke test runs with storage throwing.
5. **Long issuer names (60+ characters).** No horizontal overflow at 390px. The smoke test checks
   `scrollWidth`.

---

### Task 1: Schema setup once per database path

**Files:** modify `mika/storage.py`; test `tests/test_storage_cache.py`.

**Produces:** `Database(path)` behaves as before. `Database._prepared: set[str]` holds resolved
paths whose schema has been applied in this process.

- [ ] Write the failing tests:

```python
from pathlib import Path
from mika.storage import Database


def test_schema_applied_once_per_path(tmp_path: Path, monkeypatch):
    calls = []
    original = Database._prepare
    monkeypatch.setattr(
        Database, "_prepare", lambda self: (calls.append(self.path), original(self))[1]
    )
    Database._prepared.clear()
    for _ in range(3):
        Database(tmp_path / "a.sqlite3").close()
    Database(tmp_path / "b.sqlite3").close()
    assert [p.name for p in calls] == ["a.sqlite3", "b.sqlite3"]


def test_cached_open_still_has_tables_and_fts(tmp_path: Path):
    Database._prepared.clear()
    Database(tmp_path / "c.sqlite3").close()
    db = Database(tmp_path / "c.sqlite3")
    assert db.fts_enabled
    assert db.conn.execute("PRAGMA user_version").fetchone()[0] == 2
    db.close()
```

- [ ] Run `pytest tests/test_storage_cache.py`. Expected: FAIL, because `_prepare` and
  `_prepared` don't exist.
- [ ] Implement: move `executescript(SCHEMA)`, `_migrate` and the FTS creation into `_prepare()`.
  Call it only when the resolved path isn't in the class-level `_prepared` set (guarded by a
  lock), and recompute `fts_enabled` with a cheap `sqlite_master` lookup when the path is cached.
  `:memory:` databases are always prepared.
- [ ] Run the full pytest suite and record the per-open time before and after.
- [ ] Commit.

### Task 2: Shared scoped search

**Files:** modify `mika/app.py`, `mika/api.py` and `mika/cli.py`; test `tests/test_app_search.py`.

**Produces:**
`MikaApp.search(query: str, k: int, *, source_ids: list[int] | None = None, chunk_ids: list[int] | None = None, case_id: str | None = None) -> list[dict[str, Any]]`.
Each returned row is the `SearchHit` as a dict plus `citation`. It raises `ValueError` for an
unknown case.

- [ ] Write the failing tests: search scoped to a case returns only that case's chunks; an
  unknown case raises `ValueError`; a telemetry span named `mika.retrieval.search` is recorded.
- [ ] Implement it by moving the duplicated block out of `api.search` and the CLI `search`
  branch. Delete `_selected_chunks` from the CLI.
- [ ] Run the full suite and commit.

### Task 3: CLI dispatch table

**Files:** modify `mika/cli.py`.

- [ ] Replace the `if/elif` chain in `main` with `_HANDLERS: dict[str, Callable[[MikaApp, argparse.Namespace], int]]`.
  Each command becomes a small function returning an exit code. Aliases (`database-backup`) map
  to the same function.
- [ ] The existing `tests/test_cli.py` and `tests/test_screening_integration.py` must pass
  unchanged. They are the behavioural contract.
- [ ] Commit.

### Task 4: Batched finding evidence

**Files:** modify `mika/cases.py`; test `tests/test_cases.py` (append).

- [ ] Write the failing test: a case with 3 findings loads evidence with exactly one
  `finding_evidence` query, counted through `conn.set_trace_callback`.
- [ ] Implement with one `SELECT finding_id, chunk_id FROM finding_evidence WHERE finding_id IN (SELECT id FROM findings WHERE case_id=?)`,
  grouped in Python.
- [ ] Run the suite and commit.

### Task 5: Logo assets

**Files:** create `dashboard/assets/mika-logo.svg`, `dashboard/assets/mika-mark.svg` and
`dashboard/src/logo.ts` (`logo(): SVGSVGElement`, built with DOM APIs, using `currentColor` for
the letters and `var(--moon)` for the crescent). Serve `/favicon.svg` from the API.

- [ ] Use the exact geometry from the approved exploration: M `M6,100 V9 L50,66 L94,9 V100`;
  I `M140,0 V100`; K `M184,0 V100 M190,58 L238,0 M206,39 L241,100`; A `M262,100 L302,0 L342,100`;
  crescent centre (302,66), r=17, rotated -18 degrees. Stroke 12, viewBox `-2 -2 348 104`.
- [ ] Add an API test that `/favicon.svg` returns `image/svg+xml` behind auth, and commit.

### Task 6: Frontend modules and the Night watch UI

**Files:** replace `dashboard/src/app.ts` with:
- `api.ts` (typed fetch with error mapping)
- `types.ts`
- `dom.ts` (`h()`, `svg()`, `formatters`)
- `theme.ts`
- `router.ts` (hash routes `#exposure[/ID]`, `#evidence`, `#cases[/ID]`, `#system`)
- `moon.ts` (`moonPath(f, r)`)
- `chain.ts`
- `views/exposure.ts`, `views/evidence.ts`, `views/cases.ts`, `views/system.ts`
- `main.ts`

Also rewrite `dashboard/index.html` and `dashboard/style.css`, and update `tsconfig.json` to
`module: ES2022` with `outDir: dist` and `rootDir: src`.

- [ ] `moonPath(0)` yields no lit path, `moonPath(1)` a full disc, and the result never contains
  `NaN`.
- [ ] Keep every existing capability: search with source and case filters, the source list
  linking to search, case review with report download, health and evaluation, and screening.
- [ ] `npm run typecheck` and `npm run build` must be clean. Commit.

### Task 7: Browser smoke test

**Files:** create `scripts/ui_smoke.mjs`. It launches Edge or Chrome headless over CDP, starts
from a running server URL and an auth header, and visits every route in both themes at 1440 and
390 px. It fails on console errors, page exceptions, or `scrollWidth > innerWidth`, and saves
screenshots to `reports/ui/`.

- [ ] It covers the Review focus items: zero-value report, missing deep link, storage throwing,
  and a long name.
- [ ] Run it, review every screenshot, fix defects and commit.

### Task 8: Release

- [ ] Bump the version to 2.1.0, update the CHANGELOG, README screenshot and logo, and the
  WINDOWS_SETUP views.
- [ ] Run the full gates on a fresh clone, package `MIKA_v2.1.0.zip` with git history, verify it
  and send it.
