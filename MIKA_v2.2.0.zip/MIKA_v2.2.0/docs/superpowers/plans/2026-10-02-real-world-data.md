# Real-world data and monitoring: implementation plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** MIKA ingests real sanctions lists, real entity/parent data and news/filing/social signals
for a real portfolio, privacy-by-default, with synthetic data confined to test fixtures.

**Architecture:** A stdlib SafeClient with per-source host allowlists feeds three packages:
`mika/sanctions`, `mika/portfolio` and `mika/signals`. Each writes provenance snapshots. A
`mika monitor` pipeline composes them with the existing screening engine, and the read-only API
and dashboard gain Signals and feed status.

**Tech stack:** Python 3.13 stdlib (`urllib`, `csv`, `json`, `sqlite3`), pydantic-settings
SecretStr, FastAPI, TypeScript ES modules.

**Spec:** `docs/superpowers/specs/2026-10-02-real-world-data-design.md`

**Execution:** the owner delegated decisions, so this runs natively, task by task, with the full
gates at the end.

## Global constraints

- No new runtime dependencies. No literal U+2014 or U+2026 in text files.
- Every network URL is built from a fixed template on an allowlisted host. User text only ever
  appears percent-encoded.
- Holding-revealing sources run only when named in `MIKA_ONLINE_SOURCES`
  (`gleif,sec,gdelt,reddit,x`). Sanctions downloads are always allowed.
- Secrets use `SecretStr` and never appear in logs, audit, snapshots, reports or API output.
- Reddit and X: never store authors, and expire items after 48 h.

## Review focus

1. **A 429 with a `text/plain` body from GDELT.** The connector must not call `json.loads` on it;
   it backs off and records the source as throttled. Test with a fake transport.
2. **A malformed or adversarial upstream payload** (truncated JSON, a 300 MB body, a redirect to
   another host). The client must raise a typed error and the pipeline must carry on with the
   other sources. Test each case.
3. **A holding name that is a common word** (for example "Apple" against fruit news). Relevance
   requires the exact normalised name or `$TICKER` as whole words; generic single-word matches
   are not enough. Test it.
4. **No portfolio imported yet.** `mika monitor`, the API and the UI must give clear guidance,
   not errors. Cover the CLI, an API test and the smoke test.
5. **Secrets in error paths.** An exception message from the token call must not leak the client
   secret. Test the redaction.

---

### Task 1: Move synthetic data to fixtures

- Move `samples/` to `tests/fixtures/samples/` and `benchmarks/` to `tests/fixtures/benchmarks/`.
- Update the runner, the tests and `scripts/ui_smoke.mjs` to the new paths. The README and setup
  guide drop all sample commands.
- Gate: the full pytest suite and `mika evaluate` both pass.

### Task 2: SafeClient and snapshots

- `mika/connectors/http.py` defines `Source(name, hosts, redirect_hosts, max_bytes,
  min_interval_s, user_agent)`, `SafeClient(transport=None)` with
  `.get(source, url, *, headers=None, params=None, data=None) -> Fetched`, and the errors
  `FetchError` and `Throttled`.
- `mika/connectors/snapshots.py` defines `save(root, source, fetched, ext) -> Path` and
  `prune(root, source, max_age)`.
- Tests:
  - a disallowed host is refused;
  - an http URL is refused;
  - an allowed redirect host succeeds, and any other redirect host raises;
  - the byte cap is enforced;
  - a 429 is retried once, then raises `Throttled`;
  - a minimum interval is honoured, using an injected clock;
  - the snapshot manifest is written.

### Task 3: Sanctions

- `mika/sanctions/{ofac,uk,sync}.py` provide `parse_ofac(sdn: bytes, alt: bytes) -> list[WatchlistEntry]`,
  `parse_uk(csv_bytes) -> list[WatchlistEntry]` and
  `sync(client, workspace, force=False) -> dict`.
- Fixtures: trimmed SDN, ALT and UK files in the real formats, covering the null marker, CRLF,
  multiple programmes, the preamble, repeated address rows and aliases.
- The old `fetch-uk-sanctions` command now routes to sync, so its 25 MiB cap bug disappears.
- CLI: `mika sync sanctions [--force]`.

### Task 4: Portfolio and enrichment

- `mika/portfolio/{holdings,lei,gleif,sec}.py` provide `import_holdings(src, workspace)`,
  `valid_lei(s) -> bool`, `GleifResolver(client, cache)` and `SecTickers(client, cache)`.
- `enrich(workspace, client, sources) -> EnrichResult` writes `data/entities.csv` and
  `data/ownership.csv`.
- Tests:
  - the LEI checksum, against Apple's real LEI `HWUPKR0MPOU8FGXBT394`, one invalid LEI and one
    wrong-length LEI;
  - name search rejects loose matches;
  - a parent walk with a 404 exception is handled;
  - user ownership overrides win over GLEIF;
  - offline mode makes no calls.
- CLI: `mika portfolio import FILE`.

### Task 5: Signals core

- Schema v3 adds a `signals` table.
- `mika/signals/{model,classify,relevance,store}.py`.
- Tests:
  - classifier categories and matched terms;
  - 8-K item mapping;
  - relevance rejects a fruit headline for "Apple Inc." but accepts `$AAPL` and "Apple Inc";
  - upserts are idempotent;
  - retention purges expired rows.

### Task 6: Signal connectors

- `gdelt.py`, `sec_filings.py`, `reddit.py` and `x.py`, each exposing
  `collect(client, holding, settings) -> list[Signal]`.
- Fixtures come from the research samples.
- Tests: the GDELT 429 text; the Reddit token flow with secret redaction; the X max-posts cap;
  the SEC filing URL format.

### Task 7: Monitor pipeline, settings, API

- Settings: `online_sources`, `contact_email` (for the SEC User-Agent), the Reddit and X
  secrets, and `x_max_posts`.
- `mika monitor [--offline]`, `mika feeds check`, `/api/signals`, `/api/feeds`.
- Tests: the offline pipeline end to end with fake transports; each source's failure is
  isolated; the audit event is recorded; secrets never appear in API output.

### Task 8: UI

- A Signals view, a holding-detail signals section, System feed status with attributions, and
  the "Import your portfolio" empty state.
- Gates: strict typecheck, the Node tests, and the smoke test with a Signals route added.

### Task 9: Docs and release

- A full README rewrite for the real-world vision. Update NOTICE (GDELT citation shown in the
  UI), SECURITY, WINDOWS_SETUP and the CHANGELOG.
- Live verification: one small call each to OFAC, GDELT, SEC and GLEIF, plus a range request
  for the UK list.
- Fresh-clone gates, then package the source ZIP and send it.
