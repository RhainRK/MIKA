# MIKA 2.1.0: Night watch redesign and cleanup

Approved 2 October 2026. Version 2.1.0, chosen over the requested 1.7.0 so history does not
appear to go backwards after 2.0.0.

## Goal

A sleek, minimal, professional interface with a distinct identity drawn from the name. Mika
evokes *mikazuki*, the crescent moon: a watcher that stays awake. Plus a new wordmark logo,
measured code cleanup, and no regressions.

## Visual system

| Token | Dark (default) | Light (`prefers-color-scheme: light` or toggle) |
| --- | --- | --- |
| `--bg` | `#0B1526` | `#F3F5F9` |
| `--surface` | `#0E1A2F` | `#FFFFFF` |
| `--raised` | `#15233D` | `#EEF2F8` |
| `--line` | `#273A5E` | `#DCE2EC` |
| `--text` | `#E7ECF6` | `#14213A` |
| `--muted` | `#94A3BD` | `#5B6782` |
| `--moon` (brand, focus, selection only) | `#E8D5A3` | `#A87A1F` |
| `--blocked` / `--review` / `--clear` | `#FF7A7A` / `#F4B740` / `#4FD1A5` | `#C7362F` / `#A86400` / `#1F8A63` |

Type uses the system UI family (Segoe UI Variable / SF Pro / system-ui), because the CSP forbids
external fonts. Sentence case everywhere, no all-caps labels. Numbers use `tabular-nums`. Status
colour is always paired with a word or an accessible name.

## Layout

- **Top bar:** logo, the four views (Exposure, Evidence, Cases, System), "Screened <time>" and a
  theme toggle. Evidence merges the former Search and Sources views.
- **Exposure hero, the one bold element:** a moon whose lit area equals the flagged share
  (BLOCKED plus REVIEW) of portfolio value. Accuracy comes from an elliptical terminator,
  which makes the lit area exactly f times the disc area. Beside it, one sentence ("$19.7M of
  $80.9M needs attention."), a one-line explanation, and three status totals. A clean portfolio
  is a new moon.
- **Below:** the holdings list with filter tabs that show counts, beside the detail panel.
  Selection gets a moon-gold inset edge. ↑/↓ move the selection. The selected holding is kept in
  the URL hash (`#exposure/H05`).
- **Chain diagram:** vertical, with listed parties at the top. Listed nodes are tinted, and
  edges are labelled with their stake.
- No nested cards. One radius for controls (8px) and one for regions (14px).

## Logo: Lunar A

A monoline geometric wordmark on a 100-unit cap height with stroke 12. The A has no crossbar;
a tilted moon-gold crescent sits in its counter. It ships as `dashboard/assets/mika-logo.svg`, a
compact icon `mika-mark.svg` that is also the favicon, and inline in the top bar using
`currentColor`, so it follows the theme.

## Code cleanup

1. `Database`: apply schema and migrations once per database path per process. Measured at
   about 7 ms per API request before.
2. One shared `MikaApp.search()` (case scoping and the telemetry span), used by both the CLI
   and the API.
3. The CLI's 18-branch `elif` chain becomes a command-to-handler table.
4. `CaseStore.get_case`: one query for all findings' evidence instead of one per finding.
5. The frontend splits into ES modules compiled by `tsc` (no bundler or framework), served from
   `/assets`.

## Testing

pytest (with new tests for items 1, 2 and 4), mypy strict, ruff, bandit, pip-audit, the release
check and a fresh-clone CI run. A headless Edge smoke test loads every view in both themes at
1440px and 390px, fails on any console error or horizontal overflow, and saves screenshots for
review.

## Out of scope

Editing cases in the UI, live data feeds, and authentication changes.
