# MIKA 2.1.0: real-world data and monitoring

Approved 2 October 2026. The owner delegated detailed decisions ("I trust you to make the best
decisions"). Ships as the final 2.1.0, because 2.1.0 has not been published.
API facts come from `docs/research/real-data-sources.md`.

## Goal

MIKA screens and monitors a **real** portfolio:

- real sanctions lists (OFAC SDN and the UK Sanctions List);
- real legal-entity identity and parent links (GLEIF, SEC);
- news, filings and social posts that mention holdings (GDELT, SEC 8-K, Reddit, X).

Synthetic data leaves the product and lives only in test fixtures.

## Principles

1. **Privacy by default.** Downloading a public sanctions list reveals nothing, so it is always
   allowed. Every lookup that reveals holdings (GLEIF, SEC, GDELT, Reddit, X) is off until it is
   listed in `MIKA_ONLINE_SOURCES`.
2. **Provenance.** Every raw response is saved with its source URL, fetch time and SHA-256. Every
   result traces back to a stored snapshot.
3. **Untrusted text.** News and social text is evidence, never instructions. It is prompt-injection
   scored, never rendered as HTML, and never sent to a model as instructions.
4. **Respect each source's terms.** Rate limits are enforced in code. Attribution is shown. Reddit
   and X data is retained for 48 hours and author identities are never stored.
5. **No new runtime dependencies.** The HTTP client uses the standard library.

## Components

### `mika/connectors/http.py`: SafeClient

- HTTPS only; each source allows an explicit set of hosts.
- Redirects are refused, except to that source's own allowlisted redirect hosts. OFAC redirects
  to its signed S3 host.
- Responses are streamed with a per-source byte cap (UK list 120 MB; others 10 MB or less).
- Timeouts, and a minimum interval between requests per host. GDELT waits 5 s and GLEIF 1 s; SEC
  is limited to 10 requests per second.
- A 429 is retried at most once, honouring `Retry-After`, otherwise after the source's interval.
- Returns `Fetched(url, status, content_type, body, sha256, fetched_at)`. Secrets are never logged.

### Snapshots: `mika/connectors/snapshots.py`

`data/sources/<source>/<UTC timestamp>-<sha8>.<ext>` holds each raw response, and `manifest.jsonl`
records `url, sha256, bytes, fetched_at`. Snapshots older than 30 days are pruned. Reddit and X
snapshots are pruned after 48 hours.

### Sanctions: `mika/sanctions/`

- `ofac.py` parses the headerless `SDN.CSV` (12 columns) and `ALT.CSV` (5 columns). It handles the
  `-0- ` null marker, CRLF line endings and end-of-file junk rows, and splits programmes on `] [`.
- `uk.py` parses the UK list: it skips the `Report Date` preamble line, then groups rows by
  `Unique ID`. The name comes from `Name 6` plus `Name 1` to `Name 5`; alias rows come from
  `Name type`; the programme from `Regime Name`.
- `sync.py`:
  - downloads both lists, using the cached copy when it is less than 24 h old;
  - merges them into `data/watchlist.csv` in the screening format, with IDs prefixed `OFAC-` or
    `UK-`;
  - records each source's snapshot digest.
- Command: `mika sync sanctions [--force]`. The UK attribution travels in the output.

### Portfolio and enrichment: `mika/portfolio/`

- `mika portfolio import FILE` validates a holdings CSV and stores it as
  `data/portfolio/holdings.csv`.
  - Required: `issuer`, `market_value_usd`.
  - Optional: `holding_id`, `identifier` (an LEI, ISIN or ticker).
  - LEIs are checked with the ISO 17442 / ISO 7064 MOD 97-10 check digits.
- `gleif.py` resolves each holding to an LEI.
  - An identifier LEI is used directly.
  - Otherwise MIKA runs a full-text search, but accepts a result only when its normalised legal
    name matches exactly, because GLEIF name search is loose.
  - It then walks direct-parent links up to 5 levels, recording reporting exceptions such as
    `NATURAL_PERSONS`. A 404 means "no parent reported".
  - Results are cached for 7 days.
- `sec.py` maps tickers to CIK and name using `company_tickers.json`, cached for 7 days.
- The output is `data/entities.csv` and `data/ownership.csv`.
  - GLEIF links have `percent=100` and `basis=accounting_consolidation`. A consolidating parent
    controls the entity, and this is labelled "control, % not disclosed".
  - An optional user file, `data/ownership-overrides.csv`, holds exact percentages and wins over
    GLEIF.

### Signals: `mika/signals/`

- **Model.**
  - Fields: `Signal(source, external_id, holding_id, entity_name, title, url, published_at,
    matched_term, categories, severity, injection_score, expires_at)`.
  - Stored in SQLite (`signals` table, schema version 3), unique on `(source, external_id,
    holding_id)`.
- **Relevance.** An item is kept only when the holding's normalised name, an alias or its
  `$TICKER` appears as whole words in the title or text.
- **Classifier.** A deterministic lexicon assigns categories, and each signal records the words
  that matched:
  - `sanctions`, `legal_regulatory`, `fraud`, `financial_distress`, `governance`, `cyber`,
    `operations`.
  - SEC 8-K items map directly: 1.03 is distress, 4.01 and 4.02 are governance or accounting,
  5.02 is governance, 1.05 is cyber, and 3.01 is a delisting.
  - Severity is high, medium or low, from the category weight and the source.
- **Connectors.**
  - `gdelt.py`: one query per holding, `sourcelang:english`, at most 25 records over 7 days.
  - `sec_filings.py`: 8-K filings from the last 30 days, through the submissions API.
  - `reddit.py`: app-only OAuth. It needs `MIKA_REDDIT_CLIENT_ID`, `MIKA_REDDIT_CLIENT_SECRET`
    and `MIKA_REDDIT_USERNAME`. Reddit now requires its own approval before access, and the
    documentation says so.
  - `x.py`: a bearer token. `MIKA_X_MAX_POSTS` (default 100 per run) caps spend at $0.005 per
    post read.
- **Retention.** No author identities are stored. Reddit and X signals expire after 48 hours;
  others after 90 days. `mika monitor` purges expired rows before collecting.
- **Evidence.** Each run's signal text is ingested as one provenance-tracked evidence source, so
  injection quarantine applies to it.

### Pipeline: `mika monitor`

The steps run in this order:

1. Sync sanctions if they are stale.
2. Enrich holdings (GLEIF and SEC, if enabled).
3. Screen with the existing engine, writing `reports/screening-latest.json`.
4. Collect signals from the enabled sources, flagged holdings first.
5. Write `reports/monitor-latest.json` and record a `monitor.run` audit event.

`--offline` skips every network call. `mika feeds check` makes one minimal live call per enabled
source and reports its status.

### API and UI

- `GET /api/signals?holding_id&category&source&limit` (read-only) and `GET /api/feeds`, which
  returns source status, attribution and whether a key is configured, as a boolean only.
- A **Signals** view: a feed sorted by severity, then time, with source and category filters.
  Every row links to the original URL.
- A **holding detail** section listing the holding's signals.
- The **System** view shows each source's status and the required attributions.
- The empty state is "Import your portfolio", with the exact commands.

### Removing synthetic data

`samples/` and `benchmarks/` move to `tests/fixtures/`. The evaluation and screening gates keep
running on the fixtures. The README and setup guide document only real-world use.

## Security

- **Secrets.** Read from the environment or `.env` as `SecretStr`. They are redacted from audit
  and telemetry, and never stored in snapshots or reports.
- **SSRF.** Every URL is built from fixed templates on allowlisted hosts. User text only ever
  appears percent-encoded in query parameters.
- **Denial of service.** Caps on bytes, items per holding, holdings per run and request rates.
- **Injection.** External text is shown with `textContent` only, and receives injection scores
  and quarantine.

## Testing

- Offline unit tests use recorded fixtures (trimmed real formats) for every connector and parser.
- Separate tests cover the LEI checksum, the classifier, relevance matching, retention and the
  SafeClient's redirect, byte-cap and rate-limit rules.
- Pipeline tests use a fake transport.
- The browser smoke test covers the Signals view.
- Live verification: one small call per public source during the build. The UK list is checked
  with a range request only.
