# Public data

MIKA's public data sources, the commands that use them, and their terms are summarised in the
README's "Data sources" table and recorded in detail in [NOTICE.md](../NOTICE.md). The API facts
behind each connector, checked against official documentation and live responses, are in
[research/real-data-sources.md](research/real-data-sources.md).

```text
mika sync sanctions          # OFAC SDN + UK Sanctions List; always allowed
mika feeds check             # one minimal live call per enabled source
mika monitor                 # sync, enrich, screen, collect signals
```

Preserve the snapshot digests in `data/sources/*/manifest.jsonl` with any exported analysis. They
record the exact list versions a screening result was based on.
