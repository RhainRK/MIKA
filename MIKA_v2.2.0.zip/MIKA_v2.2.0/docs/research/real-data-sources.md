# Real data sources: API facts for MIKA

Researched 2026-10-02 against primary sources (official docs and live calls to official endpoints).
Live calls used `User-Agent: MIKA-research/2.1`, except SEC calls, which added a contact address as SEC requires.
**UNVERIFIED** marks anything not confirmed in a primary source or by a live call.

## Summary

| Source | Auth needed | Rate limit | Cost |
|---|---|---|---|
| GDELT DOC 2.0 | None | 1 request per 5 s (from a live HTTP 429 body) | Free |
| SEC EDGAR | None (User-Agent with contact info required) | 10 requests/s across all of a user's machines | Free |
| GLEIF API v1 | None | UNVERIFIED (60 req/min per a GLEIF vLEI document; no rate headers seen) | Free |
| OFAC SDN (Sanctions List Service) | None | None documented | Free |
| UK Sanctions List (FCDO) | None | None documented | Free |
| Reddit Data API | OAuth client ID and secret, **and explicit approval from Reddit** | 100 queries/min per OAuth client ID, averaged over 10 min | Free for approved non-commercial use |
| X API v2 | Bearer token (app-only) | 450 req/15 min per app on recent search | Pay per use: $0.005 per post read; no free tier listed |

---

## 1. GDELT DOC 2.0 API

**Endpoint:** `GET https://api.gdeltproject.org/api/v2/doc/doc`

**Parameters** (source: https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/)
- `query`: keywords, `"exact phrase"`, `(a OR b)`. Operators: `domain:`, `domainis:`, `sourcelang:`, `sourcecountry:` (name or FIPS 2-char code), `theme:`, `tone>5` / `tone<-5`, `near20:"a b"`, plus image operators.
- `mode`: `artlist`, `artgallery`, `imagecollage`, `imagecollageinfo`, `imagegallery`, `timelinevolinfo`, `timelinevolraw`, `tonechart`, `wordcloud*`, plus other timeline modes (the full list was not extracted).
- `format`: `html` (default), `csv`, `json`, `jsonp`, `rss`, `rssarchive`, `jsonfeed`.
- `maxrecords`: default 75, **max 250** (artlist and image collage modes only).
- `timespan`: a number plus a unit: `min`, `h`/`hours`, `d`/`days`, `w`/`weeks`, `m`/`months`. Default and maximum are both about 3 months.
- `startdatetime` / `enddatetime`: `YYYYMMDDHHMMSS`, within the last 3 months.
- `sort`: `datedesc`, `dateasc`, `tonedesc`, `toneasc`, `hybridrel` (default relevance).

**Artlist JSON fields** (live): `articles[]` with `url`, `url_mobile` (may be `""`), `title`, `seendate`, `socialimage`, `domain`, `language` (English name, e.g. `"Russian"`), `sourcecountry` (English name, e.g. `"Russia"`).
- `seendate` format: `YYYYMMDDTHHMMSSZ` (UTC), e.g. `20261001T183000Z`. Parse with `%Y%m%dT%H%M%SZ`.
- Response headers: `Content-Type: application/json; charset=utf-8`, `Cache-Control: public, max-age=900`.

**Rate limit (observed):** a second identical request 24 s after the first returned **HTTP 429** with a `text/plain` body (not JSON):
```
HTTP/1.1 429 Too Many Requests
Please limit requests to one every 5 seconds or contact GDELT (address omitted) for larger queries. All high-traffic users should switch to our ngrams dataset: ...
```

**Live sample** (`query="Rosneft"&mode=artlist&format=json&maxrecords=5&timespan=7d`; 2 of 5 articles shown):
```json
{"articles": [
 { "url": "https://russian.rt.com/business/news/1689637-aktivy-evropa-putin",
   "url_mobile": "https://russian.rt.com/business/news/1689637-aktivy-evropa-putin/amp",
   "title": "Путин : активы « Газпрома », « Роснефти » в Европе забрали грубо , нарушая все правила",
   "seendate": "20261001T183000Z", "socialimage": "https://mf.b37mrtl.ru/...png",
   "domain": "russian.rt.com", "language": "Russian", "sourcecountry": "Russia" },
 { "url": "https://www.vedomosti.ru/press_releases/2026/09/29/rosneft-povishaet-effektivnost-obustroistva-mestorozhdenii",
   "url_mobile": "", "title": " « Роснефть » повышает эффективность обустройства месторождений",
   "seendate": "20260929T144500Z", "socialimage": "https://sharing.vedomosti.ru/...jpg",
   "domain": "vedomosti.ru", "language": "Russian", "sourcecountry": "Russia" }
] }
```

**Gotchas**
- A 429 response is plain text. Check the status code and `Content-Type` before calling `json.loads`. Wait at least 5 s between requests and back off on 429. The 24 s gap still got a 429, so the actual limit window is probably stricter or per-IP (**UNVERIFIED**).
- GDELT machine-translates its sources, so an English query matches non-English articles. All 5 results were Russian-language. Add `sourcelang:english` to the query if needed.
- Titles contain spaces around punctuation (` : `, `« »`). Normalise them before deduplicating.
- When there are no matches, the response may be `{}` with no `articles` key (**UNVERIFIED**). Code defensively with `.get("articles", [])`.
- Any minimum query-term length or other query restriction is **UNVERIFIED** (not found in the docs page).

---

## 2. SEC EDGAR

**Fair access** (sources: https://www.sec.gov/about/developer-resources, https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data)
- Maximum 10 requests/second per user, "regardless of the number of machines".
- A `User-Agent` must identify you, in this format: `Sample Company Name AdminContact@<sample company domain>.com`. Unclassified bots are blocked. The SEC "reserves the right to block IP addresses" that send excessive requests.
- `data.sec.gov` does not support CORS (https://www.sec.gov/search-filings/edgar-application-programming-interfaces).

**Ticker map:** `GET https://www.sec.gov/files/company_tickers.json`
- Format: an object keyed by string index: `{"0":{"cik_str":1045810,"ticker":"NVDA","title":"NVIDIA CORP"}, "1":{"cik_str":320193,"ticker":"AAPL","title":"Apple Inc."}, ...}`
- `cik_str` is an **integer** despite its name. About 10,434 entries, about 780 KB. A Range request was ignored and the full file came back.
- Tickers use `-` for share classes (e.g. `BRK-B`).

**Submissions API:** `GET https://data.sec.gov/submissions/CIK##########.json` (10-digit CIK with leading zeros)
- Top-level keys (live): `cik, entityType, sic, sicDescription, ownerOrg, insiderTransactionForOwnerExists, insiderTransactionForIssuerExists, name, tickers, exchanges, ein, lei, description, website, investorWebsite, category, fiscalYearEnd, stateOfIncorporation, stateOfIncorporationDescription, addresses, phone, flags, formerNames, filings`.
- `filings.recent` is **columnar**: parallel arrays `accessionNumber, filingDate, reportDate, acceptanceDateTime, act, form, fileNumber, filmNumber, items, core_type, size, isXBRL, isInlineXBRL, isXBRLNumeric, primaryDocument, primaryDocDescription`.
- `filings.recent` covers "at least one year" or 1,000 filings, whichever is more. Apple returned 1,001. Older filings are in `filings.files[]`, e.g. `{"name":"CIK0000320193-submissions-001.json","filingCount":1256,"filingFrom":"1994-01-26","filingTo":"2015-08-23"}`, each fetched from `https://data.sec.gov/submissions/<name>`.
- The SEC updates it in real time, with "a typical processing delay of less than a second".

**Live sample** (Apple, CIK 0000320193; HTTP 200, 28 KB gzipped):
```
cik=0000320193 name="Apple Inc." tickers=["AAPL"] exchanges=["Nasdaq"]
recent[i] (8-K rows):
 {accessionNumber:"0000320193-26-000018", filingDate:"2026-07-30", form:"8-K", primaryDocument:"aapl-20260730.htm", items:"2.02,9.01", core_type:"XBRL"}
 {accessionNumber:"0001140361-26-015711", filingDate:"2026-04-20", form:"8-K", primaryDocument:"ef20071035_8k.htm", items:"5.02", core_type:"XBRL"}
recent[0]: {accessionNumber:"0001140361-26-038307", filingDate:"2026-10-01", form:"4", primaryDocument:"xslF345X06/form4.xml", items:""}
```

**Building a document URL** (source: accessing-edgar-data page above; a live check returned 200)
```
https://www.sec.gov/Archives/edgar/data/{int(cik)}/{accessionNumber.replace('-','')}/{primaryDocument}
e.g. https://www.sec.gov/Archives/edgar/data/320193/000114036126038307/xslF345X06/form4.xml
```
Each filing folder also has `index.json`, `index.xml` and `index.html`.

**Gotchas**
- `items` is a comma-separated string of 8-K item numbers (e.g. `"2.02,9.01"`), and `""` for non-8-K forms.
- `cik` is a zero-padded string in submissions but an int (`cik_str`) in the ticker map. Archive paths use the unpadded CIK.
- `primaryDocument` can contain a subpath (e.g. `xslF345X06/form4.xml`, the XSL-rendered view).
- `core_type` was present in the live response but not in the docs page we read. Do not rely on it.
- Send `Accept-Encoding: gzip`, because responses are compressed.

---

## 3. GLEIF API v1

**Base:** `https://api.gleif.org/api/v1`. No auth. Uses JSON:API (`Content-Type: application/vnd.api+json`). Docs: https://api.gleif.org/docs, which redirects to a Postman documenter page that could not be machine-read. The facts below come from live calls.

**Search by legal name** (live)
- `GET /lei-records?filter[entity.legalName]=Apple%20Inc.&page[size]=2` returned 24 total hits: first `HWUPKR0MPOU8FGXBT394` "Apple Inc.", second "Apple Ford, Inc.". So the filter is **not** an exact match. Re-check the legal name on your side.
- `filter[fulltext]=...` also works (HTTP 200).
- `GET /autocompletions?field=fulltext&q=Rosneft` returned name suggestions with LEI links, e.g. "Rosneft Trading S.A." to `391200PN90HUDEAMB912`.
- `GET /fuzzycompletions?field=entity.legalName&q=...` exists but returned `{"data":[]}` for both "Rosneft" and "Apple Inc", including with `field=fulltext`. Treat it as unreliable (valid `field` values are **UNVERIFIED**).
- Pagination: `meta.pagination.{currentPage, perPage, from, to, total, lastPage}`. `meta.goldenCopy.publishDate` gives the data snapshot date.

**Record fields** (live): `data[].attributes` has `lei, entity, registration, bic, mic, ocid, qcc, gem, spglobal, conformityFlag`.
- `entity.legalName.name` (an object `{name, language}`, not a string)
- `entity.otherNames[]` (`{name, language, type}`, e.g. `PREVIOUS_LEGAL_NAME`)
- `entity.jurisdiction` (e.g. `US-CA`)
- `entity.status` (`ACTIVE` or `INACTIVE`)
- `entity.legalAddress.country`
- `registration.status` (`ISSUED`, `LAPSED`, ...)

**Relationship endpoints** (listed in `data.relationships` and confirmed live)
| Purpose | Path |
|---|---|
| Direct parent record | `/lei-records/{lei}/direct-parent` |
| Direct parent relationship record | `/lei-records/{lei}/direct-parent-relationship` |
| Direct parent reporting exception | `/lei-records/{lei}/direct-parent-reporting-exception` |
| Ultimate parent record | `/lei-records/{lei}/ultimate-parent` (likewise `-relationship`, `-reporting-exception`) |
| Children | `/lei-records/{lei}/direct-children`, `/ultimate-children`, `/direct-child-relationships`, `/ultimate-child-relationships` |

**When no parent is reported:** in the record's `relationships`, `direct-parent.links` has only a `reporting-exception` link and no `related` link. Calling `/direct-parent` returns **HTTP 404** `{"errors":[{"status":"404","title":"Resource not found","detail":"Related resource not found"}]}`. Live sample for Apple Inc.:
```json
{"data":{"type":"reporting-exceptions","attributes":{"lei":"HWUPKR0MPOU8FGXBT394",
 "category":"DIRECT_ACCOUNTING_CONSOLIDATION_PARENT","reason":"NATURAL_PERSONS","reference":null}}}
```
A subsidiary example: `2549008YU9EOMHFUA249` (APPLE OPERATIONS INDIA PRIVATE LIMITED). Both `/direct-parent` and `/ultimate-parent` return Apple Inc. Its relationship record is:
```json
{"relationship":{"startNode":{"id":"2549008YU9EOMHFUA249","type":"LEI"},"endNode":{"id":"HWUPKR0MPOU8FGXBT394","type":"LEI"},
 "type":"IS_DIRECTLY_CONSOLIDATED_BY","status":"ACTIVE","periods":[...]},
 "registration":{"status":"PUBLISHED","corroborationLevel":"ENTITY_SUPPLIED_ONLY", ...}}
```

**Exception reasons** (https://www.gleif.org/en/about-lei/common-data-file-format/level-2-data-reporting-exceptions-format)
- Categories: `DIRECT_ACCOUNTING_CONSOLIDATION_PARENT`, `ULTIMATE_ACCOUNTING_CONSOLIDATION_PARENT`.
- Active reasons: `NO_LEI`, `NATURAL_PERSONS`, `NON_CONSOLIDATING`, `NO_KNOWN_PERSON`, `NON_PUBLIC`.
- Deprecated reasons that may still appear in old records: `BINDING_LEGAL_COMMITMENTS`, `LEGAL_OBSTACLES`, `DISCLOSURE_DETRIMENTAL`, `DETRIMENT_NOT_EXCLUDED`, `CONSENT_NOT_OBTAINED`.

**Is Level 2 data ownership?** No. It records **accounting consolidation**.
- The ultimate parent is "the highest level legal entity preparing consolidated financial statements".
- The direct parent is "the lowest level legal entity that prepares consolidated financial statements that consolidate the entity".
- Both are judged under US GAAP, IFRS or a local standard.

Sources: ROC policy page https://www.gleif.org/en/lei-data/access-and-use-lei-data/level-2-data-who-owns-whom/roc-policy-on-level-2-data and https://www.gleif.org/en/lei-data/access-and-use-lei-data/level-2-data-who-owns-whom.

**Ownership percentages:**
- The RR-CDF 2.1 format has an *optional* `RelationshipQuantifiers` block (`MeasurementMethod`, `QuantifierAmount`, `QuantifierUnits`) (https://www.gleif.org/en/about-lei/common-data-file-format/current-versions/level-2-data-relationship-record-rr-cdf-2-1-format).
- The live Apple-subsidiary record had none. **Do not expect ownership % from GLEIF.** Consolidation implies control, not a specific share percentage.
- Relationship types: `IS_DIRECTLY_CONSOLIDATED_BY`, `IS_ULTIMATELY_CONSOLIDATED_BY`, `IS_INTERNATIONAL_BRANCH_OF`, `IS_FUND-MANAGED_BY`, `IS_SUBFUND_OF`, `IS_FEEDER_TO`.

**Rate limit:** **UNVERIFIED**. A GLEIF vLEI governance PDF mentions 60 requests/minute, but it is not the API docs. Responses had no rate-limit headers. Budget at most 1 request/s.

**Gotchas**
- Brackets in `filter[...]` and `page[size]` must be URL-encoded (`%5B` and `%5D`) or passed through `requests` params.
- Parent data is self-reported: `corroborationLevel` can be `ENTITY_SUPPLIED_ONLY`.
- An entity with no LEI cannot be traced. Sanctioned Russian entities often have lapsed LEIs (`registration.status = LAPSED`).

---

## 4. OFAC SDN list (Sanctions List Service)

**Download URLs** (confirmed live)
```
https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN.CSV
https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/ALT.CSV
https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/ADD.CSV
https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN_COMMENTS.CSV
```
- Each URL returns a **302 redirect** to a pre-signed S3 URL (`wc2h-sls-prod-public-published.s3.us-gov-west-1.amazonaws.com/...`, `X-Amz-Expires=3600`). The client must follow redirects, and must not cache the S3 URL.
- The legacy URL `https://www.treasury.gov/ofac/downloads/sdn.csv` 302-redirects to the SLS lowercase path, so it still works.
- Observed file sizes: SDN 5.73 MB, ALT 1.07 MB, ADD 1.70 MB. `Content-Type: text/csv`. Range requests work.

**Column order** (no header row). Source: OFAC data spec https://ofac.treasury.gov/media/29976/download?inline= and tutorial https://ofac.treasury.gov/sdn-list-data-formats-data-schemas/tutorial-on-the-use-of-list-related-legacy-flat-files
- SDN.CSV (12 columns): `ent_num, SDN_Name, SDN_Type, Program, Title, Call_Sign, Vess_type, Tonnage, GRT, Vess_flag, Vess_owner, Remarks`
- ALT.CSV (5 columns): `ent_num, alt_num, alt_type, alt_name, alt_remarks`
- ADD.CSV (6 columns): `Ent_num, Add_num, Address, City/State/Province/Postal Code, Country, Add_remarks`
- In ALT and ADD, `ent_num` is a foreign key to SDN `ent_num`.
- Null marker is `-0-`. In the live files it appears **unquoted with a trailing space**, as `-0- `. Strip the value, then compare to `-0-`.
- The spec says ASCII, comma-delimited, with text in double quotes. Live files use **CRLF** line endings. Encoding beyond the ASCII in the first 1.5 KB is **UNVERIFIED**. Decode as `utf-8` with a `latin-1` fallback, or `errors="replace"`.

**Live samples** (first lines):
```
SDN: 36,"AEROCARIBBEAN AIRLINES",-0- ,"CUBA",-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,-0- 
     306,"BANCO NACIONAL DE CUBA",-0- ,"CUBA",-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,"a.k.a. 'BNC'."
ALT: 36,12,"aka","AERO-CARIBBEAN",-0- 
ADD: 173,129,"Ibex House, The Minories","London EC3N 1DY","United Kingdom",-0- 
```

**Gotchas**
- `SDN_Type` is `-0-` for entities (seen live). Individuals are expected to have `"individual"`, and vessels and aircraft `"vessel"`/`"aircraft"` (**UNVERIFIED**: those rows were not in the sample).
- `Program` can hold several codes, e.g. `"RUSSIA-EO14024] [UKRAINE-EO13662"`. Split on `] [` (format **UNVERIFIED** in this session's sample).
- `alt_type`: `aka` seen live. `fka` and `nka` are expected (**UNVERIFIED**).
- There may be a final end-of-file marker line (often `\x1a`) (**UNVERIFIED**). Skip any row whose first field is not an integer.

---

## 5. UK Sanctions List (FCDO)

**URLs** (source: https://www.gov.uk/government/publications/the-uk-sanctions-list)
- CSV: `https://sanctionslist.fcdo.gov.uk/docs/UK-Sanctions-List.csv`. **It still exists**: live HTTP 206, last modified 2026-10-02, **about 50 MB**.
- Other formats at the same path: `.xml`, `.ods`, `.odt`, `.pdf`, `.html`, `.txt`.
- The **OFSI Consolidated List closed on 28 January 2026** and is no longer updated. The UK Sanctions List is now the single UK source.

**Structure** (live first 4 KB)
- Line 1 is a preamble, `Report Date: 02-Oct-2026`. **The header is line 2.** Skip one line before `csv.DictReader`.
- No BOM. UTF-8: non-Latin script names are present. Line endings are LF. `Content-Type: application/octet-stream`.
- Header row:
```
Last Updated,Unique ID,OFSI Group ID,UN Reference Number,Name 6,Name 1,Name 2,Name 3,Name 4,Name 5,Name type,Alias strength,Title,Name non-latin script,Non-latin script type,Non-latin script language,Regime Name,Designation Type,Designation source,Sanctions Imposed,Other Information,UK Statement of Reasons,Address Line 1,...,Address Country,Phone number,Website,Email address,Date Designated,D.O.B,Nationality(/ies),National Identifier number,...,Passport number,...,Position,Gender,Town of birth,Country of birth,Type of entity,Subsidiaries,Parent company,Business registration number (s),IMO number,Current owner/operator (s),...,Hull identification number (HIN)
```

**Columns MIKA needs**

| Field | Column |
|---|---|
| Name | `Name 6`: the entity name or surname. `Name 1`–`Name 5` are forenames and other name parts for individuals. |
| Primary vs alias | `Name type` (seen: `Primary Name`; `Alias` is expected but **UNVERIFIED** in this sample), plus `Alias strength` |
| Regime | `Regime Name`, e.g. `The Afghanistan (Sanctions) (EU Exit) Regulations 2020` |
| Type | `Designation Type` (`Entity`, `Individual`, `Ship`) |
| ID | `Unique ID` (e.g. `AFG0001`); `OFSI Group ID` |
| Ownership | `Parent company` and `Subsidiaries` (free text) |

**Gotchas**
- There is **one row per name and address combination**. The first 67 rows all belonged to a few entities and were repeated per address. Group by `Unique ID`.
- The file is 50 MB. Download it with streaming and cache it with `If-Modified-Since` (`Last-Modified` is sent).
- Dates use `DD/MM/YYYY`.

---

## 6. Reddit Data API

Sources:
- Data API Wiki, updated 2026-09-29: https://support.reddithelp.com/hc/en-us/articles/16160319875092-Reddit-Data-API-Wiki
- Responsible Builder Policy, updated 2026-10-02: https://support.reddithelp.com/hc/en-us/articles/42728983564564-Responsible-Builder-Policy
- OAuth2 wiki: https://github.com/reddit-archive/reddit/wiki/OAuth2
- Live API docs: https://www.reddit.com/dev/api/#GET_search
- Data API Terms, last revised 2026-07-20: https://redditinc.com/policies/data-api-terms

**Access now requires approval.** The Responsible Builder Policy says: "Approval is required: You must request access and get explicit approval before accessing any Reddit data through our API". You request access through a support ticket form. Non-commercial developers are steered toward Devvit. **Creating a "script" app alone is no longer enough.**

**OAuth app-only flow**
```
POST https://www.reddit.com/api/v1/access_token
Authorization: Basic base64(client_id:client_secret)
Body: grant_type=client_credentials
```
- For installed (non-confidential) apps, use `grant_type=https://oauth.reddit.com/grants/installed_client&device_id=...` instead.
- `grant_type=password` exists for script apps acting as their own user.
- Tokens expire after 1 hour.
- API calls go to `https://oauth.reddit.com` with `Authorization: bearer <token>`.

**Search**
```
GET https://oauth.reddit.com/search?q=...&sort=new&t=week&limit=100&type=link
```
- Scope: `read`.
- `q` max 512 characters.
- `sort` is one of `relevance|hot|top|new|comments`.
- `t` is one of `hour|day|week|month|year|all`.
- `limit` default 25, max 100.
- `restrict_sr` is a boolean, used with the `/r/{sub}/search` path.
- Other params: `type` (`sr`, `link`, `user`), `after`, `before`, `count`, `include_facets`, `sr_detail`, `category`.
- The response is a Listing: `data.children[].data` holds the posts, and `data.after` is the pagination cursor.

**User-Agent:** `<platform>:<app ID>:<version string> (by /u/<reddit username>)`, e.g. `python:mika:2.1.0 (by /u/yourname)`. Default user agents like `Python/urllib` "are drastically limited". The wiki says "NEVER lie about your User-Agent."

**Rate limit:**
- **100 QPM per OAuth client ID**, averaged over a 10-minute window.
- Watch the headers `X-Ratelimit-Used`, `X-Ratelimit-Remaining` and `X-Ratelimit-Reset` (seconds).
- Traffic without OAuth is blocked.

**Terms that matter for a personal, non-commercial tool**
- Commercial use, or research beyond rate limits, needs a separate agreement. Selling, sublicensing or deriving revenue requires written approval.
- You must not use content to train ML/AI models without rightsholder permission.
- You must not retain data "beyond your approved use case".
- **Deletion duty:** you must delete posts, comments and author info that were deleted on Reddit. The wiki "strongly recommend[s]" deleting stored user data **within 48 hours**. MIKA should store only aggregates or short-lived data.
- Do not use Reddit trademarks in the app name.

---

## 7. X API v2

Sources:
- Endpoint: https://docs.x.com/x-api/posts/search-recent-posts
- Rate limits: https://docs.x.com/x-api/fundamentals/rate-limits
- Pricing: https://docs.x.com/x-api/getting-started/pricing

**Endpoint:** `GET https://api.x.com/2/tweets/search/recent` with `Authorization: Bearer <app-only bearer token>`. The host `api.x.com` is the current docs host; `api.twitter.com` still being accepted is **UNVERIFIED**.
- `query`: required, 1–4096 characters.
- `max_results`: **10–100**, default 10.
- `start_time` / `end_time`: ISO 8601, within the **last 7 days**.
- Pagination: `next_token` or `pagination_token` (only one may be given).
- `tweet.fields=created_at,author_id,public_metrics,lang`. `public_metrics` holds `retweet_count`, `reply_count`, `like_count`, `quote_count`, plus more on newer docs.
- `expansions=author_id` with `user.fields=username`.

**Rate limit:**
- 450 requests per 15 min per app; 300 per 15 min per user.
- Headers: `x-rate-limit-limit`, `x-rate-limit-remaining`, `x-rate-limit-reset` (Unix timestamp).

**Access and price:**
- **Pay per use with prepaid credits**, bought in the Developer Console: "No subscriptions, pay only for what you use."
- Post read: **$0.005 per post**. User read: $0.010. Owned reads: $0.001.
- Resources are deduplicated per 24-hour UTC day.
- Cap: 3 M post reads per month. Enterprise covers more.
- **No free tier is listed** on the current pricing page. The old Free, Basic ($200/mo) and Pro tiers are not mentioned (**UNVERIFIED** whether they still exist for legacy accounts).
- Recent search being billable under pay-per-use is implied but not stated explicitly (**UNVERIFIED**).
- Cost example: 1 query/hour × 100 posts ≈ 2,400 post reads per day ≈ **$12/day** before deduplication. Budget carefully or keep X optional.

---

## Source index
- GDELT: https://blog.gdeltproject.org/gdelt-doc-2-0-api-debuts/ ; live https://api.gdeltproject.org/api/v2/doc/doc
- SEC: https://www.sec.gov/about/developer-resources ; https://www.sec.gov/search-filings/edgar-search-assistance/accessing-edgar-data ; https://www.sec.gov/search-filings/edgar-application-programming-interfaces
- GLEIF: https://www.gleif.org/en/lei-data/gleif-api ; https://api.gleif.org/docs ; https://www.gleif.org/en/about-lei/common-data-file-format/level-2-data-reporting-exceptions-format ; https://www.gleif.org/en/about-lei/common-data-file-format/current-versions/level-2-data-relationship-record-rr-cdf-2-1-format ; https://www.gleif.org/en/lei-data/access-and-use-lei-data/level-2-data-who-owns-whom/roc-policy-on-level-2-data
- OFAC: https://ofac.treasury.gov/media/29976/download?inline= ; https://ofac.treasury.gov/sdn-list-data-formats-data-schemas/tutorial-on-the-use-of-list-related-legacy-flat-files ; https://ofac.treasury.gov/faqs/topic/1641
- UK: https://www.gov.uk/government/publications/the-uk-sanctions-list
- Reddit: see section 6
- X: see section 7
