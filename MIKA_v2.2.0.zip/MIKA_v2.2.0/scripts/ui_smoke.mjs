// Browser smoke test for the MIKA dashboard, driven over the Chrome DevTools Protocol.
//
//   MIKA_UI_AUTH=<base64 of mika:password> node scripts/ui_smoke.mjs http://127.0.0.1:8000 reports/ui
//
// Uses Edge or Chrome in headless mode (no extra packages). Every view is visited in both themes
// at desktop and phone widths, plus edge cases. A scenario fails on console errors, uncaught
// exceptions, horizontal overflow, phantom scroll height, rendered NaN, or a failed assertion.
// Each scenario runs in a fresh browser process: reusing one browser across viewport changes
// intermittently made headless screen capture stall for about a minute per shot.
import { spawn } from "node:child_process";
import { existsSync, mkdirSync, mkdtempSync, writeFileSync } from "node:fs";
import { tmpdir } from "node:os";
import { join } from "node:path";

const [base = "http://127.0.0.1:8000", outDir = "reports/ui"] = process.argv.slice(2);
const auth = process.env.MIKA_UI_AUTH;
if (!auth) throw new Error("Set MIKA_UI_AUTH to base64(mika:<password>)");
mkdirSync(outDir, { recursive: true });

const executable = [
  process.env.MIKA_BROWSER,
  "C:/Program Files (x86)/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Microsoft/Edge/Application/msedge.exe",
  "C:/Program Files/Google/Chrome/Application/chrome.exe",
  "/usr/bin/google-chrome",
  "/usr/bin/chromium",
  "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
].filter(Boolean).find(path => existsSync(path));
if (!executable) throw new Error("No Edge or Chrome found; set MIKA_BROWSER");

const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
const problems = [];

async function launch(scenario) {
  const port = 9300 + Math.floor(Math.random() * 600);
  const browser = spawn(executable, [
    "--headless=new", `--remote-debugging-port=${port}`, "--no-first-run", "--disable-gpu",
    `--user-data-dir=${mkdtempSync(join(tmpdir(), "mika-ui-"))}`, "about:blank",
  ], { stdio: "ignore" });
  let target;
  for (let i = 0; i < 60 && !target; i++) {
    await sleep(150);
    try { target = (await (await fetch(`http://127.0.0.1:${port}/json`)).json()).find(t => t.type === "page"); } catch { /* starting */ }
  }
  if (!target) { browser.kill(); throw new Error("browser did not start"); }
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  await new Promise(resolve => ws.addEventListener("open", resolve));
  let nextId = 0;
  const pending = new Map();
  ws.addEventListener("message", event => {
    const msg = JSON.parse(event.data);
    if (msg.id && pending.has(msg.id)) { pending.get(msg.id)(msg); pending.delete(msg.id); return; }
    if (msg.method === "Runtime.exceptionThrown") problems.push(`${scenario}: exception ${msg.params.exceptionDetails.exception?.description ?? msg.params.exceptionDetails.text}`);
    if (msg.method === "Runtime.consoleAPICalled" && msg.params.type === "error") problems.push(`${scenario}: console.error ${msg.params.args.map(a => a.value ?? a.description).join(" ")}`);
    if (msg.method === "Log.entryAdded" && msg.params.entry.level === "error") problems.push(`${scenario}: ${msg.params.entry.text} ${msg.params.entry.url ?? ""}`);
  });
  const send = (method, params = {}) => new Promise(resolve => {
    const id = ++nextId;
    pending.set(id, resolve);
    ws.send(JSON.stringify({ id, method, params }));
  });
  const evaluate = async expression => (await send("Runtime.evaluate", { expression, returnByValue: true, awaitPromise: true })).result.result.value;
  const close = () => { ws.close(); browser.kill(); };
  return { send, evaluate, close };
}

let visits = 0;
async function visit(name, { hash, width, theme, init, setup, assert }) {
  const page = await launch(name);
  try {
    await page.send("Runtime.enable");
    await page.send("Log.enable");
    await page.send("Network.enable");
    await page.send("Network.setExtraHTTPHeaders", { headers: { Authorization: `Basic ${auth}` } });
    await page.send("Emulation.setDeviceMetricsOverride", { width, height: width < 600 ? 844 : 1250, deviceScaleFactor: 1, mobile: false });
    await page.send("Emulation.setEmulatedMedia", { features: [{ name: "prefers-color-scheme", value: theme }] });
    if (init) await page.send("Page.addScriptToEvaluateOnNewDocument", { source: init });
    await page.send("Page.navigate", { url: `${base}/?visit=${++visits}${hash}` });
    await sleep(1400);
    if (setup) { await page.evaluate(setup); await sleep(600); }
    const check = await page.evaluate(`({
      overflow: document.documentElement.scrollWidth > innerWidth + 1,
      nan: document.body.innerHTML.includes("NaN"),
      // The page must not scroll far past its last visible content (escaped absolute elements).
      phantom: document.documentElement.scrollHeight - Math.max(innerHeight, ...[...document.querySelectorAll("main > section:not([hidden]) > *")].map(el => el.getBoundingClientRect().bottom + scrollY)) > 160,
    })`);
    if (check.overflow) problems.push(`${name}: horizontal overflow`);
    if (check.nan) problems.push(`${name}: NaN rendered`);
    if (check.phantom) problems.push(`${name}: page scrolls far past its content`);
    if (assert) {
      const failure = await page.evaluate(assert);
      if (failure) problems.push(`${name}: ${failure}`);
    }
    // Let the one-time moon animation finish and every tile rasterise before capturing.
    await page.evaluate("new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))");
    await sleep(700);
    const shot = await page.send("Page.captureScreenshot", { format: "png" });
    writeFileSync(join(outDir, `${name}.png`), Buffer.from(shot.result.data, "base64"));
  } finally {
    page.close();
  }
}

let count = 0;
for (const theme of ["dark", "light"]) {
  for (const [label, width] of [["desktop", 1440], ["phone", 390]]) {
    for (const hash of ["#exposure", "#signals", "#evidence", "#cases", "#system"]) {
      await visit(`${hash.slice(1)}-${theme}-${label}`, { hash, width, theme });
      count++;
    }
  }
}

// Edge cases from the review focus.
const edgeCases = [
  ["deep-link-missing", { hash: "#exposure/H99", width: 1440, theme: "dark",
    assert: `document.querySelector(".holding[aria-current='true']") ? "" : "no fallback selection"` }],
  ["deep-link-H06", { hash: "#exposure/H06", width: 1440, theme: "dark",
    assert: `document.querySelector(".holding[aria-current='true']")?.dataset.id === "H06" ? "" : "holding not selected"` }],
  ["evidence-search", { hash: "#evidence", width: 1440, theme: "dark",
    setup: `document.getElementById("query").value = "Zarvek"; document.getElementById("search-form").requestSubmit();` }],
  ["signals-mentions", { hash: "#signals", width: 1440, theme: "dark",
    setup: `document.getElementById("signal-mentions").click();`,
    // External URLs are untrusted: a javascript: URL must never become a link.
    assert: `document.querySelectorAll('a[href^="javascript"]').length ? "javascript: link rendered"
      : document.querySelectorAll(".signal-warning").length ? "" : "injection warning not shown"` }],
  ["changes-open", { hash: "#exposure", width: 1440, theme: "dark",
    setup: `document.querySelector(".change:not(:disabled)")?.click();`,
    assert: `document.getElementById("exposure-changes").hidden ? "changes panel hidden"
      : document.querySelector(".holding[aria-current='true']")?.dataset.id === document.querySelector(".change")?.dataset.id ? "" : "change did not open its holding"` }],
  ["case-open", { hash: "#cases", width: 1440, theme: "light", setup: `document.querySelector(".case-row")?.click();` }],
  ["keyboard", { hash: "#exposure", width: 1440, theme: "dark",
    setup: `const first = document.querySelector(".holding"); first.focus(); first.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }));` }],
  ["storage-blocked", { hash: "#exposure", width: 1440, theme: "dark",
    init: `Object.defineProperty(window, "localStorage", { get() { throw new Error("storage blocked"); } });`,
    setup: `document.getElementById("theme").click();` }],
];
for (const [name, options] of edgeCases) { await visit(name, options); count++; }

console.log(JSON.stringify({ screenshots: count, outDir, problems }, null, 2));
process.exit(problems.length ? 1 : 0);
