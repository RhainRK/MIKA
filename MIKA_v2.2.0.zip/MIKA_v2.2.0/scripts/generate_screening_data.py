"""Generate a deterministic large synthetic screening universe for scale benchmarks.

Usage:
    python scripts/generate_screening_data.py --entities 50000 --out data/scale
    mika screen --dir data/scale --output reports/screening-scale.json

Names are random combinations of neutral words; any resemblance to real parties is accidental.
"""

from __future__ import annotations

import argparse
import csv
import random
from pathlib import Path

PREFIX = [
    "Aurora",
    "Basalt",
    "Cobalt",
    "Delta",
    "Ember",
    "Falcon",
    "Granite",
    "Harbor",
    "Indigo",
    "Juniper",
    "Keystone",
    "Lumen",
    "Meridian",
    "Nimbus",
    "Onyx",
    "Pioneer",
    "Quartz",
    "Riverstone",
    "Sable",
    "Tundra",
    "Umber",
    "Vertex",
    "Willow",
    "Xenon",
    "Yarrow",
    "Zenith",
    "Amber",
    "Birch",
    "Cedar",
    "Dune",
    "Echo",
    "Fjord",
    "Glacier",
    "Heron",
    "Iris",
    "Jade",
    "Kestrel",
    "Lark",
    "Mesa",
    "North",
    "Oak",
    "Pine",
    "Quill",
    "Raven",
    "Summit",
    "Talon",
    "Union",
    "Valley",
    "Wren",
    "Atlas",
]
MIDDLE = [
    "Atlantic",
    "Pacific",
    "Baltic",
    "Coastal",
    "Continental",
    "Eastern",
    "Western",
    "Northern",
    "Southern",
    "Central",
    "Global",
    "Highland",
    "Lowland",
    "Metro",
    "Urban",
    "Rural",
    "Prime",
    "Allied",
    "United",
    "Royal",
    "Crown",
    "Imperial",
    "Liberty",
    "Heritage",
    "Frontier",
    "Horizon",
    "Pinnacle",
    "Premier",
    "Sterling",
    "Vanguard",
    "Apex",
    "Crescent",
    "Harmony",
    "Infinity",
    "Keystone",
    "Legacy",
    "Monarch",
    "Noble",
    "Orbit",
    "Paragon",
    "Regal",
    "Spectrum",
    "Titan",
    "Unity",
    "Venture",
    "Vista",
    "Zephyr",
]
SECTOR = [
    "Shipping",
    "Logistics",
    "Mining",
    "Energy",
    "Petroleum",
    "Chemicals",
    "Textiles",
    "Semiconductors",
    "Software",
    "Utilities",
    "Agriculture",
    "Pharmaceuticals",
    "Insurance",
    "Capital",
    "Holdings",
    "Trading",
    "Freight",
    "Construction",
    "Telecom",
    "Aerospace",
]
SUFFIX = ("Ltd", "PLC", "LLC", "Inc", "AG", "SA", "Group", "")
# Person names are coined from syllables so a generated "listed" person can never share a real
# person's name.
SYLLABLES = [
    "vel",
    "dor",
    "kin",
    "zar",
    "mol",
    "tre",
    "quen",
    "bas",
    "lir",
    "oth",
    "var",
    "nim",
    "sel",
    "dra",
    "pell",
    "rov",
    "tav",
    "ing",
]


def _coined(rng: random.Random, parts: int) -> str:
    return "".join(rng.choice(SYLLABLES) for _ in range(parts)).capitalize()


def generate(entity_count: int, out: Path, seed: int = 20261002) -> dict[str, int]:
    rng = random.Random(seed)  # nosec B311 - deterministic synthetic data, not security
    out.mkdir(parents=True, exist_ok=True)

    bases = [f"{a} {b} {c}" for a in PREFIX for b in MIDDLE for c in SECTOR]
    rng.shuffle(bases)
    person_count = entity_count // 10
    org_count = entity_count - person_count
    if org_count > len(bases):
        raise SystemExit(f"at most {len(bases) + person_count} entities supported")

    entities: list[tuple[str, str, str]] = []
    for index in range(org_count):
        suffix = rng.choice(SUFFIX)
        entities.append((f"E{index:07d}", f"{bases[index]} {suffix}".strip(), "organisation"))
    for index in range(person_count):
        name = f"{_coined(rng, 2)} {_coined(rng, 3)} {index:05d}"
        entities.append((f"P{index:07d}", name, "person"))

    with (out / "entities.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["entity_id", "name", "aliases", "entity_type", "country", "lei"])
        for entity_id, name, kind in entities:
            lei = f"SYNLEI{entity_id:0>14}"[:20] if kind == "organisation" else ""
            writer.writerow([entity_id, name, "", kind, rng.choice(["GB", "US", "DE", "SG"]), lei])

    # Layered ownership: each organisation gets 0-3 owners from earlier entities, so chains
    # form naturally; a few back-edges introduce cycles.
    links = 0
    with (out / "ownership.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["owner_id", "owned_id", "percent"])
        orgs = [item for item in entities if item[2] == "organisation"]
        people = [item for item in entities if item[2] == "person"]
        for position, (owned_id, _, _) in enumerate(orgs[1:], start=1):
            remaining = 100.0
            owners = {
                (rng.choice(people) if rng.random() < 0.3 else orgs[rng.randrange(position)])[0]
                for _ in range(rng.randint(0, 3))
            }
            for owner_id in sorted(owners):
                percent = round(rng.uniform(5, remaining), 1)
                remaining -= percent
                writer.writerow([owner_id, owned_id, percent])
                links += 1
                if remaining < 5:
                    break
        for _ in range(entity_count // 500):
            low, high = sorted(rng.sample(range(len(orgs)), 2))
            writer.writerow([orgs[high][0], orgs[low][0], round(rng.uniform(1, 20), 1)])
            links += 1

    listed = rng.sample(entities, max(10, entity_count // 100))
    with (out / "watchlist.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["list_id", "name", "aliases", "program"])
        for index, (_, name, _) in enumerate(listed, start=1):
            writer.writerow([f"WL-{index:06d}", name, "", rng.choice(["SYN-A", "SYN-B", "SYN-C"])])

    portfolio = rng.sample(entities[:org_count], min(org_count, max(100, entity_count // 25)))
    with (out / "holdings.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.writer(handle)
        writer.writerow(["holding_id", "issuer", "identifier", "market_value_usd"])
        for index, (_, name, _) in enumerate(portfolio, start=1):
            writer.writerow([f"H{index:06d}", name, "", rng.randint(50_000, 25_000_000)])

    return {
        "entities": len(entities),
        "ownership_links": links,
        "watchlist": len(listed),
        "holdings": len(portfolio),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--entities", type=int, default=50_000)
    parser.add_argument("--out", type=Path, default=Path("data/scale"))
    parser.add_argument("--seed", type=int, default=20261002)
    args = parser.parse_args()
    print(generate(args.entities, args.out, args.seed))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
