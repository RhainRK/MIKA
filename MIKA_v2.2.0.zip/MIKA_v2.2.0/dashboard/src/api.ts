export class NotFound extends Error {}

/** GET JSON from the local API. 404 becomes NotFound so views can show a useful empty state. */
export async function getJson<T>(url: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(url, { signal: signal ?? null, headers: { Accept: "application/json" } });
  if (response.status === 404) throw new NotFound(url);
  if (response.status === 401) throw new Error("Your session has expired. Reload the page and sign in with the password printed by mika serve.");
  if (response.status === 429) throw new Error("Too many requests in a short time. Wait a few seconds, then select Refresh.");
  if (!response.ok) throw new Error(`The local server returned ${response.status}. Select Refresh to try again.`);
  return await response.json() as T;
}

export function message(error: unknown): string {
  return error instanceof Error ? error.message : "Something went wrong. Select Refresh to try again.";
}
