export const VIEWS = ["exposure", "signals", "evidence", "cases", "system"] as const;
export type View = (typeof VIEWS)[number];
export type Route = { view: View; id: string | null };

/** Parse "#view" or "#view/id". Unknown views fall back to Exposure. */
export function parseRoute(hash: string): Route {
  const [rawView = "", ...rest] = hash.replace(/^#/, "").split("/");
  const view = (VIEWS as readonly string[]).includes(rawView) ? (rawView as View) : "exposure";
  const id = rest.length ? decodeURIComponent(rest.join("/")) || null : null;
  return { view, id };
}

export function href(view: View, id?: string | null): string {
  return id ? `#${view}/${encodeURIComponent(id)}` : `#${view}`;
}

/** Record a selection in the URL without adding a history entry. */
export function replaceRoute(view: View, id: string | null): void {
  history.replaceState(null, "", href(view, id));
}
