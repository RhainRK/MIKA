export type Status = "BLOCKED" | "REVIEW" | "CLEAR";

export type ChainNode = {
  entity_id: string;
  name: string;
  listed: boolean;
  blocked: boolean;
  blocked_share: number;
  programs: string[];
  list_ids: string[];
  owners: Array<{ percent: number; node: ChainNode }>;
  truncated?: boolean;
};

export type WatchlistMatch = {
  list_id: string;
  name: string;
  program: string;
  score: number;
  matched_value: string;
  entity_value: string;
};

export type ScreenedHolding = {
  holding_id: string;
  issuer: string;
  identifier: string;
  market_value: number;
  weight: number;
  status: Status;
  reasons: string[];
  entity: { entity_id: string; name: string; score: number; signals: string[] } | null;
  watchlist_matches: WatchlistMatch[];
  blocked_share: number;
  explanation: ChainNode | null;
};

export type StatusTotal = { count: number; market_value: number; weight: number };

export type ScreeningReport = {
  generated_at: string;
  summary: {
    holdings: number;
    total_market_value: number;
    by_status: Record<Status, StatusTotal>;
    entities: number;
    ownership_links: number;
    watchlist_entries: number;
    blocked_by_ownership: number;
    data_issues: number;
  };
  holdings: ScreenedHolding[];
  evaluation?: { cases: number; accuracy: number; blocked: { precision: number; recall: number } };
};

export type SearchHit = {
  citation: string;
  chunk_id: number;
  source_id: number;
  source_name: string;
  locator: string;
  content: string;
  score: number;
  source_sha256: string;
};

export type Source = {
  id: number;
  name: string;
  sha256: string;
  quarantined: boolean;
  chunk_count: number;
  ingest_count: number;
  last_ingested_at: string | null;
};

export type CaseSummary = {
  id: string;
  title: string;
  status: string;
  evidence_count: number;
  finding_count: number;
  updated_at: string;
};

export type CaseDetail = {
  case: { id: string; title: string; objective: string; status: string };
  evidence: Array<{ citation: string; source: string; locator: string; content: string }>;
  findings: Array<{
    id: string;
    statement: string;
    confidence: number;
    evidence_chunk_ids: number[];
    alternatives: string[];
    limitations: string[];
  }>;
};

export type Health = {
  version: string;
  audit_chain_valid: boolean;
  audit_records: number;
  embedding_backend: string;
  fts5: boolean;
  sources: number;
  chunks: number;
};

type Interval = { mean: number | null };
export type Evaluation = {
  status: string;
  created_at: string;
  benchmark_suites: Array<{ name: string; case_count: number; metrics: Record<string, Interval> }>;
  latency: { p50_seconds: number | null; p95_seconds: number | null };
  screening?: {
    cases: number;
    accuracy: number;
    blocked: { precision: number; recall: number };
    scale?: { entities: number; seconds: number };
  };
};

export type Severity = "high" | "medium" | "low" | "info";

export type SignalItem = {
  id: number;
  source: string;
  external_id: string;
  holding_id: string;
  entity_name: string;
  title: string;
  url: string;
  published_at: string;
  matched_term: string;
  categories: string[];
  terms: string[];
  severity: Severity;
  injection_score: number;
};

export type SourceStatus = { status: string; new: number; errors: number; last_error?: string };

export type Feeds = {
  online_sources: string[];
  credentials: { reddit: boolean; x: boolean; contact_email: boolean };
  latest: null | {
    generated_at: string;
    offline: boolean;
    signals: { sources: Record<string, SourceStatus>; collected: number; purged: number };
    sanctions: { synced_at?: string | null; entries?: number | null };
    warnings: string[];
    attribution: string[];
  };
};

export type Direction = "worse" | "new" | "evidence" | "better" | "removed";

export type HoldingChange = {
  holding_id: string;
  issuer: string;
  from: Status | null;
  to: Status | null;
  direction: Direction;
  market_value: number;
  reasons: string[];
  new_matches: string[];
};

export type Changes = {
  generated_at: string;
  since: string | null;
  first_run: boolean;
  changes: HoldingChange[];
  counts: Record<Direction, number>;
  value_newly_flagged: number;
  watchlist: {
    added: number;
    removed: number;
    added_examples: Array<{ list_id: string; name: string; program: string; affects: string[] }>;
  };
};
