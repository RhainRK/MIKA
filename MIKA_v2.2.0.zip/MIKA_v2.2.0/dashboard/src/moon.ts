import { svg } from "./dom.js";

/**
 * Path for the lit part of a moon whose lit AREA is exactly `fraction` of the disc.
 *
 * The terminator is a half-ellipse with semi-axes (r * |1 - 2f|, r). For f <= 0.5 the lit region
 * is the right half-disc minus that half-ellipse: (pi r^2 / 2)(1 - (1 - 2f)) = f * pi r^2.
 * For f > 0.5 it is the right half-disc plus the half-ellipse, which also equals f * pi r^2.
 * Returns null when nothing is lit (a new moon).
 */
export function moonPath(fraction: number, cx: number, cy: number, r: number): string | null {
  const f = Number.isFinite(fraction) ? Math.min(1, Math.max(0, fraction)) : 0;
  if (f <= 0) return null;
  if (f >= 1) return `M${cx},${cy - r} A${r},${r} 0 0 1 ${cx},${cy + r} A${r},${r} 0 0 1 ${cx},${cy - r} Z`;
  const minor = r * Math.abs(1 - 2 * f);
  const sweep = f > 0.5 ? 1 : 0;
  return `M${cx},${cy - r} A${r},${r} 0 0 1 ${cx},${cy + r} A${minor},${r} 0 0 ${sweep} ${cx},${cy - r} Z`;
}

export function moon(fraction: number, label: string): SVGSVGElement {
  const r = 86;
  const lit = moonPath(fraction, 100, 100, r);
  return svg(
    "svg",
    { viewBox: "0 0 200 200", class: "moon", role: "img", "aria-label": label },
    svg("circle", { cx: 100, cy: 100, r, class: "moon-dark" }),
    lit ? svg("path", { d: lit, class: "moon-lit" }) : null,
    svg("circle", { cx: 100, cy: 100, r: r - 0.5, class: "moon-rim" }),
  );
}
