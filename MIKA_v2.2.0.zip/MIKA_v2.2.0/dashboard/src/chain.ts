import { clip, svg } from "./dom.js";
import type { ChainNode } from "./types.js";

/** Plain-language sentences for an ownership tree, listed parties first. */
export function chainSentences(node: ChainNode, out: string[] = []): string[] {
  for (const edge of node.owners) {
    chainSentences(edge.node, out);
    const owner = edge.node.listed ? `${edge.node.name} (listed ${edge.node.list_ids.join(", ")})` : edge.node.name;
    out.push(`${owner} owns ${edge.percent}% of ${node.name}.`);
  }
  return [...new Set(out)];
}

export function depth(node: ChainNode | null): number {
  return node ? 1 + Math.max(0, ...node.owners.map(edge => depth(edge.node))) : 0;
}

type Placed = { node: ChainNode; level: number; column: number };

/**
 * Layered tree layout: listed parties at the top, the screened holding at the bottom.
 * Leaves take consecutive columns; a parent sits at the mean column of its children.
 */
export function chainDiagram(root: ChainNode): SVGSVGElement {
  const placed: Placed[] = [];
  const edges: Array<{ from: Placed; to: Placed; percent: number }> = [];
  let leaves = 0;
  let maxLevel = 0;
  const place = (node: ChainNode, level: number): Placed => {
    maxLevel = Math.max(maxLevel, level);
    const children = node.owners.map(edge => ({ edge, item: place(edge.node, level + 1) }));
    const column = children.length
      ? children.reduce((sum, child) => sum + child.item.column, 0) / children.length
      : leaves++;
    const item = { node, level, column };
    placed.push(item);
    for (const child of children) edges.push({ from: child.item, to: item, percent: child.edge.percent });
    return item;
  };
  place(root, 0);

  const nodeW = 256, nodeH = 52, colGap = 20, rowGap = 44, pad = 4;
  const width = Math.max(1, leaves) * (nodeW + colGap) - colGap + pad * 2;
  const height = (maxLevel + 1) * (nodeH + rowGap) - rowGap + pad * 2;
  const x = (column: number): number => pad + column * (nodeW + colGap);
  const y = (level: number): number => pad + (maxLevel - level) * (nodeH + rowGap);

  const canvas = svg("svg", { viewBox: `0 0 ${width} ${height}`, width, height, class: "chain" });
  for (const edge of edges) {
    const x1 = x(edge.from.column) + nodeW / 2, y1 = y(edge.from.level) + nodeH;
    const x2 = x(edge.to.column) + nodeW / 2, y2 = y(edge.to.level);
    const mid = (y1 + y2) / 2;
    canvas.append(svg("path", {
      d: `M${x1},${y1} C${x1},${mid} ${x2},${mid} ${x2},${y2}`,
      class: `chain-edge${edge.from.node.blocked ? " is-blocked" : ""}`,
      "stroke-width": (1.5 + edge.percent / 25).toFixed(2),
    }));
    const label = svg("text", { x: (x1 + x2) / 2 + 10, y: mid + 4, class: "chain-percent" });
    label.textContent = `${edge.percent}%`;
    canvas.append(label);
  }
  for (const item of placed) {
    const { node } = item;
    const state = node.listed ? "listed" : node.blocked ? "blocked" : "clear";
    const title = svg("title");
    title.textContent = node.name;
    const name = svg("text", { x: 30, y: 22, class: "chain-name" });
    name.textContent = clip(node.name, 30);
    const meta = svg("text", { x: 30, y: 39, class: "chain-meta" });
    meta.textContent = node.listed
      ? `Listed ${node.list_ids.join(", ")}, ${node.programs.join(", ")}`
      : `${node.blocked ? "Blocked, " : ""}${node.blocked_share}% held by blocked owners`;
    canvas.append(svg(
      "g",
      { class: `chain-node is-${state}`, transform: `translate(${x(item.column)},${y(item.level)})` },
      title,
      svg("rect", { width: nodeW, height: nodeH, rx: 10 }),
      svg("circle", { cx: 15, cy: nodeH / 2, r: 4.5, class: "chain-dot" }),
      name,
      meta,
    ));
  }
  return canvas;
}
