import { getJson, message } from "../api.js";
import { button, byId, empty, fmt, h } from "../dom.js";
import type { CaseSummary, SearchHit, Source } from "../types.js";

const form = byId<HTMLFormElement>("search-form");
const query = byId<HTMLInputElement>("query");
const sourceFilter = byId<HTMLSelectElement>("source-filter");
const caseFilter = byId<HTMLSelectElement>("case-filter");
const results = byId<HTMLDivElement>("results");
const resultCount = byId<HTMLSpanElement>("result-count");
const register = byId<HTMLDivElement>("sources");

function keep(select: HTMLSelectElement, options: HTMLOptionElement[]): void {
  const value = select.value;
  select.replaceChildren(...options);
  if ([...select.options].some(option => option.value === value)) select.value = value;
}

function renderHits(hits: SearchHit[]): void {
  resultCount.textContent = fmt.count(hits.length, "matching passage");
  if (!hits.length) {
    results.replaceChildren(empty("No matching evidence", "Try fewer words, or clear the source and case filters."));
    return;
  }
  results.replaceChildren(...hits.map(hit => h(
    "article",
    { class: "hit" },
    h("header", {}, h("span", { class: "citation", text: hit.citation }), h("span", { class: "hit-source", text: hit.source_name })),
    h("p", { text: hit.content }),
    h("footer", {}, h("span", { text: hit.locator }), h("span", { text: `score ${hit.score.toFixed(4)}` }), h("code", { text: `sha256 ${hit.source_sha256.slice(0, 12)}` })),
  )));
}

let controller: AbortController | undefined;
form.addEventListener("submit", async event => {
  event.preventDefault();
  const q = query.value.trim();
  if (!q) { query.focus(); return; }
  controller?.abort();
  const current = new AbortController();
  controller = current;
  const params = new URLSearchParams({ q, k: "8" });
  if (sourceFilter.value) params.append("source_id", sourceFilter.value);
  if (caseFilter.value) params.set("case_id", caseFilter.value);
  resultCount.textContent = "Searching";
  results.setAttribute("aria-busy", "true");
  try {
    renderHits(await getJson<SearchHit[]>(`/api/search?${params.toString()}`, current.signal));
  } catch (error) {
    if (current.signal.aborted) return;
    resultCount.textContent = "Search unavailable";
    results.replaceChildren(empty("Search failed", message(error)));
  } finally {
    if (controller === current) results.removeAttribute("aria-busy");
  }
});

byId<HTMLButtonElement>("clear-filters").addEventListener("click", () => {
  sourceFilter.value = "";
  caseFilter.value = "";
  query.focus();
});

export async function loadSources(): Promise<void> {
  const sources = await getJson<Source[]>("/api/sources");
  keep(sourceFilter, [new Option("All sources", ""), ...sources.map(source => new Option(source.name, String(source.id)))]);
  if (!sources.length) {
    register.replaceChildren(empty("No evidence yet", "Import a file from your MIKA folder, then select Refresh.", "mika ingest samples/operations_incidents.csv"));
    return;
  }
  register.replaceChildren(...sources.map(source => h(
    "div",
    { class: `source${source.quarantined ? " is-quarantined" : ""}` },
    h("div", { class: "source-text" },
      h("span", { class: "source-name", text: source.name, attrs: { title: source.name } }),
      h("span", { class: "muted", text: `${fmt.count(source.chunk_count, "passage")}${source.quarantined ? ", quarantined" : ""}` }),
    ),
    button("Search", () => { sourceFilter.value = String(source.id); query.focus(); }, "quiet"),
  )));
}

export function setCaseOptions(cases: CaseSummary[]): void {
  keep(caseFilter, [new Option("All evidence", ""), ...cases.map(item => new Option(item.title, item.id))]);
}

/** Pre-scope the search form to one case, used by the Cases view. */
export function scopeToCase(caseId: string): void {
  caseFilter.value = caseId;
  sourceFilter.value = "";
  query.focus();
}
