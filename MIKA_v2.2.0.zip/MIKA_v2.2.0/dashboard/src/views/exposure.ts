import { NotFound, getJson } from "../api.js";
import { chainDiagram, chainSentences, depth } from "../chain.js";
import { byId, empty, fmt, h } from "../dom.js";
import { moon } from "../moon.js";
import { replaceRoute } from "../router.js";
import { signalRow } from "../signals.js";
import { signalsFor } from "./signals.js";
import type { Changes, HoldingChange, ScreenedHolding, ScreeningReport, Status } from "../types.js";

const LABEL: Record<Status, string> = { BLOCKED: "Blocked", REVIEW: "Needs review", CLEAR: "Clear" };
const ORDER: Record<Status, number> = { BLOCKED: 0, REVIEW: 1, CLEAR: 2 };

const hero = byId<HTMLDivElement>("exposure-hero");
const changesPane = byId<HTMLDivElement>("exposure-changes");
const body = byId<HTMLDivElement>("exposure-body");
const filters = byId<HTMLDivElement>("exposure-filters");
const list = byId<HTMLDivElement>("holdings");
const detail = byId<HTMLDivElement>("holding-detail");

let report: ScreeningReport | undefined;
let filter: Status | "ALL" = "ALL";
let selected: string | null = null;

function statusTag(status: Status): HTMLElement {
  return h("span", { class: `status status-${status.toLowerCase()}` }, h("span", { class: "dot", attrs: { "aria-hidden": "true" } }), LABEL[status]);
}

function headline(data: ScreeningReport): { title: string; lede: string; flagged: number } {
  const { by_status: by, total_market_value: total, holdings } = data.summary;
  const flaggedValue = by.BLOCKED.market_value + by.REVIEW.market_value;
  const flagged = total > 0 ? flaggedValue / total : 0;
  if (holdings === 0 || total <= 0) {
    return { title: "No holding value to screen.", lede: "The latest report has no holdings with a market value. Screen a portfolio to see exposure here.", flagged: 0 };
  }
  if (flaggedValue === 0) {
    return { title: `All ${fmt.money(total)} is clear.`, lede: "No holding is listed, blocked through ownership or waiting for review. The moon is new: nothing is lit.", flagged: 0 };
  }
  const parts = [
    by.BLOCKED.count ? `${fmt.count(by.BLOCKED.count, "holding")} ${by.BLOCKED.count === 1 ? "is" : "are"} blocked under the 50% rule` : "",
    by.REVIEW.count ? `${fmt.count(by.REVIEW.count, "holding")} ${by.REVIEW.count === 1 ? "needs" : "need"} review` : "",
  ].filter(Boolean);
  return {
    title: `${fmt.money(flaggedValue)} of ${fmt.money(total)} needs attention.`,
    lede: `${parts.join(" and ")}. The lit part of the moon is that share of portfolio value.`,
    flagged,
  };
}

function renderHero(data: ScreeningReport): void {
  const { title, lede, flagged } = headline(data);
  const totals = h("dl", { class: "totals" });
  for (const status of ["BLOCKED", "REVIEW", "CLEAR"] as const) {
    const total = data.summary.by_status[status];
    totals.append(h(
      "div",
      {},
      h("dt", {}, statusTag(status)),
      h("dd", { class: "figure", text: fmt.money(total.market_value) }),
      h("dd", { class: "muted", text: `${fmt.count(total.count, "holding")}, ${fmt.percent(total.weight)}` }),
    ));
  }
  const benchmark = data.evaluation
    ? h("p", { class: "fine", text: `Checked against ${fmt.count(data.evaluation.cases, "labelled scenario")}: ${fmt.percent(data.evaluation.accuracy)} correct.` })
    : null;
  hero.replaceChildren(
    moon(flagged, `${fmt.percent(flagged)} of portfolio value needs attention`),
    h("div", { class: "hero-text" }, h("h1", { text: title }), h("p", { class: "lede", text: lede }), totals, benchmark),
  );
}

const VERB: Record<HoldingChange["direction"], string> = {
  worse: "Got worse",
  new: "New holding",
  evidence: "New evidence",
  better: "Improved",
  removed: "No longer held",
};

function changeRow(change: HoldingChange): HTMLElement {
  const from = change.from ? LABEL[change.from] : "not held";
  const to = change.to ? LABEL[change.to] : "not held";
  const detail = change.direction === "evidence"
    ? `Still ${to.toLowerCase()}; new list match ${change.new_matches.join(", ")}`
    : `${from} to ${to}${change.new_matches.length ? `, matched ${change.new_matches.join(", ")}` : ""}`;
  const row = h(
    "button",
    { class: `change change-${change.direction}`, attrs: { type: "button", "data-id": change.holding_id } },
    change.to ? statusTag(change.to) : h("span", { class: "status", text: "Removed" }),
    h("span", { class: "holding-text" },
      h("span", { class: "holding-name", text: change.issuer, attrs: { title: change.issuer } }),
      h("span", { class: "holding-reason", text: `${VERB[change.direction]}: ${detail}` }),
    ),
    h("span", { class: "holding-value", text: fmt.money(change.market_value) }),
  );
  if (change.to) row.addEventListener("click", () => { filter = "ALL"; renderFilters(); renderList(); select(change.holding_id, true); });
  else row.disabled = true;
  return row;
}

function renderChanges(data: Changes | undefined): void {
  if (!data) { changesPane.hidden = true; return; }
  changesPane.hidden = false;
  const title = h("h2", { text: "Since the last run", attrs: { id: "changes-title" } });
  if (data.first_run || !data.since) {
    changesPane.replaceChildren(title, h("p", { class: "muted", text: "This is the first recorded run. From the next run on, MIKA shows what changed here: new flags, new list entries that touch your holdings, and holdings that improved." }));
    return;
  }
  const list = data.watchlist;
  const touching = list.added_examples.filter(entry => entry.affects.length).length;
  const summary = [
    data.changes.length ? fmt.count(data.changes.length, "holding changed", "holdings changed") : "No holding changed status",
    data.value_newly_flagged > 0 ? `${fmt.money(data.value_newly_flagged)} newly needs attention` : "",
    list.added ? `${fmt.count(list.added, "new list entry", "new list entries")}${touching ? `, ${touching} matching your holdings` : ""}` : "",
    list.removed ? `${fmt.count(list.removed, "list entry", "list entries")} removed` : "",
    list.added || list.removed ? "" : "the sanctions lists are unchanged",
  ].filter(Boolean).join("; ");
  const parts: Node[] = [
    h("div", { class: "pane-head" }, title, h("span", { class: "muted", text: `Compared with ${fmt.date(data.since)}` })),
    h("p", { class: "changes-summary", text: `${summary}.` }),
  ];
  if (data.changes.length) parts.push(h("div", { class: "change-list" }, ...data.changes.slice(0, 12).map(changeRow)));
  if (data.changes.length > 12) parts.push(h("p", { class: "fine", text: `${data.changes.length - 12} more changes are in reports/changes-latest.json.` }));
  changesPane.replaceChildren(...parts);
}

function renderFilters(): void {
  if (!report) return;
  const options: Array<[Status | "ALL", string, number]> = [
    ["ALL", "All", report.summary.holdings],
    ["BLOCKED", "Blocked", report.summary.by_status.BLOCKED.count],
    ["REVIEW", "Review", report.summary.by_status.REVIEW.count],
    ["CLEAR", "Clear", report.summary.by_status.CLEAR.count],
  ];
  filters.replaceChildren(...options.map(([value, label, count]) => {
    const control = h("button", { class: "tab", attrs: { type: "button", "aria-pressed": String(value === filter) } }, label, h("span", { class: "count", text: String(count) }));
    control.addEventListener("click", () => { filter = value; renderFilters(); renderList(); });
    return control;
  }));
}

function visible(): ScreenedHolding[] {
  if (!report) return [];
  return report.holdings
    .filter(item => filter === "ALL" || item.status === filter)
    .sort((a, b) => ORDER[a.status] - ORDER[b.status] || b.market_value - a.market_value);
}

function renderList(): void {
  const rows = visible().map(item => {
    const row = h(
      "button",
      { class: `holding status-${item.status.toLowerCase()}`, attrs: { type: "button", "data-id": item.holding_id } },
      h("span", { class: "dot", attrs: { "aria-hidden": "true" } }),
      h("span", { class: "holding-text" },
        h("span", { class: "holding-name", text: item.issuer, attrs: { title: item.issuer } }),
        h("span", { class: "holding-reason", text: item.reasons[0] ?? "No sanctions links found" }),
      ),
      h("span", { class: "holding-value", text: fmt.money(item.market_value) }),
      h("span", { class: "sr-only", text: `, ${LABEL[item.status]}` }),
    );
    if (item.holding_id === selected) row.setAttribute("aria-current", "true");
    row.addEventListener("click", () => select(item.holding_id, true));
    return row;
  });
  list.replaceChildren(...rows.length ? rows : [empty("Nothing here", "No holdings have this status.")]);
}

function renderDetail(item: ScreenedHolding): void {
  const facts = h("dl", { class: "facts" });
  const fact = (label: string, value: string): void => { facts.append(h("dt", { text: label }), h("dd", { text: value })); };
  fact("Market value", `${fmt.money(item.market_value)}, ${fmt.percent(item.weight)} of portfolio`);
  fact("Register match", item.entity ? `${item.entity.name} (${item.entity.signals.join(", ").replaceAll("_", " ")})` : "Not found in the entity register");
  if (item.identifier) fact("Identifier", item.identifier);

  const reasons = h("ul", { class: "reasons" });
  for (const reason of item.reasons.length ? item.reasons : ["No watchlist match and no blocked ownership."]) reasons.append(h("li", { text: reason }));

  const parts: Node[] = [
    h("header", { class: "detail-head" }, h("h2", { text: item.issuer }), statusTag(item.status)),
    facts,
    h("h3", { text: "Why" }),
    reasons,
  ];
  if (item.explanation?.owners.length) {
    const diagram = chainDiagram(item.explanation);
    diagram.setAttribute("role", "img");
    diagram.setAttribute("aria-label", chainSentences(item.explanation).join(" "));
    const caption = item.explanation.truncated
      ? "Stakes flow down from listed parties. The chain is too large to draw in full; the largest stakes are shown."
      : "Stakes flow down from listed parties to this holding. Thicker lines are larger stakes.";
    parts.push(
      h("h3", { text: "Ownership chain" }),
      h("figure", { class: "chain-figure" }, h("div", { class: "chain-scroll", attrs: { tabindex: "0", "aria-label": "Ownership chain" } }, diagram), h("figcaption", { text: caption })),
    );
  }
  const related = signalsFor(item.holding_id).slice(0, 8);
  parts.push(h("h3", { text: "Recent signals" }));
  parts.push(related.length
    ? h("div", { class: "signal-list compact" }, ...related.map(signal => signalRow(signal, false)))
    : h("p", { class: "muted", text: "No news, filings or posts collected for this holding yet." }));
  if (item.watchlist_matches.length) {
    const matches = h("ul", { class: "reasons" });
    for (const hit of item.watchlist_matches) {
      matches.append(h("li", { text: `${hit.list_id} ${hit.name} (${hit.program}) matched "${hit.entity_value}" at ${hit.score.toFixed(2)}` }));
    }
    parts.push(h("h3", { text: "Watchlist matches" }), matches);
  }
  detail.replaceChildren(...parts);
}

function select(id: string, fromUser: boolean): void {
  const item = report?.holdings.find(holding => holding.holding_id === id);
  if (!item) return;
  selected = id;
  for (const row of list.querySelectorAll<HTMLButtonElement>(".holding")) {
    if (row.dataset.id === id) row.setAttribute("aria-current", "true");
    else row.removeAttribute("aria-current");
  }
  renderDetail(item);
  if (fromUser) {
    replaceRoute("exposure", id);
    if (window.matchMedia("(max-width: 960px)").matches) detail.scrollIntoView({ block: "start" });
  }
}

list.addEventListener("keydown", event => {
  if (event.key !== "ArrowDown" && event.key !== "ArrowUp") return;
  const rows = [...list.querySelectorAll<HTMLButtonElement>(".holding")];
  if (!rows.length) return;
  event.preventDefault();
  const index = rows.findIndex(row => row === document.activeElement);
  const next = rows[Math.max(0, Math.min(rows.length - 1, index + (event.key === "ArrowDown" ? 1 : -1)))];
  if (next?.dataset.id) { next.focus(); select(next.dataset.id, true); }
});

/** Load the latest report. Returns its timestamp, or null when no report exists yet. */
export async function loadExposure(): Promise<string | null> {
  try {
    report = await getJson<ScreeningReport>("/api/screening/latest");
  } catch (error) {
    if (!(error instanceof NotFound)) throw error;
    report = undefined;
    body.hidden = true;
    changesPane.hidden = true;
    hero.replaceChildren(empty(
      "Import your portfolio to start",
      "Export your holdings as a CSV with issuer and market_value_usd columns (optional: identifier for an LEI or ticker), then run these two commands from your MIKA folder and select Refresh.",
      ["mika portfolio import my-portfolio.csv", "mika monitor"],
    ));
    return null;
  }
  body.hidden = false;
  let changes: Changes | undefined;
  try {
    changes = await getJson<Changes>("/api/changes");
  } catch (error) {
    if (!(error instanceof NotFound)) throw error;
  }
  renderHero(report);
  renderChanges(changes);
  renderFilters();
  renderList();
  showExposure(selected);
  return report.generated_at;
}

/** Show a holding by id (from the URL); unknown ids fall back to the deepest ownership chain. */
export function showExposure(id: string | null): void {
  if (!report) return;
  const known = id && report.holdings.some(item => item.holding_id === id) ? id : null;
  const fallback = [...report.holdings].sort((a, b) => depth(b.explanation) - depth(a.explanation))[0];
  const target = known ?? fallback?.holding_id;
  if (target) select(target, false);
}
