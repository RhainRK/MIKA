import { NotFound, getJson } from "../api.js";
import { byId, empty, fmt, h } from "../dom.js";
import type { Evaluation, Feeds, Health } from "../types.js";

const health = byId<HTMLDListElement>("health");
const evaluation = byId<HTMLDivElement>("evaluation");
const feeds = byId<HTMLDivElement>("feeds");

function rows(target: HTMLElement, pairs: Array<[string, string]>): void {
  target.replaceChildren(...pairs.flatMap(([label, value]) => [h("dt", { text: label }), h("dd", { text: value })]));
}

export async function loadHealth(): Promise<void> {
  const data = await getJson<Health>("/api/health");
  rows(health, [
    ["Version", data.version],
    ["Audit chain", data.audit_chain_valid ? `Verified, ${fmt.count(data.audit_records, "record")}` : "Verification failed: run mika audit-verify"],
    ["Evidence", `${fmt.count(data.sources, "source")}, ${fmt.count(data.chunks, "passage")}`],
    ["Search backend", `${data.embedding_backend} embeddings${data.fts5 ? " with full-text index" : ""}`],
  ]);
}

const metric = (value: number | null | undefined): string => (value == null ? "not measured" : value.toFixed(3));

export async function loadEvaluation(): Promise<void> {
  let data: Evaluation;
  try {
    data = await getJson<Evaluation>("/api/evaluation/latest");
  } catch (error) {
    if (!(error instanceof NotFound)) throw error;
    evaluation.replaceChildren(empty("No evaluation yet", "Run the regression suite, then select Refresh.", "mika evaluate"));
    return;
  }
  const facts = h("dl", { class: "facts" });
  const pairs: Array<[string, string]> = [
    ["Result", `${data.status === "passed" ? "Passed" : "Failed"}, ${fmt.date(data.created_at)}`],
  ];
  if (data.screening) {
    pairs.push(["Screening scenarios", `${fmt.percent(data.screening.accuracy)} correct across ${data.screening.cases}, blocked recall ${fmt.percent(data.screening.blocked.recall)}`]);
    if (data.screening.scale) pairs.push(["Screening at scale", `${data.screening.scale.entities.toLocaleString()} entities in ${data.screening.scale.seconds.toFixed(2)} s`]);
  }
  for (const suite of data.benchmark_suites) {
    pairs.push([`Retrieval: ${suite.name}`, `Recall ${metric(suite.metrics.recall_at_k?.mean)}, MRR ${metric(suite.metrics.mrr?.mean)} over ${suite.case_count} queries`]);
  }
  if (data.latency.p50_seconds != null && data.latency.p95_seconds != null) {
    pairs.push(["Search latency", `${(data.latency.p50_seconds * 1000).toFixed(1)} ms median, ${(data.latency.p95_seconds * 1000).toFixed(1)} ms p95`]);
  }
  rows(facts, pairs);
  evaluation.replaceChildren(facts, h("p", { class: "fine", text: "Synthetic regression data. These figures check behaviour, not accuracy on your evidence." }));
}

const SOURCE_NAMES: Record<string, string> = {
  gleif: "GLEIF (entities and parents)", sec: "SEC EDGAR (tickers and 8-K filings)",
  gdelt: "GDELT (news)", reddit: "Reddit", x: "X",
};

export async function loadFeeds(): Promise<void> {
  const data = await getJson<Feeds>("/api/feeds");
  const facts = h("dl", { class: "facts" });
  const pairs: Array<[string, string]> = [
    ["Last monitor run", data.latest ? `${fmt.date(data.latest.generated_at)}${data.latest.offline ? ", offline" : ""}` : "Not run yet: mika monitor"],
    ["Sanctions lists", data.latest?.sanctions.entries ? `${data.latest.sanctions.entries.toLocaleString()} entries (OFAC SDN and UK)` : "Synced on the next monitor run"],
  ];
  for (const name of Object.keys(SOURCE_NAMES)) {
    const enabled = data.online_sources.includes(name);
    const status = data.latest?.signals.sources[name];
    const detail = !enabled ? "Off (privacy setting)"
      : status ? `${status.status}, ${fmt.count(status.new, "new signal")}${status.errors ? `, ${fmt.count(status.errors, "error")}` : ""}`
      : "On";
    pairs.push([SOURCE_NAMES[name] ?? name, detail]);
  }
  pairs.push(["Credentials", `Reddit ${data.credentials.reddit ? "configured" : "not set"}, X ${data.credentials.x ? "configured" : "not set"}, SEC contact ${data.credentials.contact_email ? "set" : "not set"}`]);
  rows(facts, pairs);
  const parts: Node[] = [facts];
  for (const warning of data.latest?.warnings ?? []) parts.push(h("p", { class: "fine warning", text: warning }));
  for (const line of data.latest?.attribution ?? []) parts.push(h("p", { class: "fine", text: line }));
  parts.push(h("p", { class: "fine", text: "Sources that reveal holdings are off until listed in MIKA_ONLINE_SOURCES. Credentials are never shown." }));
  feeds.replaceChildren(...parts);
}
