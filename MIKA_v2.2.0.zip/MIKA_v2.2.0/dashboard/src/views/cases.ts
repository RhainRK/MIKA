import { getJson, message } from "../api.js";
import { byId, empty, fmt, h } from "../dom.js";
import { href, replaceRoute } from "../router.js";
import type { CaseDetail, CaseSummary } from "../types.js";

const list = byId<HTMLDivElement>("case-list");
const detail = byId<HTMLDivElement>("case-detail");

let cases: CaseSummary[] = [];
let request = 0;

export async function loadCases(): Promise<CaseSummary[]> {
  cases = await getJson<CaseSummary[]>("/api/cases");
  if (!cases.length) {
    list.replaceChildren(empty("No cases yet", "Run screening with case creation to open one for every flagged holding.", "mika screen --dir samples/screening --create-cases"));
    return cases;
  }
  list.replaceChildren(...cases.map(item => h(
    "a",
    { class: "case-row", attrs: { href: href("cases", item.id), "data-id": item.id } },
    h("span", { class: "case-title", text: item.title }),
    h("span", { class: "muted", text: `${fmt.count(item.finding_count, "finding")}, ${fmt.count(item.evidence_count, "evidence row")}` }),
  )));
  return cases;
}

export async function showCase(id: string | null): Promise<void> {
  for (const row of list.querySelectorAll<HTMLAnchorElement>(".case-row")) {
    if (row.dataset.id === id) row.setAttribute("aria-current", "true");
    else row.removeAttribute("aria-current");
  }
  if (!id) {
    detail.replaceChildren(empty("Select a case", "Its objective, findings and cited evidence appear here."));
    return;
  }
  const mine = ++request;
  detail.setAttribute("aria-busy", "true");
  try {
    const data = await getJson<CaseDetail>(`/api/cases/${encodeURIComponent(id)}`);
    if (mine !== request) return;
    const findings = h("ol", { class: "findings" }, ...data.findings.map(item => h(
      "li",
      {},
      h("p", { text: item.statement }),
      h("p", { class: "muted", text: `Confidence ${fmt.percent(item.confidence)}${item.alternatives.length ? `. Alternative: ${item.alternatives.join(" ")}` : ""}` }),
    )));
    const evidence = h("ul", { class: "evidence" }, ...data.evidence.map(item => h(
      "li",
      {},
      h("span", { class: "citation", text: item.citation }),
      h("span", { class: "evidence-text", text: item.content }),
    )));
    const report = h("a", { class: "button", text: "Download report", attrs: { href: `/api/cases/${encodeURIComponent(id)}/report` } });
    const search = h("a", { class: "button quiet", text: "Search this evidence", attrs: { href: `#evidence`, "data-case": id } });
    detail.replaceChildren(
      h("header", { class: "detail-head" }, h("h2", { text: data.case.title })),
      ...(data.case.objective ? [h("p", { class: "lede", text: data.case.objective })] : []),
      h("h3", { text: "Findings" }),
      data.findings.length ? findings : h("p", { class: "muted", text: "No findings recorded." }),
      h("h3", { text: `Cited evidence (${data.evidence.length})` }),
      data.evidence.length ? evidence : h("p", { class: "muted", text: "No evidence attached." }),
      h("div", { class: "actions" }, report, search),
    );
  } catch (error) {
    if (mine !== request) return;
    replaceRoute("cases", null);
    detail.replaceChildren(empty("Case unavailable", message(error)));
  } finally {
    if (mine === request) detail.removeAttribute("aria-busy");
  }
}

