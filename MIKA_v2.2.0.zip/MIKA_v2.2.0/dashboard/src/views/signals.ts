import { getJson } from "../api.js";
import { byId, empty } from "../dom.js";
import { categoryLabel, signalRow, sourceLabel } from "../signals.js";
import type { SignalItem } from "../types.js";

const list = byId<HTMLDivElement>("signal-list");
const sourceFilter = byId<HTMLSelectElement>("signal-source");
const categoryFilter = byId<HTMLSelectElement>("signal-category");
const mentions = byId<HTMLInputElement>("signal-mentions");
const count = byId<HTMLSpanElement>("signal-count");
const attribution = byId<HTMLParagraphElement>("signal-attribution");

let items: SignalItem[] = [];

function options(select: HTMLSelectElement, all: string, values: string[], label: (v: string) => string): void {
  const current = select.value;
  select.replaceChildren(new Option(all, ""), ...values.map(value => new Option(label(value), value)));
  if (values.includes(current)) select.value = current;
}

function render(): void {
  const visible = items.filter(item =>
    (mentions.checked || item.severity !== "info")
    && (!sourceFilter.value || item.source === sourceFilter.value)
    && (!categoryFilter.value || item.categories.includes(categoryFilter.value)));
  const hidden = items.filter(item => item.severity === "info").length;
  count.textContent = `${visible.length} shown${!mentions.checked && hidden ? `, ${hidden} plain mentions hidden` : ""}`;
  if (!items.length) {
    list.replaceChildren(empty(
      "No signals yet",
      "Enable news or filings in MIKA_ONLINE_SOURCES (for example gdelt,sec), then run the monitor.",
      "mika monitor",
    ));
  } else if (!visible.length) {
    list.replaceChildren(empty("Nothing matches these filters", "Clear a filter or show plain mentions."));
  } else {
    list.replaceChildren(...visible.map(item => signalRow(item, true)));
  }
  attribution.textContent = items.some(item => item.source === "gdelt")
    ? "News data from The GDELT Project (gdeltproject.org)."
    : "";
}

for (const control of [sourceFilter, categoryFilter, mentions]) control.addEventListener("change", render);

export async function loadSignals(): Promise<void> {
  items = await getJson<SignalItem[]>("/api/signals?limit=500");
  options(sourceFilter, "All sources", [...new Set(items.map(i => i.source))].sort(), sourceLabel);
  options(categoryFilter, "All categories", [...new Set(items.flatMap(i => i.categories))].sort(), categoryLabel);
  render();
}

export function signalsFor(holdingId: string): SignalItem[] {
  return items.filter(item => item.holding_id === holdingId);
}
