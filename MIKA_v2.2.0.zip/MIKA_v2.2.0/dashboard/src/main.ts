import { message } from "./api.js";
import { byId, empty, fmt } from "./dom.js";
import { wordmark } from "./logo.js";
import { VIEWS, type View, parseRoute } from "./router.js";
import { initTheme } from "./theme.js";
import { loadCases, showCase } from "./views/cases.js";
import { loadSources, scopeToCase, setCaseOptions } from "./views/evidence.js";
import { loadExposure, showExposure } from "./views/exposure.js";
import { loadSignals } from "./views/signals.js";
import { loadEvaluation, loadFeeds, loadHealth } from "./views/system.js";

const TITLES: Record<View, string> = { exposure: "Exposure", signals: "Signals", evidence: "Evidence", cases: "Cases", system: "System" };
const screened = byId<HTMLSpanElement>("screened");
const refreshControl = byId<HTMLButtonElement>("refresh");

byId<HTMLAnchorElement>("brand").append(wordmark("MIKA, go to exposure"));
initTheme(byId<HTMLButtonElement>("theme"));

function route(): void {
  const { view, id } = parseRoute(location.hash);
  for (const name of VIEWS) byId<HTMLElement>(`view-${name}`).hidden = name !== view;
  for (const link of document.querySelectorAll<HTMLAnchorElement>("[data-view]")) {
    if (link.dataset.view === view) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  }
  document.title = `${TITLES[view]}, MIKA`;
  if (view === "exposure") showExposure(id);
  if (view === "cases") void showCase(id);
}

/* Each loader fails independently, so one broken endpoint never blanks the whole app. */
async function guarded(target: string, load: () => Promise<unknown>): Promise<void> {
  try {
    await load();
  } catch (error) {
    byId<HTMLElement>(target).replaceChildren(empty("Could not load this section", message(error)));
  }
}

async function refresh(): Promise<void> {
  refreshControl.disabled = true;
  refreshControl.setAttribute("aria-busy", "true");
  await Promise.all([
    guarded("exposure-hero", async () => {
      const at = await loadExposure();
      screened.textContent = at ? `Screened ${fmt.date(at)}` : "Not screened yet";
    }),
    guarded("signal-list", loadSignals),
    guarded("feeds", loadFeeds),
    guarded("sources", loadSources),
    guarded("case-list", async () => setCaseOptions(await loadCases())),
    guarded("health", loadHealth),
    guarded("evaluation", loadEvaluation),
  ]);
  route();
  refreshControl.disabled = false;
  refreshControl.removeAttribute("aria-busy");
}

document.addEventListener("click", event => {
  const link = (event.target as Element | null)?.closest<HTMLAnchorElement>("a[data-case]");
  if (link?.dataset.case) {
    const caseId = link.dataset.case;
    queueMicrotask(() => scopeToCase(caseId));
  }
});

window.addEventListener("hashchange", route);
refreshControl.addEventListener("click", () => { void refresh(); });
route();
void refresh();
