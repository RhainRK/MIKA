/* Small DOM helpers. All user and evidence text goes through textContent, never innerHTML. */

type Child = Node | string | null | undefined | false;

export function h<K extends keyof HTMLElementTagNameMap>(
  tag: K,
  props: { class?: string; text?: string; attrs?: Record<string, string> } = {},
  ...children: Child[]
): HTMLElementTagNameMap[K] {
  const node = document.createElement(tag);
  if (props.class) node.className = props.class;
  if (props.text !== undefined) node.textContent = props.text;
  for (const [key, value] of Object.entries(props.attrs ?? {})) node.setAttribute(key, value);
  for (const child of children) if (child) node.append(child);
  return node;
}

const SVG_NS = "http://www.w3.org/2000/svg";
export function svg<K extends keyof SVGElementTagNameMap>(
  tag: K,
  attrs: Record<string, string | number> = {},
  ...children: Array<SVGElement | null>
): SVGElementTagNameMap[K] {
  const node = document.createElementNS(SVG_NS, tag);
  for (const [key, value] of Object.entries(attrs)) node.setAttribute(key, String(value));
  for (const child of children) if (child) node.append(child);
  return node;
}

export function byId<T extends HTMLElement>(id: string): T {
  const node = document.getElementById(id);
  if (!node) throw new Error(`Missing element #${id}`);
  return node as T;
}

export function button(label: string, action: () => void, className = ""): HTMLButtonElement {
  const node = h("button", { class: className, text: label, attrs: { type: "button" } });
  node.addEventListener("click", action);
  return node;
}

export function empty(title: string, body: string, code?: string | string[]): HTMLElement {
  const commands = code === undefined ? [] : Array.isArray(code) ? code : [code];
  return h(
    "div",
    { class: "empty" },
    h("h3", { text: title }),
    h("p", { text: body }),
    commands.length ? h("div", { class: "commands" }, ...commands.map(line => h("code", { text: line }))) : null,
  );
}

export const ELLIPSIS = String.fromCharCode(0x2026);
export function clip(value: string, length: number): string {
  return value.length > length ? value.slice(0, length - 1) + ELLIPSIS : value;
}

const compact = new Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact", maximumFractionDigits: 1 });
const pct = new Intl.NumberFormat("en-US", { style: "percent", maximumFractionDigits: 1 });
const when = new Intl.DateTimeFormat(undefined, { dateStyle: "medium", timeStyle: "short" });

export const fmt = {
  money: (value: number): string => compact.format(value),
  percent: (value: number): string => pct.format(value),
  date: (iso: string): string => {
    const value = new Date(iso);
    return Number.isNaN(value.getTime()) ? "unknown time" : when.format(value);
  },
  count: (n: number, one: string, many = `${one}s`): string => `${n} ${n === 1 ? one : many}`,
};

/** A link to an external source, or plain text when the URL is not http(s). */
export function externalLink(url: string, text: string, className = ""): HTMLElement {
  let safe = false;
  try {
    const parsed = new URL(url);
    safe = parsed.protocol === "https:" || parsed.protocol === "http:";
  } catch {
    safe = false;
  }
  if (!safe) return h("span", { class: className, text });
  return h("a", { class: className, text, attrs: { href: url, target: "_blank", rel: "noopener noreferrer" } });
}
