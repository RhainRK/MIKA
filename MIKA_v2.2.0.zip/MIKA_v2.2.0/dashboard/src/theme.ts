/* Theme follows the OS until the person picks one; the choice is a per-browser convenience. */

type Theme = "light" | "dark";
const KEY = "mika.theme";
const root = document.documentElement;

function stored(): Theme | null {
  try {
    const value = window.localStorage.getItem(KEY);
    return value === "light" || value === "dark" ? value : null;
  } catch {
    return null;
  }
}

function current(): Theme {
  const explicit = root.dataset.theme;
  if (explicit === "light" || explicit === "dark") return explicit;
  return window.matchMedia("(prefers-color-scheme: light)").matches ? "light" : "dark";
}

function label(control: HTMLButtonElement): void {
  const next = current() === "dark" ? "light" : "dark";
  control.setAttribute("aria-label", `Switch to ${next} theme`);
  control.title = `Switch to ${next} theme`;
}

export function initTheme(control: HTMLButtonElement): void {
  const saved = stored();
  if (saved) root.dataset.theme = saved;
  label(control);
  window.matchMedia("(prefers-color-scheme: light)").addEventListener("change", () => label(control));
  control.addEventListener("click", () => {
    const next: Theme = current() === "dark" ? "light" : "dark";
    root.dataset.theme = next;
    try {
      window.localStorage.setItem(KEY, next);
    } catch {
      // Storage unavailable (private mode, blocked site data): the choice lasts for this page.
    }
    label(control);
  });
}
