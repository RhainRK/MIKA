import { externalLink, fmt, h } from "./dom.js";
import type { Severity, SignalItem } from "./types.js";

const SEVERITY_LABEL: Record<Severity, string> = { high: "High", medium: "Medium", low: "Low", info: "Mention" };
const SOURCE_LABEL: Record<string, string> = { gdelt: "News", sec: "SEC filing", reddit: "Reddit", x: "X" };
const INJECTION_WARNING = 0.35;

export function sourceLabel(source: string): string {
  return SOURCE_LABEL[source] ?? source;
}

export function categoryLabel(category: string): string {
  return category.replaceAll("_", " ");
}

/** One signal as a list row. Titles and terms are external text, so they only ever reach textContent. */
export function signalRow(item: SignalItem, showHolding: boolean): HTMLElement {
  const meta = [
    showHolding ? item.entity_name : "",
    sourceLabel(item.source),
    fmt.date(item.published_at),
    item.categories.map(categoryLabel).join(", "),
  ].filter(Boolean).join(", ");
  const row = h(
    "article",
    { class: `signal severity-${item.severity}` },
    h("span", { class: "signal-severity" }, h("span", { class: "dot", attrs: { "aria-hidden": "true" } }), SEVERITY_LABEL[item.severity]),
    h("div", { class: "signal-body" },
      externalLink(item.url, item.title || "(untitled)", "signal-title"),
      h("p", { class: "signal-meta", text: meta }),
      item.terms.length ? h("p", { class: "signal-terms", text: `Matched: ${item.terms.join(", ")}` }) : null,
      item.injection_score >= INJECTION_WARNING
        ? h("p", { class: "signal-warning", text: "Contains instruction-like text. Treat it as untrusted." })
        : null,
    ),
  );
  return row;
}
