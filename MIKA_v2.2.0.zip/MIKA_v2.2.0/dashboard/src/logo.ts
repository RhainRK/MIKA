import { svg } from "./dom.js";

/*
 * The Lunar A wordmark. Monoline geometric letters on a 100-unit cap height, stroke 12.
 * The A has no crossbar; a tilted crescent sits in its counter. Letters use currentColor so the
 * mark follows the theme; the crescent uses the brand moon colour.
 */
export function crescent(cx: number, cy: number, r: number, degrees: number): SVGGElement {
  return svg(
    "g",
    { transform: `rotate(${degrees} ${cx} ${cy})` },
    svg("path", {
      d: `M${cx - r},${cy} A${r},${r} 0 0 0 ${cx + r},${cy} A${r * 1.25},${r * 1.25} 0 0 1 ${cx - r},${cy} Z`,
      class: "logo-moon",
    }),
  );
}

export function wordmark(title = "MIKA"): SVGSVGElement {
  const mark = svg(
    "svg",
    { viewBox: "-2 -2 348 104", class: "logo", role: "img", "aria-label": title },
    svg("path", {
      d: "M6,100 V9 L50,66 L94,9 V100 M140,0 V100 M184,0 V100 M190,58 L238,0 M206,39 L241,100 M262,100 L302,0 L342,100",
      fill: "none",
      stroke: "currentColor",
      "stroke-width": 12,
      "stroke-miterlimit": 10,
    }),
    crescent(302, 66, 17, -18),
  );
  return mark;
}
