// Unit tests for the pure dashboard modules. Run with: npm test (after npm run build).
import assert from "node:assert/strict";
import test from "node:test";

import { moonPath } from "../dist/moon.js";
import { href, parseRoute } from "../dist/router.js";

/** Numerically integrate the lit area of a moon path by sampling its geometry. */
function litFraction(fraction) {
  const r = 1;
  const minor = r * Math.abs(1 - 2 * fraction);
  let lit = 0;
  const steps = 4000;
  for (let i = 0; i < steps; i++) {
    const y = -r + (2 * r * (i + 0.5)) / steps;
    const half = Math.sqrt(r * r - y * y);
    const edge = minor * Math.sqrt(Math.max(0, 1 - (y * y) / (r * r)));
    // Lit span runs from the terminator to the right limb.
    const width = fraction <= 0.5 ? half - edge : half + edge;
    lit += width * ((2 * r) / steps);
  }
  return lit / (Math.PI * r * r);
}

test("lit area equals the requested fraction", () => {
  for (const f of [0.05, 0.243, 0.5, 0.757, 0.95]) {
    assert.ok(Math.abs(litFraction(f) - f) < 1e-3, `fraction ${f} -> ${litFraction(f)}`);
  }
});

test("new and full moons, and bad input, never produce NaN", () => {
  assert.equal(moonPath(0, 100, 100, 86), null);
  assert.equal(moonPath(-1, 100, 100, 86), null);
  assert.equal(moonPath(Number.NaN, 100, 100, 86), null);
  const full = moonPath(1, 100, 100, 86);
  assert.ok(full && !full.includes("NaN"));
  const over = moonPath(5, 100, 100, 86);
  assert.equal(over, full);
  for (const f of [0.001, 0.25, 0.5, 0.75, 0.999]) {
    const path = moonPath(f, 100, 100, 86);
    assert.ok(path && !path.includes("NaN"), `fraction ${f}`);
  }
});

test("routes parse, fall back, and round-trip ids", () => {
  assert.deepEqual(parseRoute(""), { view: "exposure", id: null });
  assert.deepEqual(parseRoute("#nonsense"), { view: "exposure", id: null });
  assert.deepEqual(parseRoute("#cases/case_abc"), { view: "cases", id: "case_abc" });
  assert.deepEqual(parseRoute("#exposure/"), { view: "exposure", id: null });
  assert.deepEqual(parseRoute(href("cases", "a/b c")), { view: "cases", id: "a/b c" });
});
