# Changelog

## 2.2.0 - What changed, and what if

- **Since the last run.** Every `mika monitor` run is stored as a compact snapshot in
  `reports/runs/` (the last 90 are kept). MIKA compares each run with the previous one and lists
  holdings that got worse, improved, gained new list evidence, or were added or removed. It also
  shows sanctions-list entries added since then, with the ones that touch your holdings first. The
  first run never reports the whole list as new. Results go to `reports/changes-latest.json`,
  `mika changes`, `/api/changes`, `/api/history` and a new panel on the Exposure page.
- **What-if designations.** `mika whatif "Company"` screens the portfolio as if the named parties
  were sanctioned. It uses the same matching and 50% rule as the monitor, so it shows which holdings
  would be blocked through ownership and how much value would newly need attention. Nothing is
  saved. Names that match nothing in your register are reported rather than silently ignored.
- **Pre-trade check.** `mika check "Company" [--identifier LEI]` screens a company before you buy
  it. It exits with code 2 when the result is not CLEAR, so it can gate a script.
- **`mika watch --every 6h`.** Runs the monitor on a schedule (15 minutes to 7 days). A failed run
  is reported and retried at the next interval.
- **Fix.** Screening reports no longer claim "Synthetic sample data" in their limitations; they run
  on real lists now.
- Scenario runs and pre-trade checks are recorded in the audit chain. The web API stays read-only.

## 2.1.0 - Night watch: real-world data

- **Real sanctions lists.** `mika sync sanctions` downloads OFAC SDN (with aliases) and the UK
  Sanctions List into one versioned watchlist, keeping a last-known-good copy of each source. It
  replaces `fetch-uk-sanctions`, whose 25 MiB cap no longer fit the 50 MB UK file.
- **Real portfolios.** `mika portfolio import` adds LEI check-digit validation. GLEIF enrichment
  resolves LEIs and parent companies, and SEC enrichment maps tickers. Consolidation links are
  labelled as control rather than given an invented percentage, and ownership overrides can be
  written with company names.
- **Signals.** GDELT news, SEC 8-K filings, Reddit and X, with strict relevance matching,
  explainable risk categories and 48-hour retention for social posts with no authors stored.
- **`mika monitor`.** One pipeline for sync, enrichment, screening and signals, plus
  `mika feeds check` and the `/api/signals` and `/api/feeds` endpoints. A Signals view, holding
  signals and data-source status were added to the dashboard.
- **Privacy and security.** Holding-revealing sources are opt-in. One allowlisted HTTP client
  handles every request, and secrets are typed. Only `http(s)` links are rendered.
- **Fixes.** Static assets no longer exhaust the API rate budget. Malformed CSV input is now a
  clean error, report download filenames are restricted, and `case-report` output stays inside
  the workspace.
- **Legal.** Fixture names are fictional. `NOTICE.md` records the data terms and attributions,
  and CI actions are pinned to commit SHAs.
- **Synthetic data moved.** It now lives only in `tests/fixtures/`.

### Interface and identity

A redesigned interface, a new identity, and measured cleanup. No database schema changes.

- **Interface:** dark-first "Night watch" design with a light theme that follows the OS or a toggle.
  The Exposure hero is a moon whose lit area equals the flagged share of portfolio value
  (an elliptical terminator makes the area exact). Evidence merges search and sources. Holdings
  support arrow-key navigation, and selections and cases deep-link through the URL.
- **Logo:** the Lunar A wordmark, in which a crescent replaces the A's crossbar, plus a favicon mark.
- **Accessibility:** status colours validated for colour-blind separation in both themes, and
  always paired with words. The ownership diagram has a text equivalent, focus is visible and
  reduced motion is respected.
- **Frontend architecture:** one 540-line script becomes 12 typed ES modules under strict
  TypeScript, loaded natively with no bundler, framework or CSP change.
- **Performance:** database setup is skipped when `user_version` is current (7.05 ms to 1.72 ms per
  API request). Case evidence loads in one query instead of one per finding.
- **Cleanup:** `MikaApp.search` replaces duplicated search logic in the CLI and API, and the CLI
  dispatches through a handler table instead of an 18-branch `elif` chain.
- **Fixed:** screen-reader labels escaped the holdings scroll box and stretched the page to
  2,450 px. Case titles now read "Blocked: ..." instead of "Screening BLOCKED: ...".
- **Testing:** Node unit tests for moon geometry and routing. `scripts/ui_smoke.mjs` drives
  Edge or Chrome across every view, theme and width plus edge cases. CI runs `npm test` and fails
  if the committed bundle drifts from the source. 164 Python tests.

## 2.0.0 - Portfolio sanctions and ownership-risk screening

MIKA now screens portfolios for sanctions exposure, including exposure that arises only through
ownership, on top of the existing evidence engine.

- `mika/screening/`: validated CSV inputs with SHA-256 fingerprints and non-fatal data issues;
  register-to-watchlist matching; LEI-first issuer resolution; OFAC 50% rule propagation in
  O(V + E) with explanation trees; BLOCKED / REVIEW / CLEAR assessment with plain-language reasons.
- `mika screen`, with optional label scoring and `--create-cases`, which cites the exact ownership,
  watchlist and register rows behind each flag. Runs are recorded in the audit chain.
- `GET /api/screening/latest` and a new Exposure view with an ownership-chain diagram.
- Entity resolution: Jaro-Winkler soft token overlap, name-order variants, IDF-ranked candidate
  caps and opt-in no-full-scan mode. Candidate selection is now independent of `PYTHONHASHSEED`.
- 30 labelled screening scenarios gated in `mika evaluate`: blocked recall must be 1.0 and accuracy
  at least 0.9. A seeded scale generator is included; 50,000 entities screen in about 2.3 s.
- Fixed pre-existing mypy strict errors and adopted PEP 695 generics.
- Removed the stale `MANIFEST.sha256`, `RELEASE_NOTES.md` and the incorrect Docker claim in
  `SECURITY.md`. The 1.6 validation notes moved to `docs/validation-1.6.md`.
- Explanation trees bounded to 250 nodes so dense ownership lattices cannot exhaust memory.
- 154 tests, 90% branch coverage.

## 1.6.0 - Interface update

- Light interface with persistent Search, Sources, Cases and System navigation.
- Responsive layouts, visible keyboard focus, skip navigation and labelled filters.
- Browser Back/Forward navigation and clear empty/loading/error states.
- Cancelled stale searches and guarded out-of-order case responses.
- Compiled dashboard included, with a local Windows launcher and setup guide.

## 1.5.0 - Modern Python and static-analysis cleanup

- Python 3.13+ baseline and Python 3.14 CI coverage.
- Parameter-bound selected-evidence SQL filters.
- Windows SQLite test fix.
- Current Starlette TestClient dependency path.
- Source/test lint cleanup and shorter project docs.

## 1.4.0 - Evidence workspace and retrieval hardening

- Preserved chunk identifiers across repeat imports so case and finding evidence links survive re-ingestion.
- Added source-register browsing with ingest counts, quarantine state and relative workspace paths.
- Added source, chunk and case evidence filters to hybrid retrieval and the analyst console.
- Added citation validation for local-model answers, including invented-label detection.
- Findings now add their cited chunks to the case evidence register automatically.
- Added SQLite schema migration tracking and integrity-checked online database backups.
- Reworked semantic retrieval to stream bounded batches instead of materializing the full embedding corpus.
- Added corrupt/NaN/stale embedding repair during retrieval and single-digit numeric lexical search.
- Expanded the dashboard with source browsing, case review, filtered search and report downloads.
- Restored the 121-test regression gate and raised measured branch coverage to 88% in the reconstruction environment.

## 1.3.2 - Second security review

- Restricted model endpoints to literal loopback IPs; disabled proxy inheritance and redirects.
- Made hash retrieval the default; semantic loading is local-only with remote code disabled.
- Added request/header/body limits, login and request rate budgets, and generic API errors.
- Blocked symbolic links, Windows reparse points and alternate-stream/trailing-name paths in evidence tools.
- Applied SQL output limits incrementally and limited query columns.
- Made malformed audit records fail verification cleanly; isolated concurrent evaluations in unique temporary directories.
- Added 20 regression tests, resolved lint findings and fixed typing issues. CI type-checks against its matrix interpreter.
- Added a full Windows setup guide with local tests and dependency-audit commands.

## 1.3.1 - Local security hardening

- Added per-start browser credentials, loopback-only connections, Host/Origin checks and security headers.
- Disabled public binding, proxy-header trust, request access logs and API documentation endpoints.
- Blocked connector redirects; added SQLite authorisation, execution and output budgets.
- Excluded hidden/credential files and capped evidence-tool files at 25 MiB.
- Removed tool argument values from new audit events, redacted nested secret keys and added cross-process audit locking.
- Added security regression tests and an npm lockfile. Removed incompatible Docker recipe.
- No database schema migration. Existing stored records and old logs are not rewritten.

## 1.3.0

- Reworked the FastAPI composition layer around shared embedding state and request-scoped application sessions.
- Replaced full semantic score sorting with partial top-k selection using NumPy `argpartition`.
- Cached normalized entity candidates and token blocks to reduce repeated record-linkage work.
- Reworked BFS path finding to store parent links instead of copying complete paths during traversal.
- Added SQLite WAL, busy timeout and thread-safe connection settings for concurrent API access.
- Hardened embedding cache/model initialization and audit verification with explicit locking.
- Removed generated frontend output and legacy launch/requirements wrappers from the source tree.
- Added stricter TypeScript compiler checks, Dependabot configuration and updated GitHub Actions workflows.
- Expanded CLI/API integration tests to 36 tests and raised measured Python coverage to 82%.
- Added repository release checks for generated state, legacy project terms, sensitive key patterns and non-ASCII punctuation.

## 1.2.0

- Added explainable entity resolution with token blocking, alias matching and weighted fuzzy scoring.
- Added relationship analysis with adjacency lists and bounded breadth-first shortest-path traversal.
- Added CSV data-quality profiling with missingness, uniqueness, duplicate and candidate-key checks.
- Added an exact allow-listed FCDO public-data connector.
- Vectorized semantic scoring and batched embedding generation.
- Added benchmark/source SHA-256 fingerprints and bootstrap confidence intervals.
- Added thread-safe audit-chain appends and telemetry redaction.
- Expanded FastAPI health/evaluation endpoints and strict TypeScript analyst console.
- Added Docker non-root execution and CI gates for linting, typing, security scanning, coverage and frontend compilation.
- Expanded the automated suite to 33 tests with 78% measured Python coverage.

## 1.1.0

- Added a 120-case operational retrieval regression suite.
- Added FastAPI/TypeScript analyst interface and public-data connector scaffolding.
- Added reciprocal-rank fusion and structured-identifier ranking support.

## 1.0.0

- Established a personality-free evidence-analysis and AI-assurance architecture.
- Added provenance-bearing ingestion, hybrid retrieval, evaluation, default-deny typed tools, prompt-injection quarantine, read-only data tooling, tamper-evident audit logging, case reporting and local-model analysis.
