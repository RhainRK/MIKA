# Notices

MIKA is released under the MIT License (see `LICENSE`). This file records the terms of the
third-party data MIKA can retrieve, and the status of the bundled test data.

## Public data sources

MIKA does not ship any of the datasets below. It retrieves them only when you run the matching
command, and you are responsible for using them within their terms. MIKA is not affiliated with,
endorsed by, or authorised by any of these organisations, and nothing in MIKA implies official
status.

| Source | Retrieved by | Licence or terms | What MIKA does |
| --- | --- | --- | --- |
| UK Sanctions List (FCDO) | `mika sync sanctions`, `mika monitor` | [Open Government Licence v3.0](https://www.nationalarchives.gov.uk/doc/open-government-licence/version/3/) | Shows the attribution below; claims no official status |
| OFAC SDN list (US Treasury) | `mika sync sanctions`, `mika monitor` | US Government work, not subject to US copyright (17 U.S.C. 105) | Claims no endorsement |
| GLEIF LEI and relationship data | `mika monitor` when `gleif` is enabled | [CC0 1.0](https://www.gleif.org/en/meta/lei-data-terms-of-use); access through GLEIF's official API | Claims no GLEIF provision or authorisation |
| SEC EDGAR | `mika monitor` when `sec` is enabled | US Government public data; [fair-access policy](https://www.sec.gov/os/accessing-edgar-data) | Sends your contact address as required; stays under 10 requests per second |
| GDELT Project | `mika monitor` when `gdelt` is enabled | [Unrestricted use with citation](https://www.gdeltproject.org/about.html) | Shows the citation below wherever GDELT items appear |
| Reddit Data API | `mika monitor` when `reddit` is enabled | [Data API Terms](https://redditinc.com/policies/data-api-terms) and the Responsible Builder Policy: Reddit must approve your access first | Uses your own approved credentials; stores no author data; deletes posts after 48 hours |
| X API v2 | `mika monitor` when `x` is enabled | X Developer Agreement; paid per post read | Uses your own token; caps reads per run; stores no author data; deletes posts after 48 hours |

### Required attributions

- Contains public sector information licensed under the Open Government Licence v3.0.
- News data from The GDELT Project, https://www.gdeltproject.org/ (shown in the Signals view whenever GDELT items are present).

MIKA ships no platform credentials or platform content. You supply your own credentials, and you
are responsible for using each service within its terms. MIKA does not use any retrieved content
to train models.

## Bundled test data

Everything under `tests/fixtures/` is synthetic. Every company and person named there is a
coined, fictional name; any resemblance to a real person or organisation is coincidental. The
sanctions programmes (`SYN-A` to `SYN-E`), identifiers (`SYNLEI...`) and country codes (`XA` to
`XS`, the ISO 3166 private-use range) are deliberately not real. No real person or organisation
is represented as sanctioned.

## Dependencies

Runtime dependencies are under permissive licences compatible with MIT: MIT (FastAPI, Pydantic,
pydantic-settings, anyio, h11), BSD-3-Clause (NumPy, Starlette, uvicorn, portalocker, click,
python-dotenv, idna), PSF (typing-extensions, pywin32) and Apache-2.0 (TypeScript, build time
only). No dependency source code is vendored in this repository.
