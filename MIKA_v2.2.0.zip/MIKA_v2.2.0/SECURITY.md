# Security model

MIKA is designed around least privilege, complete mediation and reviewability.

## Controls

- **Default deny:** tools execute only when both registered and explicitly permitted by the active role policy.
- **Unknown tool rejection:** an LLM cannot invoke hidden or unregistered capabilities.
- **Typed arguments:** Pydantic models reject unknown fields and invalid bounds before handler execution.
- **Workspace confinement:** file-backed tools resolve paths against the configured workspace and reject traversal outside it.
- **Read-only SQL:** the SQLite tool accepts one bounded `SELECT`/`WITH` statement and rejects write/DDL/attach/pragma operations.
- **Untrusted retrieval:** evidence is separated from system instructions and treated as data.
- **Injection quarantine:** suspicious source text can be excluded from ordinary retrieval. This is defense-in-depth, not the security boundary.
- **Secret redaction:** common credential patterns are removed before audit/telemetry persistence.
- **Tamper evidence:** audit records include the previous record hash and their own SHA-256 digest.
- **Thread-safe audit append:** in-process writes are serialized to preserve chain ordering.
- **Endpoint restriction:** the public-data connector accepts only the exact official FCDO HTTPS sanctions-list endpoint.
- **Local model URL validation:** plaintext HTTP is accepted only for loopback endpoints.
- **Screening input confinement:** screening CSVs pass the same workspace path guard (no traversal, hidden files, symbolic links or files over 25 MiB) and reports use workspace-relative paths only.

- **One outbound gate:** every request to a public source goes through a single client. It
  allows HTTPS to that source's allowlisted hosts only, and follows a redirect only to a host the
  source declares. Responses have a byte cap that also applies after decompression, requests are
  spaced to respect rate limits, and error messages never include response bodies.
- **Privacy by default:** lookups that reveal holdings (GLEIF, SEC, GDELT, Reddit, X) run only
  when listed in `MIKA_ONLINE_SOURCES`, and `mika monitor --offline` makes no requests at all.
- **Secrets:** credentials are read from `.env` as secret types and never reach logs, the audit
  chain, reports, snapshots or the API. The API reports only whether each one is configured.
- **Untrusted external text:** news and social text is prompt-injection scored, shown as plain
  text only, and turned into a link only when its URL is `http(s)`.
- **Bounded parsing:** malformed or oversized CSV input is rejected with a clear error; screening
  and evidence files are capped at 25 MiB and confined to the workspace.
- **Safe downloads:** report filenames are restricted to a safe character set, so request data
  can never reach a response header.
- **Local web console:** loopback only, a fresh random password per start, Host/Origin and
  Fetch-Metadata checks, a strict Content Security Policy with no inline script, request and login
  rate limits, and a read-only API.
- **Supply chain:** CI actions are pinned to commit SHAs and updated by Dependabot; `pip-audit` and
  `npm audit` run before release.

## Threats exercised by tests

- implicit permission regression,
- unregistered tool invocation,
- malformed tool arguments,
- path traversal,
- SQLite write attempts,
- prompt-injection content entering the corpus,
- quarantined content leaking into default retrieval,
- audit-log modification/reordering,
- connector host substitution.

## Limitations

The audit chain is tamper-evident, not digitally signed; an attacker able to rewrite the complete log and recompute every hash can create a new internally valid chain. Multi-process append coordination is also outside the current design. Production deployment would use centralized append-only logging, external integrity anchoring and stronger identity/session controls.

Prompt-injection scanning is heuristic. Authorization remains deterministic even if that classifier misses an injection.

## Supported versions

Only the latest release receives security fixes.

## Reporting a vulnerability

Please report privately through GitHub: **Security > Report a vulnerability** on this repository.
Do not post credentials, exploit payloads or sensitive datasets in a public issue. You should
receive an acknowledgement within 7 days.
