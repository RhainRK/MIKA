"""News from the GDELT Project DOC 2.0 API (https://www.gdeltproject.org/).

GDELT asks for at most one request every five seconds and requires attribution:
"News data from The GDELT Project". The query is the holding's exact legal name as a quoted
phrase, which GDELT matches against full article text, so results are trusted as mentions.
"""

from __future__ import annotations

from datetime import UTC, datetime

from ..connectors.http import SafeClient, Source
from .classify import classify_text
from .common import NEWS_RETENTION, digest, make_signal, parse_json, phrase
from .model import Signal, Target

GDELT = Source(
    "gdelt",
    hosts=frozenset({"api.gdeltproject.org"}),
    max_bytes=5 * 1024 * 1024,
    min_interval_s=5.5,
    timeout_s=45.0,
)
ENDPOINT = "https://api.gdeltproject.org/api/v2/doc/doc"
ATTRIBUTION = "News data from The GDELT Project, https://www.gdeltproject.org/"
MAX_RECORDS = 25


def collect(client: SafeClient, target: Target, *, now: datetime) -> list[Signal]:
    name = phrase(target)
    if len(name) < 3:
        return []
    fetched = client.get(
        GDELT,
        ENDPOINT,
        params={
            "query": f'"{name}" sourcelang:english',
            "mode": "artlist",
            "format": "json",
            "maxrecords": MAX_RECORDS,
            "timespan": "7d",
            "sort": "datedesc",
        },
    )
    body = parse_json(fetched, "GDELT")
    signals = []
    for article in (body or {}).get("articles", []) if isinstance(body, dict) else []:
        url = str(article.get("url") or "")
        title = str(article.get("title") or "")
        if not url.startswith("https://") and not url.startswith("http://"):
            continue
        try:
            seen = datetime.strptime(str(article.get("seendate")), "%Y%m%dT%H%M%SZ")
            published = seen.replace(tzinfo=UTC).isoformat()
        except ValueError:
            published = now.isoformat()
        signals.append(
            make_signal(
                source="gdelt",
                external_id=digest(url),
                target=target,
                title=title,
                text="",
                url=url,
                published_at=published,
                matched_term=name,
                classification=classify_text(title),
                now=now,
                retention=NEWS_RETENTION,
            )
        )
    return signals
