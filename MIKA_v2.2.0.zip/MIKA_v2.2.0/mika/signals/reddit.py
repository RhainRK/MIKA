"""Reddit posts through the official Data API (app-only OAuth).

Reddit requires developers to request access and receive explicit approval before using the
API (Responsible Builder Policy), to identify themselves in the User-Agent, and to keep within
100 queries per minute. MIKA stores no author information and keeps posts for 48 hours.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import UTC, datetime

from .. import __version__
from ..connectors.http import FetchError, SafeClient, Source
from .classify import classify_text
from .common import SOCIAL_RETENTION, make_signal, parse_json, phrase
from .model import Signal, Target
from .relevance import find_mention

REDDIT = Source(
    "reddit",
    hosts=frozenset({"www.reddit.com", "oauth.reddit.com"}),
    max_bytes=5 * 1024 * 1024,
    min_interval_s=1.0,
)


@dataclass(frozen=True, slots=True)
class Credentials:
    client_id: str
    client_secret: str
    username: str

    def __repr__(self) -> str:  # never print the secret
        return f"Credentials(client_id={self.client_id!r}, username={self.username!r})"


def _user_agent(username: str) -> str:
    return f"python:mika:{__version__} (by /u/{username})"


def _token(client: SafeClient, creds: Credentials) -> str:
    basic = base64.b64encode(f"{creds.client_id}:{creds.client_secret}".encode()).decode()
    fetched = client.get(
        REDDIT,
        "https://www.reddit.com/api/v1/access_token",
        headers={
            "Authorization": f"Basic {basic}",
            "User-Agent": _user_agent(creds.username),
            "Content-Type": "application/x-www-form-urlencoded",
        },
        data=b"grant_type=client_credentials",
    )
    token = parse_json(fetched, "Reddit").get("access_token")
    if not isinstance(token, str) or not token:
        raise FetchError("Reddit authentication did not return a token")
    return token


def collect(
    client: SafeClient,
    target: Target,
    creds: Credentials,
    *,
    now: datetime,
    token: str | None = None,
) -> list[Signal]:
    token = token or _token(client, creds)
    query = f'"{phrase(target)}"' + (f" OR {target.ticker}" if target.ticker else "")
    fetched = client.get(
        REDDIT,
        "https://oauth.reddit.com/search",
        params={"q": query[:512], "sort": "new", "t": "week", "limit": 50, "type": "link"},
        headers={"Authorization": f"bearer {token}", "User-Agent": _user_agent(creds.username)},
    )
    listing = parse_json(fetched, "Reddit")
    signals = []
    for child in ((listing or {}).get("data") or {}).get("children") or []:
        post = (child or {}).get("data") or {}
        title = str(post.get("title") or "")
        text = str(post.get("selftext") or "")[:4000]
        matched = find_mention(f"{title}\n{text}", target)
        permalink = str(post.get("permalink") or "")
        if not matched or not permalink.startswith("/r/"):
            continue
        try:
            published = datetime.fromtimestamp(float(post["created_utc"]), UTC).isoformat()
        except (KeyError, TypeError, ValueError):
            published = now.isoformat()
        signals.append(
            make_signal(
                source="reddit",
                external_id=str(post.get("id") or permalink),
                target=target,
                title=title,
                text=text,
                url=f"https://www.reddit.com{permalink}",
                published_at=published,
                matched_term=matched,
                classification=classify_text(f"{title}\n{text}"),
                now=now,
                retention=SOCIAL_RETENTION,
            )
        )
    return signals
