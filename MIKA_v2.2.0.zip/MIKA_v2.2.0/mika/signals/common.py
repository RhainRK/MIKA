"""Helpers shared by signal connectors."""

from __future__ import annotations

import hashlib
import json
import re
from datetime import datetime, timedelta
from typing import Any

from ..connectors.http import Fetched, FetchError
from ..security import assess_prompt_injection
from .classify import Classification
from .model import Signal, Target

NEWS_RETENTION = timedelta(days=90)
# Reddit asks developers to delete stored user content within 48 hours; X content is treated
# the same way. Author identities are never stored for either.
SOCIAL_RETENTION = timedelta(hours=48)


def phrase(target: Target) -> str:
    """The legal name as a search phrase: punctuation removed, quotes impossible."""
    return re.sub(r"\s+", " ", re.sub(r"[^\w\s&'-]", " ", target.name)).strip()[:120]


def parse_json(fetched: Fetched, source: str) -> Any:
    try:
        return json.loads(fetched.body)
    except (json.JSONDecodeError, UnicodeDecodeError):
        raise FetchError(f"{source} returned a response that is not JSON") from None


def make_signal(
    *,
    source: str,
    external_id: str,
    target: Target,
    title: str,
    text: str,
    url: str,
    published_at: str,
    matched_term: str,
    classification: Classification,
    now: datetime,
    retention: timedelta,
) -> Signal:
    return Signal(
        source=source,
        external_id=external_id[:200],
        holding_id=target.holding_id,
        entity_name=target.name,
        title=" ".join(title.split())[:500],
        url=url,
        published_at=published_at,
        matched_term=matched_term,
        categories=classification.categories,
        terms=classification.terms,
        severity=classification.severity,
        injection_score=assess_prompt_injection(f"{title}\n{text}").score,
        expires_at=(now + retention).isoformat(),
    )


def digest(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()[:32]
