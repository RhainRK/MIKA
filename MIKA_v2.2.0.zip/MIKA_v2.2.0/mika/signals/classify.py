"""Explainable risk categories for signals.

A fixed lexicon of whole-word phrases per category. Every result lists the words that matched,
so an analyst can see exactly why a headline was flagged. Severity comes from the heaviest
category present. SEC 8-K items map directly to categories.
"""

from __future__ import annotations

import re
from dataclasses import dataclass

LEXICON: dict[str, tuple[str, ...]] = {
    "sanctions": (
        "sanction",
        "sanctions",
        "sanctioned",
        "ofac",
        "asset freeze",
        "export controls",
        "entity list",
        "embargo",
        "blacklisted",
        "designated by",
    ),
    "fraud": (
        "fraud",
        "fraudulent",
        "embezzlement",
        "bribery",
        "corruption",
        "money laundering",
        "ponzi",
        "falsified",
        "accounting irregularities",
        "kickbacks",
    ),
    "financial_distress": (
        "bankruptcy",
        "chapter 11",
        "insolvency",
        "insolvent",
        "default",
        "defaulted",
        "downgrade",
        "downgraded",
        "going concern",
        "liquidity crisis",
        "delisted",
        "delisting",
        "missed payment",
        "administration",
    ),
    "legal_regulatory": (
        "lawsuit",
        "sued",
        "sues",
        "probe",
        "investigation",
        "subpoena",
        "regulator",
        "fined",
        "penalty",
        "settlement",
        "indicted",
        "indictment",
        "charged",
        "antitrust",
        "class action",
    ),
    "governance": (
        "resigns",
        "resigned",
        "resignation",
        "steps down",
        "ousted",
        "restatement",
        "whistleblower",
        "auditor",
        "board shake-up",
    ),
    "cyber": ("data breach", "cyberattack", "cyber attack", "ransomware", "hacked", "hackers"),
    "operations": ("recall", "outage", "strike", "explosion", "shutdown", "plant fire"),
}
WEIGHTS = {
    "sanctions": 3,
    "fraud": 3,
    "financial_distress": 3,
    "legal_regulatory": 2,
    "governance": 2,
    "cyber": 2,
    "operations": 1,
}
SEVERITY = {3: "high", 2: "medium", 1: "low", 0: "info"}

# SEC Form 8-K items that matter for risk (https://www.sec.gov/files/form8-k.pdf).
EIGHT_K: dict[str, tuple[str, ...]] = {
    "1.03": ("financial_distress",),  # bankruptcy or receivership
    "1.05": ("cyber",),  # material cybersecurity incident
    "2.04": ("financial_distress",),  # triggering events accelerating obligations
    "2.06": ("financial_distress",),  # material impairments
    "3.01": ("financial_distress",),  # delisting notice
    "4.01": ("governance",),  # change of auditor
    "4.02": ("fraud", "governance"),  # prior financial statements cannot be relied on
    "5.02": ("governance",),  # director or officer departure
}
EIGHT_K_SEVERITY = {
    "1.03": 3,
    "1.05": 3,
    "2.04": 3,
    "3.01": 3,
    "4.02": 3,
    "2.06": 2,
    "4.01": 2,
    "5.02": 2,
}

_PATTERNS = {
    category: [(term, re.compile(rf"(?<![a-z0-9]){re.escape(term)}(?![a-z0-9])")) for term in terms]
    for category, terms in LEXICON.items()
}


@dataclass(frozen=True, slots=True)
class Classification:
    categories: tuple[str, ...]
    terms: tuple[str, ...]
    severity: str


def classify_text(text: str) -> Classification:
    lowered = text.casefold()
    categories: list[str] = []
    terms: list[str] = []
    for category, patterns in _PATTERNS.items():
        hits = [term for term, pattern in patterns if pattern.search(lowered)]
        if hits:
            categories.append(category)
            terms.extend(hits)
    weight = max((WEIGHTS[c] for c in categories), default=0)
    return Classification(tuple(sorted(categories)), tuple(dict.fromkeys(terms)), SEVERITY[weight])


def classify_8k(items: str) -> Classification:
    codes = [item.strip() for item in items.split(",") if item.strip()]
    categories = sorted({c for code in codes for c in EIGHT_K.get(code, ())})
    weight = max((EIGHT_K_SEVERITY.get(code, 0) for code in codes), default=0)
    matched = tuple(f"8-K item {code}" for code in codes if code in EIGHT_K)
    return Classification(tuple(categories), matched, SEVERITY[weight])
