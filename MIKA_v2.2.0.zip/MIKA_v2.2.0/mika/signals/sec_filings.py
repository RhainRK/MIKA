"""Material-event filings (Form 8-K) from SEC EDGAR.

SEC fair access requires a User-Agent that identifies the requester with a contact address and
at most 10 requests per second. Filings are tied to the company by CIK, so no text matching is
needed.
"""

from __future__ import annotations

from datetime import date, datetime, timedelta

from ..connectors.http import SafeClient
from ..portfolio.enrich import SEC, sec_user_agent
from .classify import classify_8k
from .common import NEWS_RETENTION, make_signal, parse_json
from .model import Signal, Target

WINDOW = timedelta(days=30)
FORMS = {"8-K", "8-K/A"}


def collect(
    client: SafeClient, target: Target, *, cik: int, contact_email: str, now: datetime
) -> list[Signal]:
    if not contact_email:
        raise ValueError("SEC filings need MIKA_CONTACT_EMAIL (the SEC requires a contact).")
    fetched = client.get(
        SEC,
        f"https://data.sec.gov/submissions/CIK{int(cik):010d}.json",
        headers={"User-Agent": sec_user_agent(contact_email)},
    )
    body = parse_json(fetched, "SEC EDGAR")
    recent = ((body or {}).get("filings") or {}).get("recent") or {}
    columns = ("accessionNumber", "filingDate", "form", "items", "primaryDocument")
    try:
        rows = zip(*(recent[column] for column in columns), strict=True)
    except (KeyError, TypeError, ValueError):
        return []
    cutoff = (now - WINDOW).date()
    signals = []
    for accession, filed, form, items, document in rows:
        if form not in FORMS:
            continue
        try:
            filed_on = date.fromisoformat(str(filed))
        except ValueError:
            continue
        if filed_on < cutoff:
            continue
        folder = str(accession).replace("-", "")
        url = f"https://www.sec.gov/Archives/edgar/data/{int(cik)}/{folder}/{document}"
        classification = classify_8k(str(items or ""))
        title = f"Form {form} filed {filed}: items {items or 'not listed'}"
        signals.append(
            make_signal(
                source="sec",
                external_id=str(accession),
                target=target,
                title=title,
                text="",
                url=url,
                published_at=f"{filed_on.isoformat()}T00:00:00+00:00",
                matched_term=f"CIK {int(cik)}",
                classification=classification,
                now=now,
                retention=NEWS_RETENTION,
            )
        )
    return signals
