"""Posts from X through the API v2 recent-search endpoint (last 7 days).

X bills reads per post, so every run has a post budget (``MIKA_X_MAX_POSTS``). A request asks for
at most the remaining budget and is skipped when fewer than 10 posts remain (the API minimum).
Author identities are never stored and posts are kept for 48 hours.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime

from ..connectors.http import SafeClient, Source
from .classify import classify_text
from .common import SOCIAL_RETENTION, make_signal, parse_json, phrase
from .model import Signal, Target
from .relevance import find_mention

X = Source("x", hosts=frozenset({"api.x.com"}), max_bytes=5 * 1024 * 1024, min_interval_s=2.0)
MIN_RESULTS, MAX_RESULTS = 10, 100


@dataclass
class Budget:
    remaining: int


def collect(
    client: SafeClient, target: Target, bearer: str, budget: Budget, *, now: datetime
) -> list[Signal]:
    wanted = min(MAX_RESULTS, budget.remaining)
    if wanted < MIN_RESULTS:
        return []
    terms = f'"{phrase(target)}"' + (f" OR ${target.ticker}" if target.ticker else "")
    fetched = client.get(
        X,
        "https://api.x.com/2/tweets/search/recent",
        params={
            "query": f"({terms}) -is:retweet lang:en",
            "max_results": wanted,
            "tweet.fields": "created_at,lang",
        },
        headers={"Authorization": f"Bearer {bearer}"},
    )
    body = parse_json(fetched, "X")
    posts = (body or {}).get("data") or []
    budget.remaining -= len(posts)
    signals = []
    for post in posts:
        text = str(post.get("text") or "")
        matched = find_mention(text, target)
        post_id = str(post.get("id") or "")
        if not matched or not post_id.isdigit():
            continue
        published = str(post.get("created_at") or now.isoformat()).replace("Z", "+00:00")
        signals.append(
            make_signal(
                source="x",
                external_id=post_id,
                target=target,
                title=text[:280],
                text=text,
                url=f"https://x.com/i/web/status/{post_id}",
                published_at=published,
                matched_term=matched,
                classification=classify_text(text),
                now=now,
                retention=SOCIAL_RETENTION,
            )
        )
    return signals
