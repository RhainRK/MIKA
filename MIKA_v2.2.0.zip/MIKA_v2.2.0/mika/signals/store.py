"""Persist signals in SQLite with retention."""

from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any

from ..storage import Database
from .model import Signal


def upsert_signals(db: Database, signals: Iterable[Signal], *, collected_at: datetime) -> int:
    """Insert new signals; existing (source, external_id, holding_id) rows are left as they are."""
    rows = [
        (
            s.source,
            s.external_id,
            s.holding_id,
            s.entity_name,
            s.title[:500],
            s.url[:2000],
            s.published_at,
            collected_at.isoformat(),
            s.matched_term,
            json.dumps(s.categories),
            json.dumps(s.terms),
            s.severity,
            s.injection_score,
            s.expires_at,
        )
        for s in signals
    ]
    with db.conn:
        before = db.conn.total_changes
        db.conn.executemany(
            """
            INSERT OR IGNORE INTO signals(
                source,external_id,holding_id,entity_name,title,url,published_at,collected_at,
                matched_term,categories_json,terms_json,severity,injection_score,expires_at)
            VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            rows,
        )
        return db.conn.total_changes - before


def list_signals(
    db: Database,
    *,
    holding_id: str | None = None,
    category: str | None = None,
    source: str | None = None,
    severity: str | None = None,
    limit: int = 200,
) -> list[dict[str, Any]]:
    rows = db.conn.execute(
        """
        SELECT * FROM signals
        WHERE (? IS NULL OR holding_id=?) AND (? IS NULL OR source=?)
          AND (? IS NULL OR severity=?)
          AND (? IS NULL OR EXISTS (SELECT 1 FROM json_each(categories_json) WHERE value=?))
        ORDER BY CASE severity WHEN 'high' THEN 0 WHEN 'medium' THEN 1 WHEN 'low' THEN 2
                 ELSE 3 END, published_at DESC, id
        LIMIT ?
        """,
        (
            holding_id,
            holding_id,
            source,
            source,
            severity,
            severity,
            category,
            category,
            max(1, min(limit, 1000)),
        ),
    ).fetchall()
    output = []
    for row in rows:
        item = dict(row)
        item["categories"] = json.loads(item.pop("categories_json"))
        item["terms"] = json.loads(item.pop("terms_json"))
        output.append(item)
    return output


def purge_expired(db: Database, *, now: datetime | None = None) -> int:
    moment = (now or datetime.now(UTC)).isoformat()
    with db.conn:
        cursor = db.conn.execute("DELETE FROM signals WHERE expires_at <= ?", (moment,))
        return cursor.rowcount
