"""Signals: dated, sourced items that may affect a holding (news, filings, social posts)."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class Target:
    """What a connector looks for: one holding, its names and its ticker."""

    holding_id: str
    name: str
    aliases: tuple[str, ...] = ()
    ticker: str = ""


@dataclass(frozen=True, slots=True)
class Signal:
    source: str
    external_id: str
    holding_id: str
    entity_name: str
    title: str
    url: str
    published_at: str
    matched_term: str
    categories: tuple[str, ...]
    terms: tuple[str, ...]
    severity: str
    injection_score: float
    expires_at: str
