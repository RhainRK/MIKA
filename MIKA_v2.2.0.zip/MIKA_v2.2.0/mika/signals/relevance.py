"""Decide whether a piece of text is about a holding.

Single-word names are where noise comes from ("Apple" the fruit, "Shell" the beach). A mention
counts only when the text contains:

- a multi-word normalised name (legal suffixes removed), e.g. "zarvek maritime holdings";
- the full legal name including its suffix when the normalised name is a single word, e.g.
  "apple inc"; or
- the ticker written as a cashtag (``$AAPL``) or with an exchange (``NASDAQ: AAPL``).
"""

from __future__ import annotations

import re

from ..entity_resolution import normalize_name
from .model import Target

_WORDS = re.compile(r"[a-z0-9]+")
_EXCHANGES = ("NASDAQ", "NYSE", "LSE", "AMEX", "TSX", "OTC")


def _flat(text: str) -> str:
    return " " + " ".join(_WORDS.findall(text.casefold())) + " "


def find_mention(text: str, target: Target) -> str | None:
    flat = _flat(text)
    for raw in (target.name, *target.aliases):
        normalised = normalize_name(raw)
        if not normalised:
            continue
        if " " in normalised:
            if f" {normalised} " in flat:
                return normalised
            continue
        legal = " ".join(_WORDS.findall(raw.casefold()))
        if legal != normalised and f" {legal} " in flat:
            return legal
    ticker = target.ticker.upper()
    if ticker:
        if re.search(rf"(?<![A-Za-z0-9])\${re.escape(ticker)}(?![A-Za-z0-9])", text, re.IGNORECASE):
            return f"${ticker}"
        for exchange in _EXCHANGES:
            pattern = rf"\b{exchange}\s*:\s*{re.escape(ticker)}\b"
            if re.search(pattern, text, re.IGNORECASE):
                return f"{exchange}:{ticker}"
    return None
