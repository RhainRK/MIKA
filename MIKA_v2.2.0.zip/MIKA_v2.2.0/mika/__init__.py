"""MIKA: Model Integrity & Knowledge Analysis."""

__version__ = "2.2.0"
