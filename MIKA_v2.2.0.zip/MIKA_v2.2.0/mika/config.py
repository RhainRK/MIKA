from __future__ import annotations

from pathlib import Path

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict

ONLINE_SOURCES = ("gleif", "sec", "gdelt", "reddit", "x")


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MIKA_", env_file=".env", extra="ignore")

    db_path: Path = Path("data/mika.sqlite3")
    audit_path: Path = Path("data/audit.jsonl")
    telemetry_path: Path = Path("data/telemetry.jsonl")
    workspace: Path = Path(".")
    embedding_model: str = "hash"
    ollama_url: str = "http://127.0.0.1:11434"
    ollama_model: str = "qwen3.5:4b"
    request_timeout: float = 90.0
    retrieval_k: int = 6
    injection_quarantine_threshold: float = 0.75

    # Lookups that reveal holdings are off until listed here (comma-separated):
    # gleif, sec, gdelt, reddit, x. Sanctions list downloads reveal nothing and always run.
    online_sources: str = ""
    contact_email: str = ""  # required by the SEC fair-access policy
    reddit_client_id: SecretStr | None = None
    reddit_client_secret: SecretStr | None = None
    reddit_username: str = ""
    x_bearer_token: SecretStr | None = None
    x_max_posts: int = 100  # X bills per post read; this caps each monitor run
    signal_holdings_limit: int = 50

    def online(self) -> set[str]:
        requested = {item.strip().casefold() for item in self.online_sources.split(",")}
        return {item for item in requested if item in ONLINE_SOURCES}

    def has_reddit(self) -> bool:
        return bool(self.reddit_client_id and self.reddit_client_secret and self.reddit_username)

    def resolve(self) -> Settings:
        self.db_path = self.db_path.expanduser().resolve()
        self.audit_path = self.audit_path.expanduser().resolve()
        self.telemetry_path = self.telemetry_path.expanduser().resolve()
        self.workspace = self.workspace.expanduser().resolve()
        return self


settings = Settings().resolve()
