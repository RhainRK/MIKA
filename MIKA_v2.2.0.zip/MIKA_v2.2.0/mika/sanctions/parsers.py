"""Parsers for the official sanctions list files, normalised to watchlist entries."""

from __future__ import annotations

import csv
import io
from collections import defaultdict

from ..screening.model import WatchlistEntry

_OFAC_NULL = "-0-"


def _decode(raw: bytes) -> str:
    try:
        return raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        return raw.decode("latin-1")


def _ofac_value(value: str) -> str:
    value = value.strip()
    return "" if value == _OFAC_NULL else value


def _natural_order(name: str) -> str | None:
    """OFAC writes individuals as "SURNAME, Given"; return "Given SURNAME"."""
    if name.count(",") != 1:
        return None
    surname, given = (part.strip() for part in name.split(","))
    return f"{given} {surname}" if surname and given else None


def parse_ofac(sdn: bytes, alt: bytes) -> list[WatchlistEntry]:
    """Parse the headerless SDN.CSV (12 columns) and ALT.CSV (5 columns) legacy flat files."""
    aliases: dict[str, list[str]] = defaultdict(list)
    for row in csv.reader(io.StringIO(_decode(alt))):
        if len(row) >= 4 and row[0].strip().isdigit() and (name := _ofac_value(row[3])):
            aliases[row[0].strip()].append(name)

    entries: list[WatchlistEntry] = []
    for row in csv.reader(io.StringIO(_decode(sdn))):
        # Skip the end-of-file marker and anything that is not a numbered record.
        if len(row) < 4 or not row[0].strip().isdigit():
            continue
        ent_num, name = row[0].strip(), _ofac_value(row[1])
        if not name:
            continue
        kind = _ofac_value(row[2]).casefold()
        programs = [part.strip() for part in _ofac_value(row[3]).split("] [") if part.strip()]
        names = list(aliases.get(ent_num, []))
        if kind == "individual":
            for value in (name, *names):
                natural = _natural_order(value)
                if natural:
                    names.append(natural)
        entries.append(
            WatchlistEntry(
                f"OFAC-{ent_num}",
                name,
                tuple(dict.fromkeys(item for item in names if item != name)),
                "; ".join(programs),
            )
        )
    return entries


_UK_REQUIRED = ("Unique ID", "Name 6", "Name type", "Regime Name", "Designation Type")


def parse_uk(raw: bytes) -> tuple[list[WatchlistEntry], int]:
    """Parse the UK Sanctions List CSV. Returns entries and the number of weak aliases skipped.

    The file starts with a "Report Date" line, then the header, then one row per combination of
    name and address, so rows are grouped by Unique ID. "Low quality a.k.a" aliases are excluded
    from matching, as OFSI advises, because they generate false positives.
    """
    text = _decode(raw)
    lines = text.splitlines()
    if lines and lines[0].startswith("Report Date"):
        lines = lines[1:]
    reader = csv.DictReader(lines)
    if not reader.fieldnames or any(name not in reader.fieldnames for name in _UK_REQUIRED):
        raise ValueError("Unexpected UK Sanctions List header; the file format may have changed")

    primary: dict[str, str] = {}
    names: dict[str, list[str]] = defaultdict(list)
    regimes: dict[str, set[str]] = defaultdict(set)
    weak = 0
    for row in reader:
        uid = (row.get("Unique ID") or "").strip()
        if not uid:
            continue
        given = " ".join((row.get(f"Name {i}") or "").strip() for i in range(1, 6)).split()
        full = " ".join([*given, (row.get("Name 6") or "").strip()]).strip()
        if not full:
            continue
        regimes[uid].add((row.get("Regime Name") or "").strip())
        kind = (row.get("Name type") or "").strip().casefold()
        if kind == "primary name" and uid not in primary:
            primary[uid] = full
        elif (row.get("Alias strength") or "").strip().casefold().startswith("low quality"):
            weak += 1
        else:
            names[uid].append(full)

    entries = []
    for uid in sorted(set(primary) | set(names)):
        name = primary.get(uid) or names[uid][0]
        aliases = tuple(dict.fromkeys(item for item in names[uid] if item != name))
        program = "; ".join(sorted(regime for regime in regimes[uid] if regime))
        entries.append(WatchlistEntry(f"UK-{uid}", name, aliases, program))
    return entries, weak
