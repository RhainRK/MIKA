"""Download the official sanctions lists and merge them into the screening watchlist.

Downloading a public list reveals nothing about the portfolio, so this always runs (unless the
caller is offline). Each source keeps its own last good copy: a failed download leaves the
previous entries in place and is reported as stale rather than silently dropping a list.
"""

from __future__ import annotations

import csv
import json
from collections.abc import Callable
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from ..connectors.http import Fetched, FetchError, SafeClient, Source
from ..connectors.snapshots import prune, save
from ..screening.model import WatchlistEntry
from .parsers import parse_ofac, parse_uk

OFAC = Source(
    "ofac",
    hosts=frozenset({"sanctionslistservice.ofac.treas.gov"}),
    # The export endpoints redirect to short-lived signed URLs on this bucket.
    redirect_hosts=frozenset({"wc2h-sls-prod-public-published.s3.us-gov-west-1.amazonaws.com"}),
    max_bytes=25 * 1024 * 1024,
    min_interval_s=1.0,
    timeout_s=120.0,
)
UK = Source(
    "uk",
    hosts=frozenset({"sanctionslist.fcdo.gov.uk"}),
    max_bytes=120 * 1024 * 1024,
    timeout_s=300.0,
)
OFAC_BASE = "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/"
UK_URL = "https://sanctionslist.fcdo.gov.uk/docs/UK-Sanctions-List.csv"
ATTRIBUTION = (
    "UK Sanctions List: contains public sector information licensed under the Open Government "
    "Licence v3.0. OFAC SDN list: US Treasury, public domain. MIKA is not affiliated with or "
    "endorsed by either."
)
FRESH_FOR = timedelta(hours=24)
SNAPSHOT_RETENTION_S = 30 * 24 * 3600


def _write(path: Path, entries: list[WatchlistEntry]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    with temp.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, lineterminator="\n")
        writer.writerow(["list_id", "name", "aliases", "program"])
        for entry in entries:
            aliases = ";".join(alias.replace(";", ",") for alias in entry.aliases)
            writer.writerow([entry.list_id, entry.name, aliases, entry.program])
    temp.replace(path)


def _download_ofac(
    client: SafeClient, snapshots: Path
) -> tuple[list[WatchlistEntry], dict[str, Any]]:
    sdn = client.get(OFAC, OFAC_BASE + "SDN.CSV")
    alt = client.get(OFAC, OFAC_BASE + "ALT.CSV")
    save(snapshots, "ofac", sdn, "csv")
    save(snapshots, "ofac", alt, "csv")
    entries = parse_ofac(sdn.body, alt.body)
    return entries, {"sha256": sdn.sha256, "alt_sha256": alt.sha256, "fetched_at": sdn.fetched_at}


def _download_uk(
    client: SafeClient, snapshots: Path
) -> tuple[list[WatchlistEntry], dict[str, Any]]:
    fetched: Fetched = client.get(UK, UK_URL)
    save(snapshots, "uk", fetched, "csv")
    entries, weak = parse_uk(fetched.body)
    return entries, {
        "sha256": fetched.sha256,
        "fetched_at": fetched.fetched_at,
        "weak_aliases_skipped": weak,
    }


_Downloader = Callable[[SafeClient, Path], tuple[list[WatchlistEntry], dict[str, Any]]]
_SOURCES: dict[str, _Downloader] = {"ofac": _download_ofac, "uk": _download_uk}


def sync_sanctions(
    client: SafeClient,
    workspace: Path,
    *,
    force: bool = False,
    now: datetime | None = None,
) -> dict[str, Any]:
    now = now or datetime.now(UTC)
    data = workspace / "data"
    cache = data / "sanctions"
    state_path = cache / "state.json"
    state: dict[str, Any] = {}
    if state_path.exists():
        state = json.loads(state_path.read_text(encoding="utf-8"))
    synced = state.get("synced_at")
    if not force and synced and now - datetime.fromisoformat(synced) < FRESH_FOR:
        return {
            "skipped": True,
            "synced_at": synced,
            "sources": state.get("sources", {}),
            "attribution": ATTRIBUTION,
        }

    snapshots = data / "sources"
    sources: dict[str, Any] = dict(state.get("sources", {}))
    for name, download in _SOURCES.items():
        try:
            entries, meta = download(client, snapshots)
            _write(cache / f"{name}.csv", entries)
            sources[name] = {"status": "updated", "entries": len(entries), **meta}
        except (FetchError, ValueError) as error:
            previous = sources.get(name, {})
            has_copy = (cache / f"{name}.csv").exists()
            sources[name] = {
                **previous,
                "status": "stale" if has_copy else "unavailable",
                "error": str(error),
            }
        prune(snapshots, name, max_age_s=SNAPSHOT_RETENTION_S)

    merged: list[WatchlistEntry] = []
    for name in _SOURCES:
        path = cache / f"{name}.csv"
        if path.exists():
            for row in csv.DictReader(path.open(encoding="utf-8")):
                aliases = tuple(item for item in row["aliases"].split(";") if item)
                merged.append(WatchlistEntry(row["list_id"], row["name"], aliases, row["program"]))
    if not merged:
        raise RuntimeError(
            "No sanctions list is available: every download failed and no earlier copy exists. "
            "Check your internet connection and run `mika sync sanctions` again."
        )
    _write(data / "watchlist.csv", merged)
    state = {"synced_at": now.isoformat(), "sources": sources}
    cache.mkdir(parents=True, exist_ok=True)
    state_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    return {
        "skipped": False,
        "synced_at": state["synced_at"],
        "entries": len(merged),
        "sources": sources,
        "attribution": ATTRIBUTION,
    }
