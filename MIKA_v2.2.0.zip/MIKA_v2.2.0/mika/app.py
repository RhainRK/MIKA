from __future__ import annotations

from collections.abc import Sequence
from dataclasses import asdict
from typing import Any

from .audit import AuditLog
from .cases import CaseStore
from .config import Settings, settings
from .embeddings import Embedder
from .provenance import EvidenceStore
from .retrieval import HybridRetriever
from .storage import Database
from .telemetry import Telemetry


class MikaApp:
    def __init__(
        self,
        config: Settings | None = None,
        *,
        embedder: Embedder | None = None,
        audit: AuditLog | None = None,
    ) -> None:
        self.settings = (config or settings).resolve()
        self.db = Database(self.settings.db_path)
        self.embedder = embedder or Embedder(self.settings.embedding_model)
        self.evidence = EvidenceStore(
            self.db,
            self.embedder,
            self.settings.workspace,
            self.settings.injection_quarantine_threshold,
        )
        self.retriever = HybridRetriever(self.db, self.embedder)
        self.audit = audit or AuditLog(self.settings.audit_path)
        self.telemetry = Telemetry(self.db, self.settings.telemetry_path)
        self.cases = CaseStore(self.db)

    def scope_chunks(
        self, case_id: str | None, chunk_ids: Sequence[int] | None
    ) -> list[int] | None:
        """Chunk filter for a case scope, intersected with any explicit chunk ids."""
        selected = list(chunk_ids) if chunk_ids is not None else None
        if case_id is None:
            return selected
        case_chunks = self.cases.evidence_chunk_ids(case_id)
        return case_chunks if selected is None else sorted(set(case_chunks).intersection(selected))

    def search(
        self,
        query: str,
        k: int,
        *,
        source_ids: Sequence[int] | None = None,
        chunk_ids: Sequence[int] | None = None,
        case_id: str | None = None,
    ) -> list[dict[str, Any]]:
        """Hybrid search, optionally scoped to a case's evidence, recorded as a telemetry span.

        A case scope intersects with any explicit ``chunk_ids``. Raises ``ValueError`` for an
        unknown case.
        """
        selected = self.scope_chunks(case_id, chunk_ids)
        with self.telemetry.span(
            "mika.retrieval.search",
            attributes={
                "mika.query.length": len(query),
                "mika.retrieval.k": k,
                "mika.retrieval.source_filter_count": len(source_ids or []),
                "mika.retrieval.chunk_filter_count": len(selected or []),
            },
        ):
            hits = self.retriever.search(query, k, source_ids=source_ids, chunk_ids=selected)
        return [asdict(hit) | {"citation": hit.citation()} for hit in hits]

    def close(self) -> None:
        self.db.close()

    def __enter__(self) -> MikaApp:
        return self

    def __exit__(self, exc_type: object, exc: object, traceback: object) -> None:
        self.close()
