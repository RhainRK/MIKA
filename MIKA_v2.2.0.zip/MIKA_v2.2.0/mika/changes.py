"""Run history and change detection: what changed since the previous monitor run.

Each run stores a compact snapshot (status, value and matched list entries per holding) in
reports/runs/, plus the set of watchlist IDs seen. Comparing two snapshots answers "what is new
since last time": holdings that got worse or better, new evidence for an existing flag, and list
entries that were added since the previous run.
"""

from __future__ import annotations

import json
import os
from collections.abc import Iterable
from datetime import datetime
from pathlib import Path
from typing import Any

from .screening.model import WatchlistEntry

SNAPSHOT_VERSION = 1
KEEP_RUNS = 90
EXAMPLES = 20
_RANK = {"CLEAR": 0, "REVIEW": 1, "BLOCKED": 2}


def _runs(workspace: Path) -> Path:
    return workspace / "reports" / "runs"


def _write(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(path.suffix + ".tmp")
    temp.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temp, path)


def _read(path: Path) -> Any:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def snapshot(report: dict[str, Any]) -> dict[str, Any]:
    """The parts of a screening report needed to detect change, and nothing else."""
    by_status = report["summary"]["by_status"]
    return {
        "version": SNAPSHOT_VERSION,
        "generated_at": report["generated_at"],
        "total_market_value": float(report["summary"]["total_market_value"]),
        "by_status": {
            status: {
                "count": int(by_status[status]["count"]),
                "market_value": float(by_status[status]["market_value"]),
            }
            for status in _RANK
        },
        "holdings": {
            row["holding_id"]: {
                "issuer": row["issuer"],
                "status": row["status"],
                "market_value": float(row["market_value"]),
                "reasons": list(row["reasons"]),
                "matches": sorted({hit["list_id"] for hit in row.get("watchlist_matches", [])}),
            }
            for row in report["holdings"]
        },
    }


def _change(
    holding_id: str, before: dict[str, Any] | None, after: dict[str, Any] | None
) -> dict[str, Any] | None:
    current = after or before
    if current is None:
        return None
    old_status = before["status"] if before else None
    new_status = after["status"] if after else None
    if before is None:
        direction = "new"
    elif after is None:
        direction = "removed"
    elif _RANK[new_status or "CLEAR"] > _RANK[old_status or "CLEAR"]:
        direction = "worse"
    elif _RANK[new_status or "CLEAR"] < _RANK[old_status or "CLEAR"]:
        direction = "better"
    elif new_status != "CLEAR" and before["matches"] != current["matches"]:
        direction = "evidence"
    else:
        return None
    old_matches = set(before["matches"]) if before else set()
    return {
        "holding_id": holding_id,
        "issuer": current["issuer"],
        "from": old_status,
        "to": new_status,
        "direction": direction,
        "market_value": current["market_value"],
        "reasons": current["reasons"],
        "new_matches": [m for m in (after or {}).get("matches", []) if m not in old_matches],
    }


def compare(previous: dict[str, Any] | None, current: dict[str, Any]) -> dict[str, Any]:
    """Holding-level differences between two snapshots, most serious first."""
    before = (previous or {}).get("holdings", {})
    after = current["holdings"]
    changes = [
        change
        for holding_id in sorted(set(before) | set(after))
        if (change := _change(holding_id, before.get(holding_id), after.get(holding_id)))
    ]
    order = {"worse": 0, "new": 1, "evidence": 2, "better": 3, "removed": 4}
    changes.sort(
        key=lambda c: (order[c["direction"]], -_RANK.get(c["to"] or "CLEAR", 0), -c["market_value"])
    )
    newly_flagged = sum(
        c["market_value"]
        for c in changes
        if c["to"] in {"BLOCKED", "REVIEW"} and (c["from"] in {None, "CLEAR"})
    )
    counts = {key: sum(c["direction"] == key for c in changes) for key in order}
    return {"changes": changes, "counts": counts, "value_newly_flagged": newly_flagged}


def _latest_snapshot(workspace: Path) -> dict[str, Any] | None:
    for path in sorted(_runs(workspace).glob("run-*.json"), reverse=True):
        value = _read(path)
        if isinstance(value, dict) and value.get("version") == SNAPSHOT_VERSION:
            return value
    return None


def record_run(
    workspace: Path,
    report: dict[str, Any],
    watchlist: Iterable[WatchlistEntry],
    *,
    now: datetime,
    keep: int = KEEP_RUNS,
) -> dict[str, Any]:
    """Store this run, compare it with the previous one and write reports/changes-latest.json."""
    runs = _runs(workspace)
    previous = _latest_snapshot(workspace)
    current = snapshot(report)
    current["generated_at"] = now.isoformat()

    entries = {entry.list_id: entry for entry in watchlist}
    stored = _read(runs / "watchlist-ids.json")
    old_ids = (
        set(stored["ids"])
        if isinstance(stored, dict) and isinstance(stored.get("ids"), list)
        else None
    )
    added = sorted(set(entries) - old_ids) if old_ids is not None else []
    removed = sorted(old_ids - set(entries)) if old_ids is not None else []
    affects: dict[str, list[str]] = {}
    for holding_id, row in current["holdings"].items():
        for list_id in row["matches"]:
            affects.setdefault(list_id, []).append(holding_id)
    # Entries that touch a holding are the ones worth reading first.
    added.sort(key=lambda list_id: (list_id not in affects, list_id))

    result = {
        "generated_at": now.isoformat(),
        "since": previous["generated_at"] if previous else None,
        "first_run": previous is None,
        # A first run has nothing to compare with, so it reports no changes rather than every
        # holding as new.
        **compare(previous or current, current),
        "watchlist": {
            "added": len(added),
            "removed": len(removed),
            "added_examples": [
                {
                    "list_id": list_id,
                    "name": entries[list_id].name,
                    "program": entries[list_id].program,
                    "affects": affects.get(list_id, []),
                }
                for list_id in added[:EXAMPLES]
            ],
        },
    }
    _write(runs / f"run-{now.strftime('%Y%m%dT%H%M%S%fZ')}.json", current)
    _write(runs / "watchlist-ids.json", {"generated_at": now.isoformat(), "ids": sorted(entries)})
    _write(workspace / "reports" / "changes-latest.json", result)
    for old in sorted(runs.glob("run-*.json"))[:-keep] if keep > 0 else []:
        old.unlink(missing_ok=True)
    return result


def latest_changes(workspace: Path) -> dict[str, Any] | None:
    value = _read(workspace / "reports" / "changes-latest.json")
    return value if isinstance(value, dict) else None


def history(workspace: Path, limit: int = KEEP_RUNS) -> list[dict[str, Any]]:
    """Exposure per run, oldest first: the series behind the trend line."""
    rows = []
    for path in sorted(_runs(workspace).glob("run-*.json"))[-limit:]:
        value = _read(path)
        if not (isinstance(value, dict) and value.get("version") == SNAPSHOT_VERSION):
            continue
        by = value["by_status"]
        rows.append(
            {
                "generated_at": value["generated_at"],
                "total_market_value": value["total_market_value"],
                "flagged_value": by["BLOCKED"]["market_value"] + by["REVIEW"]["market_value"],
                "blocked": by["BLOCKED"]["count"],
                "review": by["REVIEW"]["count"],
                "clear": by["CLEAR"]["count"],
            }
        )
    return rows
