from __future__ import annotations

import sqlite3
from pathlib import Path
from uuid import uuid4

SCHEMA_VERSION = 3

SCHEMA = """
CREATE TABLE IF NOT EXISTS sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_key TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    path TEXT,
    sha256 TEXT NOT NULL,
    media_type TEXT NOT NULL,
    metadata_json TEXT NOT NULL DEFAULT '{}',
    injection_score REAL NOT NULL DEFAULT 0,
    injection_signals_json TEXT NOT NULL DEFAULT '[]',
    quarantined INTEGER NOT NULL DEFAULT 0,
    ingested_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS chunks (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id INTEGER NOT NULL REFERENCES sources(id) ON DELETE CASCADE,
    ordinal INTEGER NOT NULL,
    content TEXT NOT NULL,
    locator TEXT NOT NULL,
    content_sha256 TEXT NOT NULL,
    embedding BLOB,
    embedding_model TEXT,
    UNIQUE(source_id, ordinal)
);
CREATE INDEX IF NOT EXISTS idx_chunks_source ON chunks(source_id, ordinal);
CREATE TABLE IF NOT EXISTS cases (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    objective TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'open',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS case_evidence (
    case_id TEXT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    chunk_id INTEGER NOT NULL REFERENCES chunks(id) ON DELETE CASCADE,
    note TEXT NOT NULL DEFAULT '',
    PRIMARY KEY(case_id, chunk_id)
);
CREATE TABLE IF NOT EXISTS findings (
    id TEXT PRIMARY KEY,
    case_id TEXT NOT NULL REFERENCES cases(id) ON DELETE CASCADE,
    statement TEXT NOT NULL,
    confidence REAL NOT NULL,
    alternatives_json TEXT NOT NULL DEFAULT '[]',
    limitations_json TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS finding_evidence (
    finding_id TEXT NOT NULL REFERENCES findings(id) ON DELETE CASCADE,
    chunk_id INTEGER NOT NULL REFERENCES chunks(id) ON DELETE CASCADE,
    PRIMARY KEY(finding_id, chunk_id)
);
CREATE TABLE IF NOT EXISTS eval_runs (
    id TEXT PRIMARY KEY,
    suite TEXT NOT NULL,
    status TEXT NOT NULL,
    results_json TEXT NOT NULL,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS signals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source TEXT NOT NULL,
    external_id TEXT NOT NULL,
    holding_id TEXT NOT NULL,
    entity_name TEXT NOT NULL,
    title TEXT NOT NULL,
    url TEXT NOT NULL,
    published_at TEXT NOT NULL,
    collected_at TEXT NOT NULL,
    matched_term TEXT NOT NULL,
    categories_json TEXT NOT NULL DEFAULT '[]',
    terms_json TEXT NOT NULL DEFAULT '[]',
    severity TEXT NOT NULL,
    injection_score REAL NOT NULL DEFAULT 0,
    expires_at TEXT NOT NULL,
    UNIQUE(source, external_id, holding_id)
);
CREATE INDEX IF NOT EXISTS idx_signals_holding ON signals(holding_id, published_at);
CREATE INDEX IF NOT EXISTS idx_signals_expiry ON signals(expires_at);
CREATE TABLE IF NOT EXISTS telemetry_spans (
    id TEXT PRIMARY KEY,
    trace_id TEXT NOT NULL,
    parent_id TEXT,
    name TEXT NOT NULL,
    started_at TEXT NOT NULL,
    duration_ms REAL NOT NULL,
    status TEXT NOT NULL,
    attributes_json TEXT NOT NULL DEFAULT '{}'
);
"""


class Database:
    def __init__(self, path: Path | str) -> None:
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.conn = sqlite3.connect(str(self.path), timeout=10.0, check_same_thread=False)
        self.conn.row_factory = sqlite3.Row
        self._configure()
        # user_version is written only after migrations complete, so a current value means the
        # schema DDL can be skipped. The API opens a connection per request; skipping saves ~7 ms.
        current = int(self.conn.execute("PRAGMA user_version").fetchone()[0])
        if current != SCHEMA_VERSION:
            self._prepare()
        self.fts_enabled = self._has_fts() or self._setup_fts()

    def _prepare(self) -> None:
        with self.conn:
            self.conn.executescript(SCHEMA)
            self._migrate()

    def _has_fts(self) -> bool:
        row = self.conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name='chunks_fts'"
        ).fetchone()
        return row is not None

    def _configure(self) -> None:
        self.conn.execute("PRAGMA foreign_keys=ON")
        self.conn.execute("PRAGMA busy_timeout=5000")
        self.conn.execute("PRAGMA synchronous=NORMAL")
        if self.path.name != ":memory:":
            self.conn.execute("PRAGMA journal_mode=WAL")

    def _migrate(self) -> None:
        source_columns = {
            str(row["name"]) for row in self.conn.execute("PRAGMA table_info(sources)").fetchall()
        }
        if "last_ingested_at" not in source_columns:
            self.conn.execute("ALTER TABLE sources ADD COLUMN last_ingested_at TEXT")
        if "ingest_count" not in source_columns:
            self.conn.execute(
                "ALTER TABLE sources ADD COLUMN ingest_count INTEGER NOT NULL DEFAULT 1"
            )
        self.conn.execute(
            "UPDATE sources SET last_ingested_at=ingested_at WHERE last_ingested_at IS NULL"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_sources_quarantine ON sources(quarantined,id)"
        )
        self.conn.execute(
            "CREATE INDEX IF NOT EXISTS idx_case_evidence_case ON case_evidence(case_id)"
        )
        self.conn.execute(f"PRAGMA user_version={SCHEMA_VERSION}")

    def _setup_fts(self) -> bool:
        try:
            with self.conn:
                self.conn.execute(
                    "CREATE VIRTUAL TABLE IF NOT EXISTS chunks_fts USING "
                    "fts5(chunk_id UNINDEXED, content)"
                )
            return True
        except sqlite3.OperationalError:
            return False

    def backup_to(self, destination: Path | str) -> Path:
        target = Path(destination).expanduser().resolve()
        source = self.path.expanduser().resolve()
        if target == source:
            raise ValueError("Backup destination must differ from the live database")
        target.parent.mkdir(parents=True, exist_ok=True)
        temp = target.with_name(f".{target.name}.{uuid4().hex}.tmp")
        backup: sqlite3.Connection | None = None
        try:
            backup = sqlite3.connect(str(temp), timeout=10.0)
            self.conn.backup(backup)
            result = backup.execute("PRAGMA quick_check").fetchone()
            if result is None or str(result[0]).casefold() != "ok":
                raise RuntimeError("Backup integrity check failed")
            backup.close()
            backup = None
            temp.replace(target)
            return target
        finally:
            if backup is not None:
                backup.close()
            temp.unlink(missing_ok=True)

    def close(self) -> None:
        self.conn.close()
