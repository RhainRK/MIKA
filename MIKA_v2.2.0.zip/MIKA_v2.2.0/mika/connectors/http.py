"""The single gate for every outbound request MIKA makes.

Each data source declares the exact hosts it may call (and the hosts it may be redirected to).
URLs are built by connectors from fixed templates; anything user-derived arrives only through
``params`` and is percent-encoded here. Responses are streamed against a byte cap (also enforced
after gzip decoding), requests to a source are spaced by its minimum interval, and HTTP errors
never echo response bodies, which can contain tokens.
"""

from __future__ import annotations

import hashlib
import time
import zlib
from collections.abc import Callable, Mapping
from dataclasses import dataclass, field
from datetime import UTC, datetime
from typing import Protocol
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urljoin, urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener

from .. import __version__

DEFAULT_USER_AGENT = f"MIKA/{__version__} (+https://github.com/RhainRK/MIKA)"
_REDIRECTS = {301, 302, 303, 307, 308}
_MAX_REDIRECTS = 3
_MAX_RETRY_AFTER_S = 30.0
_CHUNK = 64 * 1024


class FetchError(RuntimeError):
    """A request was refused or failed. Messages never include response bodies."""

    def __init__(self, message: str, *, status: int | None = None) -> None:
        super().__init__(message)
        self.status = status


class Throttled(FetchError):
    """The source rate-limited us and a single retry did not help."""


@dataclass(frozen=True, slots=True)
class Source:
    name: str
    hosts: frozenset[str]
    redirect_hosts: frozenset[str] = frozenset()
    max_bytes: int = 10 * 1024 * 1024
    min_interval_s: float = 0.0
    timeout_s: float = 30.0


@dataclass(frozen=True, slots=True)
class RawResponse:
    status: int
    headers: Mapping[str, str]
    body: bytes


@dataclass(frozen=True, slots=True)
class Fetched:
    source: str
    url: str
    status: int
    content_type: str
    body: bytes
    sha256: str
    fetched_at: str


class Transport(Protocol):
    def __call__(
        self,
        method: str,
        url: str,
        headers: Mapping[str, str],
        data: bytes | None,
        timeout: float,
    ) -> RawResponse: ...


class _NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args: object, **kwargs: object) -> None:
        return None  # surface 3xx to SafeClient, which applies its own allowlist


def _urllib_transport(max_bytes: int) -> Transport:
    opener = build_opener(_NoRedirect)

    def send(
        method: str,
        url: str,
        headers: Mapping[str, str],
        data: bytes | None,
        timeout: float,
    ) -> RawResponse:
        request = Request(url, data=data, headers=dict(headers), method=method)
        try:
            response = opener.open(request, timeout=timeout)
        except HTTPError as error:
            response = error
        except (URLError, TimeoutError, OSError) as error:
            raise FetchError(f"network error: {type(error).__name__}") from None
        with response:
            chunks: list[bytes] = []
            total = 0
            while chunk := response.read(_CHUNK):
                total += len(chunk)
                if total > max_bytes:
                    raise FetchError(f"response exceeded the {max_bytes} byte limit")
                chunks.append(chunk)
            return RawResponse(
                int(response.status),
                {key.lower(): value for key, value in response.headers.items()},
                b"".join(chunks),
            )

    return send


def _check_url(url: str, hosts: frozenset[str]) -> None:
    try:
        parts = urlsplit(url)
        port = parts.port
    except ValueError:
        raise FetchError("malformed URL") from None
    if parts.scheme != "https":
        raise FetchError("only HTTPS requests are allowed")
    if parts.username or parts.password or port not in (None, 443):
        raise FetchError("credentials and custom ports are not allowed in URLs")
    if (parts.hostname or "").lower() not in hosts:
        raise FetchError(f"host {parts.hostname!r} is not allowed for this source")


def _decode(body: bytes, encoding: str, max_bytes: int) -> bytes:
    if encoding not in {"gzip", "deflate"}:
        return body
    wbits = 16 + zlib.MAX_WBITS if encoding == "gzip" else zlib.MAX_WBITS
    decompressor = zlib.decompressobj(wbits)
    try:
        output = decompressor.decompress(body, max_bytes + 1)
    except zlib.error:
        raise FetchError("could not decompress the response") from None
    if len(output) > max_bytes or decompressor.unconsumed_tail:
        raise FetchError(f"decompressed response exceeded the {max_bytes} byte limit")
    return output


@dataclass
class SafeClient:
    transport: Transport | None = None
    clock: Callable[[], float] = time.monotonic
    sleep: Callable[[float], None] = time.sleep
    user_agent: str = DEFAULT_USER_AGENT
    _last_request: dict[str, float] = field(default_factory=dict)

    def get(
        self,
        source: Source,
        url: str,
        *,
        params: Mapping[str, str | int] | None = None,
        headers: Mapping[str, str] | None = None,
        data: bytes | None = None,
    ) -> Fetched:
        if params:
            url = f"{url}{'&' if '?' in url else '?'}{urlencode(params)}"
        _check_url(url, source.hosts)
        transport = self.transport or _urllib_transport(source.max_bytes)
        sent = {"User-Agent": self.user_agent, "Accept-Encoding": "gzip", **(headers or {})}
        method = "POST" if data is not None else "GET"
        current, retried = url, False

        for _ in range(_MAX_REDIRECTS + 2):
            self._wait(source)
            response = transport(method, current, sent, data, source.timeout_s)
            if response.status in _REDIRECTS:
                location = response.headers.get("location", "")
                target = urljoin(current, location)
                try:
                    _check_url(target, source.hosts | source.redirect_hosts)
                except FetchError as error:
                    raise FetchError(f"refused redirect: {error}") from None
                if urlsplit(target).hostname != urlsplit(current).hostname:
                    sent = {k: v for k, v in sent.items() if k.lower() != "authorization"}
                current, method, data = target, "GET", None
                continue
            if response.status == 429:
                if retried:
                    raise Throttled(
                        f"{source.name} is rate limiting requests (HTTP 429)", status=429
                    )
                retried = True
                self.sleep(self._retry_after(response, source))
                continue
            if response.status >= 400:
                raise FetchError(
                    f"{source.name} returned HTTP {response.status}", status=response.status
                )
            if len(response.body) > source.max_bytes:
                raise FetchError(f"response exceeded the {source.max_bytes} byte limit")
            body = _decode(
                response.body,
                response.headers.get("content-encoding", "").lower(),
                source.max_bytes,
            )
            return Fetched(
                source=source.name,
                url=url,
                status=response.status,
                content_type=response.headers.get("content-type", ""),
                body=body,
                sha256=hashlib.sha256(body).hexdigest(),
                fetched_at=datetime.now(UTC).isoformat(),
            )
        raise FetchError("too many redirects")

    def _wait(self, source: Source) -> None:
        last = self._last_request.get(source.name)
        now = self.clock()
        if last is not None and source.min_interval_s:
            remaining = source.min_interval_s - (now - last)
            if remaining > 0:
                self.sleep(remaining)
                now = self.clock()
        self._last_request[source.name] = now

    @staticmethod
    def _retry_after(response: RawResponse, source: Source) -> float:
        try:
            value = float(response.headers.get("retry-after", ""))
        except ValueError:
            value = max(source.min_interval_s, 5.0)
        return min(max(value, 1.0), _MAX_RETRY_AFTER_S)
