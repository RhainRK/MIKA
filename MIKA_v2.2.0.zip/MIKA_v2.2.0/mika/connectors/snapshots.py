"""Provenance snapshots: every raw response MIKA relies on is kept with its digest and origin."""

from __future__ import annotations

import json
import re
from datetime import UTC, datetime
from pathlib import Path

from .http import Fetched

_SAFE = re.compile(r"[^a-z0-9_-]")


def save(root: Path, source: str, fetched: Fetched, ext: str) -> Path:
    folder = root / _SAFE.sub("_", source.lower())
    folder.mkdir(parents=True, exist_ok=True)
    stamp = datetime.fromisoformat(fetched.fetched_at).strftime("%Y%m%dT%H%M%S%fZ")
    path = folder / f"{stamp}-{fetched.sha256[:8]}.{_SAFE.sub('', ext.lower()) or 'bin'}"
    path.write_bytes(fetched.body)
    record = {
        "file": path.name,
        "url": fetched.url,
        "status": fetched.status,
        "sha256": fetched.sha256,
        "bytes": len(fetched.body),
        "fetched_at": fetched.fetched_at,
    }
    with (folder / "manifest.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(record, sort_keys=True) + "\n")
    return path


def prune(root: Path, source: str, *, max_age_s: float, now: float | None = None) -> int:
    """Delete snapshot files older than ``max_age_s``. Returns how many were removed."""
    folder = root / _SAFE.sub("_", source.lower())
    manifest = folder / "manifest.jsonl"
    if not manifest.exists():
        return 0
    current = datetime.now(UTC).timestamp() if now is None else now
    kept: list[str] = []
    removed = 0
    for line in manifest.read_text(encoding="utf-8").splitlines():
        try:
            record = json.loads(line)
            age = current - datetime.fromisoformat(record["fetched_at"]).timestamp()
            name = str(record["file"])
        except (ValueError, KeyError, TypeError):
            continue
        target = folder / Path(name).name  # never follow a path out of the folder
        if age > max_age_s:
            target.unlink(missing_ok=True)
            removed += 1
        else:
            kept.append(line)
    manifest.write_text("".join(f"{line}\n" for line in kept), encoding="utf-8")
    return removed
