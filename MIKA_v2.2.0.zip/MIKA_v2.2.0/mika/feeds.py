"""`mika feeds check`: one minimal live request per source, to confirm configuration."""

from __future__ import annotations

from collections.abc import Callable
from typing import Any

from .config import Settings
from .connectors.http import FetchError, SafeClient
from .portfolio.enrich import GLEIF, GLEIF_BASE, SEC, sec_user_agent
from .sanctions.sync import OFAC, OFAC_BASE, UK, UK_URL
from .signals import gdelt, reddit

# A well-known public record used only to prove each service answers.
_PROBE_LEI = "HWUPKR0MPOU8FGXBT394"
_PROBE_CIK = 320193
_RANGE = {"Range": "bytes=0-2047"}


def check_feeds(settings: Settings, client: SafeClient) -> dict[str, Any]:
    online = settings.online()
    checks: dict[str, Callable[[], str]] = {
        "ofac": lambda: _ok(client.get(OFAC, OFAC_BASE + "SDN.CSV", headers=_RANGE).status),
        "uk": lambda: _ok(client.get(UK, UK_URL, headers=_RANGE).status),
    }
    if "gleif" in online:
        checks["gleif"] = lambda: _ok(client.get(GLEIF, f"{GLEIF_BASE}/{_PROBE_LEI}").status)
    if "sec" in online:
        if settings.contact_email:
            checks["sec"] = lambda: _ok(
                client.get(
                    SEC,
                    f"https://data.sec.gov/submissions/CIK{_PROBE_CIK:010d}.json",
                    headers={"User-Agent": sec_user_agent(settings.contact_email)},
                ).status
            )
        else:
            checks["sec"] = lambda: "not configured: set MIKA_CONTACT_EMAIL"
    if "gdelt" in online:
        checks["gdelt"] = lambda: _ok(
            client.get(
                gdelt.GDELT,
                gdelt.ENDPOINT,
                params={
                    "query": '"Apple Inc"',
                    "mode": "artlist",
                    "format": "json",
                    "maxrecords": 1,
                    "timespan": "1d",
                },
            ).status
        )
    if "reddit" in online:
        if settings.has_reddit() and settings.reddit_client_id and settings.reddit_client_secret:
            creds = reddit.Credentials(
                settings.reddit_client_id.get_secret_value(),
                settings.reddit_client_secret.get_secret_value(),
                settings.reddit_username,
            )
            checks["reddit"] = lambda: _ok(200 if reddit._token(client, creds) else 0)
        else:
            checks["reddit"] = lambda: "not configured: set the MIKA_REDDIT_* variables"
    if "x" in online:
        configured = bool(settings.x_bearer_token)
        checks["x"] = lambda: (
            "configured (not called: X bills every post read)"
            if configured
            else "not configured: set MIKA_X_BEARER_TOKEN"
        )

    results: dict[str, str] = {}
    for name, check in checks.items():
        try:
            results[name] = check()
        except FetchError as error:
            results[name] = f"failed: {error}"
    disabled = sorted({"gleif", "sec", "gdelt", "reddit", "x"} - online)
    return {"results": results, "disabled_by_privacy_setting": disabled}


def _ok(status: int) -> str:
    return "ok" if 200 <= status < 300 else f"unexpected HTTP {status}"
