from __future__ import annotations

import json
import mimetypes
import re
import secrets
from pathlib import Path
from typing import TYPE_CHECKING, Any

from . import __version__
from .app import MikaApp
from .audit import AuditLog
from .config import Settings, settings
from .embeddings import Embedder
from .policy import Policy
from .tools.builtins import register_builtin_tools
from .tools.registry import ToolRegistry

if TYPE_CHECKING:
    from fastapi import FastAPI


def create_app(
    config: Settings | None = None,
    *,
    embedder: Embedder | None = None,
    password: str | None = None,
) -> FastAPI:
    try:
        from fastapi import FastAPI, HTTPException, Query
        from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse
        from fastapi.staticfiles import StaticFiles
    except ImportError as exc:
        raise RuntimeError("Install the server dependencies to run the API") from exc

    runtime_settings = (config or settings).resolve()
    shared_embedder = embedder or Embedder(runtime_settings.embedding_model)
    shared_audit = AuditLog(runtime_settings.audit_path)
    root = Path(__file__).resolve().parents[1]
    dashboard = root / "dashboard"
    service = FastAPI(
        title="MIKA API", version=__version__, docs_url=None, redoc_url=None, openapi_url=None
    )
    from .web_security import LocalAccessMiddleware

    service.add_middleware(LocalAccessMiddleware, password=password or secrets.token_urlsafe(32))

    # Module scripts must be served as JavaScript; some Windows registries map .js to text/plain.
    mimetypes.add_type("text/javascript", ".js")
    if (dashboard / "dist").exists():
        service.mount("/assets", StaticFiles(directory=dashboard / "dist"), name="assets")

    @service.exception_handler(Exception)
    async def internal_error(request: Any, exc: Exception) -> Any:
        return JSONResponse(
            {"detail": "Internal operation failed"},
            status_code=500,
            headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
        )

    def open_session() -> MikaApp:
        return MikaApp(runtime_settings, embedder=shared_embedder, audit=shared_audit)

    @service.get("/")
    def index() -> Any:
        page = dashboard / "index.html"
        bundle = dashboard / "dist" / "main.js"
        if not page.exists() or not bundle.exists():
            raise HTTPException(
                status_code=503, detail="dashboard not built; run npm run build in dashboard"
            )
        return FileResponse(page)

    @service.get("/style.css")
    def stylesheet() -> Any:
        return FileResponse(dashboard / "style.css", media_type="text/css")

    @service.get("/favicon.svg")
    def favicon() -> Any:
        return FileResponse(dashboard / "assets" / "mika-mark.svg", media_type="image/svg+xml")

    @service.get("/api/health")
    def health() -> dict[str, Any]:
        with open_session() as app:
            valid, records, error = app.audit.verify()
            source_count = int(
                app.db.conn.execute("SELECT COUNT(*) AS n FROM sources").fetchone()["n"]
            )
            chunk_count = int(
                app.db.conn.execute("SELECT COUNT(*) AS n FROM chunks").fetchone()["n"]
            )
            return {
                "status": "ok",
                "version": __version__,
                "fts5": app.db.fts_enabled,
                "embedding_backend": app.embedder.backend,
                "audit_chain_valid": valid,
                "audit_records": records,
                "audit_error": error,
                "sources": source_count,
                "chunks": chunk_count,
            }

    search_query = Query(min_length=1, max_length=2000)
    search_limit = Query(default=6, ge=1, le=20)
    search_sources = Query(default=None)
    search_chunks = Query(default=None)
    search_case = Query(default=None, max_length=128)

    @service.get("/api/search")
    def search(
        q: str = search_query,
        k: int = search_limit,
        source_id: list[int] | None = search_sources,
        chunk_id: list[int] | None = search_chunks,
        case_id: str | None = search_case,
    ) -> list[dict[str, Any]]:
        with open_session() as app:
            try:
                return app.search(q, k, source_ids=source_id, chunk_ids=chunk_id, case_id=case_id)
            except ValueError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc

    @service.get("/api/sources")
    def sources(include_quarantined: bool = True) -> list[dict[str, Any]]:
        with open_session() as app:
            return app.evidence.list_sources(include_quarantined=include_quarantined)

    @service.get("/api/sources/{source_id}")
    def source(source_id: int) -> dict[str, Any]:
        with open_session() as app:
            try:
                return app.evidence.get_source(source_id)
            except ValueError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc

    @service.get("/api/evaluation/latest")
    def evaluation() -> Any:
        path = root / "reports" / "evaluation-results.json"
        if not path.exists():
            raise HTTPException(status_code=404, detail="run `mika evaluate` first")
        return json.loads(path.read_text(encoding="utf-8"))

    @service.get("/api/screening/latest")
    def screening_report() -> Any:
        path = runtime_settings.workspace / "reports" / "screening-latest.json"
        if not path.is_file():
            raise HTTPException(status_code=404, detail="run `mika screen` first")
        return json.loads(path.read_text(encoding="utf-8"))

    @service.get("/api/changes")
    def changes() -> Any:
        from .changes import latest_changes

        result = latest_changes(runtime_settings.workspace)
        if result is None:
            raise HTTPException(status_code=404, detail="run `mika monitor` first")
        return result

    @service.get("/api/history")
    def run_history() -> list[dict[str, Any]]:
        from .changes import history

        return history(runtime_settings.workspace)

    signal_limit = Query(default=200, ge=1, le=500)

    @service.get("/api/signals")
    def signals(
        holding_id: str | None = Query(default=None, max_length=64),
        category: str | None = Query(default=None, max_length=40),
        source: str | None = Query(default=None, max_length=20),
        severity: str | None = Query(default=None, pattern="^(high|medium|low|info)$"),
        limit: int = signal_limit,
    ) -> list[dict[str, Any]]:
        from .signals.store import list_signals

        with open_session() as app:
            return list_signals(
                app.db,
                holding_id=holding_id,
                category=category,
                source=source,
                severity=severity,
                limit=limit,
            )

    @service.get("/api/feeds")
    def feeds() -> dict[str, Any]:
        path = runtime_settings.workspace / "reports" / "monitor-latest.json"
        latest = json.loads(path.read_text(encoding="utf-8")) if path.is_file() else None
        return {
            "online_sources": sorted(runtime_settings.online()),
            # Whether credentials are configured, never their values.
            "credentials": {
                "reddit": runtime_settings.has_reddit(),
                "x": bool(runtime_settings.x_bearer_token),
                "contact_email": bool(runtime_settings.contact_email),
            },
            "latest": latest,
        }

    @service.get("/api/cases")
    def cases() -> list[dict[str, Any]]:
        with open_session() as app:
            return app.cases.list_cases()

    @service.get("/api/cases/{case_id}/report")
    def case_report(case_id: str) -> Any:
        with open_session() as app:
            try:
                markdown = app.cases.report_markdown(case_id)
            except ValueError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc
        # Header values must never carry CR/LF or quotes; keep a conservative character set.
        stem = re.sub(r"[^A-Za-z0-9_.-]+", "_", case_id).strip("._") or "case"
        filename = f"{stem[:100]}.md"
        return PlainTextResponse(
            markdown,
            media_type="text/markdown; charset=utf-8",
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )

    @service.get("/api/cases/{case_id}")
    def case(case_id: str) -> dict[str, Any]:
        with open_session() as app:
            try:
                return app.cases.get_case(case_id)
            except ValueError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc

    @service.get("/api/tools")
    def tools(role: str = "analyst") -> dict[str, Any]:
        try:
            policy = Policy.for_role(role)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        with open_session() as app:
            registry = ToolRegistry(policy, app.audit)
            register_builtin_tools(
                registry,
                retriever=app.retriever,
                workspace=app.settings.workspace,
                cases=app.cases,
            )
            return {"role": role, "tools": [item["function"] for item in registry.schemas()]}

    return service
