"""Legal Entity Identifier validation (ISO 17442, check digits per ISO 7064 MOD 97-10)."""

from __future__ import annotations

import re

_LEI = re.compile(r"[A-Z0-9]{18}[0-9]{2}")


def valid_lei(value: str) -> bool:
    if not _LEI.fullmatch(value):
        return False
    digits = "".join(str(int(char, 36)) for char in value)
    return int(digits) % 97 == 1
