"""Turn an imported portfolio into screening inputs using real registries.

Each lookup reveals which companies are held, so GLEIF and SEC are used only when listed in the
``online`` set. Without them MIKA still produces valid inputs from the portfolio alone.

GLEIF parent links are accounting consolidation (control), not ownership percentages. They are
written as 100% with ``basis=accounting_consolidation`` so the interface can say "consolidates"
rather than invent a figure. ``data/ownership-overrides.csv`` (owner_id, owned_id, percent) holds
known exact stakes and replaces any GLEIF link for the same pair.
"""

from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass, field
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any
from urllib.parse import quote

from ..connectors.http import FetchError, SafeClient, Source
from ..entity_resolution import normalize_name
from .lei import valid_lei

GLEIF = Source(
    "gleif", hosts=frozenset({"api.gleif.org"}), max_bytes=5 * 1024 * 1024, min_interval_s=1.0
)
SEC = Source(
    "sec",
    hosts=frozenset({"www.sec.gov", "data.sec.gov"}),
    max_bytes=20 * 1024 * 1024,
    min_interval_s=0.15,
)
GLEIF_BASE = "https://api.gleif.org/api/v1/lei-records"
SEC_TICKERS = "https://www.sec.gov/files/company_tickers.json"
CACHE_TTL = timedelta(days=7)
MAX_PARENT_DEPTH = 5
_TICKER = re.compile(r"[A-Z]{1,5}(?:[.-][A-Z]{1,2})?")


def sec_user_agent(contact_email: str) -> str:
    from .. import __version__

    return f"MIKA/{__version__} {contact_email}"


@dataclass
class _Cache:
    folder: Path
    now: datetime

    def _path(self, url: str) -> Path:
        return self.folder / f"{hashlib.sha256(url.encode()).hexdigest()[:32]}.json"

    def get(self, url: str) -> Any | None:
        path = self._path(url)
        if not path.exists():
            return None
        try:
            record = json.loads(path.read_text(encoding="utf-8"))
            if self.now - datetime.fromisoformat(record["cached_at"]) > CACHE_TTL:
                return None
            return record["value"]
        except (ValueError, KeyError):
            return None

    def put(self, url: str, value: Any) -> None:
        self.folder.mkdir(parents=True, exist_ok=True)
        payload = {"cached_at": self.now.isoformat(), "url": url, "value": value}
        self._path(url).write_text(json.dumps(payload), encoding="utf-8")


@dataclass
class _Gleif:
    client: SafeClient
    cache: _Cache

    def _json(self, url: str, params: dict[str, str | int] | None = None) -> Any | None:
        key = url + ("?" + json.dumps(params, sort_keys=True) if params else "")
        cached = self.cache.get(key)
        if cached is not None:
            return cached or None
        try:
            fetched = self.client.get(
                GLEIF, url, params=params, headers={"Accept": "application/vnd.api+json"}
            )
            value = json.loads(fetched.body)
        except FetchError as error:
            if error.status != 404:
                raise
            value = {}
        except json.JSONDecodeError:
            raise FetchError("GLEIF returned a response that is not JSON") from None
        self.cache.put(key, value)
        return value or None

    def record(self, lei: str) -> dict[str, Any] | None:
        body = self._json(f"{GLEIF_BASE}/{quote(lei)}")
        return _parse_record(body.get("data")) if body else None

    def search(self, name: str) -> dict[str, Any] | None:
        """Find a record whose normalised legal or other name equals ``name``.

        GLEIF search is loose and its full-text ranking is poor (Apple Inc. is not in the top 10
        full-text hits), so the legal-name filter is tried first and full text second, and only
        an exact normalised-name match is ever accepted.
        """
        target = normalize_name(name)
        for field_name in ("filter[entity.legalName]", "filter[fulltext]"):
            body = self._json(GLEIF_BASE, {field_name: name[:200], "page[size]": 25})
            matches = []
            for item in (body or {}).get("data", []) or []:
                record = _parse_record(item)
                names = {normalize_name(n) for n in [*(record or {}).get("aliases", [])]}
                if record and (normalize_name(record["name"]) == target or target in names):
                    matches.append(record)
            if matches:
                matches.sort(key=lambda r: (r["status"] != "ACTIVE", r["registration"] != "ISSUED"))
                return matches[0]
        return None

    def parent(self, lei: str) -> tuple[dict[str, Any] | None, str | None]:
        body = self._json(f"{GLEIF_BASE}/{quote(lei)}/direct-parent")
        if body:
            return _parse_record(body.get("data")), None
        exception = self._json(f"{GLEIF_BASE}/{quote(lei)}/direct-parent-reporting-exception")
        reason = ((exception or {}).get("data") or {}).get("attributes", {}).get("reason")
        return None, str(reason) if reason else None


def _parse_record(item: Any) -> dict[str, Any] | None:
    try:
        attributes = item["attributes"]
        entity = attributes["entity"]
        return {
            "lei": str(attributes["lei"]),
            "name": str(entity["legalName"]["name"]),
            "aliases": [str(o["name"]) for o in entity.get("otherNames") or [] if o.get("name")],
            "country": str((entity.get("legalAddress") or {}).get("country") or ""),
            "status": str(entity.get("status") or ""),
            "registration": str((attributes.get("registration") or {}).get("status") or ""),
        }
    except (KeyError, TypeError):
        return None


def load_sec_tickers(
    client: SafeClient, workspace: Path, contact_email: str, now: datetime
) -> dict[str, dict[str, Any]]:
    """Ticker -> {"title", "cik"} from SEC's company_tickers.json, cached for 7 days."""
    cache = _Cache(workspace / "data" / "cache" / "sec", now)
    cached = cache.get(SEC_TICKERS)
    if cached is None:
        fetched = client.get(
            SEC, SEC_TICKERS, headers={"User-Agent": sec_user_agent(contact_email)}
        )
        try:
            cached = {
                str(row["ticker"]).upper(): {"title": str(row["title"]), "cik": int(row["cik_str"])}
                for row in json.loads(fetched.body).values()
            }
        except (ValueError, KeyError, TypeError, AttributeError):
            raise FetchError("SEC ticker file has an unexpected format") from None
        cache.put(SEC_TICKERS, cached)
    return dict(cached)


@dataclass
class _Register:
    entities: dict[str, dict[str, str]] = field(default_factory=dict)
    links: dict[tuple[str, str], tuple[float, str]] = field(default_factory=dict)

    def resolve(self, entity_id: str, name: str) -> str | None:
        """Find an entity by id, then by normalised name or alias; otherwise create one.

        Analysts know names and LEIs, not MIKA's internal ids, so overrides may use either.
        """
        entity_id, name = entity_id.strip(), name.strip()
        if entity_id in self.entities:
            return entity_id
        target = normalize_name(name)
        if target:
            for key, row in self.entities.items():
                names = [row["name"], *row["aliases"].split(";")]
                if target in {normalize_name(n) for n in names if n}:
                    return key
        if not entity_id and not name:
            return None
        new_id = entity_id or f"X-{hashlib.sha256(target.encode()).hexdigest()[:10]}"
        self.add(new_id, name or entity_id, [], "", entity_id if valid_lei(entity_id) else "")
        return new_id

    def add(self, entity_id: str, name: str, aliases: list[str], country: str, lei: str) -> None:
        current = self.entities.get(entity_id)
        merged = list(
            dict.fromkeys([*(current["aliases"].split(";") if current else []), *aliases])
        )
        merged = [alias for alias in merged if alias and alias != name]
        self.entities[entity_id] = {
            "entity_id": entity_id,
            "name": name,
            "aliases": ";".join(alias.replace(";", ",") for alias in merged),
            "entity_type": "organisation",
            "country": country,
            "lei": lei,
        }


def _write_csv(path: Path, fields: list[str], rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)


def enrich_portfolio(
    workspace: Path,
    client: SafeClient,
    *,
    online: set[str],
    contact_email: str,
    now: datetime | None = None,
) -> dict[str, Any]:
    source = workspace / "data" / "portfolio" / "holdings.csv"
    if not source.exists():
        raise ValueError("No portfolio imported yet. Run: mika portfolio import <file.csv>")
    holdings = list(csv.DictReader(source.open(encoding="utf-8")))
    now = now or datetime.now(UTC)
    cache = _Cache(workspace / "data" / "cache", now)
    gleif = _Gleif(client, _Cache(cache.folder / "gleif", now)) if "gleif" in online else None
    warnings: list[str] = []
    titles: dict[str, str] = {}
    if "sec" in online:
        if contact_email:
            try:
                titles = {
                    ticker: str(info["title"])
                    for ticker, info in load_sec_tickers(
                        client, workspace, contact_email, now
                    ).items()
                }
            except (FetchError, ValueError) as error:
                warnings.append(f"SEC ticker lookup failed: {error}")
        else:
            warnings.append("SEC lookups need MIKA_CONTACT_EMAIL (the SEC requires a contact).")

    register = _Register()
    exceptions: dict[str, str] = {}
    unresolved: list[str] = []
    resolved = 0
    out_holdings: list[dict[str, str]] = []
    for holding in holdings:
        identifier = holding["identifier"]
        sec_title = titles.get(identifier) if _TICKER.fullmatch(identifier) else None
        record = None
        if gleif is not None:
            try:
                if valid_lei(identifier):
                    record = gleif.record(identifier)
                else:
                    record = gleif.search(sec_title or holding["issuer"])
                    if record is None and sec_title:
                        record = gleif.search(holding["issuer"])
            except FetchError as error:
                warnings.append(f"GLEIF lookup failed for {holding['holding_id']}: {error}")
        lei = record["lei"] if record else (identifier if valid_lei(identifier) else "")
        if record:
            resolved += 1
            aliases = [*record["aliases"], holding["issuer"], *([sec_title] if sec_title else [])]
            register.add(record["lei"], record["name"], aliases, record["country"], record["lei"])
            child = record["lei"]
            seen = {child}
            for _ in range(MAX_PARENT_DEPTH):
                try:
                    parent, reason = gleif.parent(child) if gleif else (None, None)
                except FetchError as error:
                    warnings.append(f"GLEIF parent lookup failed for {child}: {error}")
                    break
                if parent is None:
                    if reason:
                        exceptions[child] = reason
                    break
                if parent["lei"] in seen:
                    break
                register.add(
                    parent["lei"],
                    parent["name"],
                    parent["aliases"],
                    parent["country"],
                    parent["lei"],
                )
                register.links[(parent["lei"], child)] = (100.0, "accounting_consolidation")
                seen.add(parent["lei"])
                child = parent["lei"]
        else:
            if gleif is not None:
                unresolved.append(holding["holding_id"])
            entity_id = lei or f"H-{holding['holding_id']}"
            register.add(entity_id, holding["issuer"], [sec_title] if sec_title else [], "", lei)
        out_holdings.append({**holding, "identifier": lei or identifier})

    overrides = workspace / "data" / "ownership-overrides.csv"
    if overrides.exists():
        for row in csv.DictReader(overrides.open(encoding="utf-8")):
            try:
                percent = float(row.get("percent", ""))
            except ValueError:
                warnings.append("Ignored an override row: percent is not a number")
                continue
            owner = register.resolve(row.get("owner_id", ""), row.get("owner_name", ""))
            owned = register.resolve(row.get("owned_id", ""), row.get("owned_name", ""))
            if owner is None or owned is None or owner == owned:
                warnings.append("Ignored an override row: give an id or a name for both sides")
                continue
            register.links[(owner, owned)] = (percent, "override")

    out = workspace / "data" / "screening"
    _write_csv(
        out / "holdings.csv",
        ["holding_id", "issuer", "identifier", "market_value_usd"],
        out_holdings,
    )
    _write_csv(
        out / "entities.csv",
        ["entity_id", "name", "aliases", "entity_type", "country", "lei"],
        list(register.entities.values()),
    )
    _write_csv(
        out / "ownership.csv",
        ["owner_id", "owned_id", "percent", "basis"],
        [
            {"owner_id": a, "owned_id": b, "percent": p, "basis": basis}
            for (a, b), (p, basis) in register.links.items()
        ],
    )
    return {
        "holdings": len(holdings),
        "resolved": resolved,
        "unresolved": unresolved,
        "entities": len(register.entities),
        "ownership_links": len(register.links),
        "parent_exceptions": exceptions,
        "warnings": warnings,
        "online": sorted(online & {"gleif", "sec"}),
    }
