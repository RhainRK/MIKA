"""Import a real portfolio of holdings."""

from __future__ import annotations

import csv
import math
from pathlib import Path
from typing import Any

from ..security import safe_workspace_path

MAX_HOLDINGS = 10_000
HOLDINGS_COLUMNS = ("holding_id", "issuer", "identifier", "market_value_usd")


def _number(value: str) -> float | None:
    try:
        number = float(value.replace(",", "").replace("$", "").strip())
    except ValueError:
        return None
    return number if math.isfinite(number) and number >= 0 else None


def import_holdings(workspace: Path, candidate: str) -> dict[str, Any]:
    """Validate a holdings CSV and store it as ``data/portfolio/holdings.csv``.

    Required columns: ``issuer`` and ``market_value_usd``. Optional: ``holding_id`` and
    ``identifier`` (an LEI, ISIN or ticker). Bad rows are reported and skipped.
    """
    path = safe_workspace_path(workspace, candidate)
    if not path.is_file():
        raise ValueError(f"Portfolio file not found: {candidate}")
    try:
        text = path.read_bytes().decode("utf-8-sig", errors="replace")
        reader = csv.DictReader(text.splitlines())
        fields = {name.strip().casefold() for name in reader.fieldnames or []}
        if not {"issuer", "market_value_usd"} <= fields:
            raise ValueError(
                "Portfolio CSV needs the columns issuer and market_value_usd "
                "(optional: holding_id, identifier)"
            )
        rows: list[dict[str, str]] = []
        issues: list[dict[str, Any]] = []
        seen: set[str] = set()
        for number, raw in enumerate(reader, start=2):
            row = {str(k).strip().casefold(): (v or "").strip() for k, v in raw.items() if k}
            issuer = row.get("issuer", "")
            value = _number(row.get("market_value_usd", ""))
            if not issuer:
                issues.append({"row": number, "check": "missing_issuer"})
                continue
            if value is None:
                issues.append({"row": number, "check": "invalid_value", "issuer": issuer})
                continue
            holding_id = row.get("holding_id") or f"H{len(rows) + 1:04d}"
            if holding_id in seen:
                issues.append({"row": number, "check": "duplicate_id", "holding_id": holding_id})
                continue
            seen.add(holding_id)
            rows.append(
                {
                    "holding_id": holding_id,
                    "issuer": issuer,
                    "identifier": row.get("identifier", "").upper(),
                    "market_value_usd": str(value),
                }
            )
            if len(rows) > MAX_HOLDINGS:
                raise ValueError(f"Portfolio exceeds {MAX_HOLDINGS} holdings")
    except csv.Error as exc:
        raise ValueError(f"{path.name} is not a readable CSV: {exc}") from None
    if not rows:
        raise ValueError("No valid holdings found; check the issuer and market_value_usd columns")

    target = workspace / "data" / "portfolio" / "holdings.csv"
    target.parent.mkdir(parents=True, exist_ok=True)
    with target.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=HOLDINGS_COLUMNS, lineterminator="\n")
        writer.writeheader()
        writer.writerows(rows)
    return {
        "holdings": len(rows),
        "total_market_value": sum(float(row["market_value_usd"]) for row in rows),
        "issues": issues,
        "output": target.relative_to(workspace).as_posix(),
    }
