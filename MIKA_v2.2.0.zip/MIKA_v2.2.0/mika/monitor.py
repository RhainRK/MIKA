"""`mika monitor`: refresh public data, screen the portfolio and collect signals.

Order of work:
1. Sync sanctions lists (public downloads; reveals nothing about the portfolio).
2. Enrich holdings with GLEIF/SEC, only if enabled in MIKA_ONLINE_SOURCES.
3. Screen with the existing engine and write reports/screening-latest.json.
4. Collect signals from enabled sources, flagged holdings first. One source failing or
   throttling never stops the others.
5. Record the run and compare it with the previous one (reports/changes-latest.json).
6. Write reports/monitor-latest.json and an audit event.
"""

from __future__ import annotations

import json
import re
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from .app import MikaApp
from .changes import record_run
from .connectors.http import FetchError, SafeClient, Throttled
from .portfolio import enrich_portfolio
from .portfolio.enrich import load_sec_tickers
from .sanctions import ATTRIBUTION as SANCTIONS_ATTRIBUTION
from .sanctions import sync_sanctions
from .screening import load_inputs, screen
from .signals import gdelt, reddit, sec_filings, x
from .signals.model import Signal, Target
from .signals.store import purge_expired, upsert_signals

SIGNAL_SOURCES = ("gdelt", "sec", "reddit", "x")
_TICKER = re.compile(r"[A-Z]{1,5}(?:[.-][A-Z]{1,2})?")
_ORDER = {"BLOCKED": 0, "REVIEW": 1, "CLEAR": 2}


def _targets(report: dict[str, Any], limit: int) -> list[Target]:
    rows = sorted(
        report["holdings"],
        key=lambda row: (_ORDER.get(row["status"], 3), -float(row["market_value"])),
    )
    targets = []
    for row in rows[:limit]:
        entity = row.get("entity") or {}
        identifier = str(row.get("identifier") or "")
        ticker = identifier if _TICKER.fullmatch(identifier) else ""
        aliases = tuple(name for name in [entity.get("name", "")] if name and name != row["issuer"])
        targets.append(Target(row["holding_id"], row["issuer"], aliases, ticker))
    return targets


def _collectors(
    app: MikaApp, client: SafeClient, online: set[str], now: datetime, warnings: list[str]
) -> dict[str, Callable[[Target], list[Signal]]]:
    settings = app.settings
    collectors: dict[str, Callable[[Target], list[Signal]]] = {}
    if "gdelt" in online:
        collectors["gdelt"] = lambda target: gdelt.collect(client, target, now=now)
    if "sec" in online:
        if settings.contact_email:
            ciks = {
                ticker: int(info["cik"])
                for ticker, info in load_sec_tickers(
                    client, app.settings.workspace, settings.contact_email, now
                ).items()
            }

            def sec(target: Target) -> list[Signal]:
                cik = ciks.get(target.ticker)
                if cik is None:
                    return []
                return sec_filings.collect(
                    client, target, cik=cik, contact_email=settings.contact_email, now=now
                )

            collectors["sec"] = sec
        else:
            warnings.append("SEC filings skipped: set MIKA_CONTACT_EMAIL.")
    if "reddit" in online:
        if settings.has_reddit() and settings.reddit_client_id and settings.reddit_client_secret:
            creds = reddit.Credentials(
                settings.reddit_client_id.get_secret_value(),
                settings.reddit_client_secret.get_secret_value(),
                settings.reddit_username,
            )
            token: dict[str, str] = {}

            def reddit_collect(target: Target) -> list[Signal]:
                if "value" not in token:
                    token["value"] = reddit._token(client, creds)
                return reddit.collect(client, target, creds, now=now, token=token["value"])

            collectors["reddit"] = reddit_collect
        else:
            warnings.append(
                "Reddit skipped: set MIKA_REDDIT_CLIENT_ID, MIKA_REDDIT_CLIENT_SECRET and "
                "MIKA_REDDIT_USERNAME (Reddit must also approve your API access)."
            )
    if "x" in online:
        if settings.x_bearer_token:
            bearer = settings.x_bearer_token.get_secret_value()
            budget = x.Budget(remaining=max(0, settings.x_max_posts))
            collectors["x"] = lambda target: x.collect(client, target, bearer, budget, now=now)
        else:
            warnings.append("X skipped: set MIKA_X_BEARER_TOKEN.")
    return collectors


def _write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False), encoding="utf-8")


def run_monitor(
    app: MikaApp, client: SafeClient, *, offline: bool = False, now: datetime | None = None
) -> dict[str, Any]:
    now = now or datetime.now(UTC)
    workspace = app.settings.workspace
    online = set() if offline else app.settings.online()
    warnings: list[str] = []
    if not (workspace / "data" / "portfolio" / "holdings.csv").exists():
        raise ValueError("No portfolio imported yet. Run: mika portfolio import <file.csv>")

    sanctions: dict[str, Any] = {"skipped": True, "reason": "offline"}
    if not offline:
        try:
            sanctions = sync_sanctions(client, workspace, now=now)
        except RuntimeError as error:
            warnings.append(str(error))
    watchlist = workspace / "data" / "watchlist.csv"
    if not watchlist.exists():
        raise ValueError("No sanctions list downloaded yet. Run `mika sync sanctions` once online.")

    enrichment = enrich_portfolio(
        workspace, client, online=online, contact_email=app.settings.contact_email, now=now
    )
    warnings.extend(enrichment["warnings"])
    folder = "data/screening"
    inputs = load_inputs(
        workspace,
        holdings=f"{folder}/holdings.csv",
        entities=f"{folder}/entities.csv",
        ownership=f"{folder}/ownership.csv",
        watchlist="data/watchlist.csv",
    )
    report = screen(inputs)
    _write_json(workspace / "reports" / "screening-latest.json", report)
    changes = record_run(workspace, report, inputs.watchlist, now=now)

    purged = purge_expired(app.db, now=now)
    collectors = _collectors(app, client, online, now, warnings)
    sources: dict[str, dict[str, Any]] = {}
    collected: list[Signal] = []
    for name, collect in collectors.items():
        status: dict[str, Any] = {"status": "ok", "new": 0, "errors": 0}
        for target in _targets(report, app.settings.signal_holdings_limit):
            try:
                found = collect(target)
            except Throttled:
                status["status"] = "throttled"
                break
            except (FetchError, ValueError) as error:
                status["errors"] += 1
                status["last_error"] = str(error)[:200]
                continue
            status["new"] += upsert_signals(app.db, found, collected_at=now)
            collected.extend(found)
        sources[name] = status

    attribution = [SANCTIONS_ATTRIBUTION]
    if "gdelt" in collectors:
        attribution.append(gdelt.ATTRIBUTION)
    summary = {
        "generated_at": now.isoformat(),
        "offline": offline,
        "online_sources": sorted(online),
        "sanctions": {
            key: sanctions.get(key) for key in ("skipped", "synced_at", "entries", "sources")
        },
        "enrichment": {
            key: enrichment[key]
            for key in ("resolved", "unresolved", "entities", "ownership_links")
        },
        "screening": report["summary"],
        "changes": {
            key: changes[key] for key in ("since", "first_run", "counts", "value_newly_flagged")
        }
        | {"watchlist_added": changes["watchlist"]["added"]},
        "signals": {"sources": sources, "collected": len(collected), "purged": purged},
        "warnings": warnings,
        "attribution": attribution,
    }
    _write_json(workspace / "reports" / "monitor-latest.json", summary)
    app.audit.record(
        "monitor.run",
        {
            "offline": offline,
            "online_sources": sorted(online),
            "statuses": {k: v["count"] for k, v in report["summary"]["by_status"].items()},
            "signals": {name: status["new"] for name, status in sources.items()},
            "changes": changes["counts"],
        },
    )
    return summary
