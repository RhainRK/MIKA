"""Turn flagged screening results into evidence-backed analyst cases.

The screening inputs are ingested as provenance-tracked evidence, then each finding is linked
to the exact ownership and watchlist rows that justify it. A reviewer opening the case sees
the source rows, their file digests and the reasoning, not just a status label.
"""

from __future__ import annotations

from collections.abc import Iterator, Mapping
from typing import Any

from ..app import MikaApp

_TITLE_STATUS = {"BLOCKED": "Blocked", "REVIEW": "Needs review", "CLEAR": "Clear"}

_ALTERNATIVES = {
    "listed": "The issuer may be a distinct party with a similar name; confirm identifiers.",
    "ownership": "Ownership records may be stale or incomplete; confirm against filings.",
    "possible": "Name similarity may be coincidental; obtain identifiers before escalating.",
    "unresolved": "The issuer may be absent from the entity master rather than unknown.",
}


def _edges(node: Mapping[str, Any]) -> Iterator[tuple[str, str]]:
    for edge in node.get("owners", []):
        owner = edge["node"]
        yield owner["entity_id"], node["entity_id"]
        yield from _edges(owner)


def _list_ids(node: Mapping[str, Any]) -> Iterator[str]:
    yield from node.get("list_ids", [])
    for edge in node.get("owners", []):
        yield from _list_ids(edge["node"])


def describe_chain(node: Mapping[str, Any]) -> list[str]:
    """Render an explanation tree as plain ownership sentences, listed parties first."""
    sentences: list[str] = []
    for edge in node.get("owners", []):
        owner = edge["node"]
        sentences.extend(describe_chain(owner))
        label = owner["name"]
        if owner.get("listed"):
            label += f" (listed {', '.join(owner['list_ids'])}; {', '.join(owner['programs'])})"
        sentences.append(f"{label} owns {edge['percent']:g}% of {node['name']}")
    return list(dict.fromkeys(sentences))


def _row_chunk(app: MikaApp, source_id: int, needle: str) -> int | None:
    row = app.db.conn.execute(
        "SELECT id FROM chunks WHERE source_id=? AND instr(content, ?) > 0 ORDER BY ordinal",
        (source_id, needle),
    ).fetchone()
    return int(row["id"]) if row else None


def _confidence(row: Mapping[str, Any]) -> tuple[float, str]:
    reasons = " ".join(row["reasons"])
    if row["status"] == "BLOCKED" and "issuer is listed" in reasons:
        matches = row["watchlist_matches"]
        return (float(matches[0]["score"]) if matches else 1.0), "listed"
    if row["status"] == "BLOCKED":
        return 0.95, "ownership"
    if row["entity"] is None:
        return 0.5, "unresolved"
    if "possible watchlist match" in reasons:
        return 0.5, "possible"
    return 0.6, "ownership"


def open_cases(
    app: MikaApp, report: Mapping[str, Any], *, statuses: tuple[str, ...] = ("BLOCKED", "REVIEW")
) -> list[dict[str, Any]]:
    sources = {
        name: app.evidence.ingest_path(report["inputs"][name]["path"])
        for name in ("ownership", "watchlist", "entities")
    }
    created: list[dict[str, Any]] = []
    for row in report["holdings"]:
        if row["status"] not in statuses:
            continue
        chunk_ids: list[int] = []
        tree = row.get("explanation") or {}
        if tree:
            for owner, owned in _edges(tree):
                needle = f"owner_id={owner} | owned_id={owned} |"
                chunk = _row_chunk(app, sources["ownership"].source_id, needle)
                if chunk is not None:
                    chunk_ids.append(chunk)
        list_ids = {*_list_ids(tree), *(hit["list_id"] for hit in row["watchlist_matches"])}
        for list_id in sorted(list_ids):
            chunk = _row_chunk(app, sources["watchlist"].source_id, f"list_id={list_id} |")
            if chunk is not None:
                chunk_ids.append(chunk)
        if row["entity"] is not None:
            needle = f"entity_id={row['entity']['entity_id']} |"
            chunk = _row_chunk(app, sources["entities"].source_id, needle)
            if chunk is not None:
                chunk_ids.append(chunk)

        confidence, kind = _confidence(row)
        case_id = app.cases.create(
            f"{_TITLE_STATUS[row['status']]}: {row['issuer']} ({row['holding_id']})",
            objective=(
                f"Confirm or clear sanctions exposure for holding {row['holding_id']} "
                f"(market value {row['market_value']:,.0f} USD)."
            ),
        )
        finding_id = app.cases.add_finding(
            case_id,
            ". ".join([*row["reasons"], *describe_chain(tree)]) + ".",
            confidence,
            evidence_chunk_ids=list(dict.fromkeys(chunk_ids)),
            alternatives=[_ALTERNATIVES[kind]],
            limitations=list(report.get("limitations", []))[:2],
        )
        created.append(
            {"holding_id": row["holding_id"], "case_id": case_id, "finding_id": finding_id}
        )
    return created
