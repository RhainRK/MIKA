"""Screen a portfolio for direct and ownership-derived sanctions exposure.

Pipeline:

1. Match every entity-master record (name and aliases) against the watchlist. Scores at or
   above ``block_match`` confirm a listing; scores between ``review_match`` and
   ``block_match`` are possible matches that need an analyst.
2. Propagate blocked status through the ownership graph (see ``ownership.py``).
3. Resolve each holding to the entity master, preferring an exact identifier (LEI) match.
4. Assign BLOCKED / REVIEW / CLEAR with human-readable reasons and an explanation tree.

Every threshold is explicit configuration and is written into the report, so a result can be
reproduced from the report alone plus the fingerprinted inputs.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import UTC, datetime
from time import perf_counter
from typing import Any

from ..entity_resolution import EntityRecord, EntityResolver, normalize_name
from .model import Entity, Holding, ScreeningInputs, WatchlistEntry
from .ownership import BlockingResult, propagate_blocking

REPORT_VERSION = "1.0"
STATUSES = ("BLOCKED", "REVIEW", "CLEAR")


@dataclass(frozen=True, slots=True)
class ScreeningConfig:
    block_match: float = 0.92
    review_match: float = 0.80
    issuer_match: float = 0.90
    ownership_threshold: float = 50.0
    review_share: float = 25.0
    max_explanation_depth: int = 8
    max_candidates: int = 50

    def __post_init__(self) -> None:
        if not 0.0 < self.review_match <= self.block_match <= 1.0:
            raise ValueError("require 0 < review_match <= block_match <= 1")
        if not 0.0 < self.issuer_match <= 1.0:
            raise ValueError("issuer_match must be in (0, 1]")
        if not 0.0 < self.review_share <= self.ownership_threshold <= 100.0:
            raise ValueError("require 0 < review_share <= ownership_threshold <= 100")
        if self.max_explanation_depth < 1 or self.max_candidates < 1:
            raise ValueError("max_explanation_depth and max_candidates must be positive")


@dataclass(frozen=True, slots=True)
class WatchlistHit:
    list_id: str
    name: str
    program: str
    matched_value: str
    entity_value: str
    score: float
    signals: tuple[str, ...]


class _EntityIndex:
    def __init__(self, entities: dict[str, Entity]) -> None:
        self._by_lei = {entity.lei: entity for entity in entities.values() if entity.lei}
        # Unambiguous normalized names resolve in O(1); ambiguous ones fall through to scoring.
        exact: dict[str, set[str]] = {}
        for entity in entities.values():
            for value in (entity.name, *entity.aliases):
                exact.setdefault(normalize_name(value), set()).add(entity.entity_id)
        self._exact = {
            key: entities[next(iter(ids))] for key, ids in exact.items() if key and len(ids) == 1
        }
        self._resolver = EntityResolver(
            EntityRecord(entity.entity_id, entity.name, entity.aliases, entity.entity_type)
            for entity in entities.values()
        )

    def match_watchlist(
        self, watchlist: tuple[WatchlistEntry, ...], config: ScreeningConfig
    ) -> dict[str, list[WatchlistHit]]:
        """Find entity-master records resembling each watchlist name or alias.

        Querying once per watchlist value (hundreds) against the entity index is far cheaper
        than querying once per entity (tens of thousands); the scorer is symmetric.
        """
        best: dict[str, dict[str, WatchlistHit]] = {}
        for entry in watchlist:
            for value in (entry.name, *entry.aliases):
                for match in self._resolver.resolve(
                    value,
                    threshold=config.review_match,
                    limit=config.max_candidates,
                    require_token_overlap=True,
                    max_candidates=config.max_candidates,
                ):
                    current = best.setdefault(match.entity_id, {}).get(entry.list_id)
                    if current is None or match.score > current.score:
                        best[match.entity_id][entry.list_id] = WatchlistHit(
                            entry.list_id,
                            entry.name,
                            entry.program,
                            value,
                            match.matched_value,
                            round(match.score, 4),
                            match.signals,
                        )
        return {
            entity_id: sorted(found.values(), key=lambda hit: (-hit.score, hit.list_id))
            for entity_id, found in best.items()
        }

    def resolve(self, holding: Holding, config: ScreeningConfig) -> dict[str, Any] | None:
        if holding.identifier and holding.identifier in self._by_lei:
            entity = self._by_lei[holding.identifier]
            return {
                "entity_id": entity.entity_id,
                "name": entity.name,
                "score": 1.0,
                "signals": ["identifier_exact"],
            }
        exact = self._exact.get(normalize_name(holding.issuer))
        if exact is not None:
            return {
                "entity_id": exact.entity_id,
                "name": exact.name,
                "score": 1.0,
                "signals": ["normalized_exact"],
            }
        matches = self._resolver.resolve(
            holding.issuer,
            threshold=config.issuer_match,
            limit=1,
            require_token_overlap=True,
            max_candidates=config.max_candidates,
        )
        if not matches:
            return None
        match = matches[0]
        return {
            "entity_id": match.entity_id,
            "name": match.name,
            "score": round(match.score, 4),
            "signals": list(match.signals),
        }


def _annotate(
    node: dict[str, Any],
    inputs: ScreeningInputs,
    confirmed: dict[str, list[WatchlistHit]],
) -> dict[str, Any]:
    entity = inputs.entities.get(node["entity_id"])
    hits = confirmed.get(node["entity_id"], [])
    return {
        **node,
        "name": entity.name if entity else node["entity_id"],
        "entity_type": entity.entity_type if entity else "unknown",
        "country": entity.country if entity else "",
        "programs": sorted({hit.program for hit in hits}),
        "list_ids": [hit.list_id for hit in hits],
        "owners": [
            {
                "percent": edge["percent"],
                "basis": edge.get("basis", ""),
                "node": _annotate(edge["node"], inputs, confirmed),
            }
            for edge in node["owners"]
        ],
    }


def _assess(
    entity_match: dict[str, Any] | None,
    blocking: BlockingResult,
    confirmed: dict[str, list[WatchlistHit]],
    possible: dict[str, list[WatchlistHit]],
    config: ScreeningConfig,
) -> tuple[str, list[str]]:
    if entity_match is None:
        return "REVIEW", ["issuer could not be resolved to the entity master; screen manually"]
    entity_id = entity_match["entity_id"]
    share = blocking.blocked_share.get(entity_id, 0.0)
    if entity_id in blocking.listed:
        return "BLOCKED", [
            f"issuer is listed: {hit.list_id} {hit.name} ({hit.program}), match {hit.score:.2f}"
            for hit in confirmed[entity_id]
        ]
    if entity_id in blocking.blocked:
        if blocking.consolidated_only(entity_id):
            return "BLOCKED", [
                "controlled by a blocked parent through accounting consolidation "
                "(ownership % not disclosed)"
            ]
        return "BLOCKED", [
            f"{share:g}% owned in aggregate by blocked parties "
            f"(threshold {config.ownership_threshold:g}%)"
        ]
    reasons: list[str] = [
        f"possible watchlist match: {hit.list_id} {hit.name} via {hit.entity_value!r}, "
        f"score {hit.score:.2f}"
        for hit in possible.get(entity_id, [])
    ]
    if share >= config.review_share:
        reasons.append(
            f"{share:g}% owned by blocked parties: below the "
            f"{config.ownership_threshold:g}% rule but material"
        )
    if reasons:
        return "REVIEW", reasons
    if share > 0:
        return "CLEAR", [f"minor blocked ownership of {share:g}% (below review threshold)"]
    return "CLEAR", []


def screen(inputs: ScreeningInputs, config: ScreeningConfig | None = None) -> dict[str, Any]:
    config = config or ScreeningConfig()
    timings: dict[str, float] = {}

    started = perf_counter()
    index = _EntityIndex(inputs.entities)
    all_hits = index.match_watchlist(inputs.watchlist, config)
    confirmed = {
        key: [hit for hit in hits if hit.score >= config.block_match]
        for key, hits in all_hits.items()
    }
    confirmed = {key: value for key, value in confirmed.items() if value}
    possible = {
        key: [hit for hit in hits if hit.score < config.block_match]
        for key, hits in all_hits.items()
        if key not in confirmed
    }
    timings["watchlist_matching_ms"] = (perf_counter() - started) * 1000

    started = perf_counter()
    blocking = propagate_blocking(confirmed, inputs.ownership, threshold=config.ownership_threshold)
    timings["ownership_propagation_ms"] = (perf_counter() - started) * 1000

    started = perf_counter()
    total_value = sum(holding.market_value for holding in inputs.holdings)
    rows: list[dict[str, Any]] = []
    for holding in inputs.holdings:
        entity_match = index.resolve(holding, config)
        status, reasons = _assess(entity_match, blocking, confirmed, possible, config)
        entity_id = entity_match["entity_id"] if entity_match else None
        explanation = None
        if entity_id is not None and (status != "CLEAR" or blocking.blocked_share.get(entity_id)):
            explanation = _annotate(
                blocking.tree(entity_id, max_depth=config.max_explanation_depth),
                inputs,
                confirmed,
            )
        rows.append(
            {
                "holding_id": holding.holding_id,
                "issuer": holding.issuer,
                "identifier": holding.identifier,
                "market_value": holding.market_value,
                "weight": holding.market_value / total_value if total_value else 0.0,
                "status": status,
                "reasons": reasons,
                "entity": entity_match,
                "watchlist_matches": [asdict(hit) for hit in all_hits.get(entity_id or "", [])],
                "blocked_share": blocking.blocked_share.get(entity_id or "", 0.0),
                "explanation": explanation,
            }
        )
    timings["holding_assessment_ms"] = (perf_counter() - started) * 1000

    by_status: dict[str, dict[str, float | int]] = {}
    for status in STATUSES:
        selected = [row for row in rows if row["status"] == status]
        value = sum(row["market_value"] for row in selected)
        by_status[status] = {
            "count": len(selected),
            "market_value": value,
            "weight": value / total_value if total_value else 0.0,
        }

    return {
        "report_version": REPORT_VERSION,
        "generated_at": datetime.now(UTC).isoformat(),
        "config": asdict(config),
        "inputs": {name: asdict(meta) for name, meta in inputs.files.items()},
        "summary": {
            "holdings": len(rows),
            "total_market_value": total_value,
            "by_status": by_status,
            "entities": len(inputs.entities),
            "ownership_links": len(inputs.ownership),
            "watchlist_entries": len(inputs.watchlist),
            "listed_entities": len(blocking.listed),
            "blocked_by_ownership": len(blocking.blocked - blocking.listed),
            "possible_matches": sum(1 for hits in possible.values() if hits),
            "data_issues": len(inputs.issues),
        },
        "holdings": rows,
        "data_issues": [asdict(item) for item in inputs.issues],
        "timing_ms": {key: round(value, 3) for key, value in timings.items()},
        "limitations": [
            "Not legal or compliance advice; a CLEAR result is not a guarantee.",
            "Fuzzy name matches are leads for analyst review, not determinations.",
            "Ownership data quality bounds result quality; unrecorded owners are invisible.",
            "Token blocking skips candidates whose every name token is misspelt.",
        ],
    }
