"""What-if designations and pre-trade checks. Pure functions: nothing is saved.

Both reuse the real engine, so a scenario follows exactly the same matching and 50% rule as the
monitor. A hypothetical designation is a synthetic watchlist entry; a pre-trade check is a
one-holding portfolio screened against the current lists and ownership data.
"""

from __future__ import annotations

from dataclasses import replace
from typing import Any

from ..changes import compare, snapshot
from .engine import ScreeningConfig, _EntityIndex, screen
from .model import Entity, Holding, ScreeningInputs, WatchlistEntry

MAX_NAMES = 20
MAX_NAME_LENGTH = 300
HYPOTHETICAL = "HYPOTHETICAL"


def _clean(name: str) -> str:
    value = " ".join(str(name).split())
    if not value:
        raise ValueError("A name is required.")
    if len(value) > MAX_NAME_LENGTH:
        raise ValueError(f"Names are limited to {MAX_NAME_LENGTH} characters.")
    return value


def what_if(
    inputs: ScreeningInputs, names: list[str], config: ScreeningConfig | None = None
) -> dict[str, Any]:
    """Screen the portfolio as if each named party were added to a sanctions list."""
    if not names or len(names) > MAX_NAMES:
        raise ValueError(f"Give between 1 and {MAX_NAMES} names.")
    cleaned = [_clean(name) for name in names]
    config = config or ScreeningConfig()
    extra = tuple(
        WatchlistEntry(f"WHATIF-{i}", name, (), HYPOTHETICAL) for i, name in enumerate(cleaned, 1)
    )
    baseline = screen(inputs, config)
    scenario = screen(replace(inputs, watchlist=inputs.watchlist + extra), config)
    hits = {
        hit["list_id"]
        for row in scenario["holdings"]
        for hit in row["watchlist_matches"]
        if hit["list_id"].startswith("WHATIF-")
    }
    # A hypothetical party may sit above the holdings (an owner), so check the entity register
    # directly rather than only the holdings' matches.
    index = _EntityIndex(inputs.entities)
    register_hits = index.match_watchlist(extra, config)
    matched = hits | {hit.list_id for found in register_hits.values() for hit in found}
    diff = compare(snapshot(baseline), snapshot(scenario))
    return {
        "hypothetical": cleaned,
        "unmatched": [entry.name for entry in extra if entry.list_id not in matched],
        "baseline": baseline["summary"]["by_status"],
        "scenario": scenario["summary"]["by_status"],
        **diff,
        "note": "Hypothetical scenario. Nothing was saved and no list was changed.",
    }


def pre_trade_check(
    inputs: ScreeningInputs,
    name: str,
    identifier: str = "",
    config: ScreeningConfig | None = None,
) -> dict[str, Any]:
    """Screen one company before it is bought, against the current lists and ownership data."""
    name = _clean(name)
    identifier = " ".join(str(identifier).split())[:64]
    config = config or ScreeningConfig()
    holding = Holding("CHECK", name, identifier, 1.0)
    entities = inputs.entities
    in_register = _EntityIndex(entities).resolve(holding, config) is not None
    if not in_register:
        # Not in the register yet: screen the name itself. Ownership is unknown for it.
        entities = {
            **entities,
            "CANDIDATE": Entity("CANDIDATE", name, (), "organisation", "", identifier),
        }
    report = screen(replace(inputs, holdings=(holding,), entities=entities), config)
    row = report["holdings"][0]
    notes = []
    if not in_register:
        notes.append(
            "Not in your entity register, so ownership could not be checked. Run `mika monitor` "
            "with gleif enabled after adding it, or add parents in data/ownership-overrides.csv."
        )
    return {
        "name": name,
        "identifier": identifier,
        "in_register": in_register,
        "status": row["status"],
        "reasons": row["reasons"],
        "entity": row["entity"],
        "watchlist_matches": row["watchlist_matches"],
        "blocked_share": row["blocked_share"],
        "explanation": row["explanation"],
        "notes": notes,
    }
