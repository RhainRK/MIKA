from __future__ import annotations

import argparse
import csv
import json
import sys
from collections.abc import Callable
from dataclasses import asdict
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from . import __version__
from .analyst import AnalystEngine
from .app import MikaApp
from .connectors import FetchError, SafeClient
from .evaluation import run_suite
from .llm import OllamaClient
from .policy import Policy
from .screening import ScreeningConfig, evaluate_labels, load_inputs, load_labels, screen
from .tools.base import ToolCall
from .tools.builtins import register_builtin_tools
from .tools.registry import ToolRegistry


def _json(value: object) -> None:
    print(json.dumps(value, indent=2, ensure_ascii=False, default=str))


def _add_evidence_filters(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("--source", action="append", type=int, dest="source_ids")
    parser.add_argument("--chunk", action="append", type=int, dest="chunk_ids")
    parser.add_argument("--case", dest="case_id")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mika", description="MIKA - Model Integrity & Knowledge Analysis"
    )
    parser.add_argument("--version", action="version", version=f"MIKA {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    sub.add_parser("doctor", help="Check local configuration and integrity")

    ingest = sub.add_parser("ingest", help="Ingest evidence with provenance")
    ingest.add_argument("path")

    sources = sub.add_parser("sources", help="List the source register")
    sources.add_argument("--trusted-only", action="store_true")

    source = sub.add_parser("source", help="Inspect one source and its chunks")
    source.add_argument("source_id", type=int)

    search = sub.add_parser("search", help="Hybrid search over trusted evidence")
    search.add_argument("query")
    search.add_argument("--k", type=int, default=6)
    _add_evidence_filters(search)

    ask = sub.add_parser("ask", help="Generate a grounded local-model analysis")
    ask.add_argument("query")
    ask.add_argument("--k", type=int, default=6)
    _add_evidence_filters(ask)

    case_create = sub.add_parser("case-create", help="Create an analysis case")
    case_create.add_argument("title")
    case_create.add_argument("--objective", default="")

    sub.add_parser("cases", help="List analysis cases")

    case_attach = sub.add_parser("case-attach", help="Attach evidence to a case")
    case_attach.add_argument("case_id")
    case_attach.add_argument("chunk_ids", nargs="+", type=int)

    finding = sub.add_parser("case-finding", help="Record a finding")
    finding.add_argument("case_id")
    finding.add_argument("statement")
    finding.add_argument("--confidence", required=True, type=float)
    finding.add_argument("--evidence", nargs="*", type=int, default=[])
    finding.add_argument("--alternative", action="append", default=[])
    finding.add_argument("--limitation", action="append", default=[])

    report = sub.add_parser("case-report", help="Export an evidence-backed briefing")
    report.add_argument("case_id")
    report.add_argument("--output", type=Path)

    backup = sub.add_parser("backup", aliases=["database-backup"], help="Create a database backup")
    backup.add_argument("--output", type=Path)

    evaluate = sub.add_parser("evaluate", help="Run retrieval/security/latency benchmarks")
    evaluate.add_argument("--output", type=Path, default=Path("reports/evaluation-results.json"))
    evaluate.add_argument("--repeats", type=int, default=20)

    sub.add_parser("audit-verify", help="Verify the audit hash chain")

    tools = sub.add_parser("tools", help="List tools allowed for a role")
    tools.add_argument("--role", choices=["viewer", "analyst", "reviewer"], default="analyst")

    tool_run = sub.add_parser("tool-run", help="Execute a typed tool through policy enforcement")
    tool_run.add_argument("name")
    tool_run.add_argument("--args", default="{}", help="JSON object containing tool arguments")
    tool_run.add_argument("--role", choices=["viewer", "analyst", "reviewer"], default="analyst")

    resolve = sub.add_parser("entity-resolve", help="Resolve an entity against a workspace CSV")
    resolve.add_argument("path")
    resolve.add_argument("query")
    resolve.add_argument("--threshold", type=float, default=0.82)
    resolve.add_argument("--limit", type=int, default=10)

    graph = sub.add_parser("graph-path", help="Trace a relationship path through a CSV edge list")
    graph.add_argument("path")
    graph.add_argument("source")
    graph.add_argument("target")
    graph.add_argument("--max-depth", type=int, default=6)

    profile = sub.add_parser("profile", help="Profile CSV data quality")
    profile.add_argument("path")

    portfolio = sub.add_parser("portfolio", help="Manage the portfolio MIKA monitors")
    portfolio.add_argument("action", choices=["import"])
    portfolio.add_argument(
        "path", help="CSV with issuer, market_value_usd[, holding_id, identifier]"
    )

    monitor = sub.add_parser(
        "monitor", help="Refresh public data, screen the portfolio and collect signals"
    )
    monitor.add_argument(
        "--offline", action="store_true", help="Use only local data; make no network requests"
    )

    watch = sub.add_parser("watch", help="Run the monitor on a schedule until stopped (Ctrl+C)")
    watch.add_argument(
        "--every", default="6h", help="Interval such as 30m, 6h or 1d (minimum 15m; default 6h)"
    )
    watch.add_argument("--offline", action="store_true", help="Use only local data")
    watch.add_argument("--runs", type=int, default=0, help=argparse.SUPPRESS)

    sub.add_parser("changes", help="Show what changed since the previous monitor run")

    whatif = sub.add_parser(
        "whatif", help="Screen the portfolio as if the named parties were sanctioned"
    )
    whatif.add_argument("names", nargs="+", help="One or more company or person names")

    check = sub.add_parser("check", help="Pre-trade check: screen a company before buying it")
    check.add_argument("name", help="Company name")
    check.add_argument("--identifier", default="", help="LEI, ticker or ISIN, if known")

    feeds = sub.add_parser("feeds", help="Check data source configuration")
    feeds.add_argument("action", choices=["check"])

    sync = sub.add_parser("sync", help="Download public data used by screening")
    sync.add_argument("what", choices=["sanctions"], help="sanctions: OFAC SDN + UK list")
    sync.add_argument("--force", action="store_true", help="Ignore the 24-hour freshness window")

    screening = sub.add_parser(
        "screen", help="Screen a portfolio for sanctions and ownership-derived exposure"
    )
    screening.add_argument(
        "--dir",
        type=Path,
        help="Folder holding holdings.csv, entities.csv, ownership.csv and watchlist.csv",
    )
    for name in ("holdings", "entities", "ownership", "watchlist"):
        screening.add_argument(f"--{name}", help=f"{name} CSV (overrides --dir)")
    screening.add_argument("--labels", help="Expected-status CSV to score the run against")
    screening.add_argument("--output", type=Path, default=Path("reports/screening-latest.json"))
    screening.add_argument(
        "--create-cases", action="store_true", help="Open an evidence-backed case per flag"
    )
    screening.add_argument("--ownership-threshold", type=float, default=50.0)
    screening.add_argument("--review-share", type=float, default=25.0)

    serve = sub.add_parser("serve", help="Run the analyst API and TypeScript console")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8000)
    return parser


def _registry(app: MikaApp, role: str) -> ToolRegistry:
    registry = ToolRegistry(Policy.for_role(role), app.audit)
    register_builtin_tools(
        registry,
        retriever=app.retriever,
        workspace=app.settings.workspace,
        cases=app.cases,
    )
    return registry


def _run_tool(app: MikaApp, name: str, arguments: dict[str, Any], *, role: str = "analyst") -> int:
    result = _registry(app, role).execute(ToolCall(name, arguments))
    _json(
        {
            "name": result.name,
            "success": result.success,
            "output": result.output,
            "error": result.error,
        }
    )
    return 0 if result.success else 1


def _workspace_output(app: MikaApp, requested: Path, label: str) -> Path:
    candidate = requested.expanduser()
    if not candidate.is_absolute():
        candidate = app.settings.workspace / candidate
    target = candidate.resolve()
    try:
        relative = target.relative_to(app.settings.workspace)
    except ValueError:
        raise SystemExit(f"{label} output must remain inside the MIKA workspace") from None
    cursor = app.settings.workspace
    for part in relative.parts:
        if part.startswith(".") or ":" in part or part.endswith((".", " ")):
            raise SystemExit(f"{label} output contains a forbidden path component")
        cursor = cursor / part
        if cursor.exists() and cursor.is_symlink():
            raise SystemExit(f"{label} output cannot traverse symbolic links")
    return target


def _backup_path(app: MikaApp, requested: Path | None) -> Path:
    if requested is None:
        stamp = datetime.now(UTC).strftime("%Y%m%dT%H%M%SZ")
        requested = Path("data/backups") / f"mika-{stamp}.sqlite3"
    return _workspace_output(app, requested, "Backup")


def _screen(app: MikaApp, args: argparse.Namespace) -> int:
    from .screening.cases import open_cases

    output = _workspace_output(app, args.output, "Screening")
    paths: dict[str, str] = {}
    for name in ("holdings", "entities", "ownership", "watchlist"):
        explicit = getattr(args, name)
        if explicit is None and args.dir is None:
            raise SystemExit(f"Provide --dir or --{name}")
        paths[name] = explicit or str(args.dir / f"{name}.csv")
    try:
        config = ScreeningConfig(
            ownership_threshold=args.ownership_threshold, review_share=args.review_share
        )
        report = screen(load_inputs(app.settings.workspace, **paths), config)
        if args.labels:
            report["evaluation"] = evaluate_labels(
                report, load_labels(app.settings.workspace, args.labels)
            )
    except ValueError as exc:
        raise SystemExit(f"Screening failed: {exc}") from None
    if args.create_cases:
        report["cases"] = open_cases(app, report)
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    app.audit.record(
        "screening.run",
        {
            "inputs": {name: meta["sha256"] for name, meta in report["inputs"].items()},
            "statuses": {k: v["count"] for k, v in report["summary"]["by_status"].items()},
            "cases_opened": len(report.get("cases", [])),
            "output": output.relative_to(app.settings.workspace).as_posix(),
        },
    )
    summary = dict(report["summary"]) | {
        "output": output.relative_to(app.settings.workspace).as_posix()
    }
    if "evaluation" in report:
        summary["evaluation"] = {
            key: report["evaluation"][key] for key in ("accuracy", "blocked", "flagged")
        }
    if "cases" in report:
        summary["cases_opened"] = len(report["cases"])
    _json(summary)
    return 0


def _doctor(app: MikaApp, args: argparse.Namespace) -> int:
    valid, records, error = app.audit.verify()
    _json(
        {
            "version": __version__,
            "database": str(app.settings.db_path),
            "database_schema": int(app.db.conn.execute("PRAGMA user_version").fetchone()[0]),
            "workspace": str(app.settings.workspace),
            "fts5": app.db.fts_enabled,
            "embedding_backend": app.embedder.backend,
            "embedding_identity": app.embedder.identity,
            "embedding_fallback_error": app.embedder.load_error,
            "audit_chain_valid": valid,
            "audit_records": records,
            "audit_error": error,
        }
    )
    return 0


def _ingest(app: MikaApp, args: argparse.Namespace) -> int:
    try:
        result = app.evidence.ingest_path(args.path)
    except (ValueError, RecursionError, UnicodeDecodeError, csv.Error) as exc:
        raise SystemExit(f"Could not ingest {args.path}: {type(exc).__name__}: {exc}") from None
    app.audit.record("evidence.ingest", asdict(result))
    _json(asdict(result))
    return 0


def _sources(app: MikaApp, args: argparse.Namespace) -> int:
    _json(app.evidence.list_sources(include_quarantined=not args.trusted_only))
    return 0


def _source(app: MikaApp, args: argparse.Namespace) -> int:
    _json(app.evidence.get_source(args.source_id))
    return 0


def _search(app: MikaApp, args: argparse.Namespace) -> int:
    _json(
        app.search(
            args.query,
            args.k,
            source_ids=args.source_ids,
            chunk_ids=args.chunk_ids,
            case_id=args.case_id,
        )
    )
    return 0


def _ask(app: MikaApp, args: argparse.Namespace) -> int:
    selected = app.scope_chunks(args.case_id, args.chunk_ids)
    llm = OllamaClient(
        app.settings.ollama_url, app.settings.ollama_model, app.settings.request_timeout
    )
    try:
        engine = AnalystEngine(app.retriever, llm, app.telemetry, app.cases)
        result = engine.answer(
            args.query, args.k, source_ids=args.source_ids, chunk_ids=selected, case_id=args.case_id
        )
        _json(asdict(result))
    finally:
        llm.close()
    return 0


def _case_create(app: MikaApp, args: argparse.Namespace) -> int:
    case_id = app.cases.create(args.title, args.objective)
    app.audit.record("case.create", {"case_id": case_id, "title": args.title})
    _json({"case_id": case_id})
    return 0


def _cases(app: MikaApp, args: argparse.Namespace) -> int:
    _json(app.cases.list_cases())
    return 0


def _case_attach(app: MikaApp, args: argparse.Namespace) -> int:
    app.cases.attach_evidence(args.case_id, args.chunk_ids)
    app.audit.record("case.attach_evidence", {"case_id": args.case_id, "chunk_ids": args.chunk_ids})
    _json({"case_id": args.case_id, "attached": args.chunk_ids})
    return 0


def _case_finding(app: MikaApp, args: argparse.Namespace) -> int:
    finding_id = app.cases.add_finding(
        args.case_id,
        args.statement,
        args.confidence,
        evidence_chunk_ids=args.evidence,
        alternatives=args.alternative,
        limitations=args.limitation,
    )
    app.audit.record("case.add_finding", {"case_id": args.case_id, "finding_id": finding_id})
    _json({"finding_id": finding_id})
    return 0


def _case_report(app: MikaApp, args: argparse.Namespace) -> int:
    markdown = app.cases.report_markdown(args.case_id)
    if args.output:
        output = _workspace_output(app, args.output, "Report")
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(markdown, encoding="utf-8")
        _json({"output": output.relative_to(app.settings.workspace).as_posix()})
    else:
        print(markdown)
    return 0


def _backup(app: MikaApp, args: argparse.Namespace) -> int:
    saved = app.db.backup_to(_backup_path(app, args.output))
    app.audit.record("database.backup", {"destination": str(saved)})
    _json({"output": str(saved)})
    return 0


def _audit_verify(app: MikaApp, args: argparse.Namespace) -> int:
    valid, records, error = app.audit.verify()
    _json({"valid": valid, "records": records, "error": error})
    return 0 if valid else 1


def _tools(app: MikaApp, args: argparse.Namespace) -> int:
    names = [item["function"]["name"] for item in _registry(app, args.role).schemas()]
    _json({"role": args.role, "tools": names})
    return 0


def _tool_run(app: MikaApp, args: argparse.Namespace) -> int:
    try:
        payload = json.loads(args.args)
    except json.JSONDecodeError as exc:
        raise SystemExit(f"Invalid --args JSON: {exc}") from exc
    if not isinstance(payload, dict):
        raise SystemExit("--args must decode to a JSON object")
    return _run_tool(app, args.name, payload, role=args.role)


def _entity_resolve(app: MikaApp, args: argparse.Namespace) -> int:
    arguments = {
        "path": args.path,
        "query": args.query,
        "threshold": args.threshold,
        "limit": args.limit,
    }
    return _run_tool(app, "entity.resolve", arguments, role="viewer")


def _graph_path(app: MikaApp, args: argparse.Namespace) -> int:
    arguments = {
        "path": args.path,
        "source": args.source,
        "target": args.target,
        "max_depth": args.max_depth,
    }
    return _run_tool(app, "graph.shortest_path", arguments, role="viewer")


def _profile(app: MikaApp, args: argparse.Namespace) -> int:
    return _run_tool(app, "dataset.profile", {"path": args.path}, role="viewer")


def _sync(app: MikaApp, args: argparse.Namespace) -> int:
    from .sanctions import sync_sanctions

    try:
        summary = sync_sanctions(SafeClient(), app.settings.workspace, force=args.force)
    except (RuntimeError, FetchError) as exc:
        raise SystemExit(str(exc)) from None
    if not summary["skipped"]:
        app.audit.record(
            "sanctions.sync",
            {
                name: {key: meta.get(key) for key in ("status", "entries", "sha256")}
                for name, meta in summary["sources"].items()
            },
        )
    _json(summary)
    return 0 if all(m.get("status") != "unavailable" for m in summary["sources"].values()) else 1


def _portfolio(app: MikaApp, args: argparse.Namespace) -> int:
    from .portfolio import import_holdings

    try:
        result = import_holdings(app.settings.workspace, args.path)
    except ValueError as exc:
        raise SystemExit(f"Could not import portfolio: {exc}") from None
    app.audit.record(
        "portfolio.import",
        {"holdings": result["holdings"], "issues": len(result["issues"])},
    )
    _json(result)
    return 0


def _monitor(app: MikaApp, args: argparse.Namespace) -> int:
    from .monitor import run_monitor

    try:
        summary = run_monitor(app, SafeClient(), offline=args.offline)
    except ValueError as exc:
        raise SystemExit(str(exc)) from None
    _json(summary)
    return 0


_UNITS = {"m": 60, "h": 3600, "d": 86400}


def parse_interval(value: str) -> int:
    """'30m', '6h' or '1d' as seconds; at least 15 minutes so sources are not hammered."""
    text = value.strip().lower()
    if len(text) < 2 or text[-1] not in _UNITS or not text[:-1].isdigit():
        raise SystemExit("Use an interval such as 30m, 6h or 1d.")
    seconds = int(text[:-1]) * _UNITS[text[-1]]
    if not 900 <= seconds <= 7 * 86400:
        raise SystemExit("The interval must be between 15m and 7d.")
    return seconds


def _watch(app: MikaApp, args: argparse.Namespace) -> int:
    import time

    from .monitor import run_monitor

    interval = parse_interval(args.every)
    client = SafeClient()
    done = 0
    print(f"Watching: monitor runs every {args.every}. Press Ctrl+C to stop.", flush=True)
    try:
        while True:
            try:
                summary = run_monitor(app, client, offline=args.offline)
                changes = summary["changes"]
                counts = changes["counts"]
                print(
                    f"{summary['generated_at']}: {counts['worse']} worse, {counts['new']} new, "
                    f"{counts['better']} better, {changes['watchlist_added']} list entries added",
                    flush=True,
                )
            except ValueError as exc:
                raise SystemExit(str(exc)) from None
            except (OSError, RuntimeError) as exc:
                # One failed run (network down, file locked) must not stop the watch.
                print(f"Run failed, retrying next interval: {str(exc)[:200]}", flush=True)
            done += 1
            if args.runs and done >= args.runs:
                return 0
            time.sleep(interval)
    except KeyboardInterrupt:
        print("Stopped.", flush=True)
        return 0


def _changes(app: MikaApp, args: argparse.Namespace) -> int:
    from .changes import latest_changes

    result = latest_changes(app.settings.workspace)
    if result is None:
        raise SystemExit("No monitor runs recorded yet. Run: mika monitor")
    _json(result)
    return 0


def _screening_inputs(app: MikaApp) -> Any:
    from .screening import load_inputs

    workspace = app.settings.workspace
    folder = workspace / "data" / "screening"
    if (
        not (folder / "entities.csv").exists()
        or not (workspace / "data" / "watchlist.csv").exists()
    ):
        raise SystemExit("Run `mika monitor` first so the lists and entity register exist.")
    return load_inputs(
        workspace,
        holdings="data/screening/holdings.csv",
        entities="data/screening/entities.csv",
        ownership="data/screening/ownership.csv",
        watchlist="data/watchlist.csv",
    )


def _whatif(app: MikaApp, args: argparse.Namespace) -> int:
    from .screening.scenarios import what_if

    try:
        result = what_if(_screening_inputs(app), args.names)
    except ValueError as exc:
        raise SystemExit(str(exc)) from None
    app.audit.record(
        "scenario.what_if",
        {"names": len(result["hypothetical"]), "changes": result["counts"]},
    )
    _json(result)
    return 0


def _check(app: MikaApp, args: argparse.Namespace) -> int:
    from .screening.scenarios import pre_trade_check

    try:
        result = pre_trade_check(_screening_inputs(app), args.name, args.identifier)
    except ValueError as exc:
        raise SystemExit(str(exc)) from None
    app.audit.record("scenario.pre_trade_check", {"status": result["status"]})
    _json(result)
    return 0 if result["status"] == "CLEAR" else 2


def _feeds(app: MikaApp, args: argparse.Namespace) -> int:
    from .feeds import check_feeds

    result = check_feeds(app.settings, SafeClient())
    _json(result)
    return 0 if all(not v.startswith("failed") for v in result["results"].values()) else 1


_HANDLERS: dict[str, Callable[[MikaApp, argparse.Namespace], int]] = {
    "doctor": _doctor,
    "ingest": _ingest,
    "sources": _sources,
    "source": _source,
    "search": _search,
    "ask": _ask,
    "case-create": _case_create,
    "cases": _cases,
    "case-attach": _case_attach,
    "case-finding": _case_finding,
    "case-report": _case_report,
    "backup": _backup,
    "database-backup": _backup,
    "screen": _screen,
    "sync": _sync,
    "portfolio": _portfolio,
    "monitor": _monitor,
    "feeds": _feeds,
    "watch": _watch,
    "changes": _changes,
    "whatif": _whatif,
    "check": _check,
    "audit-verify": _audit_verify,
    "tools": _tools,
    "tool-run": _tool_run,
    "entity-resolve": _entity_resolve,
    "graph-path": _graph_path,
    "profile": _profile,
}


def _evaluate(root: Path, args: argparse.Namespace) -> int:
    report = run_suite(root, args.output.resolve(), repeats=args.repeats)
    _json(report)
    return 0 if report["status"] == "passed" else 1


def _serve(root: Path, args: argparse.Namespace) -> int:
    try:
        import uvicorn
    except ImportError as exc:
        raise SystemExit('Install the server extra with: pip install -e ".[server]"') from exc
    if args.host not in {"127.0.0.1", "::1"}:
        raise SystemExit("MIKA only serves on 127.0.0.1 or ::1")
    import secrets

    from .api import create_app

    password = secrets.token_urlsafe(32)
    print("Local browser login: username mika", flush=True)
    print(f"Session password: {password}", flush=True)
    uvicorn.run(
        create_app(password=password),
        host=args.host,
        port=args.port,
        reload=False,
        proxy_headers=False,
        access_log=False,
        limit_concurrency=16,
        timeout_keep_alive=5,
        server_header=False,
        h11_max_incomplete_event_size=16384,
    )
    return 0


# Commands that run without opening the workspace database.
_STANDALONE: dict[str, Callable[[Path, argparse.Namespace], int]] = {
    "evaluate": _evaluate,
    "serve": _serve,
}


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if standalone := _STANDALONE.get(args.command):
        return standalone(Path(__file__).resolve().parents[1], args)
    app = MikaApp()
    try:
        return _HANDLERS[args.command](app, args)
    finally:
        app.close()


if __name__ == "__main__":
    sys.exit(main())
