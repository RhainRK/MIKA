# MIKA 2.2 setup on Windows

MIKA watches a real investment portfolio for sanctions exposure, including exposure through
ownership chains, and for news, filings and posts about your holdings. Python runs a local server
and your browser shows the dashboard. No hosting account is needed, and the dashboard comes
pre-built, so you only need Node.js if you want to change the interface.

## 1. Install

Install Python 3.13 or newer. Extract the ZIP into a writable folder such as `C:\MIKA`, then open
PowerShell in the folder that contains `pyproject.toml`.

```powershell
py -3.13 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools
.\.venv\Scripts\python.exe -m pip install -e ".[server]"
.\.venv\Scripts\mika.exe --version
```

The expected version is 2.2.0. If you installed a newer Python, replace `-3.13` with your version.

## 2. Import your portfolio

Export your holdings as a CSV with at least these two columns. `holding_id` and `identifier` (an
LEI, ticker or ISIN) are optional, but an LEI gives the most accurate ownership results.

```text
issuer,identifier,market_value_usd
Apple Inc.,HWUPKR0MPOU8FGXBT394,1250000
```

```powershell
.\.venv\Scripts\mika.exe portfolio import "C:\path\to\my-portfolio.csv"
```

The file must be inside the MIKA folder. MIKA reports any rows it skipped and why.

## 3. Choose your data sources

Copy `.env.example` to `.env` and edit it in Notepad. Sanctions lists always download, because
downloading a public list reveals nothing about you. Every other source reveals which companies
you hold, so it stays off until you list it:

```text
MIKA_ONLINE_SOURCES=gleif,sec,gdelt
MIKA_CONTACT_EMAIL=you@example.com
```

- **gleif:** official company identifiers and parent companies. No account needed.
- **sec:** US tickers and 8-K filings. Needs `MIKA_CONTACT_EMAIL`, as the SEC requires.
- **gdelt:** worldwide news. No account needed.
- **reddit:** needs an approved Reddit API app (`MIKA_REDDIT_CLIENT_ID`, `MIKA_REDDIT_CLIENT_SECRET`
  and `MIKA_REDDIT_USERNAME`). Reddit must approve your access before you use it.
- **x:** needs a paid X API bearer token (`MIKA_X_BEARER_TOKEN`). `MIKA_X_MAX_POSTS` caps how
  many posts MIKA reads, and so what you pay, on each run.

Check that everything you enabled is reachable:

```powershell
.\.venv\Scripts\mika.exe feeds check
```

## 4. Run the monitor

```powershell
.\.venv\Scripts\mika.exe monitor
```

This refreshes the sanctions lists (at most once a day), looks up your holdings, screens them and
collects signals. Run it whenever you want fresh results. To use only the data already on your
computer, add `--offline`.

To keep watching, leave this running instead; it reruns the monitor every six hours:

```powershell
.\.venv\Scripts\mika.exe watch --every 6h
```

Each run is compared with the previous one. See what changed, test a "what if", or screen a
company before buying it:

```powershell
.\.venv\Scripts\mika.exe changes
.\.venv\Scripts\mika.exe whatif "Example Parent Holdings"
.\.venv\Scripts\mika.exe check "Example Shipping Group"
```

## 5. Open the dashboard

```powershell
.\.venv\Scripts\mika.exe serve --host 127.0.0.1 --port 8000
```

Keep the terminal open and visit http://127.0.0.1:8000. Sign in as `mika` with the password the
server printed. You can also double-click `START_MIKA.bat`. Stop the server with Ctrl+C.

- **Exposure:** the moon shows the share of portfolio value that needs attention. "Since the last
  run" lists what changed; select a change to open that holding. Select a holding
  to see why it was flagged, its ownership chain and its recent signals. Use the arrow keys to move
  through the list.
- **Signals:** news, filings and posts ranked by risk, each listing the words that flagged it.
  Plain mentions are hidden until you choose to show them.
- **Evidence:** search every imported file.
- **Cases:** findings with the exact source rows they cite, and downloadable reports.
- **System:** workspace health, data-source status and the regression results.

## 6. Upgrade safely

Stop the old server and keep a copy of the old folder, especially `data` and your `.env`.
Extract this release into a new folder, create a fresh virtual environment, copy `data` and
`.env` across, then run `mika monitor`. Version 2.2 needs no database change; it starts its run
history with that first run.

## 7. Edit the dashboard (optional)

You need Node.js 22 or newer.

```powershell
cd dashboard
npm.cmd ci --ignore-scripts
npm.cmd run typecheck
npm.cmd run build
npm.cmd test
cd ..
```

## Troubleshooting

- **"No portfolio imported yet":** run step 2.
- **A source shows "failed" in `feeds check`:** check your internet connection and the settings in
  `.env`. Every other source keeps working.
- **"rate limiting" for GDELT:** GDELT allows one request every few seconds, and MIKA waits for
  you. If GDELT still refuses, the monitor stops querying it for that run and reports it as
  throttled.
- **Cannot open the page:** check the server terminal is still running.
- **Login fails:** use the password from the terminal that is currently running.

MIKA serves only this computer. Evidence, caches and backups are not encrypted by MIKA.
