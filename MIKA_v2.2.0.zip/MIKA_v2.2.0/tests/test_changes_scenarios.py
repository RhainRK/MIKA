"""Run history, change detection, what-if designations and pre-trade checks (2.2.0)."""

import json
from datetime import UTC, datetime, timedelta
from pathlib import Path

import pytest

from mika.changes import compare, history, latest_changes, record_run, snapshot
from mika.screening import load_inputs, screen
from mika.screening.model import WatchlistEntry
from mika.screening.scenarios import pre_trade_check, what_if

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "samples" / "screening"
T0 = datetime(2026, 10, 1, 6, 0, tzinfo=UTC)


def _inputs():
    return load_inputs(
        FIXTURES,
        holdings="holdings.csv",
        entities="entities.csv",
        ownership="ownership.csv",
        watchlist="watchlist.csv",
    )


def _report(status: str, value: float = 100.0, matches=(), holding_id="H1", issuer="Acme"):
    return {
        "generated_at": "2026-10-01T06:00:00+00:00",
        "summary": {
            "total_market_value": value,
            "by_status": {
                s: {"count": int(s == status), "market_value": value if s == status else 0.0}
                for s in ("BLOCKED", "REVIEW", "CLEAR")
            },
        },
        "holdings": [
            {
                "holding_id": holding_id,
                "issuer": issuer,
                "status": status,
                "market_value": value,
                "reasons": [f"reason for {status}"],
                "watchlist_matches": [{"list_id": item} for item in matches],
            }
        ],
    }


def test_compare_reports_worse_better_new_removed_and_evidence_changes():
    before = snapshot(_report("CLEAR"))
    after = snapshot(_report("BLOCKED", matches=["OFAC-1"]))
    result = compare(before, after)
    [change] = result["changes"]
    assert (change["from"], change["to"], change["direction"]) == ("CLEAR", "BLOCKED", "worse")
    assert change["new_matches"] == ["OFAC-1"]
    assert result["value_newly_flagged"] == 100.0
    assert compare(after, before)["changes"][0]["direction"] == "better"

    evidence = compare(after, snapshot(_report("BLOCKED", matches=["OFAC-1", "UK-2"])))
    assert evidence["changes"][0]["direction"] == "evidence"
    assert evidence["changes"][0]["new_matches"] == ["UK-2"]

    other = snapshot(_report("REVIEW", holding_id="H2", issuer="Beta"))
    moved = compare(before, other)
    assert {c["direction"] for c in moved["changes"]} == {"new", "removed"}
    assert moved["value_newly_flagged"] == 100.0
    # Unchanged CLEAR holdings produce no noise.
    assert compare(before, before)["changes"] == []


def test_record_run_tracks_history_watchlist_diff_and_first_run(tmp_path):
    entries = (WatchlistEntry("OFAC-1", "Old Co", (), "SDGT"),)
    first = record_run(tmp_path, _report("CLEAR"), entries, now=T0)
    assert first["first_run"] is True
    # Nor every holding as "new": there is nothing to compare with yet.
    assert first["changes"] == [] and sum(first["counts"].values()) == 0
    # The first run must not report the whole list as "added".
    assert first["watchlist"] == {"added": 0, "removed": 0, "added_examples": []}

    entries += (WatchlistEntry("OFAC-2", "New Designee", (), "RUSSIA-EO14024"),)
    second = record_run(
        tmp_path, _report("BLOCKED", matches=["OFAC-2"]), entries, now=T0 + timedelta(hours=6)
    )
    assert second["first_run"] is False
    assert second["since"] == T0.isoformat()
    assert second["watchlist"]["added"] == 1
    assert second["watchlist"]["added_examples"] == [
        {
            "list_id": "OFAC-2",
            "name": "New Designee",
            "program": "RUSSIA-EO14024",
            "affects": ["H1"],
        }
    ]
    assert latest_changes(tmp_path) == second
    rows = history(tmp_path)
    assert [row["flagged_value"] for row in rows] == [0.0, 100.0]
    assert rows[-1]["generated_at"] == (T0 + timedelta(hours=6)).isoformat()


def test_record_run_prunes_old_snapshots(tmp_path):
    for i in range(5):
        record_run(tmp_path, _report("CLEAR"), (), now=T0 + timedelta(minutes=i), keep=3)
    assert len(list((tmp_path / "reports" / "runs").glob("run-*.json"))) == 3
    assert len(history(tmp_path)) == 3


def test_history_skips_corrupt_snapshots(tmp_path):
    record_run(tmp_path, _report("CLEAR"), (), now=T0)
    (tmp_path / "reports" / "runs" / "run-29990101T000000000000Z.json").write_text("{", "utf-8")
    assert len(history(tmp_path)) == 1
    # A corrupt latest snapshot is treated as no previous run rather than crashing the monitor.
    result = record_run(tmp_path, _report("CLEAR"), (), now=T0 + timedelta(hours=1))
    assert result["first_run"] is False


def test_what_if_propagates_a_hypothetical_designation_through_ownership():
    inputs = _inputs()
    baseline = {row["holding_id"]: row["status"] for row in screen(inputs)["holdings"]}
    result = what_if(inputs, ["Tarnweld Mining Corp"])
    assert result["unmatched"] == []
    changed = {c["holding_id"]: c for c in result["changes"]}
    # Tarnweld (E009) becomes blocked, and Calvetra (60% owned by Tarnweld) with it.
    worse = {hid for hid, c in changed.items() if c["direction"] == "worse"}
    assert worse, "a hypothetical designation of an owner must flag what it owns"
    assert all(baseline[hid] != "BLOCKED" for hid in worse)
    assert all(changed[hid]["to"] == "BLOCKED" for hid in worse)
    assert result["value_newly_flagged"] > 0
    # Nothing is persisted and the real inputs are untouched.
    assert len(inputs.watchlist) == len(_inputs().watchlist)


def test_what_if_reports_names_that_match_nothing_in_the_register():
    result = what_if(_inputs(), ["Completely Unknown Widget Company"])
    assert result["unmatched"] == ["Completely Unknown Widget Company"]
    assert result["changes"] == []


@pytest.mark.parametrize("names", [[], [""], ["x" * 301], ["a"] * 21])
def test_what_if_rejects_bad_names(names):
    with pytest.raises(ValueError):
        what_if(_inputs(), names)


def test_pre_trade_check_screens_a_company_not_in_the_portfolio():
    listed = pre_trade_check(_inputs(), "Zarvek Maritime Holdings")
    assert listed["status"] == "BLOCKED"
    owned = pre_trade_check(_inputs(), "Ostvane Port Logistics")
    assert owned["status"] == "BLOCKED"
    assert owned["explanation"] is not None
    unknown = pre_trade_check(_inputs(), "Brightwater Bakery Cooperative")
    assert unknown["status"] == "CLEAR"
    assert unknown["in_register"] is False
    with pytest.raises(ValueError):
        pre_trade_check(_inputs(), "   ")


def test_monitor_records_changes(tmp_path):
    from mika.connectors.http import SafeClient
    from mika.monitor import run_monitor
    from tests.test_monitor import Routes, _app, _portfolio, _settings

    _portfolio(tmp_path)
    app = _app(_settings(tmp_path))
    client = SafeClient(transport=Routes(), sleep=lambda _: None)
    try:
        first = run_monitor(app, client, now=T0)
        second = run_monitor(app, client, offline=True, now=T0 + timedelta(hours=1))
    finally:
        app.close()
    assert first["changes"]["first_run"] is True
    assert second["changes"]["first_run"] is False
    saved = json.loads((tmp_path / "reports" / "changes-latest.json").read_text("utf-8"))
    assert saved["since"] == T0.isoformat()


@pytest.mark.parametrize(
    ("value", "seconds"), [("15m", 900), ("6h", 21600), ("1d", 86400), (" 2H ", 7200)]
)
def test_parse_interval(value, seconds):
    from mika.cli import parse_interval

    assert parse_interval(value) == seconds


@pytest.mark.parametrize("value", ["5m", "8d", "h", "-1h", "1.5h", "6x", ""])
def test_parse_interval_rejects_unsafe_or_bad_values(value):
    from mika.cli import parse_interval

    with pytest.raises(SystemExit):
        parse_interval(value)


def test_cli_and_api_expose_changes_whatif_and_check(tmp_path, monkeypatch, capsys):
    from fastapi.testclient import TestClient

    import mika.cli as cli
    from mika.api import create_app
    from mika.connectors.http import SafeClient
    from mika.monitor import run_monitor
    from tests.test_monitor import Routes, _app, _portfolio, _settings

    _portfolio(tmp_path)
    config = _settings(tmp_path)
    app = _app(config)
    try:
        run_monitor(app, SafeClient(transport=Routes(), sleep=lambda _: None), now=T0)
    finally:
        app.close()

    monkeypatch.setattr(cli, "MikaApp", lambda: _app(config))
    assert cli.main(["changes"]) == 0
    assert json.loads(capsys.readouterr().out)["first_run"] is True
    assert cli.main(["whatif", "Feldmarr Freight Services"]) == 0
    assert "hypothetical" in json.loads(capsys.readouterr().out)
    assert cli.main(["check", "Zarvek Maritime Holdings"]) == 2
    assert json.loads(capsys.readouterr().out)["status"] == "BLOCKED"
    with pytest.raises(SystemExit):
        cli.main(["whatif", " "])

    password = "pw-for-tests"
    import base64

    auth = {"Authorization": "Basic " + base64.b64encode(f"mika:{password}".encode()).decode()}
    client = TestClient(
        create_app(config, password=password),
        base_url="http://127.0.0.1",
        client=("127.0.0.1", 50000),
    )
    assert client.get("/api/changes", headers=auth).json()["first_run"] is True
    assert len(client.get("/api/history", headers=auth).json()) == 1
    # Still read-only: scenarios are CLI-only in 2.2.
    assert client.post("/api/changes", headers=auth).status_code == 405


def test_api_changes_404_before_first_run(tmp_path):
    import base64

    from fastapi.testclient import TestClient

    from mika.api import create_app
    from tests.test_monitor import _settings

    auth = {"Authorization": "Basic " + base64.b64encode(b"mika:pw").decode()}
    client = TestClient(
        create_app(_settings(tmp_path), password="pw"),
        base_url="http://127.0.0.1",
        client=("127.0.0.1", 50000),
    )
    assert client.get("/api/changes", headers=auth).status_code == 404
    assert client.get("/api/history", headers=auth).json() == []
