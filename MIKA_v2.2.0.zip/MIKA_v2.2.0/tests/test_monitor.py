"""The monitor pipeline end to end, with fake transports."""

import json
import shutil
from pathlib import Path
from urllib.parse import unquote_plus

import pytest
from fastapi.testclient import TestClient

from mika.api import create_app
from mika.app import MikaApp
from mika.config import Settings
from mika.connectors.http import RawResponse, SafeClient
from mika.embeddings import Embedder
from mika.monitor import run_monitor
from mika.portfolio import import_holdings
from tests.test_sanctions import ALT, SDN, UK

FIXTURES = Path(__file__).resolve().parent / "fixtures" / "samples" / "screening"
SECRET = "super-secret-x-token"


def _settings(tmp_path: Path, **extra) -> Settings:
    return Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
        **extra,
    ).resolve()


def _app(config: Settings) -> MikaApp:
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    return MikaApp(config, embedder=embedder)


def _portfolio(tmp_path: Path) -> None:
    (tmp_path / "mine.csv").write_text(
        "issuer,identifier,market_value_usd\n"
        "Zarvek Maritime Holdings,ZRVK,1000000\n"
        "Quintor Halvane Trading,,500000\n"
        "Aurora Software Inc,,2000000\n",
        encoding="utf-8",
    )
    import_holdings(tmp_path, "mine.csv")


class Routes:
    def __init__(self):
        self.calls: list[str] = []
        self.gdelt_calls = 0

    def __call__(self, method, url, headers, data, timeout):
        decoded = unquote_plus(url)
        self.calls.append(decoded)
        if "ofac.treas.gov" in url:
            return RawResponse(200, {}, SDN if url.endswith("SDN.CSV") else ALT)
        if "sanctionslist.fcdo.gov.uk" in url:
            return RawResponse(200, {}, UK)
        if "api.gleif.org" in url:
            return RawResponse(404, {}, b"{}")
        if "api.gdeltproject.org" in url:
            self.gdelt_calls += 1
            if "Zarvek" in decoded:
                body = {
                    "articles": [
                        {
                            "url": "https://news.example.org/zarvek",
                            "title": "Zarvek Maritime Holdings accused of fraud by regulator",
                            "seendate": "20261001T120000Z",
                        }
                    ]
                }
                return RawResponse(200, {}, json.dumps(body).encode())
            return RawResponse(429, {"content-type": "text/plain"}, b"Please limit requests")
        return RawResponse(404, {}, b"")


def test_offline_monitor_uses_local_data_only(tmp_path: Path):
    _portfolio(tmp_path)
    (tmp_path / "data").mkdir(exist_ok=True)
    shutil.copy(FIXTURES / "watchlist.csv", tmp_path / "data" / "watchlist.csv")
    routes = Routes()
    with _app(_settings(tmp_path, online_sources="gleif,gdelt")) as app:
        report = run_monitor(app, SafeClient(transport=routes, sleep=lambda _: None), offline=True)
    assert routes.calls == []
    assert report["offline"] is True
    assert report["screening"]["holdings"] == 3
    statuses = {
        r["issuer"]: r["status"]
        for r in json.loads((tmp_path / "reports" / "screening-latest.json").read_text("utf-8"))[
            "holdings"
        ]
    }
    assert statuses["Zarvek Maritime Holdings"] == "BLOCKED"
    assert statuses["Aurora Software Inc"] == "CLEAR"


def test_online_monitor_syncs_screens_and_isolates_a_throttled_source(tmp_path: Path):
    _portfolio(tmp_path)
    routes = Routes()
    config = _settings(tmp_path, online_sources="gleif,gdelt", x_bearer_token=SECRET)
    with _app(config) as app:
        report = run_monitor(app, SafeClient(transport=routes, sleep=lambda _: None))
        signals = app.db.conn.execute("SELECT source, severity, holding_id FROM signals").fetchall()
    assert report["sanctions"]["entries"] == 4
    assert report["screening"]["by_status"]["BLOCKED"]["count"] >= 1
    gdelt = report["signals"]["sources"]["gdelt"]
    assert gdelt["new"] == 1 and gdelt["status"] == "throttled"
    assert [tuple(row) for row in signals] == [("gdelt", "high", "H0001")]
    # Flagged holdings are searched first; the throttled source stops instead of hammering.
    assert routes.gdelt_calls == 3
    assert "x" not in report["signals"]["sources"]  # not in MIKA_ONLINE_SOURCES
    serialized = json.dumps(report) + (tmp_path / "audit.jsonl").read_text("utf-8")
    assert SECRET not in serialized
    assert "monitor.run" in (tmp_path / "audit.jsonl").read_text("utf-8")
    assert "GDELT" in " ".join(report["attribution"])


def test_monitor_without_a_portfolio_gives_guidance(tmp_path: Path):
    with _app(_settings(tmp_path)) as app, pytest.raises(ValueError, match="mika portfolio import"):
        run_monitor(app, SafeClient(transport=Routes(), sleep=lambda _: None), offline=True)


def test_api_exposes_signals_and_feed_status_without_secrets(tmp_path: Path):
    _portfolio(tmp_path)
    config = _settings(
        tmp_path,
        online_sources="gdelt",
        x_bearer_token=SECRET,
        reddit_client_secret="reddit-secret-value",
    )
    with _app(config) as app:
        run_monitor(app, SafeClient(transport=Routes(), sleep=lambda _: None))
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    client = TestClient(
        create_app(config, embedder=embedder, password="pw"),
        base_url="http://127.0.0.1",
        client=("127.0.0.1", 50000),
    )
    client.auth = ("mika", "pw")
    feeds = client.get("/api/feeds")
    assert feeds.status_code == 200
    body = feeds.json()
    assert body["online_sources"] == ["gdelt"]
    assert body["credentials"] == {"reddit": False, "x": True, "contact_email": False}
    assert SECRET not in feeds.text and "reddit-secret-value" not in feeds.text
    signals = client.get("/api/signals", params={"holding_id": "H0001", "severity": "high"})
    assert signals.status_code == 200
    assert [item["source"] for item in signals.json()] == ["gdelt"]
    assert client.get("/api/signals", params={"limit": 5000}).status_code == 422


def test_feeds_check_reports_each_source_without_calling_paid_x(tmp_path: Path):
    from mika.feeds import check_feeds

    routes = Routes()
    config = _settings(tmp_path, online_sources="gleif,sec,x", x_bearer_token=SECRET)
    result = check_feeds(config, SafeClient(transport=routes, sleep=lambda _: None))
    assert result["results"]["ofac"] == "ok" and result["results"]["uk"] == "ok"
    assert result["results"]["gleif"].startswith("failed")  # fake GLEIF returns 404
    assert result["results"]["sec"].startswith("not configured")
    assert result["results"]["x"].startswith("configured (not called")
    assert not any("api.x.com" in call for call in routes.calls)
    assert result["disabled_by_privacy_setting"] == ["gdelt", "reddit"]
    assert SECRET not in json.dumps(result)


def test_cli_monitor_and_portfolio_commands(tmp_path: Path, monkeypatch, capsys):
    import mika.cli as cli_module
    from mika.cli import main

    config = _settings(tmp_path)
    monkeypatch.setattr(cli_module, "MikaApp", lambda: _app(config))
    with pytest.raises(SystemExit, match="mika portfolio import"):
        main(["monitor", "--offline"])
    (tmp_path / "mine.csv").write_text(
        "issuer,market_value_usd\nZarvek Maritime Holdings,10\n", encoding="utf-8"
    )
    assert main(["portfolio", "import", "mine.csv"]) == 0
    (tmp_path / "data").mkdir(exist_ok=True)
    shutil.copy(FIXTURES / "watchlist.csv", tmp_path / "data" / "watchlist.csv")
    capsys.readouterr()
    assert main(["monitor", "--offline"]) == 0
    assert json.loads(capsys.readouterr().out)["screening"]["holdings"] == 1
