from pathlib import Path

from mika.storage import SCHEMA_VERSION, Database


def test_schema_applied_only_when_out_of_date(tmp_path: Path, monkeypatch):
    calls: list[str] = []
    original = Database._prepare

    def counting(self: Database) -> None:
        calls.append(self.path.name)
        original(self)

    monkeypatch.setattr(Database, "_prepare", counting)
    for _ in range(3):
        Database(tmp_path / "a.sqlite3").close()
    Database(tmp_path / "b.sqlite3").close()
    assert calls == ["a.sqlite3", "b.sqlite3"]


def test_cached_open_still_has_tables_and_fts(tmp_path: Path):
    Database(tmp_path / "c.sqlite3").close()
    db = Database(tmp_path / "c.sqlite3")
    assert db.fts_enabled
    assert db.conn.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION
    assert db.conn.execute("SELECT COUNT(*) FROM cases").fetchone()[0] == 0
    db.close()


def test_deleted_database_is_prepared_again(tmp_path: Path):
    path = tmp_path / "d.sqlite3"
    Database(path).close()
    for suffix in ("", "-wal", "-shm"):
        Path(str(path) + suffix).unlink(missing_ok=True)
    db = Database(path)
    assert db.conn.execute("SELECT COUNT(*) FROM sources").fetchone()[0] == 0
    db.close()
