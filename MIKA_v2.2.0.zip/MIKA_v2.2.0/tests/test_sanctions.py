"""Sanctions parsers and sync, using fictional entries in the exact published file formats."""

import csv
from pathlib import Path

import pytest

from mika.connectors.http import RawResponse, SafeClient
from mika.sanctions import parse_ofac, parse_uk, sync_sanctions

# OFAC legacy flat files: no header, CRLF, "-0- " null marker, quoted text.
SDN = (
    b'90001,"ZARVEK MARITIME HOLDINGS",-0- ,"SYN-A",-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,-0- \r\n'
    b'90002,"VELMAROV, Orsik",individual,"SYN-A] [SYN-B",-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,-0- ,'
    b'"DOB 01 Jan 1970."\r\n'
    b"\x1a"
)
ALT = (
    b'90001,1,"aka","ZMH SHIPPING",-0- \r\n'
    b'90002,2,"aka","VELMAROV, Orsic",-0- \r\n'
    b'99999,3,"aka","ORPHAN ALIAS",-0- \r\n'
)

UK_HEADER = (
    "Last Updated,Unique ID,OFSI Group ID,UN Reference Number,Name 6,Name 1,Name 2,Name 3,"
    "Name 4,Name 5,Name type,Alias strength,Title,Name non-latin script,Non-latin script type,"
    "Non-latin script language,Regime Name,Designation Type,Designation source,Sanctions Imposed,"
    "Other Information,UK Statement of Reasons,Address Line 1,Address Line 2,Address Line 3,"
    "Address Line 4,Address Line 5,Address Line 6,Address Postal Code,Address Country"
)


def _uk_row(uid, name6, name1, name_type, strength, regime, kind, address=""):
    cells = [
        "01/10/2026",
        uid,
        "1",
        "",
        name6,
        name1,
        "",
        "",
        "",
        "",
        name_type,
        strength,
        "",
        "",
        "",
        "",
        regime,
        kind,
        "UK",
        "Asset freeze",
        "",
        "",
        address,
        "",
        "",
        "",
        "",
        "",
        "",
        "",
    ]
    return ",".join(f'"{cell}"' if "," in cell else cell for cell in cells)


UK = "\n".join(
    [
        "Report Date: 02-Oct-2026",
        UK_HEADER,
        _uk_row(
            "SYN0001",
            "Quintor Halvane Trading",
            "",
            "Primary Name",
            "",
            "Regime X",
            "Entity",
            "Unit 1",
        ),
        _uk_row(
            "SYN0001",
            "Quintor Halvane Trading",
            "",
            "Primary Name",
            "",
            "Regime X",
            "Entity",
            "Unit 2",
        ),
        _uk_row("SYN0001", "QHT Fictora", "", "Alias", "Good quality a.k.a", "Regime X", "Entity"),
        _uk_row("SYN0002", "Vantosh", "Idrel", "Primary name", "", "Regime Y", "Individual"),
        _uk_row(
            "SYN0002", "Vantos", "Idrell", "Primary name variation", "", "Regime Y", "Individual"
        ),
        _uk_row(
            "SYN0002", "The Engineer", "", "Alias", "Low quality a.k.a", "Regime Y", "Individual"
        ),
    ]
).encode("utf-8")


def test_parse_ofac_handles_nulls_programs_aliases_and_junk():
    entries = {e.list_id: e for e in parse_ofac(SDN, ALT)}
    assert set(entries) == {"OFAC-90001", "OFAC-90002"}
    assert entries["OFAC-90001"].name == "ZARVEK MARITIME HOLDINGS"
    assert entries["OFAC-90001"].aliases == ("ZMH SHIPPING",)
    assert entries["OFAC-90002"].program == "SYN-A; SYN-B"
    # OFAC writes individuals as "SURNAME, Given": the natural order is added as an alias.
    assert "Orsik VELMAROV" in entries["OFAC-90002"].aliases


def test_parse_uk_groups_rows_and_drops_weak_aliases():
    entries, skipped = parse_uk(UK)
    by_id = {e.list_id: e for e in entries}
    assert set(by_id) == {"UK-SYN0001", "UK-SYN0002"}
    assert by_id["UK-SYN0001"].name == "Quintor Halvane Trading"
    assert by_id["UK-SYN0001"].aliases == ("QHT Fictora",)
    assert by_id["UK-SYN0002"].name == "Idrel Vantosh"
    assert by_id["UK-SYN0002"].aliases == ("Idrell Vantos",)
    assert by_id["UK-SYN0002"].program == "Regime Y"
    assert skipped == 1


def test_parse_uk_rejects_an_unexpected_header():
    with pytest.raises(ValueError, match="UK Sanctions List"):
        parse_uk(b"Report Date: x\nfoo,bar\n1,2\n")


class Transport:
    def __init__(self, routes):
        self.routes = routes
        self.calls = []

    def __call__(self, method, url, headers, data, timeout):
        self.calls.append(url)
        for prefix, response in self.routes.items():
            if url.startswith(prefix):
                return response
        return RawResponse(404, {}, b"")


def _client(routes):
    return SafeClient(transport=Transport(routes), sleep=lambda _: None)


OFAC_BASE = "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/"
UK_URL = "https://sanctionslist.fcdo.gov.uk/docs/UK-Sanctions-List.csv"


def _routes(uk_status=200):
    return {
        OFAC_BASE + "SDN.CSV": RawResponse(200, {"content-type": "text/csv"}, SDN),
        OFAC_BASE + "ALT.CSV": RawResponse(200, {"content-type": "text/csv"}, ALT),
        UK_URL: RawResponse(uk_status, {"content-type": "application/octet-stream"}, UK),
    }


def test_sync_writes_merged_watchlist_with_provenance_and_attribution(tmp_path: Path):
    summary = sync_sanctions(_client(_routes()), tmp_path)
    rows = list(csv.DictReader((tmp_path / "data" / "watchlist.csv").open(encoding="utf-8")))
    assert {row["list_id"] for row in rows} == {
        "OFAC-90001",
        "OFAC-90002",
        "UK-SYN0001",
        "UK-SYN0002",
    }
    assert summary["sources"]["ofac"]["entries"] == 2
    assert summary["sources"]["uk"]["entries"] == 2
    assert summary["sources"]["uk"]["weak_aliases_skipped"] == 1
    assert len(summary["sources"]["uk"]["sha256"]) == 64
    assert "Open Government Licence v3.0" in summary["attribution"]
    assert list((tmp_path / "data" / "sources" / "uk").glob("*.csv"))


def test_sync_keeps_the_last_good_copy_when_one_source_fails(tmp_path: Path):
    sync_sanctions(_client(_routes()), tmp_path)
    summary = sync_sanctions(_client(_routes(uk_status=503)), tmp_path, force=True)
    assert summary["sources"]["uk"]["status"] == "stale"
    assert "HTTP 503" in summary["sources"]["uk"]["error"]
    ids = {r["list_id"] for r in csv.DictReader((tmp_path / "data" / "watchlist.csv").open())}
    assert "UK-SYN0001" in ids


def test_sync_skips_downloads_while_fresh_unless_forced(tmp_path: Path):
    sync_sanctions(_client(_routes()), tmp_path)
    client = _client(_routes())
    summary = sync_sanctions(client, tmp_path)
    assert summary["skipped"] is True
    assert client.transport.calls == []


def test_sync_fails_clearly_when_no_list_is_available(tmp_path: Path):
    with pytest.raises(RuntimeError, match="No sanctions list"):
        sync_sanctions(_client({}), tmp_path)
