# Synthetic screening scenarios

Thirty hand-built portfolio scenarios used by the test suite and `mika evaluate` to check the
screening rules: aliases, transliterations, multi-hop ownership, aggregation, the 50% boundary,
near-miss names and ownership cycles. Each row in `labels.csv` explains its scenario.

**All names are coined and fictional.** Programmes `SYN-A` to `SYN-E`, identifiers `SYNLEI...` and
country codes `XA` to `XS` (ISO 3166 private-use) are deliberately not real. No real person or
organisation is represented as sanctioned. See `NOTICE.md`.
