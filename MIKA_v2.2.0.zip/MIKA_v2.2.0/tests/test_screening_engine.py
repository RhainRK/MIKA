import shutil
from pathlib import Path

import pytest

from mika.screening import ScreeningConfig, evaluate_labels, load_inputs, load_labels, screen

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "tests" / "fixtures" / "samples" / "screening"


def _sample_inputs():
    return load_inputs(
        ROOT,
        holdings="tests/fixtures/samples/screening/holdings.csv",
        entities="tests/fixtures/samples/screening/entities.csv",
        ownership="tests/fixtures/samples/screening/ownership.csv",
        watchlist="tests/fixtures/samples/screening/watchlist.csv",
    )


@pytest.fixture(scope="module")
def report():
    return screen(_sample_inputs())


def _by_id(report):
    return {row["holding_id"]: row for row in report["holdings"]}


def test_sample_portfolio_matches_every_label(report):
    labels = load_labels(ROOT, "tests/fixtures/samples/screening/labels.csv")
    metrics = evaluate_labels(report, labels)
    assert metrics["misclassified"] == []
    assert metrics["blocked"]["recall"] == 1.0
    assert metrics["blocked"]["precision"] == 1.0
    assert metrics["accuracy"] == 1.0


def test_blocked_holding_carries_an_explanation_back_to_listed_parties(report):
    row = _by_id(report)["H05"]
    assert row["status"] == "BLOCKED"
    tree = row["explanation"]
    assert tree["name"] == "Kryllis Cold Chain AS"
    chain = []
    node = tree
    while node["owners"]:
        node = node["owners"][0]["node"]
        chain.append(node["name"])
    assert chain == [
        "Ostvane Port Logistics",
        "Feldmarr Freight Services",
        "Zarvek Maritime Holdings PLC",
    ]
    assert node["listed"] and node["programs"] == ["SYN-A"]


def test_aggregated_block_lists_both_contributors(report):
    tree = _by_id(report)["H06"]["explanation"]
    assert {edge["node"]["name"] for edge in tree["owners"]} == {
        "Orsik Velmarov",
        "Quintor Halvane Trading LLC",
    }
    assert tree["blocked_share"] == 55.0


def test_summary_reports_exposure_by_market_value(report):
    summary = report["summary"]
    total = summary["total_market_value"]
    blocked = summary["by_status"]["BLOCKED"]
    assert summary["holdings"] == 30
    assert blocked["count"] == 10
    assert blocked["weight"] == pytest.approx(blocked["market_value"] / total)
    assert sum(item["count"] for item in summary["by_status"].values()) == 30


def test_report_is_reproducible_and_uses_relative_paths(report):
    assert report["inputs"]["holdings"]["path"] == "tests/fixtures/samples/screening/holdings.csv"
    assert len(report["inputs"]["holdings"]["sha256"]) == 64
    again = screen(_sample_inputs())
    assert [r["status"] for r in again["holdings"]] == [r["status"] for r in report["holdings"]]


def test_identifier_match_takes_precedence_over_name(report):
    entity = _by_id(report)["H19"]["entity"]
    assert entity["entity_id"] == "E024"
    assert entity["signals"] == ["identifier_exact"]


def test_review_reasons_are_specific(report):
    rows = _by_id(report)
    assert any("possible watchlist match" in reason for reason in rows["H10"]["reasons"])
    assert any("49.9%" in reason for reason in rows["H07"]["reasons"])
    assert any("entity master" in reason for reason in rows["H18"]["reasons"])


def test_data_issues_are_reported_not_fatal(tmp_path: Path):
    for name in ("holdings.csv", "entities.csv", "watchlist.csv"):
        shutil.copy(SAMPLES / name, tmp_path / name)
    (tmp_path / "ownership.csv").write_text(
        "owner_id,owned_id,percent\n"
        "E002,E003,60\n"
        "E002,E003,10\n"
        "E999,E003,5\n"
        "E001,E001,50\n"
        "E006,E009,abc\n"
        "E006,E008,140\n"
        "E007,E003,45\n",
        encoding="utf-8",
    )
    inputs = load_inputs(
        tmp_path,
        holdings="holdings.csv",
        entities="entities.csv",
        ownership="ownership.csv",
        watchlist="watchlist.csv",
    )
    checks = sorted({issue.check for issue in inputs.issues})
    assert checks == [
        "duplicate_link",
        "invalid_percent",
        "over_allocated",
        "self_ownership",
        "unknown_entity",
    ]
    assert screen(inputs)["summary"]["holdings"] == 30


def test_missing_columns_fail_fast(tmp_path: Path):
    for name in ("holdings.csv", "entities.csv", "ownership.csv"):
        shutil.copy(SAMPLES / name, tmp_path / name)
    (tmp_path / "watchlist.csv").write_text("id,full_name\n1,X\n", encoding="utf-8")
    with pytest.raises(ValueError, match=r"watchlist\.csv is missing columns"):
        load_inputs(
            tmp_path,
            holdings="holdings.csv",
            entities="entities.csv",
            ownership="ownership.csv",
            watchlist="watchlist.csv",
        )


def test_inputs_must_stay_inside_the_workspace(tmp_path: Path):
    with pytest.raises(ValueError):
        load_inputs(
            tmp_path,
            holdings="../holdings.csv",
            entities="entities.csv",
            ownership="ownership.csv",
            watchlist="watchlist.csv",
        )


def test_config_validation():
    with pytest.raises(ValueError):
        ScreeningConfig(review_match=0.95, block_match=0.9)
    with pytest.raises(ValueError):
        ScreeningConfig(review_share=60.0, ownership_threshold=50.0)


def test_consolidation_links_are_described_as_control_not_a_percentage(tmp_path):
    for name in ("holdings.csv", "entities.csv", "watchlist.csv"):
        shutil.copy(SAMPLES / name, tmp_path / name)
    (tmp_path / "ownership.csv").write_text(
        "owner_id,owned_id,percent,basis\nE002,E003,100,accounting_consolidation\n",
        encoding="utf-8",
    )
    inputs = load_inputs(
        tmp_path,
        holdings="holdings.csv",
        entities="entities.csv",
        ownership="ownership.csv",
        watchlist="watchlist.csv",
    )
    row = next(r for r in screen(inputs)["holdings"] if r["holding_id"] == "H03")
    assert row["status"] == "BLOCKED"
    assert "accounting consolidation" in row["reasons"][0]
    assert "100%" not in row["reasons"][0]
    assert row["explanation"]["owners"][0]["basis"] == "accounting_consolidation"
