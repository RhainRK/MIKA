"""Regression tests for findings from the 2.1 security review."""

import shutil
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from mika.api import create_app
from mika.app import MikaApp
from mika.cli import main
from mika.config import Settings
from mika.embeddings import Embedder
from mika.screening import load_inputs

ROOT = Path(__file__).resolve().parents[1]
SAMPLES = ROOT / "tests" / "fixtures" / "samples" / "screening"


def _settings(tmp_path: Path) -> Settings:
    return Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
    ).resolve()


def _embedder() -> Embedder:
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    return embedder


def test_oversized_csv_field_is_a_clean_error_not_a_crash(tmp_path: Path):
    for name in ("entities.csv", "ownership.csv", "watchlist.csv"):
        shutil.copy(SAMPLES / name, tmp_path / name)
    (tmp_path / "holdings.csv").write_text(
        "holding_id,issuer,identifier,market_value_usd\nH1," + "a" * 200_000 + ",,1\n",
        encoding="utf-8",
    )
    with pytest.raises(ValueError, match=r"holdings.csv"):
        load_inputs(
            tmp_path,
            holdings="holdings.csv",
            entities="entities.csv",
            ownership="ownership.csv",
            watchlist="watchlist.csv",
        )


def test_report_filename_is_restricted_to_safe_characters(tmp_path: Path):
    config = _settings(tmp_path)
    with MikaApp(config, embedder=_embedder()) as app:
        app.db.conn.execute(
            "INSERT INTO cases(id,title,created_at,updated_at) VALUES(?,?,?,?)",
            ('evil"\r\nX-Injected: 1', "Injected", "now", "now"),
        )
        app.db.conn.commit()
    client = TestClient(
        create_app(config, embedder=_embedder(), password="pass"),
        base_url="http://127.0.0.1",
        client=("127.0.0.1", 50000),
    )
    client.auth = ("mika", "pass")
    response = client.get("/api/cases/evil%22%0D%0AX-Injected:%201/report")
    assert response.status_code == 200
    assert "x-injected" not in {key.lower() for key in response.headers}
    disposition = response.headers["content-disposition"]
    assert "\r" not in disposition and "\n" not in disposition
    assert disposition == 'attachment; filename="evil_X-Injected_1.md"'


def test_case_report_output_must_stay_in_workspace(tmp_path: Path, monkeypatch):
    import mika.cli as cli_module

    config = _settings(tmp_path)
    embedder = _embedder()
    monkeypatch.setattr(cli_module, "MikaApp", lambda: MikaApp(config, embedder=embedder))
    with MikaApp(config, embedder=embedder) as app:
        case_id = app.cases.create("Contained")
    with pytest.raises(SystemExit, match="workspace"):
        main(["case-report", case_id, "--output", str(tmp_path.parent / "escaped.md")])
    assert main(["case-report", case_id, "--output", "reports/case.md"]) == 0
    assert (tmp_path / "reports" / "case.md").exists()


def test_ingest_of_malformed_json_is_a_clean_cli_error(tmp_path: Path, monkeypatch):
    import mika.cli as cli_module

    config = _settings(tmp_path)
    embedder = _embedder()
    monkeypatch.setattr(cli_module, "MikaApp", lambda: MikaApp(config, embedder=embedder))
    (tmp_path / "broken.json").write_text("{not json", encoding="utf-8")
    with pytest.raises(SystemExit, match="Could not ingest"):
        main(["ingest", "broken.json"])


def test_static_assets_do_not_exhaust_the_api_budget_but_api_stays_limited(tmp_path: Path):
    config = _settings(tmp_path)
    client = TestClient(
        create_app(config, embedder=_embedder(), password="pass"),
        base_url="http://127.0.0.1",
        client=("127.0.0.1", 50000),
    )
    client.auth = ("mika", "pass")
    # Several full page loads in a row: ~16 static files each.
    for _ in range(20):
        for path in ("/", "/style.css", "/favicon.svg", "/assets/main.js", "/assets/dom.js"):
            assert client.get(path).status_code == 200, path
    # Static assets still require authentication.
    assert client.get("/assets/main.js", auth=("mika", "wrong")).status_code in {401, 429}
    # The API keeps its burst budget.
    statuses = [client.get("/api/health").status_code for _ in range(80)]
    assert 429 in statuses and statuses[0] == 200
