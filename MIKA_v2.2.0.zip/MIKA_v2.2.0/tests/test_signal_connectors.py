"""Signal connectors against recorded response formats (fictional content, no network)."""

import base64
import json
from datetime import UTC, datetime
from urllib.parse import parse_qs, urlsplit

import pytest

from mika.connectors.http import RawResponse, SafeClient, Throttled
from mika.signals import gdelt, reddit, sec_filings, x
from mika.signals.model import Target

NOW = datetime(2026, 10, 2, 12, 0, tzinfo=UTC)
TARGET = Target("H0001", "Zarvek Maritime Holdings PLC", ("Zarvek Maritime",), "ZRVK")


class Fake:
    def __init__(self, *responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, method, url, headers, data, timeout):
        self.calls.append({"method": method, "url": url, "headers": dict(headers), "data": data})
        return self.responses.pop(0)


def _client(*responses):
    fake = Fake(*responses)
    return SafeClient(transport=fake, sleep=lambda _: None), fake


def _json(body, status=200):
    return RawResponse(status, {"content-type": "application/json"}, json.dumps(body).encode())


def test_gdelt_builds_phrase_query_and_classifies_titles():
    articles = {
        "articles": [
            {
                "url": "https://news.example.org/zarvek-probe",
                "title": "Regulator opens fraud probe into Zarvek Maritime Holdings",
                "seendate": "20261001T183000Z",
                "domain": "news.example.org",
                "language": "English",
                "sourcecountry": "United Kingdom",
            }
        ]
    }
    client, fake = _client(_json(articles))
    [signal] = gdelt.collect(client, TARGET, now=NOW)
    query = parse_qs(urlsplit(fake.calls[0]["url"]).query)
    assert query["query"] == ['"Zarvek Maritime Holdings PLC" sourcelang:english']
    assert query["mode"] == ["artlist"] and query["format"] == ["json"]
    assert signal.published_at == "2026-10-01T18:30:00+00:00"
    assert signal.severity == "high" and "fraud" in signal.categories
    assert signal.expires_at > NOW.isoformat()


def test_gdelt_empty_results_and_throttling():
    client, _ = _client(_json({}))
    assert gdelt.collect(client, TARGET, now=NOW) == []
    throttled = RawResponse(429, {"content-type": "text/plain"}, b"Please limit requests")
    client, _ = _client(throttled, throttled)
    with pytest.raises(Throttled):
        gdelt.collect(client, TARGET, now=NOW)


def test_gdelt_non_json_body_is_a_clear_error():
    from mika.connectors.http import FetchError

    client, _ = _client(
        RawResponse(200, {"content-type": "text/html"}, b"Your query was too short")
    )
    with pytest.raises(FetchError, match="GDELT"):
        gdelt.collect(client, TARGET, now=NOW)


def test_sec_filings_keeps_recent_8k_with_item_mapping_and_archive_urls():
    recent = {
        "accessionNumber": ["0000999001-26-000010", "0000999001-26-000009", "0000999001-25-000001"],
        "filingDate": ["2026-09-30", "2026-09-20", "2025-01-15"],
        "form": ["8-K", "10-Q", "8-K"],
        "items": ["1.03,9.01", "", "5.02"],
        "primaryDocument": ["zrvk-8k.htm", "zrvk-10q.htm", "old.htm"],
    }
    client, fake = _client(
        _json({"cik": "0000999001", "name": "ZARVEK", "filings": {"recent": recent}})
    )
    [signal] = sec_filings.collect(
        client, TARGET, cik=999001, contact_email="ops@example.org", now=NOW
    )
    assert fake.calls[0]["url"] == "https://data.sec.gov/submissions/CIK0000999001.json"
    assert "ops@example.org" in fake.calls[0]["headers"]["User-Agent"]
    assert signal.url == (
        "https://www.sec.gov/Archives/edgar/data/999001/000099900126000010/zrvk-8k.htm"
    )
    assert signal.severity == "high" and signal.categories == ("financial_distress",)
    assert signal.matched_term == "CIK 999001"


def test_sec_requires_contact_email():
    client, _ = _client()
    with pytest.raises(ValueError, match="MIKA_CONTACT_EMAIL"):
        sec_filings.collect(client, TARGET, cik=1, contact_email="", now=NOW)


REDDIT_LISTING = {
    "data": {
        "children": [
            {
                "data": {
                    "id": "a1",
                    "title": "Zarvek Maritime Holdings hit with lawsuit",
                    "selftext": "",
                    "permalink": "/r/investing/comments/a1/x/",
                    "created_utc": 1759315200,
                    "author": "someone",
                }
            },
            {
                "data": {
                    "id": "a2",
                    "title": "Best maritime stocks?",
                    "selftext": "thoughts",
                    "permalink": "/r/investing/comments/a2/y/",
                    "created_utc": 1759315200,
                    "author": "other",
                }
            },
        ]
    }
}


def test_reddit_app_only_oauth_relevance_and_no_authors():
    token = _json({"access_token": "tok", "token_type": "bearer", "expires_in": 3600})
    client, fake = _client(token, _json(REDDIT_LISTING))
    creds = reddit.Credentials("cid", "s3cret-value", "mika_dev")
    [signal] = reddit.collect(client, TARGET, creds, now=NOW)
    auth = fake.calls[0]["headers"]["Authorization"]
    assert auth == "Basic " + base64.b64encode(b"cid:s3cret-value").decode()
    assert fake.calls[0]["data"] == b"grant_type=client_credentials"
    assert fake.calls[1]["headers"]["Authorization"] == "bearer tok"
    assert fake.calls[1]["headers"]["User-Agent"].endswith("(by /u/mika_dev)")
    assert signal.url == "https://www.reddit.com/r/investing/comments/a1/x/"
    assert "someone" not in json.dumps(
        signal.__dict__ if hasattr(signal, "__dict__") else str(signal)
    )
    assert signal.expires_at == "2026-10-04T12:00:00+00:00"  # 48 hours


def test_reddit_auth_failure_never_leaks_the_secret():
    from mika.connectors.http import FetchError

    client, _ = _client(RawResponse(401, {}, b'{"error": "invalid_grant s3cret-value"}'))
    with pytest.raises(FetchError) as info:
        reddit.collect(client, TARGET, reddit.Credentials("cid", "s3cret-value", "u"), now=NOW)
    assert "s3cret-value" not in str(info.value)


def test_x_respects_post_budget_and_strict_relevance():
    posts = {
        "data": [
            {
                "id": "1",
                "text": "$ZRVK down 9% after fraud allegations",
                "created_at": "2026-10-01T09:00:00.000Z",
            },
            {
                "id": "2",
                "text": "zarvek? never heard of it",
                "created_at": "2026-10-01T09:05:00.000Z",
            },
        ]
    }
    client, fake = _client(_json(posts))
    budget = x.Budget(remaining=30)
    signals = x.collect(client, TARGET, "bearer-xyz", budget, now=NOW)
    query = parse_qs(urlsplit(fake.calls[0]["url"]).query)
    assert query["max_results"] == ["30"]
    assert '"Zarvek Maritime Holdings PLC"' in query["query"][0] and "$ZRVK" in query["query"][0]
    assert fake.calls[0]["headers"]["Authorization"] == "Bearer bearer-xyz"
    assert [s.external_id for s in signals] == ["1"]
    assert signals[0].url == "https://x.com/i/web/status/1"
    assert budget.remaining == 28
    client, fake = _client()
    assert x.collect(client, TARGET, "t", x.Budget(remaining=5), now=NOW) == []
    assert fake.calls == []
