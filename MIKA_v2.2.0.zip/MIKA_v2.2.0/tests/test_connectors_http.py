import gzip
import json
from pathlib import Path

import pytest

from mika.connectors.http import FetchError, RawResponse, SafeClient, Source, Throttled
from mika.connectors.snapshots import prune, save

API = Source("api", hosts=frozenset({"api.example.org"}), max_bytes=1000, min_interval_s=5.0)
S3 = Source(
    "lists",
    hosts=frozenset({"lists.example.gov"}),
    redirect_hosts=frozenset({"bucket.s3.example.com"}),
)


class FakeTransport:
    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def __call__(self, method, url, headers, data, timeout):
        self.calls.append({"url": url, "headers": dict(headers), "data": data})
        return self.responses.pop(0)


class Clock:
    def __init__(self):
        self.now = 1000.0
        self.slept = []

    def time(self):
        return self.now

    def sleep(self, seconds):
        self.slept.append(seconds)
        self.now += seconds


def _client(responses, clock=None):
    transport = FakeTransport(responses)
    clock = clock or Clock()
    return SafeClient(transport=transport, clock=clock.time, sleep=clock.sleep), transport, clock


def ok(body=b"{}", headers=None, status=200):
    return RawResponse(status, {"content-type": "application/json", **(headers or {})}, body)


def test_returns_body_with_digest_and_metadata():
    client, transport, _ = _client([ok(b'{"a":1}')])
    fetched = client.get(API, "https://api.example.org/v1/x", params={"q": 'say "hi" & bye'})
    assert fetched.status == 200 and json.loads(fetched.body) == {"a": 1}
    assert len(fetched.sha256) == 64
    assert "q=say+%22hi%22+%26+bye" in transport.calls[0]["url"]
    assert transport.calls[0]["headers"]["User-Agent"].startswith("MIKA/")


@pytest.mark.parametrize(
    "url",
    [
        "http://api.example.org/v1/x",
        "https://evil.example.org/v1/x",
        "https://api.example.org.evil.com/x",
        "https://user:pw@api.example.org/x",
        "https://api.example.org:8443/x",
    ],
)
def test_refuses_urls_outside_the_allowlist(url):
    client, transport, _ = _client([])
    with pytest.raises(FetchError):
        client.get(API, url)
    assert transport.calls == []


def test_follows_only_allowlisted_redirects_and_drops_auth():
    client, transport, _ = _client(
        [
            RawResponse(302, {"location": "https://bucket.s3.example.com/f.csv?sig=1"}, b""),
            ok(b"csv-bytes", {"content-type": "text/csv"}),
        ]
    )
    fetched = client.get(S3, "https://lists.example.gov/SDN.CSV", headers={"Authorization": "x"})
    assert fetched.body == b"csv-bytes"
    assert "Authorization" not in transport.calls[1]["headers"]


def test_refuses_redirect_to_unlisted_host():
    client, _, _ = _client([RawResponse(302, {"location": "https://evil.example.com/"}, b"")])
    with pytest.raises(FetchError, match="redirect"):
        client.get(S3, "https://lists.example.gov/SDN.CSV")


def test_enforces_byte_cap_including_after_gzip():
    client, _, _ = _client([ok(b"x" * 1001)])
    with pytest.raises(FetchError, match="limit"):
        client.get(API, "https://api.example.org/big")
    bomb = gzip.compress(b"0" * 50_000)
    client, _, _ = _client([ok(bomb, {"content-encoding": "gzip"})])
    with pytest.raises(FetchError, match="limit"):
        client.get(API, "https://api.example.org/bomb")


def test_decompresses_gzip_within_cap():
    client, _, _ = _client([ok(gzip.compress(b'{"ok":true}'), {"content-encoding": "gzip"})])
    assert json.loads(client.get(API, "https://api.example.org/z").body) == {"ok": True}


def test_429_is_retried_once_then_raises_throttled_without_parsing_text():
    throttle = RawResponse(429, {"content-type": "text/plain"}, b"Please limit requests")
    client, transport, clock = _client([throttle, ok()])
    client.get(API, "https://api.example.org/a")
    assert len(transport.calls) == 2 and clock.slept
    client, _, _ = _client([throttle, throttle])
    with pytest.raises(Throttled):
        client.get(API, "https://api.example.org/a")


def test_minimum_interval_between_requests_to_a_source():
    client, _, clock = _client([ok(), ok()])
    client.get(API, "https://api.example.org/1")
    client.get(API, "https://api.example.org/2")
    assert pytest.approx(sum(clock.slept)) == 5.0


def test_http_errors_do_not_echo_response_bodies():
    client, _, _ = _client([RawResponse(401, {}, b"secret-token-in-body")])
    with pytest.raises(FetchError) as info:
        client.get(API, "https://api.example.org/x")
    assert "secret-token-in-body" not in str(info.value)
    assert "401" in str(info.value)


def test_snapshots_are_saved_with_manifest_and_pruned(tmp_path: Path):
    client, _, _ = _client([ok(b'{"a":1}')])
    fetched = client.get(API, "https://api.example.org/x")
    path = save(tmp_path, "api", fetched, "json")
    assert path.read_bytes() == b'{"a":1}'
    manifest = [
        json.loads(line) for line in (tmp_path / "api" / "manifest.jsonl").read_text().splitlines()
    ]
    assert manifest[0]["sha256"] == fetched.sha256
    assert manifest[0]["url"] == "https://api.example.org/x"
    assert prune(tmp_path, "api", max_age_s=0, now=fetched_time(fetched) + 10) == 1
    assert not path.exists()


def fetched_time(fetched):
    from datetime import datetime

    return datetime.fromisoformat(fetched.fetched_at).timestamp()
