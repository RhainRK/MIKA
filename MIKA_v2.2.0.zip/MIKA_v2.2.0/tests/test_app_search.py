import json
from pathlib import Path

import pytest

from mika.app import MikaApp
from mika.config import Settings
from mika.embeddings import Embedder


@pytest.fixture
def app(tmp_path: Path):
    config = Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
    ).resolve()
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    (tmp_path / "evidence.txt").write_text(
        "CASE-1 alpha ledger.\n\nCASE-2 alpha ledger.\n\nCASE-3 alpha ledger.", encoding="utf-8"
    )
    with MikaApp(config, embedder=embedder) as instance:
        instance.evidence.ingest_path("evidence.txt")
        yield instance


def test_search_returns_citation_rows(app: MikaApp):
    rows = app.search("alpha ledger", 3)
    assert len(rows) == 3
    assert all(row["citation"] == f"S{row['source_id']}:C{row['chunk_id']}" for row in rows)


def test_search_scoped_to_case_and_intersected_with_chunks(app: MikaApp):
    case_id = app.cases.create("Scoped")
    app.cases.attach_evidence(case_id, [1, 2])
    assert {row["chunk_id"] for row in app.search("alpha", 6, case_id=case_id)} == {1, 2}
    narrowed = app.search("alpha", 6, case_id=case_id, chunk_ids=[2, 3])
    assert [row["chunk_id"] for row in narrowed] == [2]


def test_unknown_case_raises(app: MikaApp):
    with pytest.raises(ValueError, match="Unknown case"):
        app.search("alpha", 3, case_id="case_missing")


def test_search_records_a_telemetry_span(app: MikaApp):
    app.search("alpha", 2, source_ids=[1])
    lines = app.settings.telemetry_path.read_text("utf-8").splitlines()
    spans = [json.loads(line) for line in lines]
    span = next(item for item in spans if item["name"] == "mika.retrieval.search")
    assert span["attributes"]["mika.retrieval.k"] == 2
    assert span["attributes"]["mika.retrieval.source_filter_count"] == 1
