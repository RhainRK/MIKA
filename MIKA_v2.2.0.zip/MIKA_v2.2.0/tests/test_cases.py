from pathlib import Path

from mika.cases import CaseStore
from mika.embeddings import Embedder
from mika.provenance import EvidenceStore
from mika.storage import Database


def test_case_report_contains_confidence_alternatives_limitations(tmp_path: Path):
    (tmp_path / "doc.txt").write_text("Observed queue depth was 37 records.")
    db = Database(tmp_path / "mika.sqlite3")
    embedder = Embedder("fixture")
    embedder._backend = "hash"
    try:
        store = EvidenceStore(db, embedder, tmp_path)
        result = store.ingest_path("doc.txt")
        chunk_id = int(
            db.conn.execute(
                "SELECT id FROM chunks WHERE source_id=?", (result.source_id,)
            ).fetchone()["id"]
        )
        cases = CaseStore(db)
        case_id = cases.create("Queue review", "Explain the queue anomaly")
        cases.attach_evidence(case_id, [chunk_id])
        cases.add_finding(
            case_id,
            "Queue depth exceeded threshold.",
            0.8,
            evidence_chunk_ids=[chunk_id],
            alternatives=["Late upstream feed"],
            limitations=["Single snapshot"],
        )
        report = cases.report_markdown(case_id)
        assert "80%" in report and "Alternative explanations" in report and "Limitations" in report
    finally:
        db.close()


def test_get_case_loads_all_finding_evidence_in_one_query(tmp_path):
    from mika.cases import CaseStore
    from mika.storage import Database

    db = Database(tmp_path / "cases.sqlite3")
    with db.conn:
        db.conn.execute(
            "INSERT INTO sources(source_key,name,sha256,media_type,ingested_at)"
            " VALUES('k','s.txt','x','text/plain','now')"
        )
        db.conn.executemany(
            "INSERT INTO chunks(source_id,ordinal,content,locator,content_sha256)"
            " VALUES(1,?,?,?,'h')",
            [(i, f"chunk {i}", f"s.txt#chunk-{i}") for i in range(3)],
        )
    store = CaseStore(db)
    case_id = store.create("Batched")
    for chunk in (1, 2, 3):
        store.add_finding(case_id, f"finding {chunk}", 0.5, evidence_chunk_ids=[chunk])

    statements: list[str] = []
    db.conn.set_trace_callback(statements.append)
    detail = store.get_case(case_id)
    db.conn.set_trace_callback(None)

    assert sum("finding_evidence" in sql for sql in statements) == 1
    assert [item["evidence_chunk_ids"] for item in detail["findings"]] == [[1], [2], [3]]
    db.close()
