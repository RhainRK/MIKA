from datetime import UTC, datetime, timedelta
from pathlib import Path

from mika.signals.classify import classify_8k, classify_text
from mika.signals.model import Signal, Target
from mika.signals.relevance import find_mention
from mika.signals.store import list_signals, purge_expired, upsert_signals
from mika.storage import SCHEMA_VERSION, Database

APPLE = Target("H0001", "Apple Inc.", ("Apple Inc",), "AAPL")
ZARVEK = Target("H0002", "Zarvek Maritime Holdings PLC", (), "")


def test_relevance_rejects_generic_single_word_mentions():
    assert find_mention("How to grow an apple tree", APPLE) is None
    assert find_mention("Apple shares slide in early trading", APPLE) is None
    assert find_mention("Apple Inc. faces EU antitrust probe", APPLE) == "apple inc"
    assert find_mention("Why $AAPL could fall further", APPLE) == "$AAPL"
    assert find_mention("Shares of Apple (NASDAQ: AAPL) fell", APPLE) == "NASDAQ:AAPL"
    assert find_mention("pineapple income report", APPLE) is None


def test_relevance_matches_multiword_names_without_legal_suffix():
    assert find_mention("Zarvek Maritime Holdings fined over port fees", ZARVEK) == (
        "zarvek maritime holdings"
    )
    assert find_mention("Zarvek Maritime expands", ZARVEK) is None


def test_classifier_records_categories_terms_and_severity():
    result = classify_text("Regulator opens fraud probe; company files for Chapter 11 bankruptcy")
    assert result.categories == ("financial_distress", "fraud", "legal_regulatory")
    assert {"fraud", "probe", "chapter 11", "bankruptcy"} <= set(result.terms)
    assert result.severity == "high"
    assert classify_text("Quarterly results in line with guidance").severity == "info"
    assert classify_text("CEO steps down after board review").severity == "medium"
    assert classify_text("Treasury adds firm to OFAC sanctions list").categories == ("sanctions",)
    assert classify_text("unsanctioned trading desk").categories == ()


def test_8k_items_map_to_categories():
    assert classify_8k("1.03").severity == "high"
    assert classify_8k("1.03").categories == ("financial_distress",)
    assert classify_8k("4.02,9.01").categories == ("fraud", "governance")
    assert classify_8k("5.02").severity == "medium"
    assert classify_8k("2.02,9.01").severity == "info"


def _signal(external_id: str, *, expires: datetime, severity="high") -> Signal:
    return Signal(
        source="gdelt",
        external_id=external_id,
        holding_id="H0001",
        entity_name="Apple Inc.",
        title=f"Story {external_id}",
        url=f"https://news.example.org/{external_id}",
        published_at="2026-10-01T10:00:00+00:00",
        matched_term="apple inc",
        categories=("fraud",),
        terms=("fraud",),
        severity=severity,
        injection_score=0.0,
        expires_at=expires.isoformat(),
    )


def test_store_is_idempotent_filterable_and_purges_expired(tmp_path: Path):
    db = Database(tmp_path / "s.sqlite3")
    assert db.conn.execute("PRAGMA user_version").fetchone()[0] == SCHEMA_VERSION == 3
    now = datetime(2026, 10, 2, tzinfo=UTC)
    rows = [
        _signal("a", expires=now + timedelta(days=1)),
        _signal("b", expires=now - timedelta(hours=1), severity="low"),
    ]
    assert upsert_signals(db, rows, collected_at=now) == 2
    assert upsert_signals(db, rows, collected_at=now) == 0
    assert [s["external_id"] for s in list_signals(db)] == ["a", "b"]
    assert [s["external_id"] for s in list_signals(db, severity="high")] == ["a"]
    assert list_signals(db, category="fraud", holding_id="H0001", source="gdelt")[0]["terms"] == [
        "fraud"
    ]
    assert purge_expired(db, now=now) == 1
    assert [s["external_id"] for s in list_signals(db)] == ["a"]
    db.close()


def test_existing_v2_database_upgrades_to_v3(tmp_path: Path):
    path = tmp_path / "old.sqlite3"
    db = Database(path)
    db.conn.execute("DROP TABLE signals")
    db.conn.execute("PRAGMA user_version=2")
    db.conn.commit()
    db.close()
    upgraded = Database(path)
    assert upgraded.conn.execute("PRAGMA user_version").fetchone()[0] == 3
    assert upgraded.conn.execute("SELECT COUNT(*) FROM signals").fetchone()[0] == 0
    upgraded.close()
