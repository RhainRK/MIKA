"""Portfolio import, LEI validation and GLEIF/SEC enrichment (fake transports, no network)."""

import csv
import json
from pathlib import Path
from urllib.parse import unquote_plus

import pytest

from mika.connectors.http import RawResponse, SafeClient
from mika.portfolio import enrich_portfolio, import_holdings, valid_lei


def make_lei(prefix18: str) -> str:
    """Independent ISO 7064 MOD 97-10 check-digit computation for fixtures."""
    digits = "".join(str(int(ch, 36)) for ch in prefix18 + "00")
    return prefix18 + f"{98 - int(digits) % 97:02d}"


PARENT = make_lei("SYNTH0000000000001")
CHILD = make_lei("SYNTH0000000000002")
OTHER = make_lei("SYNTH0000000000003")


def test_lei_checksum_against_a_real_published_lei():
    assert valid_lei("HWUPKR0MPOU8FGXBT394")  # Apple Inc., public GLEIF record
    assert not valid_lei("HWUPKR0MPOU8FGXBT395")
    assert not valid_lei("HWUPKR0MPOU8FGXBT39")
    assert not valid_lei("hwupkr0mpou8fgxbt394x")
    assert valid_lei(PARENT) and valid_lei(CHILD)


def _write(path: Path, text: str) -> str:
    path.write_text(text, encoding="utf-8")
    return path.name


def test_import_validates_and_normalises(tmp_path: Path):
    src = _write(
        tmp_path / "mine.csv",
        "issuer,identifier,market_value_usd\n"
        f"Kryllis Cold Chain AS,{CHILD},1500000\n"
        'Zelta Maritime Services,ZELT,"2,000,000"\n',
    )
    result = import_holdings(tmp_path, src)
    assert result["holdings"] == 2 and result["issues"] == []
    rows = list(csv.DictReader((tmp_path / "data" / "portfolio" / "holdings.csv").open()))
    assert [row["holding_id"] for row in rows] == ["H0001", "H0002"]
    assert rows[1]["market_value_usd"] == "2000000.0"


def test_import_reports_bad_rows_and_refuses_empty_or_unsafe_input(tmp_path: Path):
    src = _write(
        tmp_path / "bad.csv",
        "issuer,identifier,market_value_usd\n,X,10\nGood Co,BADLEI0000000000000X,abc\nOk Co,,5\n",
    )
    result = import_holdings(tmp_path, src)
    assert result["holdings"] == 1
    assert {issue["check"] for issue in result["issues"]} == {"missing_issuer", "invalid_value"}
    with pytest.raises(ValueError, match="columns"):
        import_holdings(tmp_path, _write(tmp_path / "x.csv", "name,value\nA,1\n"))
    with pytest.raises(ValueError):
        import_holdings(tmp_path, "../outside.csv")


def _record(lei: str, name: str, *, other: str | None = None, country: str = "XA") -> dict:
    entity = {
        "legalName": {"name": name, "language": "en"},
        "otherNames": [{"name": other, "language": "en", "type": "TRADING_OR_OPERATING_NAME"}]
        if other
        else [],
        "legalAddress": {"country": country},
        "status": "ACTIVE",
    }
    return {
        "type": "lei-records",
        "id": lei,
        "attributes": {"lei": lei, "entity": entity, "registration": {"status": "ISSUED"}},
    }


class Gleif:
    """Fake GLEIF + SEC transport keyed on the decoded request URL."""

    def __init__(self):
        self.calls: list[str] = []
        self.records = {
            CHILD: _record(CHILD, "Kryllis Cold Chain AS"),
            PARENT: _record(PARENT, "Ostvane Port Logistics", other="Ostvane"),
            OTHER: _record(OTHER, "Zelta Maritime Services Inc"),
        }
        self.parents = {CHILD: PARENT}

    def __call__(self, method, url, headers, data, timeout):
        self.calls.append(unquote_plus(url))
        decoded = unquote_plus(url)
        if decoded.startswith("https://www.sec.gov/files/company_tickers.json"):
            assert "@" in headers["User-Agent"], "SEC requires a contact in the User-Agent"
            body = {
                "0": {"cik_str": 99001, "ticker": "ZELT", "title": "Zelta Maritime Services Inc"}
            }
            return RawResponse(200, {"content-type": "application/json"}, json.dumps(body).encode())
        prefix = "https://api.gleif.org/api/v1/lei-records"
        if decoded.startswith(prefix + "?"):
            query = decoded.split("=", 1)[1].split("&", 1)[0].casefold()
            hits = [
                rec
                for rec in self.records.values()
                if query.split()[0] in rec["attributes"]["entity"]["legalName"]["name"].casefold()
            ]
            # GLEIF name search is loose: add a near-miss that must not be accepted.
            hits.append(_record(make_lei("SYNTH0000000000009"), f"{query.title()} Holdings Group"))
            return RawResponse(200, {}, json.dumps({"data": hits}).encode())
        for lei, rec in self.records.items():
            if decoded == f"{prefix}/{lei}":
                return RawResponse(200, {}, json.dumps({"data": rec}).encode())
            if decoded == f"{prefix}/{lei}/direct-parent":
                parent = self.parents.get(lei)
                if parent is None:
                    return RawResponse(404, {}, b'{"errors":[{"status":"404"}]}')
                return RawResponse(200, {}, json.dumps({"data": self.records[parent]}).encode())
            if decoded == f"{prefix}/{lei}/direct-parent-reporting-exception":
                body = {"data": {"attributes": {"reason": "NATURAL_PERSONS"}}}
                return RawResponse(200, {}, json.dumps(body).encode())
        return RawResponse(404, {}, b"")


def _portfolio(tmp_path: Path) -> None:
    import_holdings(
        tmp_path,
        _write(
            tmp_path / "mine.csv",
            "issuer,identifier,market_value_usd\n"
            f"Kryllis Cold Chain AS,{CHILD},1500000\n"
            "Zelta Maritime Services,ZELT,2000000\n"
            "Nonexistent Frontier Fund,,500\n",
        ),
    )


def _rows(path: Path) -> list[dict]:
    return list(csv.DictReader(path.open(encoding="utf-8")))


def test_enrichment_resolves_leis_walks_parents_and_labels_consolidation(tmp_path: Path):
    _portfolio(tmp_path)
    fake = Gleif()
    client = SafeClient(transport=fake, sleep=lambda _: None)
    result = enrich_portfolio(
        tmp_path, client, online={"gleif", "sec"}, contact_email="ops@example.org"
    )
    out = tmp_path / "data" / "screening"
    entities = {row["entity_id"]: row for row in _rows(out / "entities.csv")}
    assert entities[CHILD]["name"] == "Kryllis Cold Chain AS"
    assert entities[PARENT]["aliases"] == "Ostvane"
    [link] = _rows(out / "ownership.csv")
    assert (link["owner_id"], link["owned_id"], link["basis"]) == (
        PARENT,
        CHILD,
        "accounting_consolidation",
    )
    holdings = {row["issuer"]: row for row in _rows(out / "holdings.csv")}
    # Resolved through SEC ticker -> exact GLEIF legal-name match, not the loose near-miss.
    assert holdings["Zelta Maritime Services"]["identifier"] == OTHER
    assert holdings["Nonexistent Frontier Fund"]["identifier"] == ""
    assert result["resolved"] == 2 and result["unresolved"] == ["H0003"]
    assert result["parent_exceptions"][OTHER] == "NATURAL_PERSONS"


def test_ownership_overrides_win_over_gleif(tmp_path: Path):
    _portfolio(tmp_path)
    (tmp_path / "data" / "ownership-overrides.csv").write_text(
        f"owner_id,owned_id,percent\n{PARENT},{CHILD},35\n", encoding="utf-8"
    )
    client = SafeClient(transport=Gleif(), sleep=lambda _: None)
    enrich_portfolio(tmp_path, client, online={"gleif"}, contact_email="")
    [link] = _rows(tmp_path / "data" / "screening" / "ownership.csv")
    assert (link["percent"], link["basis"]) == ("35.0", "override")


def test_offline_enrichment_makes_no_calls_and_still_produces_inputs(tmp_path: Path):
    _portfolio(tmp_path)
    fake = Gleif()
    enrich_portfolio(
        tmp_path, SafeClient(transport=fake, sleep=lambda _: None), online=set(), contact_email=""
    )
    assert fake.calls == []
    entities = _rows(tmp_path / "data" / "screening" / "entities.csv")
    assert {row["name"] for row in entities} >= {"Kryllis Cold Chain AS", "Zelta Maritime Services"}
    assert _rows(tmp_path / "data" / "screening" / "ownership.csv") == []


def test_sec_lookup_without_contact_email_is_skipped_with_a_reason(tmp_path: Path):
    _portfolio(tmp_path)
    fake = Gleif()
    result = enrich_portfolio(
        tmp_path, SafeClient(transport=fake, sleep=lambda _: None), online={"sec"}, contact_email=""
    )
    assert not any("sec.gov" in call for call in fake.calls)
    assert "MIKA_CONTACT_EMAIL" in result["warnings"][0]


def test_cached_gleif_responses_are_reused(tmp_path: Path):
    _portfolio(tmp_path)
    first = Gleif()
    enrich_portfolio(
        tmp_path,
        SafeClient(transport=first, sleep=lambda _: None),
        online={"gleif"},
        contact_email="",
    )
    second = Gleif()
    enrich_portfolio(
        tmp_path,
        SafeClient(transport=second, sleep=lambda _: None),
        online={"gleif"},
        contact_email="",
    )
    assert len(second.calls) < len(first.calls)


def test_overrides_can_name_holdings_instead_of_internal_ids(tmp_path: Path):
    _portfolio(tmp_path)
    (tmp_path / "data" / "ownership-overrides.csv").write_text(
        "owner_id,owner_name,owned_id,owned_name,percent\n"
        ",Zarvek Holdings Group,,Nonexistent Frontier Fund,60\n",
        encoding="utf-8",
    )
    enrich_portfolio(
        tmp_path,
        SafeClient(transport=Gleif(), sleep=lambda _: None),
        online=set(),
        contact_email="",
    )
    entities = {
        row["entity_id"]: row["name"]
        for row in _rows(tmp_path / "data" / "screening" / "entities.csv")
    }
    [link] = _rows(tmp_path / "data" / "screening" / "ownership.csv")
    # The owned side resolves to the holding's own entity, not a new placeholder.
    assert entities[link["owned_id"]] == "Nonexistent Frontier Fund"
    assert sum(name == "Nonexistent Frontier Fund" for name in entities.values()) == 1
    assert entities[link["owner_id"]] == "Zarvek Holdings Group"
