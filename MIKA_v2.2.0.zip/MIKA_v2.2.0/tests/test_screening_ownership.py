from itertools import pairwise

import pytest

from mika.screening.ownership import OwnershipLink, propagate_blocking


def _links(*rows: tuple[str, str, float]) -> list[OwnershipLink]:
    return [OwnershipLink(owner, owned, pct) for owner, owned, pct in rows]


def test_majority_owned_subsidiary_is_blocked():
    result = propagate_blocking({"L"}, _links(("L", "A", 60.0)))
    assert result.blocked == frozenset({"L", "A"})
    assert result.blocked_share["A"] == 60.0
    assert result.contributors["A"] == (("L", 60.0),)


def test_minority_stakes_from_several_blocked_owners_aggregate():
    result = propagate_blocking({"P", "Q"}, _links(("P", "A", 30.0), ("Q", "A", 25.0)))
    assert "A" in result.blocked
    assert result.blocked_share["A"] == 55.0


def test_blocking_cascades_through_chains():
    result = propagate_blocking(
        {"L"}, _links(("L", "A", 60.0), ("A", "B", 55.0), ("B", "C", 100.0))
    )
    assert {"A", "B", "C"} <= result.blocked


def test_exactly_fifty_percent_is_blocked_and_just_below_is_not():
    result = propagate_blocking({"L"}, _links(("L", "A", 50.0), ("L", "B", 49.9)))
    assert "A" in result.blocked
    assert "B" not in result.blocked
    assert result.blocked_share["B"] == pytest.approx(49.9)


def test_unblocked_intermediary_does_not_pass_ownership_through():
    # L owns 49.9% of A (A not blocked), A owns 100% of B: B is not blocked under the 50% rule.
    result = propagate_blocking({"L"}, _links(("L", "A", 49.9), ("A", "B", 100.0)))
    assert "B" not in result.blocked
    assert result.blocked_share.get("B", 0.0) == 0.0


def test_cycles_terminate_and_still_propagate():
    result = propagate_blocking(
        {"L"},
        _links(
            ("L", "A", 60.0), ("A", "B", 50.0), ("B", "A", 40.0), ("X", "Y", 50.0), ("Y", "X", 50.0)
        ),
    )
    assert {"A", "B"} <= result.blocked
    assert not {"X", "Y"} & result.blocked
    assert result.blocked_share["A"] == 100.0


def test_blocking_tree_explains_the_path_back_to_listed_parties():
    result = propagate_blocking(
        {"P", "Q"}, _links(("P", "A", 30.0), ("Q", "A", 25.0), ("A", "B", 70.0))
    )
    tree = result.tree("B")
    assert tree["entity_id"] == "B"
    assert tree["blocked"] is True
    [edge] = tree["owners"]
    assert edge["percent"] == 70.0
    assert edge["node"]["entity_id"] == "A"
    listed = {item["node"]["entity_id"] for item in edge["node"]["owners"]}
    assert listed == {"P", "Q"}
    assert all(item["node"]["listed"] for item in edge["node"]["owners"])


def test_tree_is_cycle_safe_and_depth_bounded():
    result = propagate_blocking({"L"}, _links(("L", "A", 60.0), ("A", "B", 60.0), ("B", "A", 40.0)))
    tree = result.tree("A", max_depth=3)
    assert tree["entity_id"] == "A"
    assert propagate_blocking(set(), []).tree("Z") == {
        "entity_id": "Z",
        "listed": False,
        "blocked": False,
        "blocked_share": 0.0,
        "owners": [],
        "truncated": False,
    }


def test_invalid_threshold_is_rejected():
    with pytest.raises(ValueError):
        propagate_blocking(set(), [], threshold=0.0)


def _naive_fixed_point(listed, links, threshold=50.0):
    """Reference implementation: recompute every entity's blocked share until nothing changes."""
    blocked = set(listed)
    while True:
        share = {}
        for link in links:
            if link.owner_id in blocked:
                share[link.owned_id] = share.get(link.owned_id, 0.0) + link.percent
        grown = blocked | {node for node, value in share.items() if value + 1e-9 >= threshold}
        if grown == blocked:
            return blocked
        blocked = grown


def test_worklist_matches_naive_fixed_point_on_random_graphs():
    import random

    rng = random.Random(7)
    for _ in range(300):
        nodes = [f"N{i}" for i in range(rng.randint(2, 25))]
        links = {}
        for _ in range(rng.randint(0, 60)):
            owner, owned = rng.sample(nodes, 2)
            links[(owner, owned)] = OwnershipLink(
                owner, owned, float(rng.choice([10, 25, 30, 49.9, 50, 60, 100]))
            )
        listed = set(rng.sample(nodes, rng.randint(0, min(3, len(nodes)))))
        expected = _naive_fixed_point(listed, list(links.values()))
        assert propagate_blocking(listed, links.values()).blocked == expected


def test_explanation_tree_size_is_bounded_on_dense_lattices():
    # 8 layers of 10 blocked owners, each holding 10% of every entity in the next layer:
    # an unbounded tree would have 10**8 nodes.
    layers = [[f"L{depth}_{i}" for i in range(10)] for depth in range(9)]
    links = [
        OwnershipLink(owner, owned, 10.0)
        for upper, lower in pairwise(layers)
        for owner in upper
        for owned in lower
    ]
    result = propagate_blocking(set(layers[0]), links)
    assert set(layers[-1][0:1]) <= result.blocked

    def count(node):
        return 1 + sum(count(edge["node"]) for edge in node["owners"])

    tree = result.tree(layers[-1][0], max_nodes=200)
    assert count(tree) <= 200
    assert tree["truncated"] is True


def test_link_basis_is_carried_into_the_explanation_tree():
    result = propagate_blocking({"L"}, [OwnershipLink("L", "A", 100.0, "accounting_consolidation")])
    [edge] = result.tree("A")["owners"]
    assert edge["basis"] == "accounting_consolidation"
    assert result.consolidated_only("A") is True
    mixed = propagate_blocking(
        {"L", "M"},
        [OwnershipLink("L", "A", 100.0, "accounting_consolidation"), OwnershipLink("M", "A", 10.0)],
    )
    assert mixed.consolidated_only("A") is False
