type SearchHit = {
  citation: string;
  source_id: number;
  source_name: string;
  locator: string;
  content: string;
  score: number;
  source_sha256: string;
};

type Health = {
  version: string;
  audit_chain_valid: boolean;
  embedding_backend: string;
  sources: number;
  chunks: number;
};

type Metric = { mean: number | null };
type EvaluationSuite = { name: string; case_count: number; metrics: Record<string, Metric> };
type Evaluation = { status: string; benchmark_suites: EvaluationSuite[] };

type Source = {
  id: number;
  name: string;
  sha256: string;
  quarantined: boolean;
  chunk_count: number;
  ingest_count: number;
  last_ingested_at: string | null;
};

type CaseSummary = {
  id: string;
  title: string;
  status: string;
  evidence_count: number;
  finding_count: number;
};

type CaseDetail = {
  case: { id: string; title: string; objective: string; status: string };
  evidence: Array<{ citation: string; source: string; locator: string }>;
  findings: Array<{ statement: string; confidence: number; evidence_chunk_ids: number[] }>;
};

function requiredElement<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Missing element: ${selector}`);
  return element;
}

const form = requiredElement<HTMLFormElement>("#search-form");
const query = requiredElement<HTMLInputElement>("#query");
const sourceFilter = requiredElement<HTMLSelectElement>("#source-filter");
const caseFilter = requiredElement<HTMLSelectElement>("#case-filter");
const results = requiredElement<HTMLDivElement>("#results");
const health = requiredElement<HTMLDivElement>("#health");
const benchmark = requiredElement<HTMLDivElement>("#benchmark");
const sources = requiredElement<HTMLDivElement>("#sources");
const cases = requiredElement<HTMLDivElement>("#cases");
const caseDetail = requiredElement<HTMLDivElement>("#case-detail");

function metric(value: number | null | undefined): string {
  return value == null ? "n/a" : value.toFixed(3);
}

function text(tag: string, value: string, className?: string): HTMLElement {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}

function button(label: string, action: () => void): HTMLButtonElement {
  const node = document.createElement("button");
  node.type = "button";
  node.textContent = label;
  node.addEventListener("click", action);
  return node;
}

async function getJson<T>(url: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(url, { signal: signal ?? null, headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(response.status === 401 ? "Your session needs a login. Reload this page to sign in." : `Unable to load data (${response.status}). Try Refresh.`);
  return await response.json() as T;
}

async function loadHealth(): Promise<void> {
  const body = await getJson<Health>("/api/health");
  health.replaceChildren(
    text("strong", `MIKA ${body.version}`),
    text("span", body.audit_chain_valid ? "audit verified" : "audit failed"),
    text("span", body.embedding_backend),
    text("span", `${body.sources} sources / ${body.chunks} chunks`),
  );
}

async function loadEvaluation(): Promise<void> {
  const response = await fetch("/api/evaluation/latest", { headers: { Accept: "application/json" } });
  if (response.status === 404) {
    benchmark.textContent = "No evaluation report. Run mika evaluate.";
    return;
  }
  if (!response.ok) throw new Error(`/api/evaluation/latest: ${response.status}`);
  const body = await response.json() as Evaluation;
  const suite = body.benchmark_suites.at(-1);
  if (!suite) return;
  const summary = text("div", `${suite.name} | ${suite.case_count} cases | ${body.status}`);
  const metrics = document.createElement("div");
  metrics.className = "metrics";
  metrics.append(
    text("span", `Recall@k ${metric(suite.metrics.recall_at_k?.mean)}`),
    text("span", `MRR ${metric(suite.metrics.mrr?.mean)}`),
    text("span", `nDCG ${metric(suite.metrics.ndcg_at_k?.mean)}`),
  );
  benchmark.replaceChildren(summary, metrics);
}

function renderHits(hits: SearchHit[]): void {
  requiredElement("#result-count").textContent = `${hits.length} matching passages`;
  if (hits.length === 0) {
    results.replaceChildren(text("p", "No matching evidence. Try fewer words or reset the source and case filters.", "empty"));
    return;
  }
  const nodes = hits.map((hit) => {
    const article = document.createElement("article");
    const header = document.createElement("header");
    header.append(text("strong", hit.citation), document.createTextNode(` | ${hit.source_name}`));
    article.append(
      header,
      text("small", `${hit.locator} | score ${hit.score.toFixed(4)}`),
      text("p", hit.content),
      text("code", `sha256:${hit.source_sha256.slice(0, 16)}...`),
    );
    return article;
  });
  results.replaceChildren(...nodes);
}

async function loadSources(): Promise<void> {
  const body = await getJson<Source[]>("/api/sources");
  const options = [new Option("All sources", "")];
  for (const source of body) options.push(new Option(`${source.id}: ${source.name}`, String(source.id)));
  sourceFilter.replaceChildren(...options);
  const rows = body.map((source) => {
    const row = document.createElement("div");
    row.className = "row";
    const main = document.createElement("div");
    main.className = "row-main";
    const title = text("div", `${source.name}${source.quarantined ? " · Quarantined" : ""}`, "row-title");
    if (source.quarantined) title.classList.add("warning");
    main.append(
      title,
      text("div", `${source.chunk_count} chunks | ${source.ingest_count} imports`, "row-meta"),
      text("code", `sha256:${source.sha256.slice(0, 16)}...`),
    );
    row.append(main, button("Search source", () => { sourceFilter.value = String(source.id); location.hash = "search"; showView(); query.focus(); }));
    return row;
  });
  sources.replaceChildren(...rows.length ? rows : [text("p", "Your library is empty. Open ‘How do I add evidence?’ above to import your first file.", "empty")]);
}

let caseRequest = 0;
async function renderCase(id: string): Promise<void> {
  const request = ++caseRequest;
  caseDetail.textContent = "Loading case...";
  let body: CaseDetail;
  try { body = await getJson<CaseDetail>(`/api/cases/${encodeURIComponent(id)}`); }
  catch (error) { if (request === caseRequest) caseDetail.textContent = error instanceof Error ? error.message : "Unable to load case."; return; }
  if (request !== caseRequest) return;
  const heading = text("div", body.case.title, "row-title");
  const objective = text("p", body.case.objective || "No objective recorded.");
  const evidenceTitle = text("strong", `Evidence register (${body.evidence.length})`);
  const evidence = document.createElement("ul");
  for (const item of body.evidence) evidence.append(text("li", `${item.citation} | ${item.source} | ${item.locator}`));
  const findingsTitle = text("strong", `Findings (${body.findings.length})`);
  const findings = document.createElement("ul");
  for (const item of body.findings) findings.append(text("li", `${Math.round(item.confidence * 100)}% | ${item.statement}`));
  const actions = document.createElement("div");
  actions.className = "actions";
  const report = document.createElement("a");
  report.className = "button";
  report.href = `/api/cases/${encodeURIComponent(id)}/report`;
  report.textContent = "Download report";
  actions.append(report, button("Search this case", () => { caseFilter.value = id; location.hash = "search"; showView(); query.focus(); }));
  caseDetail.replaceChildren(heading, objective, evidenceTitle, evidence, findingsTitle, findings, actions);
}

async function loadCases(): Promise<void> {
  const body = await getJson<CaseSummary[]>("/api/cases");
  const options = [new Option("All evidence", "")];
  for (const item of body) options.push(new Option(item.title, item.id));
  caseFilter.replaceChildren(...options);
  const rows = body.map((item) => {
    const row = document.createElement("div");
    row.className = "row";
    const main = document.createElement("div");
    main.className = "row-main";
    main.append(
      text("div", item.title, "row-title"),
      text("div", `${item.status} | ${item.evidence_count} evidence | ${item.finding_count} findings`, "row-meta"),
    );
    row.append(main, button("Review", () => { void renderCase(item.id); }));
    return row;
  });
  cases.replaceChildren(...rows.length ? rows : [text("p", "No cases yet. Create a case with the MIKA command line, then select Refresh.", "empty")]);
}


/* Navigation */
function showView(): void {
  const name = ["search", "sources", "cases", "system"].includes(location.hash.slice(1)) ? location.hash.slice(1) : "search";
  document.querySelectorAll<HTMLElement>(".view").forEach(view => { view.hidden = view.id !== `view-${name}`; });
  document.querySelectorAll<HTMLAnchorElement>("[data-view]").forEach(link => {
    if (link.dataset.view === name) link.setAttribute("aria-current", "page");
    else link.removeAttribute("aria-current");
  });
  requiredElement("#page-name").textContent = name.charAt(0).toUpperCase() + name.slice(1);
  document.title = `MIKA · ${name.charAt(0).toUpperCase() + name.slice(1)}`;
}
window.addEventListener("hashchange", showView);
showView();
requiredElement("#clear-filters").addEventListener("click", () => { sourceFilter.value = ""; caseFilter.value = ""; query.focus(); });
/* Search */
let searchController: AbortController | undefined;
form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const q = query.value.trim();
  if (!q) return;
  searchController?.abort();
  const controller = new AbortController();
  searchController = controller;
  const params = new URLSearchParams({ q, k: "6" });
  if (sourceFilter.value) params.append("source_id", sourceFilter.value);
  if (caseFilter.value) params.set("case_id", caseFilter.value);
  results.textContent = "Searching evidence...";
  results.setAttribute("aria-busy", "true");
  requiredElement("#result-count").textContent = "Searching...";
  try { renderHits(await getJson<SearchHit[]>(`/api/search?${params.toString()}`, controller.signal)); }
  catch (error: unknown) {
    if (controller.signal.aborted) return;
    results.textContent = error instanceof Error ? error.message : "Search failed. Try again.";
    requiredElement("#result-count").textContent = "Search unavailable";
  } finally { if (searchController === controller) results.removeAttribute("aria-busy"); }
});
/* Workspace refresh */
async function refresh(): Promise<void> {
  const control = requiredElement<HTMLButtonElement>("#refresh");
  control.disabled = true;
  control.textContent = "Refreshing...";
  const sourceId = sourceFilter.value;
  const caseId = caseFilter.value;
  await Promise.all([
    [loadHealth, health], [loadEvaluation, benchmark], [loadSources, sources], [loadCases, cases],
  ].map(async ([loader, target]) => {
    try { await (loader as () => Promise<void>)(); }
    catch (error) { (target as HTMLElement).textContent = error instanceof Error ? error.message : "Unable to load. Try Refresh."; }
  }));
  if ([...sourceFilter.options].some(option => option.value === sourceId)) sourceFilter.value = sourceId;
  if ([...caseFilter.options].some(option => option.value === caseId)) caseFilter.value = caseId;
  control.disabled = false;
  control.textContent = "↻ Refresh";
}
requiredElement("#refresh").addEventListener("click", () => { void refresh(); });
void refresh();
