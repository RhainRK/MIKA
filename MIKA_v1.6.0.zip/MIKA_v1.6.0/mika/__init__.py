"""MIKA: Model Integrity & Knowledge Analysis."""

__version__ = "1.6.0"
