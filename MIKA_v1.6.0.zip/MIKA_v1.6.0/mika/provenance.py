from __future__ import annotations

import csv
import hashlib
import json
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import numpy as np

from .embeddings import Embedder
from .security import assess_prompt_injection, safe_workspace_path
from .storage import Database


@dataclass(frozen=True, slots=True)
class IngestResult:
    source_id: int
    source_key: str
    name: str
    chunks: int
    sha256: str
    injection_score: float
    injection_signals: tuple[str, ...]
    quarantined: bool


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _extract_text(path: Path) -> tuple[str, str]:
    suffix = path.suffix.casefold()
    if suffix in {".txt", ".md", ".rst", ".log"}:
        return path.read_text(encoding="utf-8", errors="replace"), "text/plain"
    if suffix == ".json":
        obj = json.loads(path.read_text(encoding="utf-8"))
        return json.dumps(obj, indent=2, ensure_ascii=False), "application/json"
    if suffix == ".jsonl":
        lines = [
            json.dumps(json.loads(line), ensure_ascii=False)
            for line in path.read_text(encoding="utf-8", errors="replace").splitlines()
            if line.strip()
        ]
        return "\n".join(lines), "application/x-ndjson"
    if suffix == ".csv":
        with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as handle:
            reader = csv.DictReader(handle)
            rows = [
                f"row {index}: " + " | ".join(f"{key}={value}" for key, value in row.items())
                for index, row in enumerate(reader, start=2)
            ]
        return "\n\n".join(rows), "text/csv"
    raise ValueError(f"Unsupported file type: {path.suffix or '<none>'}")


def chunk_text(text: str, size: int = 1200, overlap: int = 180) -> list[str]:
    if size <= overlap or size < 200:
        raise ValueError("Chunk size must exceed overlap and be at least 200 characters")
    raw = text.replace("\r\n", "\n").replace("\r", "\n").strip()
    if not raw:
        return []
    paragraphs = [
        "\n".join(line.rstrip() for line in block.splitlines()).strip()
        for block in re.split(r"\n\s*\n+", raw)
    ]
    paragraphs = [block for block in paragraphs if block]
    chunks: list[str] = []
    for paragraph in paragraphs:
        if len(paragraph) <= size:
            chunks.append(paragraph)
            continue
        start = 0
        while start < len(paragraph):
            end = min(len(paragraph), start + size)
            if end < len(paragraph):
                boundary = max(
                    paragraph.rfind("\n", start + size // 2, end),
                    paragraph.rfind(". ", start + size // 2, end),
                )
                if boundary > start:
                    end = boundary + 1
            chunk = paragraph[start:end].strip()
            if chunk:
                chunks.append(chunk)
            if end >= len(paragraph):
                break
            start = max(start + 1, end - overlap)
    return chunks


class EvidenceStore:
    def __init__(
        self, db: Database, embedder: Embedder, workspace: Path, quarantine_threshold: float = 0.75
    ) -> None:
        self.db = db
        self.embedder = embedder
        self.workspace = workspace
        self.quarantine_threshold = max(0.0, min(float(quarantine_threshold), 1.0))

    def ingest_path(
        self, candidate: str | Path, *, metadata: dict[str, object] | None = None
    ) -> IngestResult:
        path = safe_workspace_path(self.workspace, candidate)
        if not path.is_file():
            raise ValueError("Input must be a file inside the configured workspace")
        raw = path.read_bytes()
        text, media_type = _extract_text(path)
        digest = _sha256(raw)
        assessment = assess_prompt_injection(text)
        quarantined = assessment.score >= self.quarantine_threshold
        source_key = f"sha256:{digest}"
        now = datetime.now(UTC).isoformat()
        metadata_json = json.dumps(metadata or {}, ensure_ascii=False, sort_keys=True)
        contents = chunk_text(text)
        content_hashes = [_sha256(content.encode()) for content in contents]

        with self.db.conn:
            existing_source = self.db.conn.execute(
                "SELECT id FROM sources WHERE source_key=?", (source_key,)
            ).fetchone()
            if existing_source is None:
                cursor = self.db.conn.execute(
                    """
                    INSERT INTO sources(
                        source_key,name,path,sha256,media_type,metadata_json,
                        injection_score,injection_signals_json,quarantined,ingested_at,
                        last_ingested_at,ingest_count)
                    VALUES(?,?,?,?,?,?,?,?,?,?,?,1)
                    """,
                    (
                        source_key,
                        path.name,
                        str(path),
                        digest,
                        media_type,
                        metadata_json,
                        assessment.score,
                        json.dumps(assessment.signals),
                        int(quarantined),
                        now,
                        now,
                    ),
                )
                source_id = int(cursor.lastrowid)
            else:
                source_id = int(existing_source["id"])
                self.db.conn.execute(
                    """
                    UPDATE sources SET
                        name=?,path=?,media_type=?,metadata_json=?,injection_score=?,
                        injection_signals_json=?,quarantined=?,last_ingested_at=?,
                        ingest_count=ingest_count+1
                    WHERE id=?
                    """,
                    (
                        path.name,
                        str(path),
                        media_type,
                        metadata_json,
                        assessment.score,
                        json.dumps(assessment.signals),
                        int(quarantined),
                        now,
                        source_id,
                    ),
                )

            existing_chunks = {
                int(row["ordinal"]): row
                for row in self.db.conn.execute(
                    """
                    SELECT id,ordinal,content_sha256,embedding,embedding_model
                    FROM chunks WHERE source_id=? ORDER BY ordinal
                    """,
                    (source_id,),
                ).fetchall()
            }
            identity = self.embedder.identity
            stale_ordinals = set(existing_chunks) - set(range(len(contents)))
            if stale_ordinals:
                stale_ids = [int(existing_chunks[item]["id"]) for item in stale_ordinals]
                if self.db.fts_enabled:
                    self.db.conn.executemany(
                        "DELETE FROM chunks_fts WHERE chunk_id=?", [(item,) for item in stale_ids]
                    )
                self.db.conn.executemany(
                    "DELETE FROM chunks WHERE id=?", [(item,) for item in stale_ids]
                )

            work: list[tuple[int, str, str, int | None]] = []
            for ordinal, (content, content_hash) in enumerate(
                zip(contents, content_hashes, strict=True)
            ):
                row = existing_chunks.get(ordinal)
                locator = f"{path.name}#chunk-{ordinal + 1}"
                if row is None:
                    work.append((ordinal, content, locator, None))
                    continue
                chunk_id = int(row["id"])
                same_content = str(row["content_sha256"]) == content_hash
                same_embedding = bool(row["embedding"]) and row["embedding_model"] == identity
                if same_content and same_embedding:
                    self.db.conn.execute(
                        "UPDATE chunks SET locator=? WHERE id=?", (locator, chunk_id)
                    )
                    continue
                work.append((ordinal, content, locator, chunk_id))

            vectors = self.embedder.iter_encode_many(item[1] for item in work)
            for (ordinal, content, locator, chunk_id), vector in zip(work, vectors, strict=True):
                vector = vector.astype(np.float32, copy=False)
                content_hash = content_hashes[ordinal]
                if chunk_id is None:
                    cursor = self.db.conn.execute(
                        """
                        INSERT INTO chunks(
                            source_id,ordinal,content,locator,content_sha256,
                            embedding,embedding_model)
                        VALUES(?,?,?,?,?,?,?)
                        """,
                        (
                            source_id,
                            ordinal,
                            content,
                            locator,
                            content_hash,
                            vector.tobytes(),
                            identity,
                        ),
                    )
                    chunk_id = int(cursor.lastrowid)
                else:
                    if self.db.fts_enabled:
                        self.db.conn.execute("DELETE FROM chunks_fts WHERE chunk_id=?", (chunk_id,))
                    self.db.conn.execute(
                        """
                        UPDATE chunks
                        SET content=?,locator=?,content_sha256=?,embedding=?,embedding_model=?
                        WHERE id=?
                        """,
                        (
                            content,
                            locator,
                            content_hash,
                            vector.tobytes(),
                            identity,
                            chunk_id,
                        ),
                    )
                if self.db.fts_enabled:
                    self.db.conn.execute(
                        "INSERT INTO chunks_fts(chunk_id,content) VALUES(?,?)", (chunk_id, content)
                    )

        count = int(
            self.db.conn.execute(
                "SELECT COUNT(*) AS n FROM chunks WHERE source_id=?", (source_id,)
            ).fetchone()["n"]
        )
        return IngestResult(
            source_id,
            source_key,
            path.name,
            count,
            digest,
            assessment.score,
            assessment.signals,
            quarantined,
        )

    def list_sources(self, *, include_quarantined: bool = True) -> list[dict[str, Any]]:
        rows = self.db.conn.execute(
            """
            SELECT s.*,COUNT(c.id) AS chunk_count
            FROM sources s LEFT JOIN chunks c ON c.source_id=s.id
            WHERE (? OR s.quarantined=0)
            GROUP BY s.id ORDER BY s.id
            """,
            (int(include_quarantined),),
        ).fetchall()
        return [self._source_record(row) for row in rows]

    def get_source(self, source_id: int) -> dict[str, Any]:
        row = self.db.conn.execute(
            """
            SELECT s.*,COUNT(c.id) AS chunk_count
            FROM sources s LEFT JOIN chunks c ON c.source_id=s.id
            WHERE s.id=? GROUP BY s.id
            """,
            (int(source_id),),
        ).fetchone()
        if row is None:
            raise ValueError(f"Unknown source: {source_id}")
        source = self._source_record(row)
        chunks = self.db.conn.execute(
            """
            SELECT id,ordinal,locator,content_sha256
            FROM chunks WHERE source_id=? ORDER BY ordinal
            """,
            (int(source_id),),
        ).fetchall()
        source["chunks"] = [dict(item) for item in chunks]
        return source

    def _source_record(self, row: Any) -> dict[str, Any]:
        item = dict(row)
        item["quarantined"] = bool(item["quarantined"])
        if item.get("path"):
            try:
                item["path"] = str(
                    Path(item["path"]).resolve().relative_to(self.workspace.resolve())
                )
            except ValueError:
                item["path"] = None
        item["metadata"] = json.loads(item.pop("metadata_json"))
        item["injection_signals"] = json.loads(item.pop("injection_signals_json"))
        return item
