# Upgrade to MIKA 1.6

Follow the upgrade section in WINDOWS_SETUP.md. Keep the previous project folder and data backup until the new installation is verified.
