# MIKA 1.6.0

A local evidence search and case review workspace with a browser interface.

Start with [WINDOWS_SETUP.md](WINDOWS_SETUP.md). The compiled dashboard is included. See [RELEASE_NOTES.md](RELEASE_NOTES.md) for the UI changes and [SECURITY_REVIEW.md](SECURITY_REVIEW.md) for validation limits.
