# MIKA 1.6.0 UI update

Built from the saved MIKA 1.5.0 full release. Backend and database behaviour are preserved.

- Light interface with persistent Search, Sources, Cases and System navigation.
- Responsive layouts, visible keyboard focus, skip navigation and labelled filters.
- Browser Back/Forward navigation and clear empty/loading/error states.
- Source-to-search and case-to-search navigation, result counts and filter reset.
- Cancelled stale searches and guarded out-of-order case responses.
- Independent refresh errors; a missing evaluation no longer blocks other sections.
- Compiled dashboard included, with a local Windows launcher and setup guide.

Case editing and file imports remain CLI operations. No cloud hosting, external fonts or new runtime dependencies were added.
