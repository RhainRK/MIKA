# Dependency status

MIKA v1.4.0 adds no Python or npm dependencies relative to v1.3.2.

The saved v1.3.2 review recorded clean Bandit, pip-audit and npm-audit results for its resolved environment, including the core/server and optional Ollama Python packages. The interrupted v1.4 work also reported a clear installed dependency audit before the chat limit.

This reconstruction container could not access package registries, so registry-backed scanners were not rerun here. Run the commands in `WINDOWS_SETUP.md` on the target machine before using private evidence.
