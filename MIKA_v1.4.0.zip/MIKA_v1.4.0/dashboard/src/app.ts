type SearchHit = {
  citation: string;
  source_id: number;
  source_name: string;
  locator: string;
  content: string;
  score: number;
  source_sha256: string;
};

type Health = {
  version: string;
  audit_chain_valid: boolean;
  embedding_backend: string;
  sources: number;
  chunks: number;
};

type Metric = { mean: number | null };
type EvaluationSuite = { name: string; case_count: number; metrics: Record<string, Metric> };
type Evaluation = { status: string; benchmark_suites: EvaluationSuite[] };

type Source = {
  id: number;
  name: string;
  sha256: string;
  quarantined: boolean;
  chunk_count: number;
  ingest_count: number;
  last_ingested_at: string | null;
};

type CaseSummary = {
  id: string;
  title: string;
  status: string;
  evidence_count: number;
  finding_count: number;
};

type CaseDetail = {
  case: { id: string; title: string; objective: string; status: string };
  evidence: Array<{ citation: string; source: string; locator: string }>;
  findings: Array<{ statement: string; confidence: number; evidence_chunk_ids: number[] }>;
};

function requiredElement<T extends Element>(selector: string): T {
  const element = document.querySelector<T>(selector);
  if (!element) throw new Error(`Missing element: ${selector}`);
  return element;
}

const form = requiredElement<HTMLFormElement>("#search-form");
const query = requiredElement<HTMLInputElement>("#query");
const sourceFilter = requiredElement<HTMLSelectElement>("#source-filter");
const caseFilter = requiredElement<HTMLSelectElement>("#case-filter");
const results = requiredElement<HTMLDivElement>("#results");
const health = requiredElement<HTMLDivElement>("#health");
const benchmark = requiredElement<HTMLDivElement>("#benchmark");
const sources = requiredElement<HTMLDivElement>("#sources");
const cases = requiredElement<HTMLDivElement>("#cases");
const caseDetail = requiredElement<HTMLDivElement>("#case-detail");

function metric(value: number | null | undefined): string {
  return value == null ? "n/a" : value.toFixed(3);
}

function text(tag: string, value: string, className?: string): HTMLElement {
  const node = document.createElement(tag);
  node.textContent = value;
  if (className) node.className = className;
  return node;
}

function button(label: string, action: () => void): HTMLButtonElement {
  const node = document.createElement("button");
  node.type = "button";
  node.textContent = label;
  node.addEventListener("click", action);
  return node;
}

async function getJson<T>(url: string): Promise<T> {
  const response = await fetch(url, { headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`${url}: ${response.status}`);
  return await response.json() as T;
}

async function loadHealth(): Promise<void> {
  const body = await getJson<Health>("/api/health");
  health.replaceChildren(
    text("strong", `MIKA ${body.version}`),
    text("span", body.audit_chain_valid ? "audit verified" : "audit failed"),
    text("span", body.embedding_backend),
    text("span", `${body.sources} sources / ${body.chunks} chunks`),
  );
}

async function loadEvaluation(): Promise<void> {
  const response = await fetch("/api/evaluation/latest", { headers: { Accept: "application/json" } });
  if (response.status === 404) {
    benchmark.textContent = "No evaluation report. Run mika evaluate.";
    return;
  }
  if (!response.ok) throw new Error(`/api/evaluation/latest: ${response.status}`);
  const body = await response.json() as Evaluation;
  const suite = body.benchmark_suites.at(-1);
  if (!suite) return;
  const summary = text("div", `${suite.name} | ${suite.case_count} cases | ${body.status}`);
  const metrics = document.createElement("div");
  metrics.className = "metrics";
  metrics.append(
    text("span", `Recall@k ${metric(suite.metrics.recall_at_k?.mean)}`),
    text("span", `MRR ${metric(suite.metrics.mrr?.mean)}`),
    text("span", `nDCG ${metric(suite.metrics.ndcg_at_k?.mean)}`),
  );
  benchmark.replaceChildren(summary, metrics);
}

function renderHits(hits: SearchHit[]): void {
  if (hits.length === 0) {
    results.replaceChildren(text("p", "No trusted evidence matched."));
    return;
  }
  const nodes = hits.map((hit) => {
    const article = document.createElement("article");
    const header = document.createElement("header");
    header.append(text("strong", hit.citation), document.createTextNode(` | ${hit.source_name}`));
    article.append(
      header,
      text("small", `${hit.locator} | score ${hit.score.toFixed(4)}`),
      text("p", hit.content),
      text("code", `sha256:${hit.source_sha256.slice(0, 16)}...`),
    );
    return article;
  });
  results.replaceChildren(...nodes);
}

async function loadSources(): Promise<void> {
  const body = await getJson<Source[]>("/api/sources");
  const options = [new Option("All sources", "")];
  for (const source of body) options.push(new Option(`${source.id}: ${source.name}`, String(source.id)));
  sourceFilter.replaceChildren(...options);
  const rows = body.map((source) => {
    const row = document.createElement("div");
    row.className = "row";
    const main = document.createElement("div");
    main.className = "row-main";
    const title = text("div", `${source.id}: ${source.name}`, "row-title");
    if (source.quarantined) title.classList.add("warning");
    main.append(
      title,
      text("div", `${source.chunk_count} chunks | ${source.ingest_count} imports`, "row-meta"),
      text("code", `sha256:${source.sha256.slice(0, 16)}...`),
    );
    row.append(main, button("Filter", () => { sourceFilter.value = String(source.id); query.focus(); }));
    return row;
  });
  sources.replaceChildren(...rows.length ? rows : [text("p", "No sources ingested.")]);
}

async function renderCase(id: string): Promise<void> {
  const body = await getJson<CaseDetail>(`/api/cases/${encodeURIComponent(id)}`);
  const heading = text("div", body.case.title, "row-title");
  const objective = text("p", body.case.objective || "No objective recorded.");
  const evidenceTitle = text("strong", `Evidence register (${body.evidence.length})`);
  const evidence = document.createElement("ul");
  for (const item of body.evidence) evidence.append(text("li", `${item.citation} | ${item.source} | ${item.locator}`));
  const findingsTitle = text("strong", `Findings (${body.findings.length})`);
  const findings = document.createElement("ul");
  for (const item of body.findings) findings.append(text("li", `${Math.round(item.confidence * 100)}% | ${item.statement}`));
  const actions = document.createElement("div");
  actions.className = "actions";
  const report = document.createElement("a");
  report.className = "button";
  report.href = `/api/cases/${encodeURIComponent(id)}/report`;
  report.textContent = "Download report";
  actions.append(report, button("Search this case", () => { caseFilter.value = id; query.focus(); }));
  caseDetail.replaceChildren(heading, objective, evidenceTitle, evidence, findingsTitle, findings, actions);
}

async function loadCases(): Promise<void> {
  const body = await getJson<CaseSummary[]>("/api/cases");
  const options = [new Option("All evidence", "")];
  for (const item of body) options.push(new Option(item.title, item.id));
  caseFilter.replaceChildren(...options);
  const rows = body.map((item) => {
    const row = document.createElement("div");
    row.className = "row";
    const main = document.createElement("div");
    main.className = "row-main";
    main.append(
      text("div", item.title, "row-title"),
      text("div", `${item.status} | ${item.evidence_count} evidence | ${item.finding_count} findings`, "row-meta"),
    );
    row.append(main, button("Review", () => { void renderCase(item.id); }));
    return row;
  });
  cases.replaceChildren(...rows.length ? rows : [text("p", "No cases created.")]);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  const q = query.value.trim();
  if (!q) return;
  const params = new URLSearchParams({ q, k: "6" });
  if (sourceFilter.value) params.append("source_id", sourceFilter.value);
  if (caseFilter.value) params.set("case_id", caseFilter.value);
  results.textContent = "Searching evidence...";
  try {
    renderHits(await getJson<SearchHit[]>(`/api/search?${params.toString()}`));
  } catch (error: unknown) {
    results.textContent = error instanceof Error ? error.message : "Search failed";
  }
});

Promise.all([loadHealth(), loadEvaluation(), loadSources(), loadCases()]).catch((error: unknown) => {
  health.textContent = error instanceof Error ? error.message : "System status unavailable";
});
