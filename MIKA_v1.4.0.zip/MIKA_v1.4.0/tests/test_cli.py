import json
from pathlib import Path

import pytest

from mika.app import MikaApp
from mika.cli import _parser, main
from mika.config import Settings
from mika.embeddings import Embedder


def _config(tmp_path: Path) -> Settings:
    return Settings(
        db_path=tmp_path / "mika.sqlite3",
        audit_path=tmp_path / "audit.jsonl",
        telemetry_path=tmp_path / "telemetry.jsonl",
        workspace=tmp_path,
        embedding_model="__force_hash_backend__",
    ).resolve()


def test_parser_builds_primary_commands() -> None:
    parser = _parser()
    assert parser.parse_args(["search", "evidence"]).command == "search"
    assert parser.parse_args(["tools", "--role", "viewer"]).role == "viewer"
    assert parser.parse_args(["graph-path", "edges.csv", "A", "B"]).max_depth == 6


def test_doctor_search_and_tool_listing(tmp_path: Path, monkeypatch, capsys) -> None:
    config = _config(tmp_path)
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"

    with MikaApp(config, embedder=embedder) as seed:
        (tmp_path / "evidence.txt").write_text(
            "CASE-900 queue latency exceeded the review threshold.",
            encoding="utf-8",
        )
        seed.evidence.ingest_path("evidence.txt")
    (tmp_path / "dataset.csv").write_text("id,value\n1,ok\n", encoding="utf-8")

    import mika.cli as cli_module

    def factory() -> MikaApp:
        return MikaApp(config, embedder=embedder)

    class FakeLLM:
        model = "test-model"

        def __init__(self, *args, **kwargs) -> None:
            pass

        def chat(self, messages, *, temperature=0.0, max_tokens=700):
            from mika.llm import ModelResponse

            return ModelResponse("Supported [S1:C1].", 0.01, 10, 5, 500.0)

        def close(self) -> None:
            pass

    monkeypatch.setattr(cli_module, "MikaApp", factory)
    monkeypatch.setattr(cli_module, "OllamaClient", FakeLLM)

    assert main(["doctor"]) == 0
    assert main(["search", "CASE-900", "--k", "3", "--source", "1"]) == 0
    assert main(["sources"]) == 0
    assert main(["source", "1"]) == 0
    assert main(["tools", "--role", "viewer"]) == 0
    assert main(["ask", "CASE-900", "--k", "3"]) == 0
    assert main(["profile", "dataset.csv"]) == 0

    capsys.readouterr()
    assert main(["case-create", "CLI case", "--objective", "Review threshold"]) == 0
    case_id = json.loads(capsys.readouterr().out)["case_id"]
    assert main(["case-attach", case_id, "1"]) == 0
    assert main(["case-finding", case_id, "Threshold exceeded", "--confidence", "0.8", "--evidence", "1"]) == 0
    assert main(["cases"]) == 0
    report = tmp_path / "report.md"
    assert main(["case-report", case_id, "--output", str(report)]) == 0
    assert report.exists()
    assert main(["search", "CASE-900", "--case", case_id]) == 0
    assert main(["backup", "--output", "backup.sqlite3"]) == 0
    assert (tmp_path / "backup.sqlite3").exists()
    assert main(["audit-verify"]) == 0
    assert main(["tool-run", "dataset.profile", "--args", '{"path":"dataset.csv"}', "--role", "viewer"]) == 0
    with pytest.raises(SystemExit):
        main(["tool-run", "dataset.profile", "--args", "[]", "--role", "viewer"])
    with pytest.raises(SystemExit):
        main(["serve", "--host", "0.0.0.0"])

    output = capsys.readouterr().out
    assert '"citation": "S1:C1"' in output
    assert '"finding_id"' in output


def test_evaluate_command_writes_report(tmp_path: Path) -> None:
    output = tmp_path / "evaluation.json"
    assert main(["evaluate", "--output", str(output), "--repeats", "2"]) == 0
    assert output.exists()
