# MIKA v1.4.0 upgrade

Use [WINDOWS_SETUP.md](WINDOWS_SETUP.md) for the complete upgrade. Install v1.4.0 in a new folder, keep the old project as a backup, copy the old `data` folder only while both versions are stopped, then run `mika doctor`, `mika audit-verify` and `mika backup`.

The v1.4.0 database migration is automatic. It adds source-ingest tracking fields without deleting existing sources, cases, findings or evidence links.
