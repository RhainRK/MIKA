# MIKA v1.4.0 release notes

MIKA v1.4.0 continues the v1.3.2 local-only security model and turns the analyst console into a more complete evidence workspace.

## Main changes

- Repeat imports preserve chunk IDs when evidence is unchanged, protecting case and finding references.
- The source register exposes source metadata, quarantine state, import count and chunk inventory without exposing absolute workspace paths through the UI/API.
- Search can be restricted to selected sources, chunks or a case evidence register.
- Local-model answers now return citation validation metadata and flag invented citation labels.
- Findings automatically register their cited evidence with the case.
- Database schema migrations are tracked and the CLI can create integrity-checked SQLite backups.
- Semantic retrieval is processed in bounded batches and repairs corrupt, non-finite or stale embeddings on demand.
- The dashboard adds source browsing, case review, filtered search and Markdown report downloads.

## Validation

- 121 Python tests passed in the reconstruction environment.
- Measured Python branch coverage: 88%.
- TypeScript typecheck and build passed.
- Release publication check passed.
- A 12,000-chunk synthetic comparison reduced peak `tracemalloc` search allocation from about 49.3 MiB in v1.3.2 to about 1.51 MiB in v1.4.0, with the measured query time changing from about 0.277 s to 0.209 s on that one build environment. These figures are a regression comparison, not a production benchmark.

## Security scope

The browser service remains a single-user loopback application. It is not intended for public hosting, tunnelling or multi-user deployment. The release adds no new Python or npm dependencies beyond the v1.3.2 dependency set.

The previous v1.3.2 dependency audit was clean for its installed core/server/Ollama environment. The current reconstruction environment had no package-registry access, so registry-backed scanners were not rerun here. Run `pip-audit` and `npm audit` on the target Windows installation before using private evidence.
