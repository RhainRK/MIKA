# MIKA v1.4.0 - Windows and VS Code setup

Install v1.4.0 in a new folder. Keep the old MIKA folder until the new installation and your data backup are verified.

## 1. Stop the old version

In the terminal running MIKA, press Ctrl+C and close the browser tab. Do not delete the old project or its `data` folder yet.

## 2. Python

MIKA supports Python 3.11+. For this Windows setup, use Python 3.13.x. Python 3.13.15 is the current 3.13 maintenance release as of this release.

Check it in PowerShell:

```powershell
py -3.13 --version
```

## 3. Extract the new release

Extract `MIKA_v1.4.0_FULL.zip` to a new directory. Open the inner `MIKA_v1.4.0` folder in VS Code. It should contain `pyproject.toml`, `main.py`, `mika`, `dashboard`, `samples` and `tests`.

Do not copy the old `.venv`, `node_modules`, `.env` or generated dashboard files into the new project.

## 4. Create the Python environment

From the project root:

```powershell
py -3.13 -m venv .venv
```

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools
```

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[server]"
```

```powershell
.\.venv\Scripts\mika.exe --version
```

Expected: `MIKA 1.4.0`.

## 5. Verify the source tree

Before creating local runtime data:

```powershell
.\.venv\Scripts\python.exe scripts\release_check.py
```

Expected: `release check passed`.

## 6. Dashboard

The release includes a compiled dashboard, but install the locked frontend dependencies so you can verify or rebuild it:

```powershell
cd dashboard
npm.cmd ci --ignore-scripts
npm.cmd run typecheck
npm.cmd run build
npm.cmd audit
cd ..
```

## 7. Run the regression and dependency checks

```powershell
.\.venv\Scripts\python.exe -m pip install "pytest>=9,<10" "pytest-cov>=7,<8" "httpx>=0.28,<1" pip-audit
```

```powershell
.\.venv\Scripts\python.exe -m pytest -q --cov=mika --cov-branch
```

The release baseline is 121 passing tests. A Windows account without symlink permission can skip only the symlink-specific test if necessary.

Then run:

```powershell
.\.venv\Scripts\python.exe -m pip_audit
```

If `pip-audit` or `npm audit` reports a vulnerability, review it before putting private data into MIKA.

## 8. Fresh sample setup

For a fresh install using only bundled sample data:

```powershell
.\.venv\Scripts\mika.exe doctor
.\.venv\Scripts\mika.exe ingest samples\benchmark_evidence.txt
.\.venv\Scripts\mika.exe ingest samples\operations_incidents.csv
.\.venv\Scripts\mika.exe evaluate --repeats 20
.\.venv\Scripts\mika.exe search "reconciliation anomaly"
```

Useful v1.4.0 commands:

```powershell
.\.venv\Scripts\mika.exe sources
.\.venv\Scripts\mika.exe cases
.\.venv\Scripts\mika.exe backup
```

`backup` writes a timestamped SQLite snapshot under `data\backups` by default and verifies it before replacing the destination.

## 9. Upgrade existing MIKA data

Stop all old MIKA processes first. In the old project, make a backup of the whole `data` folder. Copy the old `data` folder into the new v1.4.0 project only while both versions are stopped.

Then run:

```powershell
.\.venv\Scripts\mika.exe doctor
.\.venv\Scripts\mika.exe audit-verify
.\.venv\Scripts\mika.exe backup
```

The database opens with an automatic v1.4 schema migration. The migration adds source-register tracking fields and keeps existing evidence, cases and findings. Repeat ingestion of unchanged evidence now preserves chunk IDs instead of replacing them.

Keep the old project backup until you have inspected your cases, source register and search results in v1.4.0.

## 10. Start the analyst console

```powershell
.\.venv\Scripts\mika.exe serve --host 127.0.0.1 --port 8000
```

The terminal prints a fresh session password. Open a private/incognito browser window and type:

```text
http://127.0.0.1:8000
```

Use username `mika` and the password printed in the terminal. Keep the terminal open. Ctrl+C stops the service and revokes that password.

Do not expose port 8000 through a firewall rule, router forwarding, reverse proxy, tunnel or public host.

## 11. New analyst workflow

The dashboard now has:

- source register browsing;
- source-filtered search;
- case-evidence-filtered search;
- case review;
- downloadable Markdown case reports.

CLI examples:

```powershell
.\.venv\Scripts\mika.exe search "CASE-900" --source 1
.\.venv\Scripts\mika.exe search "reconciliation" --case case_xxxxxxxxxxxx
.\.venv\Scripts\mika.exe source 1
```

## 12. Optional local LLM

Ollama is optional. Core retrieval, evaluation, cases and the dashboard work without it.

Install the LLM extra only if you want generated analysis:

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[llm]"
```

MIKA accepts only literal loopback model endpoints such as `http://127.0.0.1:11434`. It does not intentionally send model prompts to remote endpoints. Review the separate model server's own settings because MIKA cannot control another application's telemetry or network behaviour.

When a local model answers, v1.4.0 checks the citation labels it emitted against the retrieved evidence and reports invented labels. This is a guardrail, not proof that every claim is correct.

## 13. Security boundary

MIKA is a local, single-user research tool. Its browser password, loopback checks, request limits and security headers are not an internet-facing authentication architecture. Stored evidence is not application-encrypted. A compromised Windows account, administrator, browser extension or local process can still access local data.

Use current OS/browser/Python updates, keep the project private, and rerun the test and dependency audits after dependency changes.
