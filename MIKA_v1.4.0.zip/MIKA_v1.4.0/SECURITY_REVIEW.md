# MIKA v1.4.0 security and optimization review - 22 September 2026

## Scope

This review continues the v1.3.2 local hardening work and covers the reconstructed v1.4.0 source release. The intended deployment remains a native, single-user application bound to loopback. This is not a security certification and not an internet-facing or multi-user architecture.

## Changes reviewed

| Area | v1.4.0 result |
| --- | --- |
| Repeat ingestion | Unchanged evidence preserves chunk IDs, so case and finding references survive re-import. |
| Source register | Adds source/chunk inventory, ingest counters and quarantine visibility. API/UI paths are workspace-relative rather than absolute. |
| Selected evidence | Search can be constrained to source IDs, chunk IDs or a case evidence register. |
| Citation integrity | Model citation labels are checked against retrieved evidence; invented labels are reported. |
| Case evidence | Evidence cited by recorded findings is inserted into the case register automatically. |
| Database migration | Adds schema-version tracking and migration for source ingest metadata. |
| Database backup | Uses SQLite's online backup API, checks the copied database with `PRAGMA quick_check`, then atomically replaces the target. |
| Embedding repair | Corrupt, non-finite or stale-model vectors are regenerated instead of trusted. |
| Retrieval memory | Semantic scoring streams bounded batches and retains only the top candidate heap. |
| Dashboard | Source browsing, case review, filtered search and report download use DOM text nodes rather than HTML injection. |

The existing v1.3.2 controls are retained: per-start random browser password, loopback peer/bind restrictions, Host/Origin/Fetch Metadata checks, GET/HEAD-only API access, request/header/query limits, login/request budgets, disabled API docs, CSP/frame denial/no-store/no-referrer, default-deny tool policy, prompt-injection quarantine, restricted connector redirects, local-only model endpoint validation, disabled proxy inheritance for model traffic, redacted audit records and chained audit verification.

## Verification in this reconstruction

- 121 tests passed.
- Python branch coverage measured 88%.
- TypeScript typecheck and production build passed.
- `scripts/release_check.py` passed after generated coverage/cache files were removed.
- Python compilation passed for source and tests.
- Static grep found no use of `eval`, `exec`, `shell=True`, `subprocess`, `os.system`, `pickle` or YAML unsafe loading in MIKA source. The one intentional network connector is the existing exact allow-listed FCDO HTTPS downloader.
- Code comments remain minimal; only security/statistical rationale comments that prevent future misuse were retained.

A synthetic 12,000-chunk comparison measured peak `tracemalloc` allocation of about 49.3 MiB for v1.3.2 search and 1.51 MiB for v1.4.0 search. The same query measured about 0.277 s versus 0.209 s in that build environment. The memory reduction is the relevant regression result; timings are machine/cache dependent and are not production performance claims.

## Dependency status

v1.4.0 adds no Python or npm dependencies relative to v1.3.2. The previous v1.3.2 review recorded clean `pip-audit`, Bandit and npm-audit results for its resolved environment. The interrupted Astra build also reported a clear installed dependency audit for core/server/Ollama packages.

The reconstruction container had no package-registry access, so registry-backed vulnerability scanners could not be rerun against a newly resolved environment. This release therefore does not claim a new dependency-audit certification. Run the setup guide's `pip-audit` and `npm audit` commands on the Windows target before using private evidence.

As a freshness check on 22 September 2026, public package sources show FastAPI 0.141.1 and Uvicorn 0.53.0 as current releases, and public vulnerability listings showed no direct known issues for those current versions. NumPy 2.5.3 was also the current release with no direct known issue listed. These public listings are not a substitute for auditing the complete resolved dependency tree.

## Guidance alignment

The design continues to follow the relevant principles in OWASP REST guidance: explicit input limits, generic server errors, authentication, rate limiting and browser security headers. Prompt-injection handling follows a data/instruction separation model: retrieved evidence is explicitly treated as untrusted data and model output cannot directly execute tools.

SQLite's documented online `Connection.backup()` API is used for live backups; Python documents that it works while the source database is concurrently accessed.

## Remaining boundaries

- Browser Basic credentials travel over loopback HTTP. Do not publish, tunnel or reverse-proxy the service.
- Stored evidence, audit history and backups are not application-encrypted.
- A compromised OS account, administrator, local malware or malicious browser extension can bypass application-level protections.
- Prompt-injection detection is heuristic. Citation validation catches invented labels, not every unsupported interpretation.
- Audit hash chaining detects many edits but is not externally anchored against wholesale log replacement.
- Source files can still be changed after validation by another local process; MIKA is not a hostile-OS sandbox.
- The optional Ollama application, model weights, semantic-model packages and native Python/OpenSSL/SQLite runtime remain separate trust surfaces.
- Dependency ranges can resolve differently later. Re-run audits after upgrades.
