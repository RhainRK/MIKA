from __future__ import annotations

import json
from collections.abc import Iterable
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from .storage import Database


def _now() -> str:
    return datetime.now(UTC).isoformat()


class CaseStore:
    def __init__(self, db: Database) -> None:
        self.db = db

    def create(self, title: str, objective: str = "") -> str:
        title = title.strip()
        if not title:
            raise ValueError("Case title cannot be empty")
        case_id = f"case_{uuid4().hex[:12]}"
        now = _now()
        with self.db.conn:
            self.db.conn.execute(
                "INSERT INTO cases(id,title,objective,created_at,updated_at) VALUES(?,?,?,?,?)",
                (case_id, title, objective.strip(), now, now),
            )
        return case_id

    def list_cases(self) -> list[dict[str, Any]]:
        rows = self.db.conn.execute(
            """
            SELECT c.*,
                   COUNT(DISTINCT ce.chunk_id) AS evidence_count,
                   COUNT(DISTINCT f.id) AS finding_count
            FROM cases c
            LEFT JOIN case_evidence ce ON ce.case_id=c.id
            LEFT JOIN findings f ON f.case_id=c.id
            GROUP BY c.id ORDER BY c.updated_at DESC,c.id
            """
        ).fetchall()
        return [dict(row) for row in rows]

    def attach_evidence(self, case_id: str, chunk_ids: Iterable[int], note: str = "") -> None:
        self._require_case(case_id)
        ids = self._require_chunks(chunk_ids)
        with self.db.conn:
            self.db.conn.executemany(
                "INSERT OR REPLACE INTO case_evidence(case_id,chunk_id,note) VALUES(?,?,?)",
                [(case_id, chunk_id, note.strip()) for chunk_id in ids],
            )
            self.db.conn.execute("UPDATE cases SET updated_at=? WHERE id=?", (_now(), case_id))

    def add_finding(
        self,
        case_id: str,
        statement: str,
        confidence: float,
        *,
        evidence_chunk_ids: Iterable[int] = (),
        alternatives: Iterable[str] = (),
        limitations: Iterable[str] = (),
    ) -> str:
        self._require_case(case_id)
        statement = statement.strip()
        if not statement:
            raise ValueError("Finding statement cannot be empty")
        confidence = float(confidence)
        if not 0 <= confidence <= 1:
            raise ValueError("Confidence must be between 0 and 1")
        evidence_ids = self._require_chunks(evidence_chunk_ids)
        finding_id = f"finding_{uuid4().hex[:12]}"
        now = _now()
        with self.db.conn:
            self.db.conn.execute(
                """
                INSERT INTO findings(
                    id,case_id,statement,confidence,alternatives_json,limitations_json,created_at)
                VALUES(?,?,?,?,?,?,?)
                """,
                (
                    finding_id,
                    case_id,
                    statement,
                    confidence,
                    json.dumps(list(alternatives), ensure_ascii=False),
                    json.dumps(list(limitations), ensure_ascii=False),
                    now,
                ),
            )
            if evidence_ids:
                self.db.conn.executemany(
                    "INSERT OR IGNORE INTO case_evidence(case_id,chunk_id,note) VALUES(?,?,?)",
                    [(case_id, chunk_id, "") for chunk_id in evidence_ids],
                )
                self.db.conn.executemany(
                    "INSERT INTO finding_evidence(finding_id,chunk_id) VALUES(?,?)",
                    [(finding_id, chunk_id) for chunk_id in evidence_ids],
                )
            self.db.conn.execute("UPDATE cases SET updated_at=? WHERE id=?", (now, case_id))
        return finding_id

    def evidence_chunk_ids(self, case_id: str) -> list[int]:
        self._require_case(case_id)
        rows = self.db.conn.execute(
            "SELECT chunk_id FROM case_evidence WHERE case_id=? ORDER BY chunk_id", (case_id,)
        ).fetchall()
        return [int(row["chunk_id"]) for row in rows]

    def _require_chunks(self, chunk_ids: Iterable[int]) -> list[int]:
        ids = list(dict.fromkeys(int(value) for value in chunk_ids))
        if not ids:
            return []
        placeholders = ",".join("?" for _ in ids)
        rows = self.db.conn.execute(
            f"SELECT id FROM chunks WHERE id IN ({placeholders})", ids
        ).fetchall()
        found = {int(row["id"]) for row in rows}
        missing = [value for value in ids if value not in found]
        if missing:
            raise ValueError(f"Unknown evidence chunk: {missing[0]}")
        return ids

    def _require_case(self, case_id: str) -> Any:
        row = self.db.conn.execute("SELECT * FROM cases WHERE id=?", (case_id,)).fetchone()
        if row is None:
            raise ValueError(f"Unknown case: {case_id}")
        return row

    def get_case(self, case_id: str) -> dict[str, Any]:
        case = dict(self._require_case(case_id))
        evidence = self.db.conn.execute(
            """
            SELECT c.id AS chunk_id,c.source_id,c.locator,s.name AS source,s.sha256,
                   ce.note,c.content
            FROM case_evidence ce JOIN chunks c ON c.id=ce.chunk_id
            JOIN sources s ON s.id=c.source_id
            WHERE ce.case_id=? ORDER BY c.id
            """,
            (case_id,),
        ).fetchall()
        findings = self.db.conn.execute(
            "SELECT * FROM findings WHERE case_id=? ORDER BY created_at,id", (case_id,)
        ).fetchall()
        output_findings = []
        for row in findings:
            item = dict(row)
            item["alternatives"] = json.loads(item.pop("alternatives_json"))
            item["limitations"] = json.loads(item.pop("limitations_json"))
            cited = self.db.conn.execute(
                "SELECT chunk_id FROM finding_evidence WHERE finding_id=? ORDER BY chunk_id",
                (item["id"],),
            ).fetchall()
            item["evidence_chunk_ids"] = [int(value["chunk_id"]) for value in cited]
            output_findings.append(item)
        output_evidence = []
        for row in evidence:
            item = dict(row)
            item["citation"] = f"S{item['source_id']}:C{item['chunk_id']}"
            output_evidence.append(item)
        return {"case": case, "evidence": output_evidence, "findings": output_findings}

    def report_markdown(self, case_id: str) -> str:
        data = self.get_case(case_id)
        case = data["case"]
        lines = [
            f"# {case['title']}",
            "",
            f"**Case ID:** `{case_id}`",
            f"**Status:** {case['status']}",
        ]
        if case["objective"]:
            lines += ["", "## Objective", "", case["objective"]]
        lines += ["", "## Findings", ""]
        if not data["findings"]:
            lines.append("No findings recorded.")
        evidence_by_chunk = {item["chunk_id"]: item for item in data["evidence"]}
        for index, finding in enumerate(data["findings"], start=1):
            labels = [
                evidence_by_chunk[chunk_id]["citation"]
                for chunk_id in finding["evidence_chunk_ids"]
                if chunk_id in evidence_by_chunk
            ]
            lines += [
                f"### {index}. Finding",
                "",
                finding["statement"],
                "",
                f"**Confidence:** {finding['confidence']:.0%}",
                f"**Evidence:** {', '.join(labels) or 'None'}",
            ]
            if finding["alternatives"]:
                lines += [
                    "",
                    "**Alternative explanations**",
                    *[f"- {item}" for item in finding["alternatives"]],
                ]
            if finding["limitations"]:
                lines += ["", "**Limitations**", *[f"- {item}" for item in finding["limitations"]]]
            lines.append("")
        lines += ["## Evidence register", ""]
        for item in data["evidence"]:
            lines.append(
                f"- [{item['citation']}] `{item['source']}` / `{item['locator']}` / "
                f"SHA-256 `{item['sha256']}`"
            )
        return "\n".join(lines).rstrip() + "\n"
