# Upgrade instructions

Use [WINDOWS_SETUP.md](WINDOWS_SETUP.md) for the current v1.3.2 installation. Keep the old directory as a backup and install in a new folder.
