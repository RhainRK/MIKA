# MIKA v1.3.2 security review - 16 September 2026

## Scope and verdict

Second source review and targeted hardening of the saved v1.3.1 release, itself based on v1.3.0. Appropriate target: a native, single-user local research application with sample or public evidence. This is not a certification, a guarantee of perfect security, a remote deployment design or an audit of the user's Windows machine.

## Changes verified in this pass

| Finding | Resolution |
| --- | --- |
| Model requests accepted remote HTTPS endpoints and inherited environment proxies | Literal loopback IPs only, no endpoint paths/credentials/query strings, HTTPX proxy inheritance and redirects disabled. |
| Installing the semantic extra could trigger automatic downloads | Default hash retrieval; semantic loading requests local files only, disables remote model code and requests safetensors weights. |
| SQL output was limited after collecting all rows | Incremental byte budget while fetching, 64-column cap, retained instruction/time budget and read-only SQLite authorizer. |
| Path checks resolved aliases before inspecting names | Reject lexical hidden/parent names, symbolic links, Windows reparse points, alternate-stream syntax and trailing dot/space aliases. Existing workspace/file-size limits retained. |
| HTTP input and login attempts lacked application budgets | Reject duplicate sensitive headers, oversized headers/query strings and request bodies; bounded request/login token buckets and explicit WebSocket rejection. |
| Malformed JSON audit entries could crash verification | Non-object entries return a failed verification result. |
| Evaluation used predictable temporary filenames | Independent temporary directories prevent concurrent-run collisions and deletion of pre-existing fixed-name files. |
| Generic server failures could expose detail through future code changes | Generic HTTP 500 body with no-store; no raw exception content in the response. |
| Prior release retained style/type failures | Fixed source and script formatting/lint; strict typing passes on the tested Python 3.12 target. CI uses each matrix interpreter's version for dependency stubs. |

Retained from v1.3.1: per-start random password on all HTTP routes; loopback bind/peer checks; Host/Origin/Fetch Metadata checks; restricted methods; CSP, frame denial, no-store and no-referrer; default-deny tools; connector redirect rejection; redacted new audit/telemetry records; cross-process audit locking; disabled HTTP access logs and proxy-header trust. Added browser Permissions-Policy and same-origin resource policy.

## Evidence

- Linux/Python 3.12.14: 79 tests passed, 84.26% coverage, meeting the 82% gate. Tests include synthetic retrieval evaluation and adversarial regression cases.
- Ruff lint and formatting: passed for the repository. Strict mypy: passed for 29 modules with --python-version 3.12. Windows and the full hosted CI interpreter matrix were not executed here.
- TypeScript typecheck/build: passed. npm audit: zero known advisories in the installed dashboard dependency graph.
- Bandit: no reported findings. The deterministic bootstrap PRNG has a documented non-security suppression.
- pip-audit: no known advisories in the resolved Python environment, including core/server and the optional Ollama Python SDK plus test/audit tools. The local project itself is checked by source/tests rather than by a package-index advisory match. Semantic/torch packages, Windows-only packages, Python/OpenSSL/SQLite native-runtime advisories and the Ollama application/model binaries are outside this scan.
- A real Uvicorn process on an ephemeral loopback port returned 401 without credentials or with an incorrect password, 200 for authenticated dashboard/CSS/JS/health, 403 for foreign Origin/Host, and 404 for disabled /docs. It omitted the Server header and returned no-store. No browser password is included in reports.
- Actual Ollama SDK construction/close accepted the hardened transport parameters, without invoking generation. SDK import was checked in a subprocess with this runner's proxy variables removed; some proxy configurations can cause the SDK's unused global client to fail at import. MIKA's own model client still disables proxy inheritance.
- An interactive Windows browser, Windows ACLs, firewall and user-installed extensions were not inspected. Run the setup guide's local tests and audits.

Raw check outputs and the resolved Python package inventory are in security-review/. These are evidence from the review environment, not promises about a different machine or a future dependency resolution.

## Remaining boundaries

- Basic credentials are transported over loopback HTTP. This is explicitly local-only; do not publish or tunnel the service. Stop the server to revoke the password. Use a new private browser window after restart.
- A compromised OS, administrator or process with your user's access can read files, terminal output or browser state. MIKA cannot prevent that. Evidence databases and historical logs are not encrypted or scrubbed by this update.
- A literal loopback endpoint constrains MIKA's connection, not everything a separate local model server can do. Use locally downloaded models and review that server's cloud/telemetry settings. A locally running proxy could still forward data elsewhere.
- Package installation, vulnerability scans and the explicitly invoked FCDO download contact external services. Those services can observe the connection IP. Normal hash retrieval and the dashboard require no outbound application request.
- Prompt-injection scanning is heuristic; model responses still need evidence review. No model-output tools are automatically executed. CLI role flags are not OS-user authentication.
- Audit hash chaining cannot establish authenticity against someone who rewrites the entire file or removes its tail. There is no externally anchored signature.
- File checks do not defeat a malicious process racing to replace files after validation. Row/file/request budgets reduce resource abuse but do not eliminate denial of service. The global request budget can also throttle another tab.
- Dependency ranges can resolve differently by platform and date. No known advisory is not proof of absence of vulnerabilities. Review lockfile updates and re-run audits after changes.

## Reference guidance used

- [OWASP REST Security](https://cheatsheetseries.owasp.org/cheatsheets/REST_Security_Cheat_Sheet.html): access control, input limits, headers and error handling. This local HTTP design is not a claim of full OWASP compliance.
- [HTTPX environment variables](https://www.python-httpx.org/environment_variables/): trust_env=False avoids proxy inheritance in the configured model client.
- [Python SQLite](https://docs.python.org/3/library/sqlite3.html): authorizers, limits and progress handlers.
- [Ollama chat API](https://docs.ollama.com/api/chat): local chat interface.
