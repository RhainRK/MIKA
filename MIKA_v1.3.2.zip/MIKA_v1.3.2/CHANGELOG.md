## 1.3.2 - Second security review

- Restricted model endpoints to literal loopback IPs; disabled proxy inheritance and redirects.
- Made hash retrieval the default; semantic loading is local-only with remote code disabled.
- Added request/header/body limits, login and request rate budgets, and generic API errors.
- Blocked symbolic links, Windows reparse points and alternate-stream/trailing-name paths in evidence tools.
- Applied SQL output limits incrementally and limited query columns.
- Made malformed audit records fail verification cleanly; isolated concurrent evaluations in unique temporary directories.
- Added 20 regression tests, resolved lint findings and fixed typing issues. CI type-checks against its matrix interpreter.
- Added a full Windows setup guide with local tests and dependency-audit commands.

## 1.3.1 - Local security hardening

- Added per-start browser credentials, loopback-only connections, Host/Origin checks and security headers.
- Disabled public binding, proxy-header trust, request access logs and API documentation endpoints.
- Blocked connector redirects; added SQLite authorisation, execution and output budgets.
- Excluded hidden/credential files and capped evidence-tool files at 25 MiB.
- Removed tool argument values from new audit events, redacted nested secret keys and added cross-process audit locking.
- Added security regression tests and an npm lockfile. Removed incompatible Docker recipe.
- No database schema migration. Existing stored records and old logs are not rewritten.

# Changelog

## 1.3.0

- Reworked the FastAPI composition layer around shared embedding state and request-scoped application sessions.
- Replaced full semantic score sorting with partial top-k selection using NumPy `argpartition`.
- Cached normalized entity candidates and token blocks to reduce repeated record-linkage work.
- Reworked BFS path finding to store parent links instead of copying complete paths during traversal.
- Added SQLite WAL, busy timeout and thread-safe connection settings for concurrent API access.
- Hardened embedding cache/model initialization and audit verification with explicit locking.
- Removed generated frontend output and legacy launch/requirements wrappers from the source tree.
- Added stricter TypeScript compiler checks, Dependabot configuration and updated GitHub Actions workflows.
- Expanded CLI/API integration tests to 36 tests and raised measured Python coverage to 82%.
- Added repository release checks for generated state, legacy project terms, sensitive key patterns and non-ASCII punctuation.

## 1.2.0

- Added explainable entity resolution with token blocking, alias matching and weighted fuzzy scoring.
- Added relationship analysis with adjacency lists and bounded breadth-first shortest-path traversal.
- Added CSV data-quality profiling with missingness, uniqueness, duplicate and candidate-key checks.
- Added an exact allow-listed FCDO public-data connector.
- Vectorized semantic scoring and batched embedding generation.
- Added benchmark/source SHA-256 fingerprints and bootstrap confidence intervals.
- Added thread-safe audit-chain appends and telemetry redaction.
- Expanded FastAPI health/evaluation endpoints and strict TypeScript analyst console.
- Added Docker non-root execution and CI gates for linting, typing, security scanning, coverage and frontend compilation.
- Expanded the automated suite to 33 tests with 78% measured Python coverage.

## 1.1.0

- Added a 120-case operational retrieval regression suite.
- Added FastAPI/TypeScript analyst interface and public-data connector scaffolding.
- Added reciprocal-rank fusion and structured-identifier ranking support.

## 1.0.0

- Established a personality-free evidence-analysis and AI-assurance architecture.
- Added provenance-bearing ingestion, hybrid retrieval, evaluation, default-deny typed tools, prompt-injection quarantine, read-only data tooling, tamper-evident audit logging, case reporting and local-model analysis.
