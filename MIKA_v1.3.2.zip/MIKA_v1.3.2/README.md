# Security update: v1.3.2

Start with [WINDOWS_SETUP.md](WINDOWS_SETUP.md). This release is for native, single-user local operation. Run `mika serve`; use username `mika` and the fresh session password printed in your terminal. Every HTTP route requires authentication. Public network binding and API docs are disabled. The old container recipe was removed because it was incompatible with this local-only mode.

Default retrieval is offline hash-based. Model endpoints are restricted to literal loopback IPs, and semantic model files must already be available locally.

Read [SECURITY_REVIEW.md](SECURITY_REVIEW.md) for verified fixes, test scope and remaining limitations. Historical benchmark numbers below describe the earlier baseline, not a new security certification.

# MIKA

MIKA is a local evidence analysis and AI assurance system for working with operational data. It combines provenance-aware ingestion, hybrid retrieval, entity resolution, relationship analysis, constrained tool execution, auditable case findings and reproducible evaluation.

The language model is optional. Retrieval, authorization, provenance, quarantine, audit integrity and evaluation are deterministic Python components outside model generation.

## System

| Area | Implementation |
| --- | --- |
| Retrieval | SQLite FTS5/BM25, semantic embeddings, reciprocal-rank fusion, exact identifier boost |
| Ranking performance | Batched embedding generation, vectorized NumPy scoring, partial top-k selection |
| Provenance | SHA-256 source/chunk fingerprints, stable locators, source quarantine state |
| Entity resolution | Unicode normalization, alias expansion, token blocking, weighted fuzzy scoring |
| Relationships | Adjacency lists, bounded BFS shortest-path traversal, degree ranking |
| Tool security | Pydantic schemas, explicit permissions, default deny, unknown-tool rejection |
| Data controls | Workspace confinement, bounded read-only SQLite, prompt-injection quarantine |
| Audit | Redacted JSONL events chained with SHA-256 and integrity verification |
| Evaluation | Precision@k, Recall@k, MRR, nDCG, bootstrap intervals, latency percentiles |
| Interface | Python CLI, FastAPI service, strict TypeScript analyst console |
| Delivery | GitHub Actions, Dependabot, Ruff, mypy, Bandit, pip-audit, pytest |

## Verified state

The bundled regression data is synthetic and is used to detect engineering regressions.

- 79 Python tests passing (Linux/Python 3.12)
- 84.26% measured Python coverage
- 120-case operations retrieval suite
- Recall@5: 1.000
- MRR: 1.000
- nDCG@5: 1.000
- default-deny authorization: pass
- unknown-tool rejection: pass
- prompt-injection quarantine: pass
- audit-chain verification: pass

Exact benchmark and source fingerprints are written to `reports/evaluation-results.json`. See [docs/regression-baseline.md](docs/regression-baseline.md) for the regression baseline and limitations.

## Architecture

```text
source data
    |
    v
+----------------------+      +----------------------+
| ingest + provenance  |----->| injection assessment |
+----------+-----------+      +----------+-----------+
           |                             |
           | trusted                     | quarantined
           v                             v
+----------------------+         excluded by default
| chunk store + FTS5   |
+----------+-----------+
           |
     +-----+-------------------------+
     |                               |
     v                               v
+----------------------+   +----------------------+
| semantic retrieval   |   | entity resolution    |
| vector scoring       |   | aliases + blocking   |
+----------+-----------+   +----------+-----------+
           |                          |
           +------------+-------------+
                        |
                        v
              +----------------------+
              | cases + graph        |
              | findings + evidence  |
              +----------+-----------+
                         |
                         v
              +----------------------+
              | optional local LLM   |
              | grounded synthesis   |
              +----------------------+

Tool calls -> policy -> execution -> audit chain
Operations -> telemetry -> evaluation reports
```

Detailed design notes are in [docs/architecture.md](docs/architecture.md).

## Run

Python 3.11+ is required.

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -e ".[dev,server]"
mika doctor
mika evaluate
```

Build the analyst console:

```bash
cd dashboard
npm install
npm run typecheck
npm run build
cd ..
mika serve
```

Optional semantic embeddings (local model files only; set MIKA_EMBEDDING_MODEL to the trusted local model path; default is hash):

```bash
pip install -e ".[semantic]"
```

Optional local LLM:

```bash
pip install -e ".[llm]"
ollama pull qwen3.5:4b
mika ask "What evidence explains the reconciliation anomaly?"
```

## Core workflows

```bash
mika ingest samples/benchmark_evidence.txt
mika search "tool authorization policy"
mika profile samples/operations_incidents.csv
mika entity-resolve samples/entities.csv "Northstar Comp"
mika graph-path samples/relationships.csv "Maya Chen" "Helios Research Group"
mika audit-verify
```

The public-data connector is restricted to the official FCDO UK Sanctions List endpoint:

```bash
mika fetch-uk-sanctions
```

MIKA does not make compliance decisions. Entity matches and analytical findings require human review.

## Quality gates

Local release check:

```bash
python scripts/release_check.py
pytest --cov=mika --cov-fail-under=82 -q
mika evaluate --repeats 50
npm run --prefix dashboard typecheck
```

CI also runs Ruff formatting/linting, mypy, Bandit, pip-audit and frontend compilation. GitHub Dependabot is configured for Python, npm and Actions dependencies.

## Documentation

- [Architecture](docs/architecture.md)
- [Evaluation](docs/evaluation.md)
- [Operations case study](docs/case-study.md)
- [Public data](docs/public-data.md)
- [Design references](docs/references.md)
- [Security](SECURITY.md)
- [Contributing](CONTRIBUTING.md)
- [Changelog](CHANGELOG.md)
