import json
from pathlib import Path

import pytest

from mika.storage import Database
from mika.telemetry import Telemetry


def test_telemetry_redacts_attributes_and_records_errors(tmp_path: Path):
    db = Database(tmp_path / "mika.sqlite3")
    telemetry_path = tmp_path / "telemetry.jsonl"
    telemetry = Telemetry(db, telemetry_path)
    with pytest.raises(RuntimeError), telemetry.span("test", attributes={"token": "secret-value"}):
        raise RuntimeError("password=hunter2")
    record = json.loads(telemetry_path.read_text(encoding="utf-8").splitlines()[0])
    assert record["status"] == "error"
    assert "[REDACTED]" in json.dumps(record)
    db.close()
