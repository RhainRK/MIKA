import sqlite3
from pathlib import Path

import pytest

from mika.tools.builtins import _read_only_sqlite


def test_read_only_sqlite(tmp_path: Path):
    path = tmp_path / "x.sqlite3"
    conn = sqlite3.connect(path)
    conn.execute("CREATE TABLE t(x INTEGER)")
    conn.execute("INSERT INTO t VALUES (1),(2)")
    conn.commit()
    conn.close()
    result = _read_only_sqlite(path, "SELECT * FROM t ORDER BY x", 10)
    assert [row["x"] for row in result["rows"]] == [1, 2]


def test_write_sql_rejected(tmp_path: Path):
    path = tmp_path / "x.sqlite3"
    sqlite3.connect(path).close()
    with pytest.raises(ValueError):
        _read_only_sqlite(path, "DROP TABLE t", 10)
