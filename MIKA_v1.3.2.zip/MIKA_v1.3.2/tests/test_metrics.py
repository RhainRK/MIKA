from mika.evaluation.metrics import (
    ndcg_at_k,
    percentile,
    precision_at_k,
    recall_at_k,
    reciprocal_rank,
)


def test_retrieval_metrics():
    retrieved = [9, 2, 3]
    relevant = {2, 3}
    assert recall_at_k(retrieved, relevant, 3) == 1.0
    assert precision_at_k(retrieved, relevant, 3) == 2 / 3
    assert reciprocal_rank(retrieved, relevant) == 0.5
    assert 0 < ndcg_at_k(retrieved, relevant, 3) <= 1


def test_nearest_rank_percentile():
    assert percentile(list(range(1, 101)), 0.95) == 95
