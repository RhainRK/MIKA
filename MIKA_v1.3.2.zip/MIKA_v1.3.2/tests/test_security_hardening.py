import base64
import sqlite3

import pytest
from fastapi.testclient import TestClient

from mika.api import create_app
from mika.audit import AuditLog
from mika.config import Settings
from mika.connectors.fcdo import RejectRedirects
from mika.security import safe_workspace_path
from mika.tools.builtins import _read_only_sqlite


@pytest.fixture
def app(tmp_path):
    return create_app(
        Settings(
            db_path=tmp_path / "db",
            audit_path=tmp_path / "audit",
            telemetry_path=tmp_path / "telemetry",
            workspace=tmp_path,
            embedding_model="__force_hash_backend__",
        ),
        password="test-password",
    )


def client(app, **kwargs):
    auth = kwargs.pop("auth", None)
    if auth:
        kwargs["headers"] = {
            "Authorization": "Basic " + base64.b64encode((":".join(auth)).encode()).decode()
        }
    return TestClient(app, base_url="http://127.0.0.1", client=("127.0.0.1", 50000), **kwargs)


@pytest.mark.parametrize(
    "path",
    [
        "/",
        "/api/health",
        "/api/search?q=test",
        "/api/tools",
        "/api/evaluation/latest",
        "/api/cases/test",
        "/assets/app.js",
        "/style.css",
    ],
)
def test_login_required(app, path):
    response = client(app).get(path)
    assert response.status_code == 401
    assert response.headers["cache-control"] == "no-store"


def test_login(app):
    assert client(app, auth=("mika", "wrong")).get("/api/health").status_code == 401
    response = client(app, auth=("mika", "test-password")).get("/api/health")
    assert response.status_code == 200
    assert "frame-ancestors 'none'" in response.headers["content-security-policy"]


@pytest.mark.parametrize(
    "headers",
    [
        {"Host": "evil.example"},
        {"Origin": "https://evil.example"},
        {"Sec-Fetch-Site": "cross-site"},
        {"Origin": "http://127.0.0.1:9000"},
    ],
)
def test_boundary(app, headers):
    assert (
        client(app, auth=("mika", "test-password")).get("/api/health", headers=headers).status_code
        == 403
    )


def test_remote_peer(app):
    c = TestClient(app, base_url="http://127.0.0.1", client=("192.0.2.1", 50000))
    assert c.get("/api/health").status_code == 403


def test_redirect():
    with pytest.raises(ValueError):
        RejectRedirects().redirect_request(None, None, 302, "", {}, "http://127.0.0.1/private")


def test_sql(tmp_path):
    path = tmp_path / "sample?#.sqlite3"
    with sqlite3.connect(path) as c:
        c.execute("CREATE TABLE example (value INTEGER)")
        c.execute("INSERT INTO example VALUES (7)")
    assert _read_only_sqlite(path, "SELECT value FROM example", 10)["rows"] == [{"value": 7}]
    with pytest.raises(sqlite3.DatabaseError):
        _read_only_sqlite(
            path,
            "WITH RECURSIVE n(x) AS (SELECT 1 UNION ALL SELECT x+1 FROM n) SELECT sum(x) FROM n",
            10,
        )
    with pytest.raises(ValueError):
        _read_only_sqlite(path, "DELETE FROM example", 10)


def test_redaction(tmp_path):
    log = AuditLog(tmp_path / "audit")
    log.record("test", {"nested": {"token": "sensitive-test-value"}})
    assert "sensitive-test-value" not in log.path.read_text()
    assert log.verify()[0]


@pytest.mark.parametrize("name", [".env", ".git/config", "private.key"])
def test_sensitive_paths(tmp_path, name):
    with pytest.raises(ValueError):
        safe_workspace_path(tmp_path, name)


def test_public_bind():
    from mika.cli import main

    with pytest.raises(SystemExit, match="only serves"):
        main(["serve", "--host", "0.0.0.0"])


def test_dashboard_assets_authenticated(app):
    c = client(app, auth=("mika", "test-password"))
    from pathlib import Path

    built = (Path(__file__).resolve().parents[1] / "dashboard/dist/app.js").exists()
    assert c.get("/").status_code == (200 if built else 503)
    assert c.get("/style.css").status_code == 200
    assert c.get("/assets/app.js").status_code == (200 if built else 404)
    assert c.get("/docs").status_code == 404
    assert c.post("/api/health").status_code == 405


def test_audit_multiple_processes(tmp_path):
    import subprocess
    import sys

    path = tmp_path / "shared.jsonl"
    code = (
        "from mika.audit import AuditLog; import sys; "
        'log=AuditLog(sys.argv[1]); [log.record("parallel", {"i":i}) for i in range(20)]'
    )
    processes = [subprocess.Popen([sys.executable, "-c", code, str(path)]) for _ in range(3)]
    assert all(p.wait(timeout=20) == 0 for p in processes)
    assert AuditLog(path).verify()[:2] == (True, 60)
