from pathlib import Path

from mika.audit import AuditLog
from mika.policy import Permission, Policy
from mika.tools.base import ToolArgs, ToolCall, ToolDefinition
from mika.tools.registry import ToolRegistry


class Empty(ToolArgs):
    pass


def test_default_deny_does_not_invoke_handler(tmp_path: Path):
    called = []
    registry = ToolRegistry(Policy(), AuditLog(tmp_path / "audit.jsonl"))
    registry.register(
        ToolDefinition("x", "x", Empty, lambda _: called.append(True), Permission.READ_DATA)
    )
    result = registry.execute(ToolCall("x", {}))
    assert not result.success
    assert called == []


def test_explicit_allow_invokes_handler(tmp_path: Path):
    registry = ToolRegistry(Policy([Permission.READ_DATA]), AuditLog(tmp_path / "audit.jsonl"))
    registry.register(ToolDefinition("x", "x", Empty, lambda _: "ok", Permission.READ_DATA))
    result = registry.execute(ToolCall("x", {}))
    assert result.success and result.output == "ok"


def test_unknown_tool_denied(tmp_path: Path):
    registry = ToolRegistry(Policy([Permission.READ_DATA]), AuditLog(tmp_path / "audit.jsonl"))
    assert not registry.execute(ToolCall("missing", {})).success
