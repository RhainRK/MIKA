import sys
from types import SimpleNamespace

import pytest
from fastapi.testclient import TestClient

from mika.api import create_app
from mika.audit import AuditLog
from mika.config import Settings
from mika.embeddings import Embedder
from mika.llm import OllamaClient
from mika.security import safe_workspace_path, validate_endpoint


@pytest.fixture
def app(tmp_path):
    return create_app(
        Settings(
            workspace=tmp_path,
            db_path=tmp_path / "db",
            audit_path=tmp_path / "audit",
            telemetry_path=tmp_path / "telemetry",
        ),
        password="review-password",
    )


def client(app):
    c = TestClient(app, base_url="http://127.0.0.1", client=("127.0.0.1", 50000))
    c.auth = ("mika", "review-password")
    return c


@pytest.mark.parametrize(
    "url",
    [
        "https://example.com",
        "http://localhost:11434",
        "http://127.0.0.1:11434/proxy",
        "http://user:pass@127.0.0.1",
        "http://127.0.0.1?x=y",
    ],
)
def test_model_egress_denied(url):
    with pytest.raises(ValueError):
        validate_endpoint(url)


def test_model_transport_ignores_proxies(monkeypatch):
    captured = {}

    class FakeClient:
        def __init__(self, **kwargs):
            captured.update(kwargs)

    monkeypatch.setitem(sys.modules, "ollama", SimpleNamespace(Client=FakeClient))
    OllamaClient("http://127.0.0.1:11434", "local")._get_client()
    assert captured["trust_env"] is False
    assert captured["follow_redirects"] is False


def test_offline_embedding_flags(monkeypatch):
    captured = {}

    def model(name, **kwargs):
        captured.update(kwargs)
        raise OSError("private filesystem detail")

    monkeypatch.setitem(
        sys.modules, "sentence_transformers", SimpleNamespace(SentenceTransformer=model)
    )
    assert Embedder("hash").backend == "hash"
    assert not captured
    semantic = Embedder("local-model")
    assert semantic.backend == "hash"
    assert captured["local_files_only"] is True
    assert captured["trust_remote_code"] is False
    assert captured["model_kwargs"]["use_safetensors"] is True
    assert "private filesystem detail" not in semantic.load_error


@pytest.mark.parametrize("name", ["input.txt:secret", ".env", "folder./input.txt", "input.txt "])
def test_windows_path_alias_denied(tmp_path, name):
    with pytest.raises(ValueError):
        safe_workspace_path(tmp_path, name)


def test_symlink_denied(tmp_path):
    (tmp_path / ".env").write_text("test-only")
    try:
        (tmp_path / "evidence.txt").symlink_to(tmp_path / ".env")
    except OSError:
        pytest.skip("Symlinks unavailable on this account")
    with pytest.raises(ValueError):
        safe_workspace_path(tmp_path, "evidence.txt")


@pytest.mark.parametrize("line", ["[]", "null", "123", '"text"'])
def test_invalid_audit_types(tmp_path, line):
    path = tmp_path / "audit"
    path.write_text(line + "\n")
    assert AuditLog(path).verify()[0] is False


def test_request_budgets(app):
    c = client(app)
    assert c.request("GET", "/api/health", content=b"body").status_code == 413
    assert c.get("/api/health", headers={"x-padding": "x" * 17000}).status_code == 431
    assert c.get(
        "/api/health", headers=[("Host", "127.0.0.1"), ("Host", "evil.example")]
    ).status_code in {400, 403}


def test_login_throttle_and_recovery(app, monkeypatch):
    import mika.web_security as security

    clock = [100.0]
    monkeypatch.setattr(security, "monotonic", lambda: clock[0])
    c = client(app)
    for _ in range(10):
        assert c.get("/api/health", auth=("mika", "wrong")).status_code == 401
    assert c.get("/api/health", auth=("mika", "wrong")).status_code == 429
    assert c.get("/api/health").status_code == 200
    clock[0] += 5
    assert c.get("/api/health", auth=("mika", "wrong")).status_code == 401


def test_auth_is_per_server(app, tmp_path):
    c = client(app)
    assert c.get("/api/health").status_code == 200
    other = create_app(
        Settings(workspace=tmp_path, db_path=tmp_path / "other", audit_path=tmp_path / "a2"),
        password="different-password",
    )
    assert client(other).get("/api/health").status_code == 401


def test_errors_are_generic(app):
    @app.get("/api/failure-test")
    def failure():
        raise RuntimeError("sensitive evidence must never be returned")

    c = TestClient(
        app, base_url="http://127.0.0.1", client=("127.0.0.1", 1), raise_server_exceptions=False
    )
    response = c.get("/api/failure-test", auth=("mika", "review-password"))
    assert response.status_code == 500
    assert "sensitive evidence" not in response.text
    assert response.headers["cache-control"] == "no-store"
