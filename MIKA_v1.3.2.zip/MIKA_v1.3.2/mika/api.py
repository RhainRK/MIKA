from __future__ import annotations

import json
import secrets
from dataclasses import asdict
from pathlib import Path
from typing import TYPE_CHECKING, Any

from . import __version__
from .app import MikaApp
from .audit import AuditLog
from .config import Settings, settings
from .embeddings import Embedder
from .policy import Policy
from .tools.builtins import register_builtin_tools
from .tools.registry import ToolRegistry

if TYPE_CHECKING:
    from fastapi import FastAPI


def create_app(
    config: Settings | None = None,
    *,
    embedder: Embedder | None = None,
    password: str | None = None,
) -> FastAPI:
    try:
        from fastapi import FastAPI, HTTPException, Query
        from fastapi.responses import FileResponse, JSONResponse
        from fastapi.staticfiles import StaticFiles
    except ImportError as exc:
        raise RuntimeError("Install the server dependencies to run the API") from exc

    runtime_settings = (config or settings).resolve()
    shared_embedder = embedder or Embedder(runtime_settings.embedding_model)
    shared_audit = AuditLog(runtime_settings.audit_path)
    root = Path(__file__).resolve().parents[1]
    dashboard = root / "dashboard"
    service = FastAPI(
        title="MIKA API", version=__version__, docs_url=None, redoc_url=None, openapi_url=None
    )
    from .web_security import LocalAccessMiddleware

    service.add_middleware(LocalAccessMiddleware, password=password or secrets.token_urlsafe(32))

    if (dashboard / "dist").exists():
        service.mount("/assets", StaticFiles(directory=dashboard / "dist"), name="assets")

    @service.exception_handler(Exception)
    async def internal_error(request: Any, exc: Exception) -> Any:
        return JSONResponse(
            {"detail": "Internal operation failed"},
            status_code=500,
            headers={"Cache-Control": "no-store", "X-Content-Type-Options": "nosniff"},
        )

    def open_session() -> MikaApp:
        return MikaApp(runtime_settings, embedder=shared_embedder, audit=shared_audit)

    @service.get("/")
    def index() -> Any:
        page = dashboard / "index.html"
        bundle = dashboard / "dist" / "app.js"
        if not page.exists() or not bundle.exists():
            raise HTTPException(
                status_code=503, detail="dashboard not built; run npm run build in dashboard"
            )
        return FileResponse(page)

    @service.get("/style.css")
    def stylesheet() -> Any:
        return FileResponse(dashboard / "style.css", media_type="text/css")

    @service.get("/api/health")
    def health() -> dict[str, Any]:
        with open_session() as app:
            valid, records, error = app.audit.verify()
            source_count = int(
                app.db.conn.execute("SELECT COUNT(*) AS n FROM sources").fetchone()["n"]
            )
            chunk_count = int(
                app.db.conn.execute("SELECT COUNT(*) AS n FROM chunks").fetchone()["n"]
            )
            return {
                "status": "ok",
                "version": __version__,
                "fts5": app.db.fts_enabled,
                "embedding_backend": app.embedder.backend,
                "audit_chain_valid": valid,
                "audit_records": records,
                "audit_error": error,
                "sources": source_count,
                "chunks": chunk_count,
            }

    @service.get("/api/search")
    def search(
        q: str = Query(min_length=1, max_length=2000),
        k: int = Query(default=6, ge=1, le=20),
    ) -> list[dict[str, Any]]:
        with (
            open_session() as app,
            app.telemetry.span(
                "mika.retrieval.search",
                attributes={"mika.query.length": len(q), "mika.retrieval.k": k},
            ),
        ):
            return [
                asdict(hit) | {"citation": hit.citation()} for hit in app.retriever.search(q, k)
            ]

    @service.get("/api/evaluation/latest")
    def evaluation() -> Any:
        path = root / "reports" / "evaluation-results.json"
        if not path.exists():
            raise HTTPException(status_code=404, detail="run `mika evaluate` first")
        return json.loads(path.read_text(encoding="utf-8"))

    @service.get("/api/cases/{case_id}")
    def case(case_id: str) -> dict[str, Any]:
        with open_session() as app:
            try:
                return app.cases.get_case(case_id)
            except ValueError as exc:
                raise HTTPException(status_code=404, detail=str(exc)) from exc

    @service.get("/api/tools")
    def tools(role: str = "analyst") -> dict[str, Any]:
        try:
            policy = Policy.for_role(role)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail=str(exc)) from exc
        with open_session() as app:
            registry = ToolRegistry(policy, app.audit)
            register_builtin_tools(
                registry,
                retriever=app.retriever,
                workspace=app.settings.workspace,
                cases=app.cases,
            )
            return {"role": role, "tools": [item["function"] for item in registry.schemas()]}

    return service
