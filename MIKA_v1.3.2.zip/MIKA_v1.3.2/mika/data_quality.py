from __future__ import annotations

import csv
from dataclasses import asdict, dataclass
from pathlib import Path
from statistics import mean
from typing import Any


@dataclass(frozen=True, slots=True)
class QualityIssue:
    severity: str
    column: str
    check: str
    detail: str


def profile_csv(path: Path) -> dict[str, Any]:
    with path.open("r", encoding="utf-8-sig", newline="", errors="replace") as handle:
        reader = csv.DictReader(handle)
        fields = list(reader.fieldnames or [])
        rows = list(reader)

    stats: dict[str, Any] = {}
    issues: list[QualityIssue] = []
    row_count = len(rows)
    for field in fields:
        values = [(row.get(field) or "").strip() for row in rows]
        nonempty = [value for value in values if value]
        missing = row_count - len(nonempty)
        distinct = len(set(nonempty))
        numeric: list[float] = []
        for value in nonempty:
            try:
                numeric.append(float(value))
            except ValueError:
                continue

        column: dict[str, Any] = {
            "missing": missing,
            "missing_rate": missing / row_count if row_count else 0.0,
            "distinct": distinct,
            "unique_rate": distinct / len(nonempty) if nonempty else 0.0,
        }
        if numeric and len(numeric) >= max(1, len(nonempty) // 2):
            column.update(
                {
                    "numeric_count": len(numeric),
                    "min": min(numeric),
                    "max": max(numeric),
                    "mean": mean(numeric),
                }
            )
        stats[field] = column

        if row_count and missing / row_count >= 0.5:
            issues.append(
                QualityIssue(
                    "warning", field, "missingness", f"{missing}/{row_count} values missing"
                )
            )
        if nonempty and distinct == 1 and len(nonempty) > 1:
            issues.append(
                QualityIssue("info", field, "constant_column", "all populated values are identical")
            )

    duplicate_rows = row_count - len(
        {tuple((row.get(field) or "") for field in fields) for row in rows}
    )
    if duplicate_rows:
        issues.append(
            QualityIssue("warning", "*", "duplicate_rows", f"{duplicate_rows} duplicate rows")
        )

    candidate_keys = [
        field
        for field in fields
        if row_count > 0 and stats[field]["missing"] == 0 and stats[field]["distinct"] == row_count
    ]
    return {
        "path": str(path),
        "rows": row_count,
        "columns": fields,
        "column_stats": stats,
        "candidate_keys": candidate_keys,
        "duplicate_rows": duplicate_rows,
        "issues": [asdict(issue) for issue in issues],
    }
