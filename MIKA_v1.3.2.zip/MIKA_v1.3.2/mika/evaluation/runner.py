from __future__ import annotations

import json
import platform
from datetime import UTC, datetime
from pathlib import Path
from tempfile import TemporaryDirectory
from time import perf_counter
from typing import Any
from uuid import uuid4

from ..audit import AuditLog
from ..benchmarking import evaluate_suite, load_jsonl_suite
from ..embeddings import Embedder
from ..policy import Permission, Policy
from ..provenance import EvidenceStore
from ..retrieval import HybridRetriever
from ..storage import Database
from ..tools.base import ToolArgs, ToolCall, ToolDefinition
from ..tools.registry import ToolRegistry
from .metrics import percentile


class _EmptyArgs(ToolArgs):
    pass


def _ordinal_map(db: Database, source_id: int) -> dict[int, int]:
    rows = db.conn.execute(
        "SELECT id,ordinal FROM chunks WHERE source_id=?", (source_id,)
    ).fetchall()
    return {int(row["ordinal"]): int(row["id"]) for row in rows}


def run_suite(root: Path, output: Path, *, repeats: int = 30) -> dict[str, Any]:
    output.parent.mkdir(parents=True, exist_ok=True)
    temporary = TemporaryDirectory(prefix="mika-eval-")
    temp_db = Path(temporary.name) / "evaluation.sqlite3"
    temp_audit = Path(temporary.name) / "audit.jsonl"
    db = Database(temp_db)
    embedder = Embedder("__force_hash_backend__")
    embedder._backend = "hash"
    store = EvidenceStore(db, embedder, root, quarantine_threshold=0.75)
    retriever = HybridRetriever(db, embedder)
    latencies: list[float] = []

    try:
        core_source = store.ingest_path(Path("samples/benchmark_evidence.txt"))
        core_suite = load_jsonl_suite(
            root / "benchmarks/retrieval.jsonl",
            name="core-retrieval",
            version="1.0",
            source_path=root / "samples/benchmark_evidence.txt",
            synthetic=True,
        )
        core_result = evaluate_suite(
            core_suite,
            ordinal_to_id=_ordinal_map(db, core_source.source_id),
            search=retriever.search,
        )

        operations_source = store.ingest_path(Path("samples/operations_incidents.csv"))
        operations_suite = load_jsonl_suite(
            root / "benchmarks/operations_120.jsonl",
            name="operations-120",
            version="1.0",
            source_path=root / "samples/operations_incidents.csv",
            synthetic=True,
        )
        operations_result = evaluate_suite(
            operations_suite,
            ordinal_to_id=_ordinal_map(db, operations_source.source_id),
            search=retriever.search,
        )

        latency_query = operations_suite.cases[0].query
        for _ in range(max(10, repeats)):
            started = perf_counter()
            retriever.search(latency_query, k=5)
            latencies.append(perf_counter() - started)

        audit = AuditLog(temp_audit)
        called = {"value": False}
        denied_registry = ToolRegistry(Policy(), audit)
        denied_registry.register(
            ToolDefinition(
                "test.read",
                "test",
                _EmptyArgs,
                lambda _: called.__setitem__("value", True),
                Permission.READ_DATA,
            )
        )
        denied = denied_registry.execute(ToolCall("test.read", {}))
        allow_registry = ToolRegistry(Policy([Permission.READ_DATA]), audit)
        allow_registry.register(
            ToolDefinition("test.read", "test", _EmptyArgs, lambda _: "ok", Permission.READ_DATA)
        )
        allowed = allow_registry.execute(ToolCall("test.read", {}))
        unknown = allow_registry.execute(ToolCall("test.unadvertised", {}))
        audit_ok, audit_records, audit_error = audit.verify()

        malicious = store.ingest_path(Path("samples/injection_evidence.txt"))
        normal_search = retriever.search(
            "quarterly payment reconciliation secret tool command", k=10
        )
        quarantined_hidden = all(hit.source_id != malicious.source_id for hit in normal_search)

        report: dict[str, Any] = {
            "suite_version": "1.1",
            "run_id": f"eval_{uuid4().hex[:12]}",
            "created_at": datetime.now(UTC).isoformat(),
            "python": platform.python_version(),
            "platform": platform.platform(),
            "embedding_backend": embedder.backend,
            "benchmark_suites": [core_result, operations_result],
            "authorization": {
                "default_deny_passed": (not denied.success) and not called["value"],
                "explicit_allow_passed": allowed.success and allowed.output == "ok",
                "unadvertised_tool_denied": not unknown.success,
            },
            "retrieval_security": {
                "malicious_source_quarantined": malicious.quarantined,
                "quarantined_source_hidden_by_default": quarantined_hidden,
                "injection_score": malicious.injection_score,
                "signals": malicious.injection_signals,
            },
            "audit_integrity": {"valid": audit_ok, "records": audit_records, "error": audit_error},
            "latency": {
                "samples": len(latencies),
                "p50_seconds": percentile(latencies, 0.50),
                "p95_seconds": percentile(latencies, 0.95),
                "p99_seconds": percentile(latencies, 0.99),
            },
            "limitations": [
                (
                    "Bundled retrieval suites are deterministic synthetic regression "
                    "benchmarks; they are not evidence of production-domain accuracy."
                ),
                (
                    "The operations suite contains 120 held-out query cases over "
                    "generated operational records and is intended to detect ranking regressions."
                ),
                (
                    "Hash embeddings provide deterministic offline coverage but are "
                    "not a substitute for measuring the configured semantic model."
                ),
                (
                    "Latency varies with hardware, cache state and corpus size; these "
                    "figures are local developer benchmarks."
                ),
                (
                    "Prompt-injection scanning is heuristic defense-in-depth and must "
                    "not be treated as a complete security boundary."
                ),
            ],
        }
        operations_recall = operations_result["metrics"]["recall_at_k"]["mean"] or 0.0
        passed = (
            report["authorization"]["default_deny_passed"]
            and report["authorization"]["explicit_allow_passed"]
            and report["authorization"]["unadvertised_tool_denied"]
            and report["retrieval_security"]["malicious_source_quarantined"]
            and report["retrieval_security"]["quarantined_source_hidden_by_default"]
            and report["audit_integrity"]["valid"]
            and operations_recall >= 0.95
        )
        report["status"] = "passed" if passed else "failed"
        output.parent.mkdir(parents=True, exist_ok=True)
        output.write_text(json.dumps(report, indent=2), encoding="utf-8")
        with db.conn:
            db.conn.execute(
                "INSERT INTO eval_runs(id,suite,status,results_json,created_at) VALUES(?,?,?,?,?)",
                (
                    report["run_id"],
                    "core+operations",
                    report["status"],
                    json.dumps(report),
                    report["created_at"],
                ),
            )
        return report
    finally:
        db.close()
        temporary.cleanup()
