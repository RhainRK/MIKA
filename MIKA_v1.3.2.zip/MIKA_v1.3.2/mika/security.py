from __future__ import annotations

import ipaddress
import re
from dataclasses import dataclass
from pathlib import Path
from urllib.parse import urlsplit

_SECRET = re.compile(
    r"(?i)(\b(?:api[_-]?key|token|password|passwd|secret|authorization|cookie)\b"
    r"[\"']?\s*[:=]\s*[\"']?)(?:bearer\s+)?[^\s&\"'<>;,}]+"
)
_BEARER = re.compile(r"(?i)\bbearer\s+[A-Za-z0-9._~+/=-]+")
_PROVIDER_KEY = re.compile(
    r"\b(?:"
    r"sk-[A-Za-z0-9_-]{16,}|"
    r"sk-ant-[A-Za-z0-9_-]{20,}|"
    r"gh[pousr]_[A-Za-z0-9]{20,}|"
    r"github_pat_[A-Za-z0-9_]{20,}|"
    r"(?:AKIA|ASIA)[A-Z0-9]{16}|"
    r"AIza[0-9A-Za-z_-]{30,}|"
    r"xox[baprs]-[0-9A-Za-z-]{20,}|"
    r"(?:sk|rk)_live_[0-9A-Za-z]{16,}|"
    r"hf_[0-9A-Za-z]{20,}"
    r")\b"
)

_PATTERNS: tuple[tuple[re.Pattern[str], float, str], ...] = (
    (
        re.compile(r"(?i)\bignore\s+(?:all\s+)?(?:previous|prior|above)\s+instructions?\b"),
        0.45,
        "instruction_override",
    ),
    (re.compile(r"(?i)\b(?:system|developer)\s+prompt\b"), 0.25, "prompt_reference"),
    (
        re.compile(
            r"(?i)\b(?:reveal|print|show|leak|expose)\b.{0,32}\b(?:secret|token|password|prompt)\b"
        ),
        0.35,
        "secret_exfiltration",
    ),
    (
        re.compile(r"(?i)\b(?:call|invoke|execute|run)\b.{0,24}\b(?:tool|function|command)\b"),
        0.20,
        "tool_directive",
    ),
    (
        re.compile(
            r"(?i)\b(?:send|upload|exfiltrate|post)\b.{0,32}\b(?:data|content|secret|credentials?)\b"
        ),
        0.35,
        "data_exfiltration",
    ),
    (re.compile(r"(?i)\b(?:you are now|act as|new role|override policy)\b"), 0.25, "role_override"),
)


@dataclass(frozen=True, slots=True)
class InjectionAssessment:
    score: float
    signals: tuple[str, ...]

    @property
    def suspicious(self) -> bool:
        return self.score >= 0.35


def redact_text(value: str) -> str:
    value = _SECRET.sub(r"\1[REDACTED]", value)
    value = _BEARER.sub("Bearer [REDACTED]", value)
    return _PROVIDER_KEY.sub("[REDACTED]", value)


def assess_prompt_injection(text: str) -> InjectionAssessment:
    score = 0.0
    signals: list[str] = []
    for pattern, weight, label in _PATTERNS:
        if pattern.search(text):
            score += weight
            signals.append(label)
    return InjectionAssessment(min(score, 1.0), tuple(dict.fromkeys(signals)))


def validate_endpoint(value: str) -> str:
    try:
        parsed = urlsplit(value)
        host = parsed.hostname
        _ = parsed.port
    except ValueError:
        raise ValueError("Invalid endpoint URL") from None
    if parsed.scheme not in {"http", "https"} or not host:
        raise ValueError("Endpoint requires an HTTP(S) URL")
    if (
        parsed.username is not None
        or parsed.password is not None
        or parsed.query
        or parsed.fragment
    ):
        raise ValueError("Use a base URL without credentials, query parameters or fragments")
    try:
        local = ipaddress.ip_address(host).is_loopback
    except ValueError:
        local = False
    if not local or parsed.path not in {"", "/"}:
        raise ValueError("Model endpoints must use a literal loopback IP and no path")
    return value


def safe_workspace_path(workspace: Path, candidate: str | Path) -> Path:
    root = workspace.expanduser().resolve()
    path = Path(candidate).expanduser()
    if not path.is_absolute():
        path = root / path
    # Inspect the supplied path before resolution so aliases cannot hide forbidden names.
    try:
        lexical = path.relative_to(root)
    except ValueError:
        raise ValueError("Path escapes the configured workspace") from None
    cursor = root
    for part in lexical.parts:
        if part.startswith(".") or ":" in part or part.endswith((".", " ")):
            raise ValueError("Hidden, parent and alternate-stream paths are excluded")
        cursor = cursor / part
        if cursor.is_symlink():
            raise ValueError("Evidence tools do not follow symbolic links")
        if cursor.exists() and getattr(cursor.lstat(), "st_file_attributes", 0) & 0x400:
            raise ValueError("Evidence tools do not follow Windows reparse points")
    path = path.resolve()
    try:
        path.relative_to(root)
    except ValueError:
        raise ValueError("Path escapes the configured workspace") from None
    relative = path.relative_to(root)
    if any(part.startswith(".") for part in relative.parts) or path.suffix.lower() in {
        ".pem",
        ".key",
        ".p12",
        ".pfx",
    }:
        raise ValueError("Hidden files and credential files are excluded from evidence tools")
    if path.exists() and (not path.is_file() or path.stat().st_size > 25 * 1024 * 1024):
        raise ValueError("Evidence tools require a regular file no larger than 25 MiB")
    return path
