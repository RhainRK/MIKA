from __future__ import annotations

import base64
import binascii
import ipaddress
import secrets
from time import monotonic
from urllib.parse import urlsplit

from starlette.responses import PlainTextResponse
from starlette.types import ASGIApp, Message, Receive, Scope, Send


class LocalAccessMiddleware:
    """Single-user loopback access; not a remote deployment authentication system."""

    def __init__(self, app: ASGIApp, password: str) -> None:
        self.app = app
        self.expected = ("mika:" + password).encode()
        self._request_tokens = 60.0
        self._request_time = monotonic()
        self._login_tokens = 10.0
        self._login_time = monotonic()

    def _permit(self, login: bool = False) -> bool:
        now = monotonic()
        tokens_name = "_login_tokens" if login else "_request_tokens"
        time_name = "_login_time" if login else "_request_time"
        capacity, rate = (10.0, 0.2) if login else (60.0, 10.0)
        tokens = min(capacity, getattr(self, tokens_name) + (now - getattr(self, time_name)) * rate)
        setattr(self, time_name, now)
        permitted = tokens >= 1
        setattr(self, tokens_name, tokens - 1 if permitted else tokens)
        return bool(permitted)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] == "websocket":
            await send({"type": "websocket.close", "code": 1008})
            return
        if scope["type"] != "http":
            return await self.app(scope, receive, send)
        headers = {k.lower(): v for k, v in scope.get("headers", [])}
        status, message = 200, ""
        raw_headers = scope.get("headers", [])
        sensitive = {b"host", b"authorization", b"origin", b"content-length", b"transfer-encoding"}
        if any(sum(k.lower() == name for k, _ in raw_headers) > 1 for name in sensitive):
            status, message = 400, "Duplicate security headers"
        if (
            sum(len(k) + len(v) for k, v in raw_headers) > 16384
            or len(scope.get("query_string", b"")) > 8192
        ):
            status, message = 431, "Request too large"
        if b"transfer-encoding" in headers or headers.get(b"content-length", b"0") != b"0":
            status, message = 413, "Request bodies are not accepted"
        try:
            peer = scope.get("client")
            if not peer or not ipaddress.ip_address(peer[0]).is_loopback:
                raise ValueError("Local connections only")
            host = headers.get(b"host", b"").decode("ascii")
            parsed = urlsplit("http://" + host)
            if (
                parsed.hostname not in {"localhost", "127.0.0.1", "::1"}
                or parsed.username
                or parsed.password
                or parsed.path
                or parsed.query
                or parsed.fragment
            ):
                raise ValueError("Invalid host")
            _ = parsed.port
            origin = headers.get(b"origin")
            if origin and origin.decode("ascii") != scope.get("scheme", "http") + "://" + host:
                raise ValueError("Cross-origin access denied")
            if headers.get(b"sec-fetch-site", b"") in {b"cross-site", b"same-site"}:
                raise ValueError("Cross-site access denied")
        except (ValueError, UnicodeError):
            status, message = 403, "Local same-origin access required"
        if status == 200 and not self._permit():
            status, message = 429, "Request rate exceeded"
        if status == 200:
            try:
                scheme, token = headers.get(b"authorization", b"").split(b" ", 1)
                supplied = base64.b64decode(token, validate=True)
                authenticated = scheme.lower() == b"basic" and secrets.compare_digest(
                    supplied, self.expected
                )
            except (ValueError, binascii.Error):
                authenticated = False
            if not authenticated:
                status, message = (
                    (401, "Authentication required")
                    if self._permit(login=True)
                    else (429, "Login rate exceeded")
                )
        if status == 200 and scope["method"] not in {"GET", "HEAD"}:
            status, message = 405, "Read-only API"

        async def secured_send(message: Message) -> None:
            if message["type"] == "http.response.start":
                extra = [
                    (b"cache-control", b"no-store"),
                    (b"x-content-type-options", b"nosniff"),
                    (b"x-frame-options", b"DENY"),
                    (b"referrer-policy", b"no-referrer"),
                    (b"permissions-policy", b"camera=(), microphone=(), geolocation=()"),
                    (b"cross-origin-resource-policy", b"same-origin"),
                    (
                        b"content-security-policy",
                        (
                            b"default-src 'none'; script-src 'self'; style-src 'self'; "
                            b"connect-src 'self'; img-src 'self'; frame-ancestors 'none'; "
                            b"base-uri 'none'; form-action 'self'"
                        ),
                    ),
                ]
                message["headers"] = list(message.get("headers", [])) + extra
            await send(message)

        if status != 200:
            response = PlainTextResponse(
                message,
                status_code=status,
                headers=(
                    {"WWW-Authenticate": 'Basic realm="MIKA", charset="UTF-8"'}
                    if status == 401
                    else {"Retry-After": "5"}
                    if status == 429
                    else {}
                ),
            )
            return await response(scope, receive, secured_send)
        await self.app(scope, receive, secured_send)
