from __future__ import annotations

import json
from collections.abc import Iterator
from contextlib import contextmanager
from datetime import UTC, datetime
from pathlib import Path
from time import perf_counter
from typing import Any
from uuid import uuid4

from .security import redact_text
from .storage import Database


def _sanitize(value: Any) -> Any:
    if isinstance(value, dict):
        return {
            str(key): "[REDACTED]"
            if str(key).casefold()
            in {"password", "token", "secret", "api_key", "authorization", "cookie"}
            else _sanitize(item)
            for key, item in value.items()
        }
    if isinstance(value, (list, tuple)):
        return [_sanitize(item) for item in value]
    if isinstance(value, str):
        return redact_text(value)
    return value


class Telemetry:
    def __init__(self, db: Database, path: Path | str) -> None:
        self.db = db
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    @contextmanager
    def span(
        self,
        name: str,
        *,
        trace_id: str | None = None,
        parent_id: str | None = None,
        attributes: dict[str, Any] | None = None,
    ) -> Iterator[dict[str, Any]]:
        span_id = uuid4().hex[:16]
        trace_id = trace_id or uuid4().hex
        started_at = datetime.now(UTC).isoformat()
        started = perf_counter()
        state: dict[str, Any] = {
            "span_id": span_id,
            "trace_id": trace_id,
            "attributes": dict(attributes or {}),
        }
        status = "ok"
        try:
            yield state
        except Exception as exc:
            status = "error"
            state["attributes"]["error.type"] = type(exc).__name__
            state["attributes"]["error.message"] = "Operation failed"
            raise
        finally:
            duration_ms = (perf_counter() - started) * 1000.0
            attributes_clean = _sanitize(state["attributes"])
            record = {
                "id": span_id,
                "trace_id": trace_id,
                "parent_id": parent_id,
                "name": name,
                "started_at": started_at,
                "duration_ms": duration_ms,
                "status": status,
                "attributes": attributes_clean,
            }
            with self.db.conn:
                self.db.conn.execute(
                    """
                    INSERT INTO telemetry_spans(
                        id,trace_id,parent_id,name,started_at,duration_ms,status,attributes_json)
                    VALUES(?,?,?,?,?,?,?,?)
                    """,
                    (
                        span_id,
                        trace_id,
                        parent_id,
                        name,
                        started_at,
                        duration_ms,
                        status,
                        json.dumps(attributes_clean, ensure_ascii=False, default=str),
                    ),
                )
            with self.path.open("a", encoding="utf-8") as handle:
                handle.write(json.dumps(record, ensure_ascii=False, default=str) + "\n")
