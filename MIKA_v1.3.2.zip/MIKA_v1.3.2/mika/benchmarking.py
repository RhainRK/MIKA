from __future__ import annotations

import hashlib
import json
import random
from collections.abc import Callable, Iterable
from dataclasses import dataclass
from pathlib import Path
from statistics import mean
from typing import Any

from .evaluation.metrics import ndcg_at_k, precision_at_k, recall_at_k, reciprocal_rank


@dataclass(frozen=True, slots=True)
class BenchmarkCase:
    case_id: str
    query: str
    relevant_ordinals: tuple[int, ...]
    k: int = 5


@dataclass(frozen=True, slots=True)
class BenchmarkSuite:
    name: str
    version: str
    source_path: Path
    definition_path: Path
    cases: tuple[BenchmarkCase, ...]
    synthetic: bool = True


def _file_sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_jsonl_suite(
    path: Path, *, name: str, version: str, source_path: Path, synthetic: bool = True
) -> BenchmarkSuite:
    cases: list[BenchmarkCase] = []
    for line_number, raw in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not raw.strip():
            continue
        row = json.loads(raw)
        try:
            cases.append(
                BenchmarkCase(
                    case_id=str(row["id"]),
                    query=str(row["query"]),
                    relevant_ordinals=tuple(int(value) for value in row["relevant_ordinals"]),
                    k=int(row.get("k", 5)),
                )
            )
        except (KeyError, TypeError, ValueError) as exc:
            raise ValueError(f"Invalid benchmark row at {path}:{line_number}") from exc
    if not cases:
        raise ValueError(f"Benchmark suite is empty: {path}")
    return BenchmarkSuite(name, version, source_path, path, tuple(cases), synthetic)


def confidence_interval(
    values: Iterable[float], *, confidence: float = 0.95, resamples: int = 1000, seed: int = 42
) -> dict[str, float | None]:
    values = list(values)
    if not values:
        return {"mean": None, "low": None, "high": None}
    if len(values) == 1:
        value = float(values[0])
        return {"mean": value, "low": value, "high": value}
    # Deterministic statistical resampling, never credential generation.
    rng = random.Random(seed)  # nosec B311
    n = len(values)
    boot = [mean(values[rng.randrange(n)] for _ in range(n)) for _ in range(max(100, resamples))]
    boot.sort()
    alpha = (1.0 - confidence) / 2.0
    lo = boot[min(len(boot) - 1, max(0, int(alpha * len(boot))))]
    hi = boot[min(len(boot) - 1, max(0, int((1.0 - alpha) * len(boot)) - 1))]
    return {"mean": mean(values), "low": lo, "high": hi}


def evaluate_suite(
    suite: BenchmarkSuite,
    *,
    ordinal_to_id: dict[int, int],
    search: Callable[[str, int], list[Any]],
) -> dict[str, Any]:
    rows: list[dict[str, Any]] = []
    for case in suite.cases:
        relevant = {
            ordinal_to_id[value] for value in case.relevant_ordinals if value in ordinal_to_id
        }
        hits = search(case.query, case.k)
        retrieved = [int(hit.chunk_id) for hit in hits]
        rows.append(
            {
                "id": case.case_id,
                "query": case.query,
                "k": case.k,
                "retrieved": retrieved,
                "relevant": sorted(relevant),
                "precision_at_k": precision_at_k(retrieved, relevant, case.k),
                "recall_at_k": recall_at_k(retrieved, relevant, case.k),
                "mrr": reciprocal_rank(retrieved, relevant),
                "ndcg_at_k": ndcg_at_k(retrieved, relevant, case.k),
            }
        )
    metrics: dict[str, Any] = {}
    for key in ("precision_at_k", "recall_at_k", "mrr", "ndcg_at_k"):
        metrics[key] = confidence_interval([float(row[key]) for row in rows])
    return {
        "name": suite.name,
        "version": suite.version,
        "synthetic": suite.synthetic,
        "case_count": len(rows),
        "definition_sha256": _file_sha256(suite.definition_path),
        "source_sha256": _file_sha256(suite.source_path),
        "metrics": metrics,
        "cases": rows,
    }
