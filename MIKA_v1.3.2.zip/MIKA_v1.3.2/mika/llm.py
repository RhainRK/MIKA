from __future__ import annotations

from dataclasses import dataclass
from time import perf_counter
from typing import Any

from .security import validate_endpoint


class LLMError(RuntimeError):
    pass


@dataclass(frozen=True, slots=True)
class ModelResponse:
    text: str
    wall_seconds: float
    prompt_tokens: int | None = None
    output_tokens: int | None = None
    tokens_per_second: float | None = None


class OllamaClient:
    def __init__(self, base_url: str, model: str, timeout: float = 90.0) -> None:
        self.base_url = validate_endpoint(base_url)
        self.model = model
        self.timeout = timeout
        self._client: Any = None

    def _get_client(self) -> Any:
        if self._client is None:
            try:
                from ollama import Client
            except ImportError as exc:
                raise LLMError('Install the LLM extra with `pip install -e ".[llm]"`') from exc
            self._client = Client(
                host=self.base_url, timeout=self.timeout, trust_env=False, follow_redirects=False
            )
        return self._client

    def chat(
        self, messages: list[dict[str, str]], *, temperature: float = 0.0, max_tokens: int = 700
    ) -> ModelResponse:
        started = perf_counter()
        try:
            response = self._get_client().chat(
                model=self.model,
                messages=messages,
                stream=False,
                keep_alive="10m",
                think=False,
                options={"temperature": temperature, "num_predict": max_tokens},
            )
        except Exception as exc:
            raise LLMError(f"Ollama request failed: {type(exc).__name__}") from None
        wall = perf_counter() - started
        prompt = getattr(response, "prompt_eval_count", None)
        output = getattr(response, "eval_count", None)
        duration = getattr(response, "eval_duration", None)
        rate = None
        if output and duration:
            rate = float(output) / (float(duration) / 1_000_000_000)
        return ModelResponse(
            text=(response.message.content or "").strip(),
            wall_seconds=wall,
            prompt_tokens=int(prompt) if prompt is not None else None,
            output_tokens=int(output) if output is not None else None,
            tokens_per_second=rate,
        )

    def close(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None
