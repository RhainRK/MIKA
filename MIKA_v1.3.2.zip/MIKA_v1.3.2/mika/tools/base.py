from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any, Generic, TypeVar

from pydantic import BaseModel, ConfigDict

from ..policy import Permission


class ToolArgs(BaseModel):
    model_config = ConfigDict(extra="forbid")


TArgs = TypeVar("TArgs", bound=ToolArgs)


@dataclass(frozen=True, slots=True)
class ToolCall:
    name: str
    arguments: dict[str, Any]


@dataclass(frozen=True, slots=True)
class ToolResult:
    name: str
    success: bool
    output: Any = None
    error: str | None = None


@dataclass(frozen=True, slots=True)
class ToolDefinition(Generic[TArgs]):
    name: str
    description: str
    args_model: type[TArgs]
    handler: Callable[[TArgs], Any]
    permission: Permission

    def schema(self) -> dict[str, Any]:
        parameters = self.args_model.model_json_schema()
        parameters.pop("title", None)
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": parameters,
                "strict": True,
            },
        }
