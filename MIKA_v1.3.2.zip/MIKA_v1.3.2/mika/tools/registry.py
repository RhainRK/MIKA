from __future__ import annotations

from typing import Any

from pydantic import ValidationError

from ..audit import AuditLog
from ..policy import Policy
from .base import ToolCall, ToolDefinition, ToolResult


class ToolRegistry:
    def __init__(self, policy: Policy, audit: AuditLog) -> None:
        self.policy = policy
        self.audit = audit
        self._tools: dict[str, ToolDefinition[Any]] = {}

    def register(self, tool: ToolDefinition[Any]) -> None:
        if tool.name in self._tools:
            raise ValueError(f"Tool already registered: {tool.name}")
        self._tools[tool.name] = tool

    def schemas(self) -> list[dict[str, Any]]:
        return [
            tool.schema()
            for tool in self._tools.values()
            if self.policy.check(tool.permission).allowed
        ]

    def execute(self, call: ToolCall) -> ToolResult:
        tool = self._tools.get(call.name)
        if tool is None:
            return self._deny(call, "unknown tool")
        decision = self.policy.check(tool.permission)
        if not decision.allowed:
            return self._deny(
                call, f"permission denied: {tool.permission.value} ({decision.reason})"
            )
        try:
            args = tool.args_model.model_validate(call.arguments)
            output = tool.handler(args)
            result = ToolResult(call.name, True, output=output)
            self.audit.record(
                "tool.execute",
                {"tool": call.name, "argument_names": sorted(call.arguments), "success": True},
            )
            return result
        except (ValidationError, ValueError, RuntimeError) as exc:
            result = ToolResult(
                call.name, False, error=type(exc).__name__ + ": tool request failed"
            )
            self.audit.record(
                "tool.execute",
                {
                    "tool": call.name,
                    "argument_names": sorted(call.arguments),
                    "success": False,
                    "error": type(exc).__name__,
                },
            )
            return result
        except Exception as exc:
            message = f"{type(exc).__name__}: tool request failed"
            result = ToolResult(call.name, False, error=message)
            self.audit.record(
                "tool.execute",
                {
                    "tool": call.name,
                    "argument_names": sorted(call.arguments),
                    "success": False,
                    "error": message,
                },
            )
            return result

    def _deny(self, call: ToolCall, error: str) -> ToolResult:
        self.audit.record(
            "tool.denied",
            {"tool": call.name, "argument_names": sorted(call.arguments), "error": error},
        )
        return ToolResult(call.name, False, error=error)
