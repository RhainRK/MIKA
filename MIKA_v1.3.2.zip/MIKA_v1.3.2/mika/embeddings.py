from __future__ import annotations

import hashlib
import re
from collections import OrderedDict
from collections.abc import Iterable
from threading import RLock
from typing import Any

import numpy as np


class Embedder:
    def __init__(self, model_name: str, fallback_dim: int = 384, cache_size: int = 256) -> None:
        self.model_name = model_name
        self.fallback_dim = fallback_dim
        self.cache_size = max(0, cache_size)
        self._model: Any = None
        self._backend: str | None = None
        self._load_error: str | None = None
        self._cache: OrderedDict[tuple[str, str], np.ndarray] = OrderedDict()
        self._lock = RLock()

    @property
    def load_error(self) -> str | None:
        with self._lock:
            self._load()
            return self._load_error

    @property
    def identity(self) -> str:
        with self._lock:
            self._load()
            return (
                self.model_name
                if self._backend == "sentence_transformers"
                else f"hash-v2-{self.fallback_dim}"
            )

    @property
    def backend(self) -> str:
        with self._lock:
            self._load()
            return str(self._backend)

    def _load(self) -> None:
        if self._backend is not None:
            return
        if self.model_name in {"hash", "__force_hash_backend__"}:
            self._backend = "hash"
            return
        try:
            from sentence_transformers import SentenceTransformer

            self._model = SentenceTransformer(
                self.model_name,
                local_files_only=True,
                trust_remote_code=False,
                model_kwargs={"use_safetensors": True},
            )
            self._backend = "sentence_transformers"
        except Exception as exc:
            self._backend = "hash"
            self._load_error = f"{type(exc).__name__}: local semantic model unavailable"

    def _identity_unlocked(self) -> str:
        self._load()
        return (
            self.model_name
            if self._backend == "sentence_transformers"
            else f"hash-v2-{self.fallback_dim}"
        )

    def _cache_get(self, identity: str, text: str) -> np.ndarray | None:
        cached = self._cache.get((identity, text))
        if cached is None:
            return None
        self._cache.move_to_end((identity, text))
        return cached.copy()

    def _cache_put(self, identity: str, text: str, vector: np.ndarray) -> None:
        if self.cache_size == 0 or len(text) > 8192:
            return
        self._cache[(identity, text)] = vector.copy()
        while len(self._cache) > self.cache_size:
            self._cache.popitem(last=False)

    def encode(self, text: str) -> np.ndarray:
        with self._lock:
            identity = self._identity_unlocked()
            cached = self._cache_get(identity, text)
            if cached is not None:
                return cached
            if self._backend == "sentence_transformers":
                vector = np.asarray(
                    self._model.encode(
                        text,
                        convert_to_numpy=True,
                        normalize_embeddings=True,
                        show_progress_bar=False,
                    ),
                    dtype=np.float32,
                )
            else:
                vector = self._hash_encode(text)
            self._cache_put(identity, text, vector)
            return vector.copy()

    def encode_many(self, texts: Iterable[str]) -> list[np.ndarray]:
        values = list(texts)
        if not values:
            return []

        with self._lock:
            identity = self._identity_unlocked()
            output: list[np.ndarray | None] = [None] * len(values)
            missing_indices: list[int] = []
            missing_texts: list[str] = []

            for index, text in enumerate(values):
                cached = self._cache_get(identity, text)
                if cached is None:
                    missing_indices.append(index)
                    missing_texts.append(text)
                else:
                    output[index] = cached

            if missing_texts:
                if self._backend == "sentence_transformers":
                    encoded = np.asarray(
                        self._model.encode(
                            missing_texts,
                            convert_to_numpy=True,
                            normalize_embeddings=True,
                            show_progress_bar=False,
                        ),
                        dtype=np.float32,
                    )
                    vectors = [encoded] if encoded.ndim == 1 else list(encoded)
                else:
                    vectors = [self._hash_encode(text) for text in missing_texts]

                for index, text, vector in zip(
                    missing_indices, missing_texts, vectors, strict=True
                ):
                    item = np.asarray(vector, dtype=np.float32)
                    output[index] = item
                    self._cache_put(identity, text, item)

            return [vector.copy() for vector in output if vector is not None]

    def _hash_encode(self, text: str) -> np.ndarray:
        tokens = re.findall(r"[\w']+", text.casefold(), flags=re.UNICODE)
        features = tokens + [f"{tokens[i]}::{tokens[i + 1]}" for i in range(len(tokens) - 1)]
        vector = np.zeros(self.fallback_dim, dtype=np.float32)
        for feature in features:
            digest = hashlib.blake2b(feature.encode(), digest_size=16).digest()
            for offset in (0, 4):
                index = int.from_bytes(digest[offset : offset + 4], "big") % self.fallback_dim
                vector[index] += 1.0 if digest[offset + 8] & 1 else -1.0
        norm = float(np.linalg.norm(vector))
        if norm:
            vector /= norm
        return vector
