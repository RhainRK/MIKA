# MIKA v1.3.2 - Windows and VS Code setup

This is the replacement for v1.3.0 and v1.3.1. Install it in a new folder. You already have VS Code and Node.js; do not repeat those installations.

## 1. Stop the old version

Go to the terminal running MIKA and press Ctrl+C. Close its browser tab. Keep your old folder as a backup. Do not delete your data.

## 2. Update Python for this new environment

Your earlier output showed Python 3.11.9. For this security-focused installation, use the latest stable Python 3.13 Windows installer from:

https://www.python.org/downloads/windows/

Select Python 3.13, Windows installer (64-bit), not the embeddable package or a prerelease. At review time, Python.org lists 3.13.15. Install for your user account with pip and the Python launcher enabled. Keep your previous Python installation if other projects use it.

Close and reopen VS Code, then check in a PowerShell terminal:

```powershell
py -3.13 --version
```

Expected: Python 3.13.x. MIKA declares Python 3.11+ compatibility; this release was executed here on Linux/Python 3.12.14. Windows/Python 3.13 validation is performed by the local checks below, not claimed to have happened here.

## 3. Extract and open the new project

Extract MIKA_v1.3.2_SECURITY_UPDATE.zip to a NEW folder. Choose File > Open Folder in VS Code and open the inner MIKA_v1.3.2 folder containing pyproject.toml, main.py, mika, dashboard and samples.

Do not merge the ZIP into your old installation. Do not copy the old .venv, node_modules, .env or dashboard/dist.

Open Terminal > New Terminal and use PowerShell. Run each command separately; wait for the prompt to return before the next command. If a command fails, stop and share the error without passwords.

## 4. Create the environment and install

```powershell
py -3.13 -m venv .venv
```

```powershell
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools
```

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[server]"
```

```powershell
.\.venv\Scripts\mika.exe --version
```

Expected: MIKA 1.3.2. You do not need to activate the environment or change PowerShell execution policy. Ctrl+Shift+P > Python: Select Interpreter > choose this project's .venv.

Run the publication check now, before creating local runtime data:

```powershell
.\.venv\Scripts\python.exe scripts\release_check.py
```

Expected: release check passed. This scans for selected secrets and generated files; it is not a complete security audit.

## 5. Build the dashboard

```powershell
cd dashboard
```

```powershell
npm.cmd ci --ignore-scripts
```

```powershell
npm.cmd run typecheck
```

```powershell
npm.cmd run build
```

```powershell
npm.cmd audit
```

```powershell
cd ..
```

The npm lockfile makes the dashboard dependency install repeatable. Installation/audit commands use the internet. Normal dashboard use does not require external browser scripts.

## 6. Validate this computer's installation

Install the test/audit tools:

```powershell
.\.venv\Scripts\python.exe -m pip install "pytest>=9,<10" "pytest-cov>=7,<8" "httpx>=0.28,<1" pip-audit
```

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

```powershell
.\.venv\Scripts\python.exe -m pip_audit
```

The release has 79 tests before any later additions. On a Windows account that cannot create symlinks, the symlink test can be skipped explicitly. If tests fail or the audit reports vulnerabilities, send the output before putting private data into MIKA. Dependency checks cover your actual resolved packages; they do not audit Windows, Python's native runtime or Ollama binaries.

## 7. Load the sample data and evaluate

You previously loaded only the bundled samples, so a fresh index is simplest:

```powershell
.\.venv\Scripts\mika.exe doctor
```

```powershell
.\.venv\Scripts\mika.exe ingest samples\benchmark_evidence.txt
```

```powershell
.\.venv\Scripts\mika.exe ingest samples\operations_incidents.csv
```

```powershell
.\.venv\Scripts\mika.exe evaluate --repeats 20
```

```powershell
.\.venv\Scripts\mika.exe search "reconciliation anomaly"
```

The default embedding backend is hash: deterministic, offline retrieval with lower semantic capability than a trained model. Evaluation should report status passed. These are synthetic regression tests, not proof of production accuracy.

## 8. Start MIKA

```powershell
.\.venv\Scripts\mika.exe serve --host 127.0.0.1 --port 8000
```

The terminal prints:

- Local browser login: username mika
- Session password: a newly generated password

Open a private/incognito browser window and TYPE this address into its address bar:

```text
http://127.0.0.1:8000
```

Enter username mika and the password shown in the terminal. Do not post the password or include it in screenshots. It changes every server start. Keep the terminal open; Ctrl+C stops MIKA and revokes that password.

Typing the address avoids a cross-site navigation from another website, which the browser-access checks may reject. The /docs endpoint is intentionally disabled.

## 9. Confirm the listener and login requirement

Open a second VS Code terminal while the server runs:

```powershell
Get-NetTCPConnection -LocalPort 8000 -State Listen | Select-Object LocalAddress,LocalPort
```

Expected for this launch: 127.0.0.1, port 8000. If another listener appears, stop and inspect it; do not open firewall ports or set up router forwarding/tunnels.

```powershell
curl.exe --silent --output NUL --write-out "%{http_code}" http://127.0.0.1:8000/api/health
```

Expected: 401, because this request has no login. Repeated attempts can return 429; wait a few seconds.

## Next time

Open the new project folder and run only the command in step 8. Use a fresh private browser window and the new password. Rebuild the dashboard only when its source/dependencies change.

## Keeping existing real data

Do this only if you have real cases beyond the samples. Stop every old MIKA process, keep a backup, and copy the complete old data folder into the new project before ingesting anything. Copy evidence files with their relative paths. The database schema is unchanged. Run audit-verify afterwards.

If the old index used a semantic model, keep the same trusted local model configuration or rebuild a separate index; do not mix embedding backends. Old logs may contain information the newer code would now redact. Upgrading does not erase or encrypt them. Keep old folders private.

## Optional local model

First finish and verify the core setup. You do not need Ollama for the dashboard or evaluation.

The model endpoint must now be a literal loopback IP, normally http://127.0.0.1:11434. Remote URLs and localhost hostnames are rejected; redirects and environment proxies are disabled. Use a locally downloaded model: a separate local model server could still forward requests to a cloud provider if configured to do so. An installed local model can be used after installing the llm extra and auditing the resulting environment. The separate Ollama application/model files were not audited in this review.

Semantic models are opt-in. MIKA no longer downloads them automatically: it requires locally available files, disables remote model code and requests safetensors weights. If loading fails it reports a hash fallback. Optional semantic packages and model weights are outside the dependency audit in this delivery.

## What security means here

This is a local, single-user research tool. The browser password and loopback checks are not an internet-hosting solution. Local malware, administrator access, malicious browser extensions, stolen user-account access and unpatched OS/runtime vulnerabilities remain outside MIKA's control. Stored data is not encrypted by the application.

Keep your OS, browser and Python maintained. Use sample/public data until your local tests pass. Package installation, vulnerability checks and explicitly requested public-data downloads contact external services, which can see your connection's public IP. Default hash retrieval does not need internet access. The local dashboard does not publish itself online.
