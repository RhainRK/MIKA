# MIKA v1.5.0 upgrade

Install v1.5.0 in a new folder.

Keep the old folder until the new build is verified.

Copy only the `data` folder while both versions are stopped.

Then run:

```powershell
.\.venv\Scripts\mika.exe doctor
.\.venv\Scripts\mika.exe audit-verify
.\.venv\Scripts\mika.exe backup
```
