# MIKA v1.5.0 security review

## Changes

- Removed dynamic SQL assembly from selected-evidence retrieval.
- IDs are passed through SQLite parameters and `json_each`.
- Existing loopback-only HTTP controls remain in place.
- Tool execution remains default-deny.
- Workspace path controls remain enabled.
- Prompt-injection quarantine remains enabled.
- Audit-chain verification remains enabled.

## Validation

- 121 tests passed.
- Dashboard typecheck/build passed.
- Release check passed.
- Python compile passed.

Run `pip-audit`, Bandit, Ruff, mypy and `npm audit` on the target machine after install.

## Boundary

MIKA is a local single-user tool. Do not expose it to the public internet. Local files are not protected from a compromised OS account or administrator.
