# MIKA v1.5.0

## Changes

- Python 3.13+ baseline.
- Python 3.14-ready dependency/tooling config.
- Fully parameter-bound selected-evidence SQL filters.
- Windows SQLite regression fix.
- Cleaner FastAPI query definitions.
- Updated CI for Python 3.13 and 3.14.
- `httpx2` test dependency for current Starlette TestClient.
- Ruff cleanup across source and tests.
- Shorter code comments and setup docs.

## Validation

- 121 Python tests passed.
- Branch-aware coverage: 88.18%.
- Dashboard typecheck passed.
- Dashboard build passed.
- Release check passed.
- Python source/test compile passed.
