# MIKA v1.5.0 setup

## Requirements

- Python 3.13+
- Node.js 22+
- Ollama only for local LLM use

## Install

```powershell
py -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip setuptools
.\.venv\Scripts\python.exe -m pip install -e ".[server]"
.\.venv\Scripts\mika.exe --version
```

Expected: `MIKA 1.5.0`

## Dashboard

```powershell
cd dashboard
npm.cmd ci --ignore-scripts
npm.cmd run typecheck
npm.cmd run build
npm.cmd audit
cd ..
```

## Check

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[dev,server]"
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\ruff.exe check .
.\.venv\Scripts\mypy.exe mika
.\.venv\Scripts\bandit.exe -r mika
.\.venv\Scripts\python.exe -m pip_audit
.\.venv\Scripts\python.exe scripts\release_check.py
```

## Sample data

```powershell
.\.venv\Scripts\mika.exe ingest samples\benchmark_evidence.txt
.\.venv\Scripts\mika.exe ingest samples\operations_incidents.csv
.\.venv\Scripts\mika.exe evaluate --repeats 20
```

## Run

```powershell
.\.venv\Scripts\mika.exe serve --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`.

Username: `mika`

Password: printed in the terminal.

## Local LLM

```powershell
.\.venv\Scripts\python.exe -m pip install -e ".[llm]"
ollama pull qwen3.5:4b
```

Keep MIKA local. Do not expose port 8000 publicly.
